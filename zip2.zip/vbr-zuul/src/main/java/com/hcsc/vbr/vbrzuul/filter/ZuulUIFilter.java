package com.hcsc.vbr.vbrzuul.filter;

import static org.springframework.cloud.netflix.zuul.filters.support.FilterConstants.POST_TYPE;

import org.springframework.stereotype.Component;

import com.netflix.zuul.ZuulFilter;
import com.netflix.zuul.exception.ZuulException;

@Component
public class ZuulUIFilter extends ZuulFilter
{

    @Override
    public boolean shouldFilter()
    {
        return false;
    }

    //For the angular app, always send to /view/ to root, which maps to index.html
    @Override
    public Object run() throws ZuulException
    {
        return null;
    }

    @Override
    public String filterType()
    {
        return POST_TYPE;
    }

    @Override
    public int filterOrder()
    {
        return 30;
    }
}
