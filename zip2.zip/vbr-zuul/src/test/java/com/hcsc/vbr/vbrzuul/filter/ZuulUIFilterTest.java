package com.hcsc.vbr.vbrzuul.filter;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.springframework.cloud.netflix.zuul.filters.support.FilterConstants.PROXY_KEY;
import static org.springframework.cloud.netflix.zuul.filters.support.FilterConstants.REQUEST_URI_KEY;

import org.junit.Test;

import com.netflix.zuul.context.RequestContext;
import com.netflix.zuul.exception.ZuulException;

public class ZuulUIFilterTest
{

    ZuulUIFilter filter = new ZuulUIFilter();

    @Test
    public void shouldFilterTest()
    {

        RequestContext context = RequestContext.getCurrentContext();

        context.set( PROXY_KEY,
                     "labor-fund-hub-ui" );
        boolean shouldFilter = filter.shouldFilter();
        assertFalse( shouldFilter );

        context.set( PROXY_KEY,
                     "anything" );
        shouldFilter = filter.shouldFilter();
        assertFalse( shouldFilter );

        context.set( PROXY_KEY,
                     null );
        shouldFilter = filter.shouldFilter();
        assertFalse( shouldFilter );
    }

    @Test
    public void runTestUnModifiedURL() throws ZuulException
    {

        RequestContext context = RequestContext.getCurrentContext();

        context.set( REQUEST_URI_KEY,
                     "/service1/anything" );
        filter.run();
        assertEquals( "/service1/anything",
                      context.get( REQUEST_URI_KEY ) );
    }

    @Test
    public void runTestModifiedURL() throws ZuulException
    {

        RequestContext context = RequestContext.getCurrentContext();

        context.set( REQUEST_URI_KEY,
                     "/service1/view/" );
        filter.run();
        assertEquals( "/service1/view/",
                      context.get( REQUEST_URI_KEY ) );
    }

    @Test
    public void filterTypeTest()
    {

        assertEquals( "post",
                      filter.filterType() );
    }

    @Test
    public void filterOrderTest()
    {

        assertEquals( 30,
                      filter.filterOrder() );
    }
}
