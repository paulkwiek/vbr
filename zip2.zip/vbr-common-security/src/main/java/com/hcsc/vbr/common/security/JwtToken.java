package com.hcsc.vbr.common.security;

import java.io.Serializable;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.oauth2.common.exceptions.InvalidTokenException;
import org.springframework.stereotype.Component;

import com.nimbusds.jose.JOSEException;
import com.nimbusds.jose.crypto.RSASSAVerifier;
import com.nimbusds.jwt.JWTClaimsSet;
import com.nimbusds.jwt.SignedJWT;

@Component
public class JwtToken implements Serializable
{

    private static final long serialVersionUID = -3301605591108950415L;
    private static final String CLAIM_KEY_ROLES = "hcsc_private_claims";

    @Autowired
    RSASSAVerifier rsaVerifier;

    //build roles based on the JWT token, in this case, permissions is the key 
    private List<GrantedAuthority> getRoles( JWTClaimsSet claimsSet )
    {
        String jsonString = claimsSet.getClaims().get( CLAIM_KEY_ROLES ).toString();
        List<GrantedAuthority> roles = new ArrayList<>();
        try
        {
            JSONObject json = new JSONObject( jsonString );
            String rolesString = json.getString( "roles" );
            String[] rolesArr = rolesString.split( ";" );
            for( int i = 0; i < rolesArr.length; i++ )
            {
                roles.add( new SimpleGrantedAuthority( rolesArr[i] ) );
            }
        }
        catch( JSONException e )
        {
            throw new InvalidTokenException( "roles in jwt were not in the right format" );
        }
        return roles;
    }

    public JWTClaimsSet validateToken( String jwtToken )
    {
        SignedJWT stsJWT = null;
        JWTClaimsSet claimsSet = null;

        try
        {
            stsJWT = SignedJWT.parse( jwtToken );

            if( !stsJWT.verify( rsaVerifier ) )
                throw new InvalidTokenException( "The JWT token from the auth service could not be verified, invalid token" );
            if( stsJWT.getJWTClaimsSet().getExpirationTime().getTime() < new Date().getTime() )
                throw new InvalidTokenException( "The JWT token from the auth service has expired" );
            claimsSet = stsJWT.getJWTClaimsSet();
        }
        catch( ParseException e )
        {
            throw new InvalidTokenException( "Could not parse token, invalid token" );
        }
        catch( JOSEException e )
        {
            throw new InvalidTokenException( "Could validate token" + e.getMessage() );
        }
        return claimsSet;

    }

    public JwtUser getUserFromToken( String token )
    {
        JWTClaimsSet claimsSet = validateToken( token );
        return new JwtUser( claimsSet.getSubject(),
                            null,
                            getRoles( claimsSet ),
                            true );
    }

}