package com.hcsc.vbr.common.security;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.authentication.SimpleUrlAuthenticationFailureHandler;

public class JwtAuthenticationFailureHandler extends SimpleUrlAuthenticationFailureHandler{

	@Override
	public void onAuthenticationFailure(HttpServletRequest request, HttpServletResponse response,
			AuthenticationException exception) throws IOException, ServletException {
		if(exception.getClass().isAssignableFrom(JwtTokenException.class)){
			//set this so it is not using session
			setUseForward(true);
			//pass the expired token back to the request
			setDefaultFailureUrl("/expire?token=" + request.getHeader("Authorization"));
		}
		super.onAuthenticationFailure(request, response, exception);
		
	}

}
