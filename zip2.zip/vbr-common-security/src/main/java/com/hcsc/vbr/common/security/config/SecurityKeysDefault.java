package com.hcsc.vbr.common.security.config;

import java.io.IOException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.security.interfaces.RSAPublicKey;
import java.security.spec.InvalidKeySpecException;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.core.io.ClassPathResource;

import com.nimbusds.jose.crypto.RSASSAVerifier;

@Configuration
@ConfigurationProperties
@Profile("default")
public class SecurityKeysDefault {

    @Value("${laborfund.sts.layer7.cert}") 
    String layer7Cert;
	
	@Bean
	public RSASSAVerifier rsaVerifier() throws NoSuchAlgorithmException, InvalidKeySpecException, IOException, CertificateException 
	{
		return new RSASSAVerifier(publicKey());
	}
	
	private RSAPublicKey publicKey() throws NoSuchAlgorithmException, InvalidKeySpecException, IOException, CertificateException {
	    ClassPathResource resource = new ClassPathResource(layer7Cert);
	    
	    CertificateFactory cf = CertificateFactory.getInstance("X.509");
	    X509Certificate cert = (X509Certificate)cf.generateCertificate(resource.getInputStream());
	    return (RSAPublicKey)cert.getPublicKey();
	}		

}