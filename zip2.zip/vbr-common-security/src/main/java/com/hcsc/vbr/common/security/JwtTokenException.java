package com.hcsc.vbr.common.security;

import org.springframework.security.core.AuthenticationException;

public class JwtTokenException extends AuthenticationException{
    private static final long serialVersionUID = 1L;
    private final String msg;
    public JwtTokenException(String msg) {
        super(msg);
        this.msg = msg;
    }
    public String getMsg() {
        return msg;
    }

}
