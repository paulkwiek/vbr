package com.hcsc.vbr.common.security.config;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.security.interfaces.RSAPublicKey;
import java.security.spec.InvalidKeySpecException;
import java.util.Base64;
import java.util.regex.Pattern;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;

import com.nimbusds.jose.crypto.RSASSAVerifier;

@Configuration
@ConfigurationProperties
@Profile("!default")
public class SecurityKeys {

    @Value("${sts-public-cert}") 
    String stsPublicKey;

	@Bean
	public RSASSAVerifier rsaVerifier() throws NoSuchAlgorithmException, InvalidKeySpecException, IOException, CertificateException 
	{
		return new RSASSAVerifier(publicKey());
	}
	
	private RSAPublicKey publicKey() throws NoSuchAlgorithmException, InvalidKeySpecException, IOException, CertificateException {
	    CertificateFactory cf = CertificateFactory.getInstance("X.509");
	    X509Certificate cert = (X509Certificate)cf.generateCertificate(new ByteArrayInputStream(loadPEM(stsPublicKey)));
	    
	    return (RSAPublicKey)cert.getPublicKey();
	}		

	private byte[] loadPEM(String resource) throws IOException {
	    Pattern parse = Pattern.compile("(?m)(?s)^---*BEGIN.*---*$(.*)^---*END.*---*$.*");
		String encoded = parse.matcher(resource).replaceFirst("$1");
	    
	    return Base64.getMimeDecoder().decode(encoded);
	}
}