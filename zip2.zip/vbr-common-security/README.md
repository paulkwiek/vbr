# Spring Security in VBR
## Steps

* Add dependency to POM
```xml
    <dependency>
        <groupId>com.hcsc.vbr</groupId>
        <artifactId>vbr-common-security</artifactId>
        <version>0.0.1-SNAPSHOT</version>
    </dependency>
```

* Add the following java class to config of project
```java
package com.hcsc.vbr.security.config;

import java.util.Arrays;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.ProviderManager;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

import com.hcsc.vbr.common.security.JwtAuthenticationEntryPoint;
import com.hcsc.vbr.common.security.JwtAuthenticationFailureHandler;
import com.hcsc.vbr.common.security.JwtAuthenticationProvider;
import com.hcsc.vbr.common.security.JwtAuthenticationSuccessHandler;
import com.hcsc.vbr.common.security.JwtAuthenticationTokenFilter;


@Configuration
@EnableGlobalMethodSecurity(prePostEnabled=true)
public class WebSecurityConfig extends WebSecurityConfigurerAdapter {

    @Autowired
    private JwtAuthenticationEntryPoint unauthorizedHandler;

    @Autowired
    private JwtAuthenticationProvider authenticationProvider;

    @Bean
    @Override
    public AuthenticationManager authenticationManager() throws Exception {
        return new ProviderManager(Arrays.asList((AuthenticationProvider)authenticationProvider));
    }
    @Bean
    public JwtAuthenticationTokenFilter authenticationTokenFilterBean() throws Exception {
    	JwtAuthenticationTokenFilter authenticationTokenFilter = new JwtAuthenticationTokenFilter();
        authenticationTokenFilter.setAuthenticationManager(authenticationManager());
        authenticationTokenFilter.setAuthenticationSuccessHandler(new JwtAuthenticationSuccessHandler());
        authenticationTokenFilter.setAuthenticationFailureHandler(new JwtAuthenticationFailureHandler());
        return authenticationTokenFilter;
    }

    //tell spring security to ignore this url, as this handles JWT token expire HTTP status code
    //for complex pattern matching, use regexMatchers instead of antMachers
    @Override
	public void configure(WebSecurity web) throws Exception {
    	web.ignoring().regexMatchers("/expire\\?token.*");
    }

    @Override
    protected void configure(HttpSecurity httpSecurity) throws Exception {
        httpSecurity
                .csrf().disable()
        		
                .exceptionHandling().authenticationEntryPoint(unauthorizedHandler).and()

                // don't create session
                .sessionManagement().sessionCreationPolicy(SessionCreationPolicy.STATELESS).and()
                .authorizeRequests()
	            	.mvcMatchers("/alerts/admin","/tpas/admin").hasAuthority("SCPH HCSC Admin User")
	            	.mvcMatchers("/alerts/authorized","/tpas/authorized").hasAuthority("SCPH Fund Basic User")
	            	.mvcMatchers("/alerts","/tpas").hasAnyAuthority("SCPH HCSC Basic User", "SCPH HCSC Admin User", "SCPH HCSC Account Mgmt User")
                	.anyRequest().denyAll();

        // Custom JWT based security filter
        httpSecurity
                .addFilterBefore(authenticationTokenFilterBean(), UsernamePasswordAuthenticationFilter.class);

        // disable page caching
        httpSecurity.headers().cacheControl();
    }
}
```
* Change the mvcMatchers to match the Rest endpoints in the controllers of the project.  The Authorities are the roles directly out of LDAP.

