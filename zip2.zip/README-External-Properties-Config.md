# Externalizing Configurations Table of Contents

  * [Topics Covered](#topics-covered)
  * [Installing Vault](#installing-vault)
  * [Using Vault Sever (For Secured Properties)](#using-vault-sever--for-secured-properties-)
  * [What is Config Server](#what-is-config-server)
  * [Config Server in PCF](#config-server-in-pcf)
  * [Schematic Representation](#schematic-representation)
  * [Using Config Server Locally](#using-config-server-locally)
  * [Creating Config Server in PCF](#creating-config-server-in-pcf)
    + [Understanding the JSON used for the service creation](#understanding-the-json-used-for-the-service-creation)
      - [uri](#uri)
      - [privateKey](#privatekey)
      - [searchPaths](#searchpaths)
      - [label](#label)
      - [encrypt.key](#encryptkey)
    + [Screenshots](#screenshots)
      - [Success](#success)
      - [No Encryption Key](#no-encryption-key)
    + [Troubleshooting Issues](#troubleshooting-issues)
  * [Encrypting Values using Config Server Endpoint](#encrypting-values-using-config-server-endpoint)
    + [Identify the Config Server Endpoint](#identify-the-config-server-endpoint)
    + [Get Oauth Token](#get-oauth-token)
    + [Make a POST call using SOAP-UI or POSTMAN](#make-a-post-call-using-soap-ui-or-postman)
      - [Header](#header)
      - [Body](#body)
      - [Response](#response)
  * [Storing Encrypted Values in GitHub](#storing-encrypted-values-in-github)
  * [Decrypting Values using Config Server Endpoint](#decrypting-values-using-config-server-endpoint)
  * [Decrypting Values](#decrypting-values)
  * [Application Changes required for Consuming properties from Config Server (Client Implementation)](#application-changes-required-for-consuming-properties-from-config-server--client-implementation-)
    + [Pre-requisite Reading](#pre-requisite-reading)
  * [Code Changes](#code-changes)
    + [Add Dependencies in `pom.xml`](#add-dependencies-in--pomxml-)
      - [spring-cloud-services-starter-config-client](#spring-cloud-services-starter-config-client)
      - [spring-security-rsa](#spring-security-rsa)
      - [spring-cloud-starter-bus-amqp](#spring-cloud-starter-bus-amqp)
    + [Add `@RefreshScope` to all classes that use `@Value`](#add---refreshscope--to-all-classes-that-use---value-)
    + [Manifest File Changes](#manifest-file-changes)
  * [Refreshing Properties](#refreshing-properties)
    + [Single Instance Applications](#single-instance-applications)
    + [Multiple Instance Applications](#multiple-instance-applications)
  * [Adding new property file based on environment in Git repo](#adding-new-property-file-based-on-environment-in-git-repo)
    + [Important Notes regarding Property Files in the GitHub Repo](#important-notes-regarding-property-files-in-the-github-repo)
  * [Common Properties in Config Server](#common-properties-in-config-server)
- [Using User Provided Service (For properties shared by multiple Applications)](#using-user-provided-service--for-properties-shared-by-multiple-applications-)

## Topics Covered

- Loading secure environment properties from Vault server (This works only in local as of August 2018)
- Loading version controlled properties from GitHub using Config Server
- Loading properties from User Provided Services

## Installing Vault
Use the below link to download and install the Vault Server:

https://www.vaultproject.io/downloads.html

## Using Vault Sever (For Secured Properties)
**_All sensitive properties need to be stored in the vault_**. 

###Local Development
We will not use the vault for local development so all properties need to be put into application.properties.

This property needs to be set in the bootstrap.properties file.
spring.cloud.vault.enabled=false

###PCF
Follow this document to install the PCF service, bind applications, and put entries in the vault.
http://docs.cfaa.hcsc.net/developing/using-vault-for-secrets/

NOTE***
* The location of the vault backends can be found when browsing the environment variables of a bound application.  We will be using the 'space' scoped vault as noted by this property: spring.cloud.vault.generic.backend=${vcap.services.vault.credentials.backends_shared.space}
* Spring looks in the following locations for properties when the 'cloud' profile and the 'dev' profile are active for the application with a spring.application.name=vbr-test  These are the locations available to put properties in for each application.
  * ${vcap.services.vault.credentials.backends_shared.space}secret/vbr-test/cloud
    * Use this location for properties that are specific to the vbr-test application, but do not vary by environment.  These properties will only be used by applications running on PCF, not local applications.
  * ${vcap.services.vault.credentials.backends_shared.space}vbr-test/dev
    * Use this location for properties that are specific to the vbr-test application, but vary by environment.
  * ${vcap.services.vault.credentials.backends_shared.space}vbr-test
    * Could be used for properties that are specific to the vbr-test application and apply to both local development and cloud development that do not vary by environment.  Since we are not configured to use the vault locally, these do not apply.
  * ${vcap.services.vault.credentials.backends_shared.space}application/cloud 
    * Use this location for properties that apply to all applications in this space but do NOT vary by environment.  These properties will only be used by applications running on PCF, not local applications.
  * ${vcap.services.vault.credentials.backends_shared.space}application/dev
    * Use this location for properties that apply to all applications in this space but vary by environment.
  * ${vcap.services.vault.credentials.backends_shared.space}application
    * Could be used for properties that are generic to all applications and apply to both local development and cloud development that do not vary by environment.  Since we are not configured to use the vault locally, these do not apply.
    
* Change the appropriate manifest file to bind to the vault service.

Set the following properties in the bootstrap-cloud.properties file of the service connecting to the vault:
spring.cloud.vault.enabled=true

Add the following dependencies to allow the app to pick up the properties from PCF
		  <dependency>
		    <groupId>io.pivotal.spring.cloud</groupId>
		    <artifactId>spring-cloud-vault-connector-core</artifactId>
		    <version>2.0.0.RELEASE</version>
		  </dependency>
		
		  <dependency>
		    <groupId>io.pivotal.spring.cloud</groupId>
		    <artifactId>spring-cloud-vault-spring-connector</artifactId>
		    <version>2.0.0.RELEASE</version>
		  </dependency>
		
		  <!-- If you intend to deploy the app on CloudFoundry, add the following -->
		  <dependency>
		    <groupId>io.pivotal.spring.cloud</groupId>
		    <artifactId>spring-cloud-vault-cloudfoundry-connector</artifactId>
		    <version>2.0.0.RELEASE</version>
		  </dependency>
 		<dependency>

## What is Config Server
Spring Cloud Config provides server and client-side support for externalized configuration in a distributed system. With the Config Server you have a central place to manage external properties for applications across all environments.

Further Reading - https://cloud.spring.io/spring-cloud-config/

## Config Server in PCF
Documentation - https://docs.pivotal.io/spring-cloud-services/2-0/common/config-server/index.html

## Schematic Representation

![alt text](docs/images/config-server-fig1.png)

## Using Config Server Locally

We have the config server disabled for local development by setting spring.cloud.config.enabled=false in the bootstrap.properties file.

All properties needed for local development will be put in the application.properties file of the appropriate project.

## Creating Config Server in PCF

To create Config Server service instance through command prompt, use the below command

Here are more detailed [insctructions](http://hcsc-cookbook.cfaa.hcsctest.net/recipes/config/)
* VERY IMPORTANT
    * The instructions say to use private-key in the json, the correct key is privateKey
    * After the "-----BEGIN PRIVATE KEY-----" in the private key pasted in the json, there MUST be a "\n" after it.  Looks like this: "-----BEGIN PRIVATE KEY-----\n......"

### Understanding the JSON used for the service creation

Config server service instance takes json input which can have the below configurations

#### uri
The URL to the GitHub repo which has the properties

#### privateKey
The key used to transact with the GitHub Repo. **_This should be sourced only from DevOps/Security Team_**

#### searchPaths
The folder in which the properties are kept (if you have multiple folders). This is optional

#### label
The branch which you want to use in the GitHub Repo

#### encrypt.key
- Any values that need encryption are sensitive in nature and should not be stored in the properties files, they should be stored in the HashiCorp Vault

> **Note** There could be many other configurations that the JSON can take. These are not discussed as they are not in scope for this requirement.

### Screenshots

#### Success 
If your Config Server has been created successfully, this is how you would see the Screen:

![alt text](docs/images/config-server-in-pcf-online.jpg)

### Troubleshooting Issues

In your JSON file created for passing to the Config Server Service, ensure that

- The GIT `uri` is correct
- `searchpaths` refers to an available folder in the repo
- `label` refers to the mapped branch in the repo. Only properties file in this branch will be used for Dependency Injection
- Your private key has close to 3k characters
- You have removed all line breaks (and replaced them with `\n`) from your private key when putting it in the JSON

If it still doesn't work, contact Framework Team!

## Application Changes required for Consuming properties from Config Server (Client Implementation)

### Pre-requisite Reading

http://cloud.spring.io/spring-cloud-config/single/spring-cloud-config.html

## Code Changes

### Add Dependencies in `pom.xml`

```
		<dependency>
			<groupId>org.springframework.cloud</groupId>
			<artifactId>spring-cloud-starter-config</artifactId>
		</dependency>
    
    <dependency>
        <groupId>org.springframework.cloud</groupId>
        <artifactId>spring-cloud-starter-bus-amqp</artifactId>
    </dependency>
```

#### spring-cloud-services-starter-config-client
This is required for the application to know that it is the (config) client who will consume (properties) from the (config) server

#### spring-cloud-starter-bus-amqp
This is required for refreshing multiple instances of an application in one go


### Add `@RefreshScope` to all classes that use `@Value`
Refresh scope beans are lazy proxies that initialize when they are used (i.e. when a method is called), and the scope acts as a cache of initialized values. To force a bean to re-initialize on the next method call you just need to invalidate its cache entry.

The RefreshScope is a bean in the context and it has a public method refreshAll() to refresh all beans in the scope by clearing the target cache. There is also a refresh(String) method to refresh an individual bean by name. This functionality is exposed in the /refresh endpoint (over HTTP or JMX).


### Manifest File Changes

- Bind the `config-server` service
- Bind the `rabbit-mq` service

> **Note** Creating the `rabbit-mq` service is a straight forward process. The PCG UI (apps manager) can be used to create the service by selecting all default values. **No special/additional configurations required**. Nothing special required to be done for creating this service from market place.

## Refreshing Properties 

### Single Instance Applications

The properties files are now going to reside in an external isolated GitHub repo and not in the resources folder of the application. Hence any changes required to application properties have to be done in the GitHub repo for that application.

The property management.endpoints.web.exposure.include=refresh must be included in the correct bootstrap properties file to expose this endpoint.

Use the below command in POSTMAN to load the updated properties from git repo through refresh endpoint:

**Syntax**
```
THE_ENTIRE_URL_OF_THE_APP_AS_IN_PCF/actuator/refresh
```

**Example**
```
https://vbr-ui.cfaa.hcsctest.net/actuator/refresh
```

### Multiple Instance Applications

When we introduce the rabbit dependency, the client will have another endpoint ‘actuator/bus-refresh’. Calling this endpoint will do the following:

- Get the latest configuration from the config server and update its configuration annotated by @RefreshScope

- Send a message to AMQP exchange informing about refresh event

- All subscribed nodes will update their configuration as well

This way, we don’t need to go to individual nodes and trigger configuration update.

The property management.endpoints.web.exposure.include=bus-refresh must be included in the correct bootstrap properties file to expose this endpoint.

Use the below command in POSTMAN to load the updated properties from git repo through refresh endpoint:

**Syntax**
```
THE_ENTIRE_URL_OF_THE_APP_AS_IN_PCF/actuator/bus-refresh
```

**Example**
```
https://vbr-ui.cfaa.hcsctest.net/actuator/bus-refresh
```

## Adding new property file based on environment in Git repo
1) Multiple property files can be placed in the git repo of config server, so that the app can refer to the particular file based on environment (such as dev, uat, prod). Spring profiles are used to identify/configure environments.

2) Create a new property file in the directory of the git repo corresponding to the spring.application.name of the application **config/_configClient_** E.g.: config/vbr-ui. Name of the .property file should follow the naming convention as **application-ENVIRONMENT.properties** E.g.: application-dev.properties

where
- **_configClient_** is the name of the application as defined in application.properties file in the application
- **_dev_** is a valid spring profile in the application

3) We have to mention the environment of the application using 'spring.profiles.active' tag in manifest.yml file. For example **_env: SPRING_PROFILES_ACTIVE: dev_**

### Important Notes regarding Property Files in the GitHub Repo

- The folder name of the property file should be same as application name of that application as defined in bootstrap or application properties files

- The config server in PCF is configured to look in a directory that's named after the spring application name.

- Properties based on environment are identified and resolved following the convention discussed earlier i.e. `application-environment.properties` where environment should be mapped to a defined spring profile.

## Common Properties in Config Server
- Some scenarios require applications to share same properties across profiles. There are multiple ways to achieve this

- Similarly if multiple applications want to share the same properties across profiles that can also be resolved easily

> **Note** The RIs/approaches for Common Properties are not discussed in this document and RI as they have to be tailored based on requirements. Please talk to framework team for specifics on this.

# Using User Provided Service (For properties shared by multiple Applications)
Create a UPS in PCF console and add the values there. These can be accessed using VCAP variables in the application.
