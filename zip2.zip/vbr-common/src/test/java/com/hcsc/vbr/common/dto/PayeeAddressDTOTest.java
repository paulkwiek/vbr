package com.hcsc.vbr.common.dto;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class PayeeAddressDTOTest
{
    private PayeeAddressDTO payeeAddressDTO;

    @Before
    public void setUp()
    {
        payeeAddressDTO = new PayeeAddressDTO();
    }

    @Test
    public void testPayeeAddress()
    {
        payeeAddressDTO.setAddressLine1( "ADDL1" );
        payeeAddressDTO.setAddressLine2( "ADDL2" );
        payeeAddressDTO.setCity( "EAGLE WAY" );
        payeeAddressDTO.setState( "CHICAGO" );
        payeeAddressDTO.setZipCode( "606781095" );

        Assert.assertTrue( payeeAddressDTO != null );
        Assert.assertEquals( "ADDL1",
                             payeeAddressDTO.getAddressLine1() );
        Assert.assertEquals( "ADDL2",
                             payeeAddressDTO.getAddressLine2() );
        Assert.assertEquals( "EAGLE WAY",
                             payeeAddressDTO.getCity() );
        Assert.assertEquals( "CHICAGO",
                             payeeAddressDTO.getState() );
        Assert.assertEquals( "606781095",
                             payeeAddressDTO.getZipCode() );
        Assert.assertTrue( payeeAddressDTO.toString().contains( "city=EAGLE WAY" ) );
    }
}
