package com.hcsc.vbr.common.dto;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class CodeSetValueDTOTest
{
    private CodeSetValueDTO codeSetValueDTO;

    @Before
    public void setUp()
    {
        codeSetValueDTO = new CodeSetValueDTO();
    }

    @Test
    public void testCodeSetValue()
    {
        codeSetValueDTO.setCodeSetName( "CD_NAME" );
        codeSetValueDTO.setCodeValueDescription( "CD_VALUE_DESC" );
        codeSetValueDTO.setCodeSetDescription( "CODE_DESC" );
        codeSetValueDTO.setCodeValueText( "TEXT" );
        codeSetValueDTO.setCorporateEntityCode( "NM1" );

        Assert.assertTrue( codeSetValueDTO != null );
        Assert.assertEquals( "CD_NAME",
                             codeSetValueDTO.getCodeSetName() );
        Assert.assertEquals( "CD_VALUE_DESC",
                             codeSetValueDTO.getCodeValueDescription() );
        Assert.assertEquals( "CODE_DESC",
                             codeSetValueDTO.getCodeSetDescription() );
        Assert.assertEquals( "TEXT",
                             codeSetValueDTO.getCodeValueText() );
        Assert.assertEquals( "NM1",
                             codeSetValueDTO.getCorporateEntityCode() );

    }
}
