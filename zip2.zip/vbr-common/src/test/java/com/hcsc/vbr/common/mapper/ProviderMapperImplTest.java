package com.hcsc.vbr.common.mapper;

import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.Test;

import com.hcsc.vbr.common.dto.PayToPFINPayeeAddressDTO;
import com.hcsc.vbr.common.dto.PayeeAddressDTO;
import com.hcsc.vbr.web.response.ProviderAPIResponseDTO;
import com.hcsc.vbr.web.response.ProviderAPISearchResponseDTO;
import com.hcsc.vbr.web.response.ProviderApiAddressDTO;

public class ProviderMapperImplTest
{
    @Test
    public void testToProviderAPIResponseDTO()
    {
        ProviderAPIResponseDTO providerAPIResponseDTO =
            ProviderMapper.INSTANCE.toProviderAPIResponseDTO( getProviderAPISearchResponseDTO() );

        Assert.assertEquals( "A1",
                             providerAPIResponseDTO.getCapitationTypeCode() );
        Assert.assertEquals( "NM1",
                             providerAPIResponseDTO.getCorpEntityCode() );
        Assert.assertEquals( "772129111",
                             providerAPIResponseDTO.getNetworkAssociationID() );
        Assert.assertEquals( "ECHO FIRST CHOICE REG",
                             providerAPIResponseDTO.getNetworkAssociationName() );
        Assert.assertEquals( "MCD",
                             providerAPIResponseDTO.getNetworkCode() );
        Assert.assertEquals( "PF001",
                             providerAPIResponseDTO.getPayToPFINId() );
        Assert.assertEquals( "01/01/2019",
                             providerAPIResponseDTO.getPfinEffectiveDate() );
        Assert.assertEquals( "12/31/2019",
                             providerAPIResponseDTO.getPfinEndDate() );
        Assert.assertEquals( "01/01/2019",
                             providerAPIResponseDTO.getPINGroupEffectiveDate() );
        Assert.assertEquals( "12/31/2019",
                             providerAPIResponseDTO.getPINGroupEndDate() );
        Assert.assertEquals( "REG001",
                             providerAPIResponseDTO.getPingroupID() );
        Assert.assertEquals( "REG",
                             providerAPIResponseDTO.getPingroupName() );
        Assert.assertEquals( "CP",
                             providerAPIResponseDTO.getProcessCode() );
    }

    @Test
    public void testToProviderAPIResponseDTO_Neg()
    {
        ProviderAPIResponseDTO providerAPIResponseDTO = ProviderMapper.INSTANCE.toProviderAPIResponseDTO( null );
        Assert.assertTrue( providerAPIResponseDTO == null );
    }

    @Test
    public void testToProviderAPIResponseDTOs()
    {
        List<ProviderAPIResponseDTO> providerAPIResponseDTOList =
            ProviderMapper.INSTANCE.toProviderAPIResponseDTOs( getProviderAPISearchResponseDTOList() );
        Assert.assertEquals( "A1",
                             providerAPIResponseDTOList.get( 0 ).getCapitationTypeCode() );
        Assert.assertEquals( "NM1",
                             providerAPIResponseDTOList.get( 0 ).getCorpEntityCode() );
        Assert.assertEquals( "772129111",
                             providerAPIResponseDTOList.get( 0 ).getNetworkAssociationID() );
        Assert.assertEquals( "ECHO FIRST CHOICE REG",
                             providerAPIResponseDTOList.get( 0 ).getNetworkAssociationName() );
        Assert.assertEquals( "MCD",
                             providerAPIResponseDTOList.get( 0 ).getNetworkCode() );
        Assert.assertEquals( "PF001",
                             providerAPIResponseDTOList.get( 0 ).getPayToPFINId() );
        Assert.assertEquals( "01/01/2019",
                             providerAPIResponseDTOList.get( 0 ).getPfinEffectiveDate() );
        Assert.assertEquals( "12/31/2019",
                             providerAPIResponseDTOList.get( 0 ).getPfinEndDate() );
        Assert.assertEquals( "01/01/2019",
                             providerAPIResponseDTOList.get( 0 ).getPINGroupEffectiveDate() );
        Assert.assertEquals( "12/31/2019",
                             providerAPIResponseDTOList.get( 0 ).getPINGroupEndDate() );
        Assert.assertEquals( "REG001",
                             providerAPIResponseDTOList.get( 0 ).getPingroupID() );
        Assert.assertEquals( "REG",
                             providerAPIResponseDTOList.get( 0 ).getPingroupName() );
        Assert.assertEquals( "CP",
                             providerAPIResponseDTOList.get( 0 ).getProcessCode() );
    }

    @Test
    public void testToProviderAPIResponseDTOs_Neg()
    {
        List<ProviderAPIResponseDTO> providerAPIResponseDTOList = ProviderMapper.INSTANCE.toProviderAPIResponseDTOs( null );
        Assert.assertTrue( providerAPIResponseDTOList == null );
    }

    @Test
    public void testToPayeeAddressDTO()
    {
        PayeeAddressDTO payeeAddressDTO = ProviderMapper.INSTANCE.toPayeeAddressDTO( getProviderApiAddressDTO() );
        Assert.assertEquals( "ADRS1",
                             payeeAddressDTO.getAddressLine1() );
        Assert.assertEquals( "ADRS2",
                             payeeAddressDTO.getAddressLine2() );
        Assert.assertEquals( "EAGLE CITY",
                             payeeAddressDTO.getCity() );
        Assert.assertEquals( "CHICAGO",
                             payeeAddressDTO.getState() );
        Assert.assertEquals( "502631",
                             payeeAddressDTO.getZipCode() );

    }

    @Test
    public void testToPayeeAddressDTO_Neg()
    {
        PayeeAddressDTO payeeAddressDTO = ProviderMapper.INSTANCE.toPayeeAddressDTO( null );
        Assert.assertTrue( payeeAddressDTO == null );
    }

    @Test
    public void testToPayToPFINPayeeAddressDTO()
    {
        PayToPFINPayeeAddressDTO payToPFINPayeeAddressDTO =
            ProviderMapper.INSTANCE.toPayToPFINPayeeAddressDTO( getProviderApiAddressDTO() );
        Assert.assertEquals( "ADRS1",
                             payToPFINPayeeAddressDTO.getAddressLine1() );
        Assert.assertEquals( "ADRS2",
                             payToPFINPayeeAddressDTO.getAddressLine2() );
        Assert.assertEquals( "EAGLE CITY",
                             payToPFINPayeeAddressDTO.getCity() );
        Assert.assertEquals( "CHICAGO",
                             payToPFINPayeeAddressDTO.getState() );
        Assert.assertEquals( "502631",
                             payToPFINPayeeAddressDTO.getZipCode() );
    }

    @Test
    public void testToPayToPFINPayeeAddressDTO_Neg()
    {
        PayToPFINPayeeAddressDTO payToPFINPayeeAddressDTO = ProviderMapper.INSTANCE.toPayToPFINPayeeAddressDTO( null );
        Assert.assertTrue( payToPFINPayeeAddressDTO == null );
    }

    @Test
    public void testToProviderApiAddressDTO()
    {
        ProviderApiAddressDTO providerApiAddressDTO = ProviderMapper.INSTANCE.toProviderApiAddressDTO( getPayToPFINPayeeAddressDTO() );
        Assert.assertEquals( "ADRS1",
                             providerApiAddressDTO.getAddressLine1() );
        Assert.assertEquals( "ADRS2",
                             providerApiAddressDTO.getAddressLine2() );
        Assert.assertEquals( "EAGLE CITY",
                             providerApiAddressDTO.getCity() );
        Assert.assertEquals( "CHICAGO",
                             providerApiAddressDTO.getState() );
        Assert.assertEquals( "502631",
                             providerApiAddressDTO.getZipCode() );
    }

    @Test
    public void testToProviderApiAddressDTO_Neg()
    {
        ProviderApiAddressDTO providerApiAddressDTO = ProviderMapper.INSTANCE.toProviderApiAddressDTO( null );
        Assert.assertTrue( providerApiAddressDTO == null );
    }

    private PayToPFINPayeeAddressDTO getPayToPFINPayeeAddressDTO()
    {
        PayToPFINPayeeAddressDTO payToPFINPayeeAddressDTO = new PayToPFINPayeeAddressDTO();
        payToPFINPayeeAddressDTO.setAddressLine1( "ADRS1" );
        payToPFINPayeeAddressDTO.setAddressLine2( "ADRS2" );
        payToPFINPayeeAddressDTO.setCity( "EAGLE CITY" );
        payToPFINPayeeAddressDTO.setState( "CHICAGO" );
        payToPFINPayeeAddressDTO.setZipCode( "502631" );
        return payToPFINPayeeAddressDTO;
    }

    private ProviderApiAddressDTO getProviderApiAddressDTO()
    {
        ProviderApiAddressDTO providerApiAddressDTO = new ProviderApiAddressDTO();
        providerApiAddressDTO.setAddressLine1( "ADRS1" );
        providerApiAddressDTO.setAddressLine2( "ADRS2" );
        providerApiAddressDTO.setCity( "EAGLE CITY" );
        providerApiAddressDTO.setState( "CHICAGO" );
        providerApiAddressDTO.setZipCode( "502631" );
        return providerApiAddressDTO;
    }

    private ProviderAPISearchResponseDTO getProviderAPISearchResponseDTO()
    {
        ProviderAPISearchResponseDTO response = new ProviderAPISearchResponseDTO();
        response.setCapitationType( "A1" );
        response.setCorpEntityCode( "NM1" );
        response.setNetworkAssociationID( "772129111" );
        response.setNetworkAssociationName( "ECHO FIRST CHOICE REG" );
        response.setNetworkCode( "MCD" );
        response.setPfin( "PF001" );
        response.setPfinEffectiveDate( "01/01/2019" );
        response.setPfinEndDate( "12/31/2019" );
        response.setPinGroupEffectiveDate( "01/01/2019" );
        response.setPinGroupEndDate( "12/31/2019" );
        response.setPingroupID( "REG001" );
        response.setPingroupName( "REG" );
        response.setProcessCode( "CP" );
        return response;
    }

    private List<ProviderAPISearchResponseDTO> getProviderAPISearchResponseDTOList()
    {
        List<ProviderAPISearchResponseDTO> list = new ArrayList<ProviderAPISearchResponseDTO>();
        list.add( getProviderAPISearchResponseDTO() );
        return list;

    }
}
