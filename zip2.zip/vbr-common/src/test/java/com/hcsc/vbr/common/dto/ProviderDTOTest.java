package com.hcsc.vbr.common.dto;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class ProviderDTOTest
{
    private ProviderDTO providerDTO;

    @Before
    public void setUp()
    {
        providerDTO = new ProviderDTO();
    }

    @Test
    public void testProviderDTO()
    {
        providerDTO.setCapitationTypeCode( "A1" );
        providerDTO.setCorpCode( "NM1" );
        providerDTO.setNetworkAssociationID( 123 );
        providerDTO.setNetworkCode( "MCD" );
        providerDTO.setPayToPFIN( "00NMCAP001" );
        providerDTO.setPinGroupID( "REG" );
        providerDTO.setProcessCode( "CP" );

        Assert.assertTrue( providerDTO != null );
        Assert.assertEquals( "A1",
                             providerDTO.getCapitationTypeCode() );
        Assert.assertEquals( "NM1",
                             providerDTO.getCorpCode() );
        Assert.assertEquals( "MCD",
                             providerDTO.getNetworkCode() );
        Assert.assertEquals( Integer.valueOf( 123 ),
                             providerDTO.getNetworkAssociationID() );
        Assert.assertEquals( "00NMCAP001",
                             providerDTO.getPayToPFIN() );
        Assert.assertEquals( "REG",
                             providerDTO.getPinGroupID() );
        Assert.assertEquals( "CP",
                             providerDTO.getProcessCode() );

        Assert.assertTrue( providerDTO.toString().contains( "processCode=CP" ) );
    }
}
