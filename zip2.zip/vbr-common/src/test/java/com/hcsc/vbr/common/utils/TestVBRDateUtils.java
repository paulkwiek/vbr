package com.hcsc.vbr.common.utils;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.assertj.core.util.DateUtil;
import org.junit.Assert;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.hcsc.vbr.common.domain.DateRecord;
import com.hcsc.vbr.common.dto.BaseEntityDTO;
import com.hcsc.vbr.common.dto.DateRecordDTO;

public class TestVBRDateUtils
{

    private static final Logger LOGGER = LoggerFactory.getLogger( TestVBRDateUtils.class );

    /***************
     * convertStringToDate(String str)
     * 
     * @throws ParseException
     *****************************/

    @Test
    public void testConvertStringToDate() throws Exception
    {
        Date expectedDate = null;
        expectedDate = VBRDateUtils.convertStringToDate( "04/10/2019" );
        Date actualDate = convertStrToDate( "04/10/2019" );
        Assert.assertEquals( expectedDate,
                             actualDate );

    }

    // Input wrong date format and ParseException is expected.
    @SuppressWarnings( "unused" )
    @Test
    public void testConvertStringToDate_Neg_0()
    {
        Date expectedDate = null;
        try
        {
            expectedDate = VBRDateUtils.convertStringToDate( "10-04-1889" );
        }
        catch( Exception e )
        {
            LOGGER.info( "Exception while converting String to Date " + e.getMessage() );
        }

    }

    // Null is expected
    @Test( expected = NullPointerException.class )
    public void testConvertStringToDate_Neg_1() throws Exception
    {
        Date expectedDate = null;
        expectedDate = VBRDateUtils.convertStringToDate( null );
        Assert.assertEquals( expectedDate,
                             null );

    }

    /***************
     * convertDateToString(Date date)
     * 
     * @throws Exception
     *****************************/
    // Input Today's date
    @Test
    public void testConvertDateToString() throws Exception
    {
        String expectedDate = VBRDateUtils.convertDateToString( new Date() );
        DateFormat dateFormat = new SimpleDateFormat( "MM/dd/yyyy" );
        String actualDate = dateFormat.format( new Date() );
        Assert.assertEquals( expectedDate,
                             actualDate );
    }

    @Test
    public void testConvertDateToString_0() throws Exception
    {
        String expectedDate = VBRDateUtils.convertDateToString( convertStrToDate( "09/09/2001" ) );
        DateFormat dateFormat = new SimpleDateFormat( "MM/dd/yyyy" );
        String actualDate = dateFormat.format( convertStrToDate( "09/09/2001" ) );
        Assert.assertEquals( expectedDate,
                             actualDate );
    }

    // Input today's date with truncated time.
    @Test
    public void testConvertDateToString_2() throws Exception
    {
        String expectedDate = VBRDateUtils.convertDateToString( DateUtil.truncateTime( new Date() ) );
        DateFormat dateFormat = new SimpleDateFormat( "MM/dd/yyyy" );
        String actualDate = dateFormat.format( DateUtil.truncateTime( new Date() ) );
        Assert.assertEquals( expectedDate,
                             actualDate );
    }

    // Input Null Date
    @Test( expected = NullPointerException.class )
    public void testConvertDateToString_Neg_0() throws Exception
    {
        String expectedDate = VBRDateUtils.convertDateToString( null );
        Assert.assertEquals( expectedDate,
                             null );
    }

    @Test
    public void testConvertDateToString_Neg_1() throws Exception
    {
        String expectedDate = VBRDateUtils.convertDateToString( convertStrToDate( "09/01/900" ) );
        Assert.assertTrue( expectedDate != null );
    }

    // Input Long Date
    @Test
    public void testConvertDateToString_Neg_2() throws Exception
    {
        Date date = new Date( 1234567890123456L );
        String expectedDate = VBRDateUtils.convertDateToString( date );
        Assert.assertTrue( expectedDate != null );
    }

    @Test
    public void testConvertStringToLocalDate()
    {
        VBRDateUtils.convertStringToLocalDate( "2019-01-01" );
    }

    @Test
    public void testConvertStringToLocalDateDefaultFormat()
    {
        VBRDateUtils.convertStringToLocalDateDefaultFormat( "01/01/2019" );
    }

    /***************
     * checkDateCoverage(DateRecord parent,DateRecord child)
     * 
     * @throws Exception
     *****************************/
    // Input child dates within parent
    @Test
    public void testCheckDateCoverage() throws Exception
    {
        boolean flag;
        DateRecord parent = new DateRecord();
        parent.setRecordEffectiveDate( convertStringToLocalDate( "09/09/2001" ) );
        parent.setRecordEndDate( convertStringToLocalDate( "10/12/2001" ) );
        DateRecord child = new DateRecord();
        child.setRecordEffectiveDate( convertStringToLocalDate( "09/19/2001" ) );
        child.setRecordEndDate( convertStringToLocalDate( "10/04/2001" ) );
        flag = VBRDateUtils.checkDateCoverage( parent,
                                               child );
        Assert.assertTrue( flag == true );

    }

    // Input child dates out of parent dates
    @Test
    public void testCheckDateCoverage_Neg_0() throws Exception
    {
        boolean flag;
        DateRecord parent = new DateRecord();
        parent.setRecordEffectiveDate( convertStringToLocalDate( "09/09/2001" ) );
        parent.setRecordEndDate( convertStringToLocalDate( "09/09/2001" ) );
        DateRecord child = new DateRecord();
        child.setRecordEffectiveDate( convertStringToLocalDate( "09/19/2000" ) );
        child.setRecordEndDate( convertStringToLocalDate( "10/04/2001" ) );
        flag = VBRDateUtils.checkDateCoverage( parent,
                                               child );
        Assert.assertTrue( flag == false );

    }

    // Input parentEffDate=null and parentEndDate=null
    @Test
    public void testCheckDateCoverage_Neg_1() throws Exception
    {
        boolean flag;
        DateRecord parent = new DateRecord();
        DateRecord child = new DateRecord();
        child.setRecordEffectiveDate( convertStringToLocalDate( "09/19/2001" ) );
        child.setRecordEndDate( convertStringToLocalDate( "10/04/2001" ) );
        flag = VBRDateUtils.checkDateCoverage( parent,
                                               child );
        Assert.assertTrue( flag == false );

    }

    // Input parent and child with same Dates.
    @Test
    public void testCheckDateCoverage_Neg_2() throws Exception
    {
        boolean flag;
        DateRecord parent = new DateRecord();
        parent.setRecordEffectiveDate( convertStringToLocalDate( "09/01/2001" ) );
        parent.setRecordEndDate( convertStringToLocalDate( "09/01/2001" ) );
        DateRecord child = new DateRecord();
        child.setRecordEffectiveDate( convertStringToLocalDate( "09/09/2001" ) );
        child.setRecordEndDate( convertStringToLocalDate( "09/09/2001" ) );
        flag = VBRDateUtils.checkDateCoverage( parent,
                                               child );
        Assert.assertTrue( flag == false );

    }

    // Input childEndDate=null
    @Test
    public void testCheckDateCoverage_Neg_3() throws Exception
    {
        boolean flag;
        DateRecord parent = new DateRecord();
        parent.setRecordEffectiveDate( convertStringToLocalDate( "09/09/2001" ) );
        parent.setRecordEndDate( convertStringToLocalDate( "10/09/2001" ) );
        DateRecord child = new DateRecord();
        child.setRecordEffectiveDate( convertStringToLocalDate( "09/09/2001" ) );
        flag = VBRDateUtils.checkDateCoverage( parent,
                                               child );
        Assert.assertTrue( flag == false );
    }

    // Input parentEndDate and childEndDate null
    @Test
    public void testCheckDateCoverage_Neg_4() throws Exception
    {
        boolean flag;
        DateRecord parent = new DateRecord();
        parent.setRecordEffectiveDate( convertStringToLocalDate( "09/09/2000" ) );
        parent.setRecordEndDate( null );
        DateRecord child = new DateRecord();
        child.setRecordEffectiveDate( convertStringToLocalDate( "09/09/2001" ) );
        child.setRecordEndDate( null );
        flag = VBRDateUtils.checkDateCoverage( parent,
                                               child );
        Assert.assertTrue( flag == false );
    }

    // Input parentEffDate and childEffDate null
    @Test
    public void testCheckDateCoverage_Neg_5() throws Exception
    {
        boolean flag;
        DateRecord parent = new DateRecord();
        parent.setRecordEffectiveDate( null );
        parent.setRecordEndDate( convertStringToLocalDate( "09/01/1990" ) );
        DateRecord child = new DateRecord();
        child.setRecordEffectiveDate( null );
        child.setRecordEndDate( convertStringToLocalDate( "09/09/2001" ) );
        flag = VBRDateUtils.checkDateCoverage( parent,
                                               child );
        Assert.assertTrue( flag == false );
    }

    // Input childEffDate null
    @Test
    public void testCheckDateCoverage_Neg_6() throws Exception
    {
        boolean flag;
        DateRecord parent = new DateRecord();
        parent.setRecordEffectiveDate( convertStringToLocalDate( "09/01/1880" ) );
        parent.setRecordEndDate( convertStringToLocalDate( "09/01/1990" ) );
        DateRecord child = new DateRecord();
        child.setRecordEffectiveDate( null );
        child.setRecordEndDate( convertStringToLocalDate( "09/09/2001" ) );
        flag = VBRDateUtils.checkDateCoverage( parent,
                                               child );
        Assert.assertTrue( flag == false );
    }

    // Input parentEffDate = childEffDate
    @Test
    public void testCheckDateCoverage_Neg_7() throws Exception
    {
        boolean flag;
        DateRecord parent = new DateRecord();
        parent.setRecordEffectiveDate( convertStringToLocalDate( "09/01/2001" ) );
        parent.setRecordEndDate( convertStringToLocalDate( "10/01/2001" ) );
        DateRecord child = new DateRecord();
        child.setRecordEffectiveDate( convertStringToLocalDate( "09/09/2001" ) );
        child.setRecordEndDate( convertStringToLocalDate( "10/09/2001" ) );
        flag = VBRDateUtils.checkDateCoverage( parent,
                                               child );
        Assert.assertTrue( flag == false );

    }

    // Input parentEndDate = childEndDate
    @Test
    public void testCheckDateCoverage_Neg_8() throws Exception
    {
        boolean flag;
        DateRecord parent = new DateRecord();
        parent.setRecordEffectiveDate( convertStringToLocalDate( "09/01/2001" ) );
        parent.setRecordEndDate( convertStringToLocalDate( "12/01/2001" ) );
        DateRecord child = new DateRecord();
        child.setRecordEffectiveDate( convertStringToLocalDate( "09/19/2001" ) );
        child.setRecordEndDate( convertStringToLocalDate( "12/09/2001" ) );
        flag = VBRDateUtils.checkDateCoverage( parent,
                                               child );
        Assert.assertTrue( flag == false );

    }

    // Input null parent and child
    @Test
    public void testCheckDateCoverage_Neg_9() throws Exception
    {
        boolean flag;
        DateRecord parent = null;
        DateRecord child = null;
        flag = VBRDateUtils.checkDateCoverage( parent,
                                               child );
        Assert.assertTrue( flag == false );

    }

    // Input null parent and child
    @Test
    public void testCheckDateCoverage_Neg_10() throws Exception
    {
        boolean flag;
        DateRecord parent = new DateRecord();
        parent.setRecordEffectiveDate( convertStringToLocalDate( "09/09/2000" ) );
        parent.setRecordEndDate( convertStringToLocalDate( "09/09/2009" ) );
        DateRecord child = null;
        flag = VBRDateUtils.checkDateCoverage( parent,
                                               child );
        Assert.assertTrue( flag == false );

    }

    // Input null parent and child
    @Test
    public void testCheckDateCoverage_Neg_11() throws Exception
    {
        boolean flag;
        DateRecord parent = null;
        DateRecord child = new DateRecord();
        child.setRecordEffectiveDate( convertStringToLocalDate( "09/09/2000" ) );
        child.setRecordEndDate( convertStringToLocalDate( "09/09/2009" ) );
        flag = VBRDateUtils.checkDateCoverage( parent,
                                               child );
        Assert.assertTrue( flag == false );

    }

    /***************
     * checkDateCoverage(List<DateRecord> parent,DateRecord child)
     * 
     * @throws Exception
     *****************************/
    // Input child dates within parent limits.
    @Test
    public void testCheckDateCoverage_ListParent() throws Exception
    {
        boolean flag;
        DateRecord child = new DateRecord();
        child.setRecordEffectiveDate( convertStringToLocalDate( "09/02/2014" ) );
        child.setRecordEndDate( convertStringToLocalDate( "09/02/2017" ) );
        flag = VBRDateUtils.checkDateCoverage( getDateRecordList(),
                                               child );
        Assert.assertTrue( flag == true );
    }

    // Input parentList empty
    @Test
    public void testCheckDateCoverage_ListParent_Neg_0() throws Exception
    {
        boolean flag;
        DateRecord child = new DateRecord();
        child.setRecordEffectiveDate( convertStringToLocalDate( "09/02/2014" ) );
        child.setRecordEndDate( convertStringToLocalDate( "09/02/2017" ) );
        List<DateRecord> parentList = new ArrayList<DateRecord>();
        flag = VBRDateUtils.checkDateCoverage( parentList,
                                               child );
        Assert.assertTrue( flag == false );
    }

    // Input parentList empty and child null
    @Test
    public void testCheckDateCoverage_ListParent_Neg_1() throws Exception
    {
        boolean flag;
        List<DateRecord> parentList = new ArrayList<DateRecord>();
        DateRecord child = new DateRecord();
        flag = VBRDateUtils.checkDateCoverage( parentList,
                                               child );
        Assert.assertTrue( flag == false );
    }

    // Input child date not within parents limit
    @Test
    public void testCheckDateCoverage_ListParent_Neg_2() throws Exception
    {
        boolean flag;
        DateRecord child = new DateRecord();
        child.setRecordEffectiveDate( convertStringToLocalDate( "09/02/1992" ) );
        child.setRecordEndDate( convertStringToLocalDate( "09/02/2100" ) );
        flag = VBRDateUtils.checkDateCoverage( getDateRecordList(),
                                               child );
        Assert.assertTrue( flag == false );
    }

    // Input child null
    @Test
    public void testCheckDateCoverage_ListParent_Neg_4() throws Exception
    {
        boolean flag;
        DateRecord child = null;
        flag = VBRDateUtils.checkDateCoverage( getDateRecordList(),
                                               child );
        Assert.assertTrue( flag == false );
    }

    // Input child date end date null
    @Test
    public void testCheckDateCoverage_ListParent_Neg_5() throws Exception
    {
        boolean flag;
        DateRecord child = new DateRecord();
        child.setRecordEffectiveDate( convertStringToLocalDate( "09/02/1992" ) );
        child.setRecordEndDate( null );
        flag = VBRDateUtils.checkDateCoverage( getDateRecordList(),
                                               child );
        Assert.assertTrue( flag == false );
    }

    // Input child eff and end dates same
    @Test
    public void testCheckDateCoverage_ListParent_Neg_6() throws Exception
    {
        boolean flag;
        DateRecord child = new DateRecord();
        child.setRecordEffectiveDate( convertStringToLocalDate( "09/02/1992" ) );
        child.setRecordEndDate( convertStringToLocalDate( "09/02/1992" ) );
        flag = VBRDateUtils.checkDateCoverage( getDateRecordList(),
                                               child );
        Assert.assertTrue( flag == false );
    }

    /***************
     * checkDateCoverage(DateRecord parent,List<DateRecord>child)
     * 
     * @throws Exception
     *****************************/
    // Input list of child dates within parent
    @Test
    public void testCheckDateCoverage_ListChild() throws Exception
    {
        boolean flag;
        DateRecord parent = new DateRecord();
        parent.setRecordEffectiveDate( convertStringToLocalDate( "12/12/1870" ) );
        parent.setRecordEndDate( convertStringToLocalDate( "12/12/2070" ) );
        flag = VBRDateUtils.checkDateCoverage( parent,
                                               getDateRecordList() );
        Assert.assertTrue( flag == true );
    }

    // Input childList Empty
    @Test
    public void testCheckDateCoverage_ListChild_Neg_0() throws Exception
    {
        boolean flag;
        DateRecord parent = new DateRecord();
        List<DateRecord> childList = new ArrayList<DateRecord>();
        flag = VBRDateUtils.checkDateCoverage( parent,
                                               childList );
        Assert.assertTrue( flag == false );
    }

    // Input parentEffDate,parentEndDate,childEndDate and childEffDate null
    @Test
    public void testCheckDateCoverage_ListChild_Neg_1() throws Exception
    {
        boolean flag;
        DateRecord parent = new DateRecord();
        List<DateRecord> childList = new ArrayList<DateRecord>();
        childList.add( new DateRecord() );
        flag = VBRDateUtils.checkDateCoverage( parent,
                                               childList );
        Assert.assertTrue( flag == false );
    }

    // Input childList dates out of parent Date
    @Test
    public void testCheckDateCoverage_ListChild_Neg_2() throws Exception
    {
        boolean flag;
        DateRecord parent = new DateRecord();
        parent.setRecordEffectiveDate( convertStringToLocalDate( "01/01/2006" ) );
        parent.setRecordEndDate( convertStringToLocalDate( "01/01/2007" ) );
        flag = VBRDateUtils.checkDateCoverage( parent,
                                               getDateRecordList() );
        Assert.assertTrue( flag == false );
    }

    // Input childList dates out of parent Date
    @Test
    public void testCheckDateCoverage_ListChild_Neg_3() throws Exception
    {
        boolean flag;
        DateRecord parent = null;
        flag = VBRDateUtils.checkDateCoverage( parent,
                                               getDateRecordList() );
        Assert.assertTrue( flag == false );
    }

    // Input parent End date null
    @Test
    public void testCheckDateCoverage_ListChild_Neg_4() throws Exception
    {
        boolean flag;
        DateRecord parent = new DateRecord();
        parent.setRecordEffectiveDate( convertStringToLocalDate( "01/01/2006" ) );
        parent.setRecordEndDate( null );
        flag = VBRDateUtils.checkDateCoverage( parent,
                                               getDateRecordList() );
        Assert.assertTrue( flag == false );
    }

    // Input parent End date  and eff date same
    @Test
    public void testCheckDateCoverage_ListChild_Neg_5() throws Exception
    {
        boolean flag;
        DateRecord parent = new DateRecord();
        parent.setRecordEffectiveDate( convertStringToLocalDate( "01/01/2006" ) );
        parent.setRecordEndDate( convertStringToLocalDate( "01/01/2006" ) );
        flag = VBRDateUtils.checkDateCoverage( parent,
                                               getDateRecordList() );
        Assert.assertTrue( flag == false );
    }

    /********************
     * checkDateCoverage(List<DateRecord> parent,List<DateRecord>child)
     * 
     * @throws Exception
     *****************************/
    // Input childList Dates within ParentList dates
    @Test
    public void testCheckDateCoverage_ListParentChild() throws Exception
    {
        boolean flag;
        DateRecord dr1 = new DateRecord();
        dr1.setRecordEffectiveDate( convertStringToLocalDate( "12/12/1880" ) );
        dr1.setRecordEndDate( convertStringToLocalDate( "12/12/2038" ) );
        DateRecord dr2 = new DateRecord();
        dr2.setRecordEffectiveDate( convertStringToLocalDate( "10/10/1789" ) );
        dr2.setRecordEndDate( convertStringToLocalDate( "10/10/2036" ) );

        List<DateRecord> parentList = new ArrayList<DateRecord>();
        parentList.add( dr1 );
        parentList.add( dr2 );

        flag = VBRDateUtils.checkDateCoverage( parentList,
                                               getDateRecordList() );
        Assert.assertTrue( flag == true );
    }

    // Input parentList and childList empty
    @Test
    public void testCheckDateCoverage_ListParentChild_Neg_0() throws Exception
    {
        boolean flag;
        List<DateRecord> parentList = new ArrayList<DateRecord>();
        List<DateRecord> childList = new ArrayList<DateRecord>();

        flag = VBRDateUtils.checkDateCoverage( parentList,
                                               childList );
        Assert.assertTrue( flag == false );
    }

    // Input childList Dates out of ParentList Dates
    @Test
    public void testCheckDateCoverage_ListParentChild_Neg_1() throws Exception
    {
        boolean flag;
        DateRecord dr1 = new DateRecord();
        dr1.setRecordEffectiveDate( convertStringToLocalDate( "01/01/2006" ) );
        dr1.setRecordEndDate( convertStringToLocalDate( "01/01/2007" ) );
        DateRecord dr2 = new DateRecord();
        dr2.setRecordEffectiveDate( convertStringToLocalDate( "02/02/2005" ) );
        dr2.setRecordEndDate( convertStringToLocalDate( "05/06/2009" ) );

        List<DateRecord> parentList = new ArrayList<DateRecord>();
        parentList.add( dr1 );
        parentList.add( dr2 );

        flag = VBRDateUtils.checkDateCoverage( parentList,
                                               getDateRecordList() );
        Assert.assertTrue( flag == false );
    }

    // Input ParentEff,ParentEnd,childEff and childEnd Dates null
    @Test
    public void testCheckDateCoverage_ListParentChild_Neg_2() throws Exception
    {
        boolean flag;
        DateRecord dr1 = new DateRecord();
        dr1.setRecordEffectiveDate( null );
        dr1.setRecordEndDate( null );
        List<DateRecord> parentList = new ArrayList<DateRecord>();
        parentList.add( dr1 );

        List<DateRecord> childList = new ArrayList<DateRecord>();
        childList.add( dr1 );

        flag = VBRDateUtils.checkDateCoverage( parentList,
                                               childList );
        Assert.assertTrue( flag == false );

    }

    // Input parentList empty
    @Test
    public void testCheckDateCoverage_ListParentChild_Neg_3() throws Exception
    {
        boolean flag;
        List<DateRecord> parentList = new ArrayList<DateRecord>();
        flag = VBRDateUtils.checkDateCoverage( parentList,
                                               getDateRecordList() );
        Assert.assertTrue( flag == false );

    }

    // Input childList empty
    @Test
    public void testCheckDateCoverage_ListParentChild_Neg_4() throws Exception
    {
        boolean flag;
        List<DateRecord> childList = new ArrayList<DateRecord>();
        flag = VBRDateUtils.checkDateCoverage( getDateRecordList(),
                                               childList );
        Assert.assertTrue( flag == false );

    }

    /***************
     * checkNotIntersecting(List<DateRecord> dateRecordsList)
     * 
     * @throws Exception
     *****************************/
    // Overlaps hence flag=false is expected
    @Test
    public void testCheckNotIntersecting() throws Exception
    {
        boolean flag;
        DateRecord dr1 = new DateRecord();
        dr1.setRecordEffectiveDate( convertStringToLocalDate( "01/01/2000" ) );
        dr1.setRecordEndDate( convertStringToLocalDate( "12/02/2000" ) );
        DateRecord dr2 = new DateRecord();
        dr2.setRecordEffectiveDate( convertStringToLocalDate( "06/01/2001" ) );
        dr2.setRecordEndDate( convertStringToLocalDate( "02/02/2002" ) );
        DateRecord dr3 = new DateRecord();
        dr3.setRecordEffectiveDate( convertStringToLocalDate( "01/01/2003" ) );
        dr3.setRecordEndDate( convertStringToLocalDate( "02/02/2011" ) );
        DateRecord dr4 = new DateRecord();
        dr4.setRecordEffectiveDate( convertStringToLocalDate( "01/01/2000" ) );
        dr4.setRecordEndDate( convertStringToLocalDate( "02/02/2011" ) );

        List<DateRecord> dateRecordsList = new ArrayList<DateRecord>();
        dateRecordsList.add( dr1 );
        dateRecordsList.add( dr2 );
        dateRecordsList.add( dr3 );
        dateRecordsList.add( dr4 );

        flag = VBRDateUtils.checkNotIntersecting( dateRecordsList );
        Assert.assertTrue( flag == false );
    }

    // List of DateRecords doesn't overlap hence flag=true is expected
    @Test
    public void testCheckNotIntersecting_Neg_0() throws Exception
    {
        boolean flag;
        DateRecord dr1 = new DateRecord();
        dr1.setRecordEffectiveDate( convertStringToLocalDate( "01/01/2000" ) );
        dr1.setRecordEndDate( convertStringToLocalDate( "12/12/2000" ) );
        DateRecord dr2 = new DateRecord();
        dr2.setRecordEffectiveDate( convertStringToLocalDate( "01/01/2001" ) );
        dr2.setRecordEndDate( convertStringToLocalDate( "12/12/2001" ) );
        DateRecord dr3 = new DateRecord();
        dr3.setRecordEffectiveDate( convertStringToLocalDate( "01/01/2006" ) );
        dr3.setRecordEndDate( convertStringToLocalDate( "12/12/2007" ) );
        DateRecord dr4 = new DateRecord();
        dr4.setRecordEffectiveDate( convertStringToLocalDate( "01/01/2004" ) );
        dr4.setRecordEndDate( convertStringToLocalDate( "12/12/2005" ) );

        List<DateRecord> dateRecordsList = new ArrayList<DateRecord>();
        dateRecordsList.add( dr1 );
        dateRecordsList.add( dr2 );
        dateRecordsList.add( dr3 );
        dateRecordsList.add( dr4 );

        flag = VBRDateUtils.checkNotIntersecting( dateRecordsList );
        Assert.assertTrue( flag == true );
    }

    // Input empty DateRecordList
    @Test
    public void testCheckNotIntersecting_Neg_1() throws Exception
    {
        boolean flag;
        List<DateRecord> dateRecordList = new ArrayList<DateRecord>();
        flag = VBRDateUtils.checkNotIntersecting( dateRecordList );
        Assert.assertTrue( flag == false );
    }

    // Input effective and endDate null in List
    @Test
    public void testCheckNotIntersecting_Neg_2() throws Exception
    {
        boolean flag;
        List<DateRecord> dateRecordList = new ArrayList<DateRecord>();
        DateRecord dateRec = new DateRecord();
        dateRec.setRecordEffectiveDate( null );
        dateRec.setRecordEndDate( convertStringToLocalDate( "01/01/2000" ) );

        DateRecord dateRec1 = new DateRecord();
        dateRec1.setRecordEffectiveDate( convertStringToLocalDate( "10/02/2001" ) );
        dateRec1.setRecordEndDate( convertStringToLocalDate( "11/02/2009" ) );

        dateRecordList.add( dateRec );
        dateRecordList.add( dateRec1 );

        flag = VBRDateUtils.checkNotIntersecting( dateRecordList );
        Assert.assertTrue( flag == false );

    }

    // Input effective and endDate null in List
    @Test
    public void testCheckNotIntersecting_Neg_3() throws Exception
    {
        boolean flag;
        List<DateRecord> dateRecordList = new ArrayList<DateRecord>();
        DateRecord dateRec = new DateRecord();
        dateRec.setRecordEffectiveDate( convertStringToLocalDate( "01/01/2000" ) );
        dateRec.setRecordEndDate( null );

        DateRecord dateRec1 = new DateRecord();
        dateRec1.setRecordEffectiveDate( convertStringToLocalDate( "12/01/2007" ) );
        dateRec1.setRecordEndDate( convertStringToLocalDate( "12/01/2009" ) );

        dateRecordList.add( dateRec );
        dateRecordList.add( dateRec1 );

        flag = VBRDateUtils.checkNotIntersecting( dateRecordList );
        Assert.assertTrue( flag == false );

    }

    // Input effective and endDate null in List
    @Test
    public void testCheckNotIntersecting_Neg_4() throws Exception
    {
        boolean flag;
        List<DateRecord> dateRecordList = new ArrayList<DateRecord>();
        DateRecord dateRec = new DateRecord();
        dateRec.setRecordEffectiveDate( convertStringToLocalDate( "01/01/2000" ) );
        dateRec.setRecordEndDate( convertStringToLocalDate( "12/01/2007" ) );

        DateRecord dateRec1 = new DateRecord();
        dateRec1.setRecordEffectiveDate( null );
        dateRec1.setRecordEndDate( convertStringToLocalDate( "12/01/2009" ) );

        dateRecordList.add( dateRec );
        dateRecordList.add( dateRec1 );

        flag = VBRDateUtils.checkNotIntersecting( dateRecordList );
        Assert.assertTrue( flag == false );

    }

    // Input effective and endDate null in List
    @Test
    public void testCheckNotIntersecting_Neg_5() throws Exception
    {
        boolean flag;
        List<DateRecord> dateRecordList = new ArrayList<DateRecord>();
        DateRecord dateRec = new DateRecord();
        dateRec.setRecordEffectiveDate( convertStringToLocalDate( "01/01/2000" ) );
        dateRec.setRecordEndDate( convertStringToLocalDate( "01/01/2001" ) );

        DateRecord dateRec1 = new DateRecord();
        dateRec1.setRecordEffectiveDate( convertStringToLocalDate( "12/01/2007" ) );
        dateRec1.setRecordEndDate( null );

        dateRecordList.add( dateRec );
        dateRecordList.add( dateRec1 );

        flag = VBRDateUtils.checkNotIntersecting( dateRecordList );
        Assert.assertTrue( flag == false );

    }

    /***************
     * checkForNoGaps(List<DateRecord> dateRecordsList)
     * 
     * @throws Exception
     *****************************/
    @Test
    public void testCheckForNoGaps() throws Exception
    {
        boolean flag;
        DateRecord dr1 = new DateRecord();
        dr1.setRecordEffectiveDate( convertStringToLocalDate( "01/01/2019" ) );
        dr1.setRecordEndDate( convertStringToLocalDate( "01/31/2019" ) );
        DateRecord dr2 = new DateRecord();
        dr2.setRecordEffectiveDate( convertStringToLocalDate( "02/01/2019" ) );
        dr2.setRecordEndDate( convertStringToLocalDate( "12/31/2019" ) );
        List<DateRecord> drList = new ArrayList<DateRecord>();
        drList.add( dr1 );
        drList.add( dr2 );
        flag = VBRDateUtils.checkForNoGaps( drList );
        Assert.assertTrue( flag == true );
    }

    @Test
    public void testCheckForNoGaps_Neg_1() throws Exception
    {
        boolean flag;
        DateRecord dr1 = new DateRecord();
        dr1.setRecordEffectiveDate( convertStringToLocalDate( "01/01/2019" ) );
        dr1.setRecordEndDate( convertStringToLocalDate( "01/31/2019" ) );
        DateRecord dr2 = new DateRecord();
        dr2.setRecordEffectiveDate( convertStringToLocalDate( "01/01/2019" ) );
        dr2.setRecordEndDate( convertStringToLocalDate( "02/28/2019" ) );
        List<DateRecord> drList = new ArrayList<DateRecord>();
        drList.add( dr1 );
        drList.add( dr2 );
        flag = VBRDateUtils.checkForNoGaps( drList );
        Assert.assertTrue( flag == false );
    }

    //empty dateRecordsList
    @Test
    public void testCheckForNoGaps_Neg_2() throws Exception
    {
        boolean flag;
        List<DateRecord> dateRecordList = new ArrayList<DateRecord>();
        flag = VBRDateUtils.checkForNoGaps( dateRecordList );
        Assert.assertTrue( flag == false );
    }

    // Input effective and End Dates are null 
    @Test( expected = NullPointerException.class )
    public void testCheckForNoGaps_Neg_3() throws Exception
    {
        boolean flag;
        List<DateRecord> dateRecordList = new ArrayList<DateRecord>();
        DateRecord dateRec = new DateRecord();
        dateRec.setRecordEffectiveDate( null );
        dateRec.setRecordEndDate( null );

        DateRecord dateRec1 = new DateRecord();
        dateRec1.setRecordEffectiveDate( null );
        dateRec1.setRecordEndDate( null );

        dateRecordList.add( dateRec );
        dateRecordList.add( dateRec1 );

        flag = VBRDateUtils.checkForNoGaps( dateRecordList );
        Assert.assertTrue( flag == false );

    }

    // Effective And End Dates are same 
    @Test
    public void testCheckForNoGaps_Neg_4() throws Exception
    {
        boolean flag;
        List<DateRecord> dateRecordList = new ArrayList<DateRecord>();
        DateRecord dateRec = new DateRecord();
        dateRec.setRecordEffectiveDate( convertStringToLocalDate( "01/02/2009" ) );
        dateRec.setRecordEndDate( convertStringToLocalDate( "11/30/2009" ) );

        DateRecord dateRec1 = new DateRecord();
        dateRec1.setRecordEffectiveDate( convertStringToLocalDate( "01/02/2009" ) );
        dateRec1.setRecordEndDate( convertStringToLocalDate( "11/30/2009" ) );

        dateRecordList.add( dateRec );
        dateRecordList.add( dateRec1 );

        flag = VBRDateUtils.checkForNoGaps( dateRecordList );
        Assert.assertTrue( flag == true );

    }

    /***************
     * checkEffectiveAndEndDates(DateRecord dateRecord)
     * 
     * @throws Exception
     *****************************/
    // Input effDate before endDate
    @Test
    public void testCheckEffectiveAndEndDates() throws Exception
    {
        boolean flag;
        DateRecord dateRecord = new DateRecord();
        dateRecord.setRecordEffectiveDate( convertStringToLocalDate( "01/01/2000" ) );
        dateRecord.setRecordEndDate( convertStringToLocalDate( "02/02/2000" ) );

        flag = VBRDateUtils.checkEffectiveAndEndDates( dateRecord );
        Assert.assertTrue( flag == true );
    }

    // Input effDate and EndDate null
    @Test
    public void testCheckEffectiveAndEndDates_Neg_0() throws Exception
    {
        boolean flag;
        DateRecord dateRecord = new DateRecord();
        flag = VBRDateUtils.checkEffectiveAndEndDates( dateRecord );
        Assert.assertTrue( flag == false );
    }

    // Input DateRecord=null
    @Test
    public void testCheckEffectiveAndEndDates_Neg_1() throws Exception
    {
        boolean flag;
        DateRecord dateRecord = null;
        flag = VBRDateUtils.checkEffectiveAndEndDates( dateRecord );
        Assert.assertTrue( flag == false );
    }

    // Input endDate before effDate
    @Test
    public void testCheckEffectiveAndEndDates_Neg_2() throws Exception
    {
        boolean flag;
        DateRecord dateRecord = new DateRecord();
        dateRecord.setRecordEffectiveDate( convertStringToLocalDate( "09/03/1997" ) );
        dateRecord.setRecordEndDate( convertStringToLocalDate( "03/03/1997" ) );
        flag = VBRDateUtils.checkEffectiveAndEndDates( dateRecord );
        Assert.assertTrue( flag == false );

    }

    // Input endDate null
    @Test
    public void testCheckEffectiveAndEndDates_Neg_3() throws Exception
    {
        boolean flag;
        DateRecord dateRecord = new DateRecord();
        dateRecord.setRecordEffectiveDate( convertStringToLocalDate( "09/03/1997" ) );
        dateRecord.setRecordEndDate( null );
        flag = VBRDateUtils.checkEffectiveAndEndDates( dateRecord );
        Assert.assertTrue( flag == false );

    }

    /***************
     * checkEffectiveAndEndDatesList(List<DateRecord> dateRecordsList)
     * 
     * @throws Exception
     *****************************/
    @Test
    public void testCheckEffectiveAndEndDatesList() throws Exception
    {
        boolean flag;
        DateRecord dr1 = new DateRecord();
        dr1.setRecordEffectiveDate( convertStringToLocalDate( "01/01/2019" ) );
        dr1.setRecordEndDate( convertStringToLocalDate( "01/31/2019" ) );
        DateRecord dr2 = new DateRecord();
        dr2.setRecordEffectiveDate( convertStringToLocalDate( "01/01/2019" ) );
        dr2.setRecordEndDate( convertStringToLocalDate( "02/28/2019" ) );
        List<DateRecord> drList = new ArrayList<DateRecord>();
        drList.add( dr1 );
        drList.add( dr2 );
        flag = VBRDateUtils.checkEffectiveAndEndDatesList( drList );
        Assert.assertTrue( flag == true );

    }

    @Test
    public void testCheckEffectiveAndEndDatesList_Neg_1() throws Exception
    {
        boolean flag;
        DateRecord dr1 = new DateRecord();
        dr1.setRecordEffectiveDate( null );
        dr1.setRecordEndDate( convertStringToLocalDate( "01/31/2019" ) );
        DateRecord dr2 = new DateRecord();
        dr2.setRecordEffectiveDate( convertStringToLocalDate( "01/01/2019" ) );
        dr2.setRecordEndDate( convertStringToLocalDate( "02/28/2019" ) );
        List<DateRecord> drList = new ArrayList<DateRecord>();
        drList.add( dr1 );
        drList.add( dr2 );
        flag = VBRDateUtils.checkEffectiveAndEndDatesList( drList );
        Assert.assertTrue( flag == false );

    }

    /***************
     * getLastDayOfMonth(LocalDate endDate)
     * @throws Exception 
     * 
     *****************************/
    @Test
    public void testgetLastDayOfMonth() throws Exception
    {
        VBRDateUtils.getLastDayOfMonth( LocalDate.now() );
    }

    /***************
     * isThisDateValid(String Date)
     * 
     * 
     *****************************/
    @Test
    public void testisThisDateValid()
    {
        boolean flag;
        flag = VBRDateUtils.isThisDateValid( "01/01/2019" );
        Assert.assertTrue( flag == true );
    }

    @Test
    public void testisThisDateValid_Neg_1()
    {
        boolean flag;
        flag = VBRDateUtils.isThisDateValid( null );
        Assert.assertTrue( flag == false );
    }

    @Test
    public void testisThisDateValid_Neg_2()
    {
        boolean flag;
        flag = VBRDateUtils.isThisDateValid( "4/31/2019" );
        Assert.assertTrue( flag == false );
    }

    @Test
    public void testisThisDateValid_Neg_3()
    {
        boolean flag;
        flag = VBRDateUtils.isThisDateValid( "2/31/2019" );
        Assert.assertTrue( flag == false );
    }

    /***************
     * getProcessingMonth(LocalDate endDate)
     *
     *****************************/
    @Test
    public void testgetProcessingMonth()
    {
        VBRDateUtils.getProcessingMonth( LocalDate.now() );
    }

    /***************
     *checkVoidDate( DateRecord dateRecord )
     * 
     *****************************/
    @Test
    public void testCheckVoidDate()
    {
        boolean flag;
        DateRecord dr = new DateRecord();
        dr.setRecordEffectiveDate( convertStringToLocalDate( "01/01/2019" ) );
        dr.setRecordEndDate( convertStringToLocalDate( "02/28/2019" ) );
        flag = VBRDateUtils.checkVoidDate( dr );
        Assert.assertTrue( flag = true );
    }

    /***************
     *removeVoidDates(List<DateRecord> dateRecordsList )
     * 
     *****************************/
    @Test
    public void testRemoveVoidDates()
    {
        DateRecord dr1 = new DateRecord();
        dr1.setRecordEffectiveDate( convertStringToLocalDate( "01/01/2019" ) );
        dr1.setRecordEndDate( convertStringToLocalDate( "01/31/2019" ) );
        DateRecord dr2 = new DateRecord();
        dr2.setRecordEffectiveDate( convertStringToLocalDate( "01/01/2019" ) );
        dr2.setRecordEndDate( convertStringToLocalDate( "02/28/2019" ) );
        List<DateRecord> drList = new ArrayList<DateRecord>();
        drList.add( dr1 );
        drList.add( dr2 );
        VBRDateUtils.removeVoidDates( drList );
    }

    @Test
    public void testCheckVoidDate_Neg_1()
    {
        boolean flag;
        DateRecord dr = new DateRecord();
        dr.setRecordEffectiveDate( convertStringToLocalDate( "01/01/2019" ) );
        dr.setRecordEndDate( convertStringToLocalDate( "01/01/2019" ) );
        flag = VBRDateUtils.checkVoidDate( dr );
        Assert.assertTrue( flag = true );
    }

    /***************
     *isNotSameDay(DateRecord dateRecord)
     * 
     *****************************/
    @Test
    public void testIsNotSameDay()
    {
        boolean flag;
        DateRecord dr = new DateRecord();
        dr.setRecordEffectiveDate( convertStringToLocalDate( "01/01/2019" ) );
        dr.setRecordEndDate( convertStringToLocalDate( "01/01/2019" ) );
        flag = VBRDateUtils.isNotSameDay( dr );
        Assert.assertTrue( flag = true );
    }

    @Test
    public void testIsNotSameDay_Neg_1()
    {
        boolean flag;
        DateRecord dr = new DateRecord();
        dr.setRecordEffectiveDate( convertStringToLocalDate( "01/01/2019" ) );
        dr.setRecordEndDate( convertStringToLocalDate( "01/31/2019" ) );
        flag = VBRDateUtils.isNotSameDay( dr );
        Assert.assertTrue( flag = true );
    }

    /**********************
     * Utility methods for TestCases
     * 
     * @throws ParseException
     *********************************************/
    private Date convertStrToDate( String str ) throws ParseException
    {
        Date date = null;
        DateFormat formatter = new SimpleDateFormat( "MM/dd/yyyy" );
        date = formatter.parse( str );
        return date;
    }

    private LocalDate convertStringToLocalDate( String str )
    {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern( "MM/dd/yyyy" );
        LocalDate localDate = LocalDate.parse( str,
                                               formatter );
        return localDate;
    }

    private List<DateRecord> getDateRecordList()
    {
        DateRecord dr1 = new DateRecord();
        dr1.setRecordEffectiveDate( convertStringToLocalDate( "09/21/1993" ) );
        dr1.setRecordEndDate( convertStringToLocalDate( "09/21/2035" ) );
        LOGGER.info( "Parent1 Eff & End Date " + dr1.getRecordEffectiveDate() + " " + dr1.getRecordEndDate() );

        DateRecord dr2 = new DateRecord();
        dr2.setRecordEffectiveDate( convertStringToLocalDate( "09/21/2001" ) );
        dr2.setRecordEndDate( convertStringToLocalDate( "09/21/2019" ) );
        LOGGER.info( "Parent2 Eff & End Date " + dr2.getRecordEffectiveDate() + " " + dr2.getRecordEndDate() );

        List<DateRecord> drList = new ArrayList<DateRecord>();
        drList.add( dr1 );
        drList.add( dr2 );
        return drList;
    }

    @Test
    public void testToString()
    {
        BaseEntityDTO dto = new BaseEntityDTO();
        dto.setCreateUserId( "89767" );
        dto.setUpdateUserId( "8977" );
        dto.setCreateRecordTimestamp( LocalDateTime.now() );
        dto.setUpdateRecordTimestamp( LocalDateTime.now() );

        DateRecordDTO dto1 = new DateRecordDTO();
        dto1.setCreateUserId( "8788" );
        dto1.setUpdateUserId( "454" );
        dto1.setRecordEffectiveDate( "09/21/2035" );
        dto1.setCreateRecordTimestamp( LocalDateTime.now() );
        dto1.setRecordEndDate( "09/21/2035" );
        dto1.setUpdateRecordTimestamp( LocalDateTime.now() );
    }

}
