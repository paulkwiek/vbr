package com.hcsc.vbr.common.mapper;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.Test;

import com.hcsc.vbr.common.domain.BaseEntity;
import com.hcsc.vbr.common.dto.BaseEntityDTO;

public class BaseEntityMapperImplTest
{

    @Test
    public void testToBaseEntity()
    {

        BaseEntity baseEntity = BaseEntityMapper.INSTANCE.toBaseEntity( getBaseEntityDTO() );
        Assert.assertEquals( LocalDateTime.of( 2016,
                                               07,
                                               14,
                                               17,
                                               18 ),
                             baseEntity.getCreateRecordTimestamp() );
        Assert.assertEquals( "u399187",
                             baseEntity.getCreateUserId() );

        Assert.assertEquals( "u454566",
                             baseEntity.getUpdateUserId() );
        Assert.assertEquals( LocalDateTime.of( 2018,
                                               07,
                                               14,
                                               17,
                                               18 ),
                             baseEntity.getUpdateRecordTimestamp() );

    }

    @Test
    public void testToBaseEntity_Neg()
    {
        BaseEntity baseEntity = BaseEntityMapper.INSTANCE.toBaseEntity( null );
        Assert.assertTrue( baseEntity == null );
    }

    @Test
    public void testToBaseEntityDTO()
    {
        BaseEntityDTO baseEntityDTO = BaseEntityMapper.INSTANCE.toBaseEntityDTO( getBaseEntity() );
        Assert.assertEquals( LocalDateTime.of( 2016,
                                               07,
                                               14,
                                               17,
                                               18 ),
                             baseEntityDTO.getCreateRecordTimestamp() );
        Assert.assertEquals( "u399187",
                             baseEntityDTO.getCreateUserId() );
        Assert.assertEquals( "u454566",
                             baseEntityDTO.getUpdateUserId() );
        Assert.assertEquals( LocalDateTime.of( 2018,
                                               07,
                                               14,
                                               17,
                                               18 ),
                             baseEntityDTO.getUpdateRecordTimestamp() );
    }

    @Test
    public void testToBaseEntityDTO_Neg()
    {
        BaseEntityDTO baseEntityDTO = BaseEntityMapper.INSTANCE.toBaseEntityDTO( null );
        Assert.assertTrue( baseEntityDTO == null );
    }

    @Test
    public void testToBaseEntityDTOs()
    {
        List<BaseEntityDTO> baseEntityDTOList = BaseEntityMapper.INSTANCE.toBaseEntityDTOs( getBaseEntityList() );

        Assert.assertEquals( LocalDateTime.of( 2016,
                                               07,
                                               14,
                                               17,
                                               18 ),
                             baseEntityDTOList.get( 0 ).getCreateRecordTimestamp() );
        Assert.assertEquals( "u399187",
                             baseEntityDTOList.get( 0 ).getCreateUserId() );
        Assert.assertEquals( LocalDateTime.of( 2018,
                                               07,
                                               14,
                                               17,
                                               18 ),
                             baseEntityDTOList.get( 0 ).getUpdateRecordTimestamp() );
        Assert.assertEquals( "u454566",
                             baseEntityDTOList.get( 0 ).getUpdateUserId() );
    }

    @Test
    public void testToBaseEntityDTOs_Neg()
    {
        List<BaseEntityDTO> baseEntityDTOList = BaseEntityMapper.INSTANCE.toBaseEntityDTOs( null );
        Assert.assertTrue( baseEntityDTOList == null );
    }

    @Test
    public void testToBaseEntitys()
    {
        List<BaseEntity> baseEntityList = BaseEntityMapper.INSTANCE.toBaseEntitys( getBaseEntityDTOList() );

        Assert.assertEquals( LocalDateTime.of( 2016,
                                               07,
                                               14,
                                               17,
                                               18 ),
                             baseEntityList.get( 0 ).getCreateRecordTimestamp() );
        Assert.assertEquals( "u399187",
                             baseEntityList.get( 0 ).getCreateUserId() );

        Assert.assertEquals( LocalDateTime.of( 2018,
                                               07,
                                               14,
                                               17,
                                               18 ),
                             baseEntityList.get( 0 ).getUpdateRecordTimestamp() );
        Assert.assertEquals( "u454566",
                             baseEntityList.get( 0 ).getUpdateUserId() );
    }

    @Test
    public void testToBaseEntitys_Neg()
    {
        List<BaseEntity> baseEntityList = BaseEntityMapper.INSTANCE.toBaseEntitys( null );
        Assert.assertTrue( baseEntityList == null );
    }

    private BaseEntityDTO getBaseEntityDTO()
    {
        BaseEntityDTO dto = new BaseEntityDTO();
        dto.setCreateRecordTimestamp( LocalDateTime.of( 2016,
                                                        07,
                                                        14,
                                                        17,
                                                        18 ) );
        dto.setCreateUserId( "u399187" );
        dto.setUpdateRecordTimestamp( LocalDateTime.of( 2018,
                                                        07,
                                                        14,
                                                        17,
                                                        18 ) );
        dto.setUpdateUserId( "u454566" );
        return dto;

    }

    private BaseEntity getBaseEntity()
    {
        BaseEntity entity = new BaseEntity();
        entity.setCreateRecordTimestamp( LocalDateTime.of( 2016,
                                                           07,
                                                           14,
                                                           17,
                                                           18 ) );
        entity.setCreateUserId( "u399187" );
        entity.setUpdateRecordTimestamp( LocalDateTime.of( 2018,
                                                           07,
                                                           14,
                                                           17,
                                                           18 ) );
        entity.setUpdateUserId( "u454566" );
        return entity;

    }

    private List<BaseEntity> getBaseEntityList()
    {

        List<BaseEntity> list = new ArrayList<BaseEntity>();
        list.add( getBaseEntity() );
        return list;
    }

    private List<BaseEntityDTO> getBaseEntityDTOList()
    {

        List<BaseEntityDTO> list = new ArrayList<BaseEntityDTO>();
        list.add( getBaseEntityDTO() );
        return list;
    }

}
