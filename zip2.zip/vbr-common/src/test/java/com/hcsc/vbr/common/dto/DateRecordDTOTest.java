package com.hcsc.vbr.common.dto;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class DateRecordDTOTest
{
    private DateRecordDTO dateRecordDTO;

    @Before
    public void setUp()
    {
        dateRecordDTO = new DateRecordDTO();
    }

    @Test
    public void testDateRecord()
    {

        dateRecordDTO.setRecordEffectiveDate( "01/01/2019" );
        dateRecordDTO.setRecordEndDate( "01/31/2019" );

        Assert.assertTrue( dateRecordDTO != null );

        Assert.assertEquals( "01/01/2019",
                             dateRecordDTO.getRecordEffectiveDate() );
        Assert.assertEquals( "01/31/2019",
                             dateRecordDTO.getRecordEndDate() );
        Assert.assertTrue( dateRecordDTO.toString() != null );

    }
}
