package com.hcsc.vbr.common.dto;

import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class ReturnMessageDTOTest
{
    private ReturnMessageDTO returnMessageDTO;

    @Before
    public void setUp()
    {
        returnMessageDTO = new ReturnMessageDTO();
        returnMessageDTO = new ReturnMessageDTO( "Item" );
    }

    @Test
    public void testReturnMessageDTO()
    {
        returnMessageDTO.setItemName( "ItemName" );
        returnMessageDTO.setStatus( "Status" );
        returnMessageDTO.setErrors( getErrors() );
        returnMessageDTO.setTempList( getErrors() );
        returnMessageDTO.setWarnings( getErrors() );
        returnMessageDTO.add( getErrors() );
        returnMessageDTO.add( getErrorMessage() );
        returnMessageDTO.add( "rateName",
                              getErrorMessage() );
        returnMessageDTO.add( "Id",
                              null );
        returnMessageDTO.addToTempList( "rateName",
                                        Long.valueOf( 11 ),
                                        "keyvalues" );
        Assert.assertTrue( returnMessageDTO.toString().contains( "itemName=ItemName" ) );

    }

    private ErrorMessageDTO getErrorMessage()
    {
        ErrorMessageDTO errorMessageDTO = new ErrorMessageDTO();
        errorMessageDTO.setComponentName( "rateName" );
        errorMessageDTO.setErrorMessageCategoryCode( "RTNM" );
        errorMessageDTO.setErrorMessageId( 11L );
        errorMessageDTO.setErrorMsgDescriptionText( "Name Already Exists" );
        errorMessageDTO.setFieldId( "rateName" );
        errorMessageDTO.setSeveritylevel( "E" );
        errorMessageDTO.setKeyValues( "keyvalues" );
        errorMessageDTO.setValidationClass( "RateName" );
        returnMessageDTO.add( errorMessageDTO );
        return errorMessageDTO;
    }

    private List<ErrorMessageDTO> getErrors()
    {
        List<ErrorMessageDTO> errors = new ArrayList<ErrorMessageDTO>();
        ErrorMessageDTO error = new ErrorMessageDTO();
        error.setComponentName( "rateName" );
        error.setErrorMessageCategoryCode( "RTNM" );
        error.setErrorMessageId( 11L );
        error.setErrorMsgDescriptionText( "Name Already Exists" );
        error.setFieldId( "rateName" );
        error.setSeveritylevel( "E" );
        error.setKeyValues( "keyvalues" );
        error.setValidationClass( "RateName" );

        ErrorMessageDTO warning = new ErrorMessageDTO();
        warning.setComponentName( "rateName" );
        warning.setErrorMessageCategoryCode( "RTNM" );
        warning.setErrorMessageId( 11L );
        warning.setErrorMsgDescriptionText( "Name Already Exists" );
        warning.setFieldId( "rateName" );
        warning.setSeveritylevel( "W" );
        warning.setKeyValues( "keyvalues" );
        warning.setValidationClass( "RateName" );

        ErrorMessageDTO others = new ErrorMessageDTO();
        others.setComponentName( "rateName" );
        others.setErrorMessageCategoryCode( "RTNM" );
        others.setErrorMessageId( 11L );
        others.setErrorMsgDescriptionText( "Name Already Exists" );
        others.setFieldId( "rateName" );
        others.setSeveritylevel( "" );
        others.setKeyValues( "keyvalues" );
        others.setValidationClass( "RateName" );

        errors.add( error );
        errors.add( warning );
        errors.add( others );

        return errors;
    }
}
