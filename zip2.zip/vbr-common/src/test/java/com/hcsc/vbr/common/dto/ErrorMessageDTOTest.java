package com.hcsc.vbr.common.dto;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class ErrorMessageDTOTest
{
    private ErrorMessageDTO errorMessageDTO;

    @Before
    public void setUp()
    {
        errorMessageDTO = new ErrorMessageDTO();
    }

    @Test
    public void testErrorMessage()
    {
        errorMessageDTO.setComponentName( "RTNM" );
        errorMessageDTO.setErrorMessageCategoryCode( "PCF-PMAM" );
        errorMessageDTO.setErrorMessageId( 1L );
        errorMessageDTO.setErrorMsgDescriptionText( "Name Already Exists" );
        errorMessageDTO.setFieldId( "RATEID" );
        errorMessageDTO.setKeyValues( "KV" );
        errorMessageDTO.setSeveritylevel( "E" );
        errorMessageDTO.setValidationClass( "ErrorMessage" );

        Assert.assertTrue( errorMessageDTO != null );
        Assert.assertEquals( "RTNM",
                             errorMessageDTO.getComponentName() );
        Assert.assertEquals( "PCF-PMAM",
                             errorMessageDTO.getErrorMessageCategoryCode() );
        Assert.assertEquals( Long.valueOf( "1" ),
                             errorMessageDTO.getErrorMessageId() );
        Assert.assertEquals( "Name Already Exists",
                             errorMessageDTO.getErrorMsgDescriptionText() );
        Assert.assertEquals( "RATEID",
                             errorMessageDTO.getFieldId() );
        Assert.assertEquals( "KV",
                             errorMessageDTO.getKeyValues() );
        Assert.assertEquals( "E",
                             errorMessageDTO.getSeveritylevel() );
        Assert.assertEquals( "ErrorMessage",
                             errorMessageDTO.getValidationClass() );
        Assert.assertTrue( errorMessageDTO.toString().contains( "componentName=RTNM" ) );
    }
}
