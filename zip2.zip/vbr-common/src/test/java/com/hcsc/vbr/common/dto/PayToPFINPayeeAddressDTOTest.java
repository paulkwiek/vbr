package com.hcsc.vbr.common.dto;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class PayToPFINPayeeAddressDTOTest
{
    private PayToPFINPayeeAddressDTO payToPFINPayeeAddressDTO;

    @Before
    public void setUp()
    {
        payToPFINPayeeAddressDTO = new PayToPFINPayeeAddressDTO();
    }

    @Test
    public void testPayToPFINPayeeAddress()
    {
        payToPFINPayeeAddressDTO.setAddressLine1( "ADDL1" );
        payToPFINPayeeAddressDTO.setAddressLine2( "ADDL2" );
        payToPFINPayeeAddressDTO.setCity( "EAGLE WAY" );
        payToPFINPayeeAddressDTO.setState( "CHICAGO" );
        payToPFINPayeeAddressDTO.setZipCode( "606781095" );

        Assert.assertTrue( payToPFINPayeeAddressDTO != null );
        Assert.assertEquals( "ADDL1",
                             payToPFINPayeeAddressDTO.getAddressLine1() );
        Assert.assertEquals( "ADDL2",
                             payToPFINPayeeAddressDTO.getAddressLine2() );
        Assert.assertEquals( "EAGLE WAY",
                             payToPFINPayeeAddressDTO.getCity() );
        Assert.assertEquals( "CHICAGO",
                             payToPFINPayeeAddressDTO.getState() );
        Assert.assertEquals( "606781095",
                             payToPFINPayeeAddressDTO.getZipCode() );
        Assert.assertTrue( payToPFINPayeeAddressDTO.toString().contains( "city=EAGLE WAY" ) );
    }
}
