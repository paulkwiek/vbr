package com.hcsc.vbr.common.domain;

import java.time.LocalDateTime;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class BaseEntityTest
{
    private BaseEntity baseEntity;

    @Before
    public void setUp()
    {
        baseEntity = new BaseEntity();
    }

    @Test
    public void testBaseEntity()
    {
        baseEntity.setCreateRecordTimestamp( LocalDateTime.parse( "2019-04-28T16:00:49" ) );
        baseEntity.setCreateUserId( "IL1" );
        baseEntity.setUpdateRecordTimestamp( LocalDateTime.parse( "2019-04-29T16:00:49" ) );
        baseEntity.setUpdateUserId( "MEM123" );

        Assert.assertTrue( baseEntity != null );

        Assert.assertEquals( "IL1",
                             baseEntity.getCreateUserId() );
        Assert.assertEquals( "MEM123",
                             baseEntity.getUpdateUserId() );

        Assert.assertEquals( LocalDateTime.of( 2019,
                                               04,
                                               28,
                                               16,
                                               00,
                                               49 ),
                             baseEntity.getCreateRecordTimestamp() );
        Assert.assertEquals( LocalDateTime.of( 2019,
                                               04,
                                               29,
                                               16,
                                               00,
                                               49 ),
                             baseEntity.getUpdateRecordTimestamp() );

        Assert.assertTrue( baseEntity.toString().contains( "createUserId=IL1" ) );

    }

}
