package com.hcsc.vbr.common.mapper;

import java.text.ParseException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.Test;

import com.hcsc.vbr.common.domain.DateRecord;
import com.hcsc.vbr.common.dto.DateRecordDTO;
import com.hcsc.vbr.common.utils.VBRDateUtils;

public class DateRecordMapperImplTest
{

    @Test
    public void testToDateRecordDTO() throws ParseException
    {
        DateRecordDTO dto = DateRecordMapper.INSTANCE.toDateRecordDTO( getDateRecord() );
        Assert.assertEquals( "u3456789",
                             dto.getCreateUserId() );
        Assert.assertEquals( LocalDateTime.of( 2018,
                                               2,
                                               16,
                                               05,
                                               22 ),
                             dto.getCreateRecordTimestamp() );
        Assert.assertEquals( "u567894",
                             dto.getUpdateUserId() );
        Assert.assertEquals( "2019-06-04",
                             dto.getRecordEffectiveDate() );
        Assert.assertEquals( "2019-02-08",
                             dto.getRecordEndDate() );
        Assert.assertEquals( LocalDateTime.of( 2019,
                                               3,
                                               4,
                                               5,
                                               6 ),
                             dto.getUpdateRecordTimestamp() );
    }

    @Test
    public void testToDateRecordDTO_Neg()
    {
        DateRecordDTO dto = DateRecordMapper.INSTANCE.toDateRecordDTO( null );
        Assert.assertTrue( dto == null );
    }

    @Test
    public void testToDateRecord()
    {
        DateRecord dateRecord = DateRecordMapper.INSTANCE.toDateRecord( getDateRecordDTO() );
        Assert.assertEquals( "u3456789",
                             dateRecord.getCreateUserId() );
        Assert.assertEquals( LocalDateTime.of( 2018,
                                               2,
                                               16,
                                               05,
                                               22 ),
                             dateRecord.getCreateRecordTimestamp() );

        Assert.assertEquals( "u567894",
                             dateRecord.getUpdateUserId() );
        Assert.assertEquals( "06/04/2019",
                             VBRDateUtils.convertLocalDateToString( dateRecord.getRecordEffectiveDate() ) );
        Assert.assertEquals( "08/02/2019",
                             VBRDateUtils.convertLocalDateToString( dateRecord.getRecordEndDate() ) );
        Assert.assertEquals( LocalDateTime.of( 2019,
                                               3,
                                               4,
                                               5,
                                               6 ),
                             dateRecord.getUpdateRecordTimestamp() );
    }

    @Test
    public void testToDateRecord_Neg()
    {
        DateRecord dateRecord = DateRecordMapper.INSTANCE.toDateRecord( null );
        Assert.assertTrue( dateRecord == null );
    }

    @Test
    public void testToDateRecordDTOs()
    {
        List<DateRecordDTO> dateRecordDTOList = DateRecordMapper.INSTANCE.toDateRecordDTOs( getDateRecordList() );
        Assert.assertEquals( LocalDateTime.of( 2018,
                                               2,
                                               16,
                                               05,
                                               22 ),
                             dateRecordDTOList.get( 0 ).getCreateRecordTimestamp() );
        Assert.assertEquals( "u3456789",
                             dateRecordDTOList.get( 0 ).getCreateUserId() );
        Assert.assertEquals( "2019-06-04",
                             dateRecordDTOList.get( 0 ).getRecordEffectiveDate() );
        Assert.assertEquals( "2019-02-08",
                             dateRecordDTOList.get( 0 ).getRecordEndDate() );
        Assert.assertEquals( LocalDateTime.of( 2019,
                                               3,
                                               4,
                                               5,
                                               6 ),
                             dateRecordDTOList.get( 0 ).getUpdateRecordTimestamp() );
        Assert.assertEquals( "u567894",
                             dateRecordDTOList.get( 0 ).getUpdateUserId() );
    }

    @Test
    public void testToDateRecordDTOs_Neg()
    {
        List<DateRecordDTO> dateRecordDTOList = DateRecordMapper.INSTANCE.toDateRecordDTOs( null );
        Assert.assertTrue( dateRecordDTOList == null );
    }

    @Test
    public void testToDateRecords()
    {
        List<DateRecord> dateRecordList = DateRecordMapper.INSTANCE.toDateRecords( getDateRecordDTOList() );
        Assert.assertEquals( "u3456789",
                             dateRecordList.get( 0 ).getCreateUserId() );

        Assert.assertEquals( "u567894",
                             dateRecordList.get( 0 ).getUpdateUserId() );
        Assert.assertEquals( LocalDateTime.of( 2018,
                                               2,
                                               16,
                                               05,
                                               22 ),
                             dateRecordList.get( 0 ).getCreateRecordTimestamp() );
        Assert.assertEquals( "06/04/2019",
                             VBRDateUtils.convertLocalDateToString( dateRecordList.get( 0 ).getRecordEffectiveDate() ) );
        Assert.assertEquals( "08/02/2019",
                             VBRDateUtils.convertLocalDateToString( dateRecordList.get( 0 ).getRecordEndDate() ) );
        Assert.assertEquals( LocalDateTime.of( 2019,
                                               3,
                                               4,
                                               5,
                                               6 ),
                             dateRecordList.get( 0 ).getUpdateRecordTimestamp() );

    }

    @Test
    public void testToDateRecords_Neg()
    {
        List<DateRecord> dateRecordList = DateRecordMapper.INSTANCE.toDateRecords( null );
        Assert.assertTrue( dateRecordList == null );
    }

    private DateRecord getDateRecord()
    {
        DateRecord dateRecord = new DateRecord();
        dateRecord.setCreateRecordTimestamp( LocalDateTime.of( 2018,
                                                               2,
                                                               16,
                                                               05,
                                                               22 ) );
        dateRecord.setCreateUserId( "u3456789" );
        dateRecord.setRecordEffectiveDate( LocalDate.of( 2019,
                                                         06,
                                                         04 ) );
        dateRecord.setRecordEndDate( LocalDate.of( 2019,
                                                   2,
                                                   8 ) );
        dateRecord.setUpdateRecordTimestamp( LocalDateTime.of( 2019,
                                                               3,
                                                               4,
                                                               5,
                                                               6 ) );
        dateRecord.setUpdateUserId( "u567894" );
        return dateRecord;

    }

    private DateRecordDTO getDateRecordDTO()
    {
        DateRecordDTO dto = new DateRecordDTO();
        dto.setCreateRecordTimestamp( LocalDateTime.of( 2018,
                                                        2,
                                                        16,
                                                        05,
                                                        22 ) );
        dto.setCreateUserId( "u3456789" );
        dto.setRecordEffectiveDate( "06/04/2019" );
        dto.setRecordEndDate( "08/02/2019" );
        dto.setUpdateRecordTimestamp( LocalDateTime.of( 2019,
                                                        3,
                                                        4,
                                                        5,
                                                        6 ) );

        dto.setUpdateUserId( "u567894" );
        return dto;

    }

    private List<DateRecordDTO> getDateRecordDTOList()
    {
        List<DateRecordDTO> list = new ArrayList<DateRecordDTO>();
        list.add( getDateRecordDTO() );
        return list;
    }

    private List<DateRecord> getDateRecordList()
    {
        List<DateRecord> list = new ArrayList<DateRecord>();
        list.add( getDateRecord() );
        return list;
    }

}
