package com.hcsc.vbr.common.dto;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class ReturnMessageSubItemDTOTest
{
    private ReturnMessageSubItemDTO returnMessageSubItemDTO;

    @Before
    public void setUp()
    {
        returnMessageSubItemDTO = new ReturnMessageSubItemDTO();
    }

    @Test
    public void testReturnMessageSubItemDTO()
    {
        returnMessageSubItemDTO.setMessage( "Message" );
        returnMessageSubItemDTO.setMessageId( 1L );
        returnMessageSubItemDTO.setSubItemId( "SubId" );
        returnMessageSubItemDTO.setValues( "Values" );

        Assert.assertTrue( returnMessageSubItemDTO != null );
        Assert.assertEquals( "Message",
                             returnMessageSubItemDTO.getMessage() );
        Assert.assertEquals( "SubId",
                             returnMessageSubItemDTO.getSubItemId() );
        Assert.assertEquals( "Values",
                             returnMessageSubItemDTO.getValues() );
        Assert.assertEquals( Long.valueOf( 1 ),
                             returnMessageSubItemDTO.getMessageId() );

        Assert.assertTrue( returnMessageSubItemDTO.toString().contains( "message=Message" ) );
    }

}
