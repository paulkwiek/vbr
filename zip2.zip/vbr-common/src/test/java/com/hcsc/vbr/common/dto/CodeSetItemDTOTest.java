package com.hcsc.vbr.common.dto;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class CodeSetItemDTOTest
{
    private CodeSetItemDTO codeSetItemDTO;

    @Before
    public void setUp()
    {
        codeSetItemDTO = new CodeSetItemDTO();
    }

    @Test
    public void testCodeSetItem()
    {
        codeSetItemDTO.setCodeSetKey( "CD_KEY" );
        codeSetItemDTO.setCodeValueText( "CD_VALUE" );
        codeSetItemDTO.setCorporateEntityCode( "NM1" );
        codeSetItemDTO.setDescription( "DESC" );

        Assert.assertTrue( codeSetItemDTO != null );
        Assert.assertEquals( "CD_KEY",
                             codeSetItemDTO.getCodeSetKey() );
        Assert.assertEquals( "CD_VALUE",
                             codeSetItemDTO.getCodeValueText() );
        Assert.assertEquals( "DESC",
                             codeSetItemDTO.getDescription() );
        Assert.assertEquals( "NM1",
                             codeSetItemDTO.getCorporateEntityCode() );
        Assert.assertTrue( codeSetItemDTO.toString().contains( "corporateEntityCode=NM1" ) );

    }
}
