package com.hcsc.vbr.common.dto;

import java.time.LocalDateTime;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class BaseEntityDTOTest
{
    private BaseEntityDTO baseEntityDTO;

    @Before
    public void setUp()
    {
        baseEntityDTO = new BaseEntityDTO();
    }

    @Test
    public void testBaseEntityDTO()
    {
        baseEntityDTO.setCreateRecordTimestamp( LocalDateTime.parse( "2019-04-28T16:00:49" ) );
        baseEntityDTO.setCreateUserId( "IL1" );
        baseEntityDTO.setUpdateRecordTimestamp( LocalDateTime.parse( "2019-04-29T16:00:49" ) );
        baseEntityDTO.setUpdateUserId( "MEM123" );

        Assert.assertTrue( baseEntityDTO != null );

        Assert.assertEquals( "IL1",
                             baseEntityDTO.getCreateUserId() );
        Assert.assertEquals( "MEM123",
                             baseEntityDTO.getUpdateUserId() );
        Assert.assertEquals( LocalDateTime.of( 2019,
                                               04,
                                               28,
                                               16,
                                               00,
                                               49 ),
                             baseEntityDTO.getCreateRecordTimestamp() );
        Assert.assertEquals( LocalDateTime.of( 2019,
                                               04,
                                               29,
                                               16,
                                               00,
                                               49 ),
                             baseEntityDTO.getUpdateRecordTimestamp() );

        Assert.assertTrue( baseEntityDTO.toString().contains( "Entity" ) );

    }

}
