package com.hcsc.vbr.common.domain;

import java.time.LocalDate;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class DateRecordTest
{
    private DateRecord dateRecord;

    @Before
    public void setUp()
    {
        dateRecord = new DateRecord();
    }

    @Test
    public void testDateRecord()
    {

        dateRecord.setRecordEffectiveDate( LocalDate.parse( "2019-04-28" ) );
        dateRecord.setRecordEndDate( LocalDate.parse( "2019-04-29" ) );

        Assert.assertTrue( dateRecord != null );

        Assert.assertEquals( LocalDate.of( 2019,
                                           04,
                                           28 ),
                             dateRecord.getRecordEffectiveDate() );
        Assert.assertEquals( LocalDate.of( 2019,
                                           04,
                                           29 ),
                             dateRecord.getRecordEndDate() );
        Assert.assertTrue( dateRecord.toString() != null );

    }
}
