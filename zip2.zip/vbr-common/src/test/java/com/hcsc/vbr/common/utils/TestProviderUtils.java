package com.hcsc.vbr.common.utils;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.hcsc.vbr.web.response.ProviderApiDemographicsDTO;
import com.hcsc.vbr.web.response.ProviderApiDemographicsResponse;

public class TestProviderUtils
{
    private static final Logger LOGGER = LoggerFactory.getLogger( TestProviderUtils.class );

    @Test
    public void testMapBillingName()
    {
        String mapBillingName = ProviderUtils.mapBillingName( getDemographics() );
        assertTrue( !mapBillingName.isEmpty() );
    }

    @Test
    public void testMapBillingName_Neg_1()
    {
        String mapBillingName = ProviderUtils.mapBillingName( getDemographicsAsNull() );
        assertFalse( mapBillingName.isEmpty() );
    }

    private ProviderApiDemographicsResponse getDemographics()
    {
        ProviderApiDemographicsResponse response = new ProviderApiDemographicsResponse();
        ProviderApiDemographicsDTO demographicsDTO = new ProviderApiDemographicsDTO();
        demographicsDTO.setProviderFirstName( "FIRST" );
        demographicsDTO.setProviderLastName( "LAST" );
        demographicsDTO.setProviderOrganizationName( "ORG" );
        demographicsDTO.setProviderOrganizationSecondName( "ORG2" );
        demographicsDTO.setProviderTitleCode( "TITLE" );
        demographicsDTO.setProviderTitleDescription( "DESC" );
        response.setBilling( demographicsDTO );
        response.setOffice( demographicsDTO );
        return response;
    }

    private ProviderApiDemographicsResponse getDemographicsAsNull()
    {
        ProviderApiDemographicsResponse response = new ProviderApiDemographicsResponse();
        ProviderApiDemographicsDTO demographicsDTO = new ProviderApiDemographicsDTO();
        demographicsDTO.setProviderFirstName( "FIRST" );
        demographicsDTO.setProviderLastName( "LAST" );
        demographicsDTO.setProviderOrganizationName( null );
        demographicsDTO.setProviderOrganizationSecondName( "ORG2" );
        demographicsDTO.setProviderTitleCode( "TITLE" );
        demographicsDTO.setProviderTitleDescription( "DESC" );
        response.setBilling( demographicsDTO );
        response.setOffice( demographicsDTO );
        return response;
    }
}
