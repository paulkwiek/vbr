package com.hcsc.vbr.common.dto;

import java.io.Serializable;

import org.apache.commons.lang3.builder.ReflectionToStringBuilder;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.hcsc.vbr.common.utils.MultilineRecursiveToStringStyleCustom;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ProviderDTO implements Serializable
{

    private static final long serialVersionUID = 1L;

    private String corpCode;

    @JsonProperty( "PINGroupID" )
    private String pinGroupID;

    private String networkCode;

    private String payToPFIN;

    private String capitationTypeCode;

    private String processCode;

    private Integer networkAssociationID;

    @Override
    public String toString()
    {
        return new ReflectionToStringBuilder( this,
                                              new MultilineRecursiveToStringStyleCustom() ).toString();
    }
}
