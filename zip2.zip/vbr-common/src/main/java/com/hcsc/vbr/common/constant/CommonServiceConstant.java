package com.hcsc.vbr.common.constant;

public class CommonServiceConstant
{
    public static final String SUCCESS_VALIDATION_STATUS = "SUCCESS";
    public static final String FAILURE_VALIDATION_STATUS = "FAILED";
}