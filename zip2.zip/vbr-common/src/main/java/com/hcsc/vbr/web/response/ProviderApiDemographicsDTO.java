package com.hcsc.vbr.web.response;

import java.io.Serializable;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter

public class ProviderApiDemographicsDTO implements Serializable
{

    private static final long serialVersionUID = 5526141425666245910L;

    private String providerTitleCode;
    private String providerTitleDescription;
    private String providerFirstName;
    private String providerLastName;
    private String providerOrganizationName;
    private String providerOrganizationSecondName;

}
