package com.hcsc.vbr.common.constant;

public class CommonServiceErrorMessageConstant
{

    public static final Long NO_PAYEE_RECORDS_FOUND = Long.valueOf( 40 );

}
