package com.hcsc.vbr.common.dto;

import java.io.Serializable;

import org.apache.commons.lang3.builder.ReflectionToStringBuilder;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.hcsc.vbr.common.utils.MultilineRecursiveToStringStyleCustom;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonInclude( JsonInclude.Include.NON_NULL )
public class ErrorMessageDTO implements Serializable
{
    private static final long serialVersionUID = 1L;

    private String componentName;
    private String fieldId;
    private Long errorMessageId;
    private String errorMsgDescriptionText;
    private String severitylevel;
    private String errorMessageCategoryCode;
    private String validationClass;
    private String keyValues;

    //add parameter list with key,value pair and save in DB as dynamic msg, {parameter1}some text {parameter2}
    @Override
    public String toString()
    {
        return new ReflectionToStringBuilder( this,
                                              new MultilineRecursiveToStringStyleCustom() ).toString();
    }
}
