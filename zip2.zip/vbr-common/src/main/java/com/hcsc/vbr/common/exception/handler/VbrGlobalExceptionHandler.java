package com.hcsc.vbr.common.exception.handler;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.hcsc.vbr.common.constant.VBRCommonConstant;
import com.hcsc.vbr.common.dto.ErrorMessageDTO;
import com.hcsc.vbr.common.dto.ReturnMessageDTO;
import com.hcsc.vbr.common.exception.VbrApplicationException;
import com.hcsc.vbr.common.web.response.ReturnResponse;

@ControllerAdvice
public class VbrGlobalExceptionHandler
{

    private static final Logger logger = LoggerFactory.getLogger( VbrGlobalExceptionHandler.class );

    /**
    * Method: handleNewException
    * @param vbrApplicationException
    * @return
    * @throws Exception
    */
    @ExceptionHandler( VbrApplicationException.class )
    @ResponseStatus( HttpStatus.BAD_REQUEST ) //400
    @ResponseBody
    public ReturnResponse handleNewException( VbrApplicationException vbrApplicationException ) throws Exception
    {
        ReturnResponse returnMessageResponse = constructReturnResponse( vbrApplicationException );
        logger.error( vbrApplicationException.getMessage() );
        return returnMessageResponse;
    }

    /**
     * Method: constructReurnResponse
     * @param vbrApplicationException
     * @return
     */
    private ReturnResponse constructReturnResponse( VbrApplicationException vbrApplicationException )
    {
        ReturnResponse returnResponse = new ReturnResponse();
        returnResponse.setReturnMessage( vbrApplicationException.getReturnMessage() );
        return returnResponse;
    }

    /**
     * Method: handleException
     * @param ex
     * @return
     * @throws Exception
     */
    @ExceptionHandler( Exception.class )
    @ResponseStatus( HttpStatus.INTERNAL_SERVER_ERROR ) //500
    @ResponseBody
    public ReturnResponse handleException( Exception ex ) throws Exception
    {
        ReturnResponse returnResponse = constructExceptionResponse( ex );
        logger.error( ex.getMessage() );
        return returnResponse;
    }

    /**
     * Method: constructExceptionResponse
     * @param ex
     * @return
     * @throws Exception
     */
    private ReturnResponse constructExceptionResponse( Exception ex ) throws Exception
    {
        ReturnResponse returnResponse = new ReturnResponse();

        List<ErrorMessageDTO> errors = new ArrayList<ErrorMessageDTO>();

        ErrorMessageDTO errorMessage = new ErrorMessageDTO();
        errorMessage.setErrorMessageCategoryCode( VBRCommonConstant.DEFAULT_EXCEPTION_MESSAGE_CATEGORY_CODE );
        errorMessage.setErrorMessageId( VBRCommonConstant.DEFAULT_EXCEPTION_ERROR_MESSAGE_ID );
        errorMessage.setErrorMsgDescriptionText( VBRCommonConstant.DEFAULT_EXCEPTION_ERROR_MESSAGE_DESCRIPTION );
        errorMessage.setSeveritylevel( VBRCommonConstant.DEFAULT_EXCEPTION_SEVERITY_LVL );
        errors.add( errorMessage );

        ReturnMessageDTO returnMessage = new ReturnMessageDTO();
        returnMessage.add( errorMessage );
        returnResponse.setReturnMessage( returnMessage );

        return returnResponse;
    }

}
