package com.hcsc.vbr.common.validator.base;

public class VbrBaseValidator extends VbrBaseValidationUnit
{

    //TODO
}
