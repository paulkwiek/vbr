package com.hcsc.vbr.web.response;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ProviderApiAddressesResponse implements Serializable
{

    private static final long serialVersionUID = 7113507694604605731L;

    @JsonProperty( "office" )
    private ProviderApiAddressWrapperDTO officeAddress;

    @JsonProperty( "billing" )
    private ProviderApiAddressWrapperDTO billingAddress;

    private List<ProviderApiAddressDTO> directory;

}
