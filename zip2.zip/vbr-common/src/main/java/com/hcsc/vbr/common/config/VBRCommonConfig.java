package com.hcsc.vbr.common.config;


public class VBRCommonConfig {

}
