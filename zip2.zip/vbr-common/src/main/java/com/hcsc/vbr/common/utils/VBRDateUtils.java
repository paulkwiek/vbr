package com.hcsc.vbr.common.utils;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.time.temporal.TemporalAdjusters;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.CollectionUtils;

import com.hcsc.vbr.common.domain.DateRecord;

/**
 *This class contains common methods used for dateconversions and validations
 */

public class VBRDateUtils
{
    private static final Logger LOGGER = LoggerFactory.getLogger( VBRDateUtils.class );
    public static final String DATE_FORMAT = "MM/dd/yyyy";

    private static Pattern pattern;
    private static Matcher matcher;
    private static final String DATE_PATTERN = "(^(0[0-9]||1[0-2])/([0-2][0-9]||3[0-1])/([0-9][0-9])?[0-9][0-9]$)";

    /**
     * Method: convertDateToString
     * @param date
     * @return
     */
    public static String convertDateToString( Date date )
    {
        return new SimpleDateFormat( DATE_FORMAT ).format( date );

    }

    /**
     * Method: convertStringToDate
     * @param date
     * @return
     * @throws ParseException
     */
    public static Date convertStringToDate( String date ) throws ParseException
    {
        return new SimpleDateFormat( DATE_FORMAT ).parse( date );
    }

    /**
     * Method: checkDateCoverage
     * @param parent
     * @param child
     * @return
     * @throws Exception
     */
    public static boolean checkDateCoverage( DateRecord parent,
            DateRecord child ) throws Exception
    {
        return ( ( ( parent != null )
            && ( child != null )
            && ( parent.getRecordEffectiveDate() != null )
            && ( parent.getRecordEndDate() != null )
            && ( child.getRecordEffectiveDate() != null )
            && ( child.getRecordEndDate() != null ) )
            && ( ( ( parent.getRecordEffectiveDate().isEqual( child.getRecordEffectiveDate() ) )
                || ( parent.getRecordEffectiveDate().isBefore( child.getRecordEffectiveDate() ) ) )
                && ( ( ( parent.getRecordEndDate() ).isEqual( child.getRecordEndDate() ) )
                    || ( ( parent.getRecordEndDate() ).isAfter( child.getRecordEndDate() ) ) ) )

        ) ? true
            : false;
    }

    /**
     * Method: checkDateCoverage
     * @param parentList
     * @param child
     * @return
     * @throws Exception
     */
    public static boolean checkDateCoverage( List<? extends DateRecord> parentList,
            DateRecord child ) throws Exception
    {
        if( ( child == null ) || ( child.getRecordEffectiveDate() == null ) || ( child.getRecordEndDate() == null ) )
        {
            return false;
        }
        else if( CollectionUtils.isEmpty( parentList ) )
        {
            return false;
        }
        else
        {
            DateRecord parent = convertDateRecordListToDateRecordRange( parentList );
            return checkDateCoverage( parent,
                                      child );

        }

    }

    /**
     * Method: checkDateCoverage
     * @param parent
     * @param childList
     * @return
     * @throws Exception
     */
    public static boolean checkDateCoverage( DateRecord parent,
            List<? extends DateRecord> childList ) throws Exception
    {
        if( ( parent != null )
            && ( parent.getRecordEffectiveDate() != null )
            && ( parent.getRecordEndDate() != null )
            && ( convertLocalDateToString( parent.getRecordEffectiveDate() ) )
                    .equals( convertLocalDateToString( parent.getRecordEndDate() ) ) )
        {
            return false;
        }
        else if( CollectionUtils.isEmpty( childList ) )
        {
            return false;
        }
        else
        {
            DateRecord child = convertDateRecordListToDateRecordRange( childList );
            return checkDateCoverage( parent,
                                      child );

        }

    }

    /**
     * Method: checkDateCoverage
     * @param parent
     * @param childList
     * @return
     * @throws Exception
     */
    public static boolean checkDateCoverage( List<? extends DateRecord> parentList,
            List<? extends DateRecord> childList ) throws Exception
    {
        if( CollectionUtils.isEmpty( childList ) || CollectionUtils.isEmpty( parentList ) )
        {
            return false;
        }
        else
        {
            DateRecord parent = convertDateRecordListToDateRecordRange( parentList );
            DateRecord child = convertDateRecordListToDateRecordRange( childList );
            return checkDateCoverage( parent,
                                      child );

        }

    }

    /**
     * Method: checkNotIntersecting
     * @param List<DateRecord>
     * @return
     * @throws Exception
     */
    public static boolean checkNotIntersecting( List<? extends DateRecord> dateRecords ) throws Exception
    {
        if( !dateRecords.isEmpty() )
        {
            int size = dateRecords.size();

            for( int i = 0; i < size; i++ )
            {

                for( int j = i + 1; j < size; j++ )
                {
                    if( ( dateRecords.get( i ).getRecordEffectiveDate() != null
                        && dateRecords.get( i ).getRecordEndDate() != null
                        && dateRecords.get( j ).getRecordEffectiveDate() != null
                        && dateRecords.get( j ).getRecordEndDate() != null )
                        && ( !( dateRecords.get( i ).getRecordEffectiveDate().isBefore( dateRecords.get( j ).getRecordEndDate() )
                            && dateRecords.get( j ).getRecordEffectiveDate().isBefore( dateRecords.get( i ).getRecordEndDate() ) ) ) )
                    {
                        LOGGER.debug( " Doesn't overtlap" );

                    }
                    else
                    {
                        LOGGER.debug( " Overlaps" );
                        return false;
                    }
                }

            }
        }
        else
        {
            LOGGER.debug( "DateRecord List empty" );
            return false;
        }
        return true;

    }

    /**
     * Method: Check for No Gap in the dateRecords List
     * @param List<DateRecord>
     * @return checkForNoGapflag
     * @throws Exception
     */
    public static boolean checkForNoGaps( List<? extends DateRecord> dateRecords ) throws Exception
    {
        LOGGER.debug( "checkForNoGaps : START" );
        boolean checkForNoGapFlag = true;
        // Check if dateRecord is empty
        if( !CollectionUtils.isEmpty( dateRecords ) )
        {
            Collections.sort( dateRecords );

            for( int jCountDateRecord = 0; jCountDateRecord < dateRecords.size(); jCountDateRecord++ )
            {
                for( int kCountDateRecord = jCountDateRecord + 1; kCountDateRecord < dateRecords.size(); )
                {
                    // Call the below method to check if there is gap between two date records
                    checkForNoGapFlag = checkForNoGapBetweenTwoDateRecords( dateRecords.get( jCountDateRecord ),
                                                                            dateRecords.get( kCountDateRecord ) );
                    if( checkForNoGapFlag == Boolean.FALSE )
                    {
                        return checkForNoGapFlag;
                    }
                    break;
                }
            }
        }
        else
        {
            LOGGER.debug( "checkForNoGaps : DateRecord List is empty" );
            checkForNoGapFlag = false;
        }
        LOGGER.debug( "checkForNoGaps : END" );
        return checkForNoGapFlag;
    }

    /**
     * Method: Check for No Gap between two dateRecords
     * @param List<DateRecord>
     * @return checkForNoGapFlag
     * @throws Exception
     */
    public static boolean checkForNoGapBetweenTwoDateRecords( DateRecord dateRecord1,
            DateRecord dateRecord2 ) throws Exception
    {
        LOGGER.debug( "checkForNoGapBetweenTwoDateRecords : START" );
        //check for overlap condition
        boolean checkForNoGapFlag = true;

        //check for null in the date records
        if( null != dateRecord1.getRecordEffectiveDate()
            && null != dateRecord1.getRecordEndDate()
            && null != dateRecord2.getRecordEffectiveDate()
            && null != dateRecord2.getRecordEndDate() )
        {
            //check for void condition
            if( dateRecord1.getRecordEffectiveDate().equals( dateRecord2.getRecordEffectiveDate() )
                && dateRecord1.getRecordEndDate().equals( dateRecord2.getRecordEndDate() ) )
            {
                checkForNoGapFlag = true;
            }
            else
            {
                Period between = Period.between( dateRecord1.getRecordEndDate(),
                                                 dateRecord2.getRecordEffectiveDate() );

                long months = ChronoUnit.MONTHS.between( dateRecord1.getRecordEndDate(),
                                                         dateRecord2.getRecordEffectiveDate() );

                int days = between.getDays();

                if( ( dateRecord1.getRecordEffectiveDate().isBefore( dateRecord2.getRecordEndDate() )
                    || dateRecord1.getRecordEffectiveDate().equals( dateRecord2.getRecordEndDate() ) )
                    && ( ( days == 1 && months == 0 ) ) )

                {
                    checkForNoGapFlag = true;
                }
                else
                {
                    checkForNoGapFlag = false;
                }
            }
        }
        else
        {
            checkForNoGapFlag = false;
        }
        LOGGER.debug( "checkForNoGapflag : " + checkForNoGapFlag );
        LOGGER.debug( "checkForNoGapBetweenTwoDateRecords : END" );
        return checkForNoGapFlag;
    }

    /**
     * Method: checkEffectiveAndEndDates
     * @param DateRecord
     * @return
     * @throws Exception
     */
    public static boolean checkEffectiveAndEndDates( DateRecord dateRecord ) throws Exception
    {
        if( dateRecord != null
            && dateRecord.getRecordEffectiveDate() != null
            && dateRecord.getRecordEndDate() != null
            && ( ( ( dateRecord.getRecordEffectiveDate() ).isEqual( dateRecord.getRecordEndDate() ) )
                || ( ( dateRecord.getRecordEffectiveDate() ).isBefore( dateRecord.getRecordEndDate() ) ) ) )
        {
            return true;
        }
        else
        {
            return false;
        }
    }

    /**
     * Method: checkEffectiveAndEndDates List
     * @param DateRecord
     * @return
     * @throws Exception
     */
    public static boolean checkEffectiveAndEndDatesList( List<? extends DateRecord> dateRecords ) throws Exception
    {
        boolean flag = false;
        for( DateRecord dateRecord : dateRecords )
        {
            if( dateRecord != null
                && dateRecord.getRecordEffectiveDate() != null
                && dateRecord.getRecordEndDate() != null
                && ( ( ( dateRecord.getRecordEffectiveDate() ).isEqual( dateRecord.getRecordEndDate() ) )
                    || ( ( dateRecord.getRecordEffectiveDate() ).isBefore( dateRecord.getRecordEndDate() ) ) ) )
            {
                flag = true;
            }
            else
            {
                flag = false;
                break;
            }
        }
        return flag;
    }

    /**
     * Method: convertDateRecordListToDateRecordRange
     * @param List<DateRecord>
     * @return
     */
    public static <T extends DateRecord> T convertDateRecordListToDateRecordRange( List<? extends DateRecord> dateRecordList )
    {
        DateRecord dateRecord = null;
        List<LocalDate> minDateList = new ArrayList<LocalDate>();
        List<LocalDate> maxDateList = new ArrayList<LocalDate>();
        for( DateRecord record : dateRecordList )
        {
            minDateList.add( record.getRecordEffectiveDate() );
            maxDateList.add( record.getRecordEndDate() );
        }

        LocalDate minDate = Collections.min( minDateList );
        LocalDate maxDate = Collections.max( maxDateList );
        dateRecord = new DateRecord();
        dateRecord.setRecordEffectiveDate( minDate );
        dateRecord.setRecordEndDate( maxDate );
        return (T) dateRecord;

    }

    /**
     * Method: convertLocaDateToString
     * @param LocalDate
     * @return
     */
    public static String convertLocalDateToString( LocalDate localDate )
    {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern( DATE_FORMAT );
        String formattedString = localDate.format( formatter );
        return formattedString;
    }

    /**
     * Method: convertLocaDateToString
     * @param LocalDate
     * @return
     */
    public static LocalDate convertStringToLocalDate( String date )
    {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern( "yyyy-MM-dd" );
        LocalDate localDate = LocalDate.parse( date,
                                               formatter );
        return localDate;
    }

    /**
     * Method: convertStringToLocalDateDefaultFormat
     * @param date
     * @return
     */
    public static LocalDate convertStringToLocalDateDefaultFormat( String date )
    {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern( DATE_FORMAT );
        LocalDate localDate = LocalDate.parse( date,
                                               formatter );
        return localDate;
    }

    /***  Get the last day of the month for given LocalDate ******/
    /**
     * Method: getLastDayOfMonth
     * @param endDate
     * @return
     * @throws ParseException
     */
    public static LocalDate getLastDayOfMonth( LocalDate endDate ) throws ParseException
    {
        LocalDate lastDate = null;

        lastDate = endDate.with( TemporalAdjusters.lastDayOfMonth() );
        LOGGER.debug( "Last Date of this month= " + endDate.with( TemporalAdjusters.lastDayOfMonth() ) );

        return lastDate;
    }

    /**
     * Validate date format with regular expression
     * @param date date address for validation
     * @return true valid date format, false invalid date format
     */
    public static boolean isThisDateValid( String date )
    {
        if( date == null || StringUtils.equalsIgnoreCase( date,
                                                          "00/00/0000" ) )
        {
            return false;
        }

        pattern = Pattern.compile( DATE_PATTERN );
        matcher = pattern.matcher( date );

        if( matcher.matches() )
        {

            matcher.reset();

            if( matcher.find() )
            {

                String day = matcher.group( 2 );
                String month = matcher.group( 1 );
                int year = Integer.parseInt( matcher.group( 3 ) );

                if( day.equals( "31" )
                    && ( month.equals( "4" )
                        || month.equals( "6" )
                        || month.equals( "9" )
                        || month.equals( "11" )
                        || month.equals( "04" )
                        || month.equals( "06" )
                        || month.equals( "09" ) ) )
                {
                    return false; // only 1,3,5,7,8,10,12 has 31 days
                }
                else if( month.equals( "2" ) || month.equals( "02" ) )
                {
                    //leap year
                    if( year % 4 == 0 )
                    {
                        if( day.equals( "30" ) || day.equals( "31" ) )
                        {
                            return false;
                        }
                        else
                        {
                            return true;
                        }
                    }
                    else
                    {
                        if( day.equals( "29" ) || day.equals( "30" ) || day.equals( "31" ) )
                        {
                            return false;
                        }
                        else
                        {
                            return true;
                        }
                    }
                }
                else
                {
                    return true;
                }
            }
            else
            {
                return false;
            }
        }
        else
        {
            return false;
        }
    }

    /**
     * Method: getProcessingMonth
     * @param date
     * @return
     */
    public static LocalDate getProcessingMonth( LocalDate date )
    {
        LocalDate processingMonth = date.plusMonths( 1 );
        return processingMonth;
    }

    /**
     * This method will check whether the date is void or not.
     * Method: checkVoidDate
     * @param dateRecord
     * @return isVoidDate
     */
    public static boolean checkVoidDate( DateRecord dateRecord )
    {
        boolean isVoidDate = false;
        if( dateRecord.getRecordEffectiveDate().equals( dateRecord.getRecordEndDate() ) )
        {
            isVoidDate = true;
        }
        return isVoidDate;
    }

    /**
     * Removing void Dates
     */
    /**
     * Method: removeVoidDates
     * @param dateRecords
     * @return
     */
    public static List<? extends DateRecord> removeVoidDates( List<? extends DateRecord> dateRecords )
    {
        List<DateRecord> dateRecordWithoutVoidDates = new ArrayList<DateRecord>();
        for( DateRecord daterecord : dateRecords )
        {
            if( !VBRDateUtils.checkVoidDate( daterecord ) )
            {
                dateRecordWithoutVoidDates.add( daterecord );
            }
        }

        return dateRecordWithoutVoidDates;

    }

    /**
     * This method will check whether the dates are equal or not.
     * Method: checkVoidDate
     * @param dateRecord
     * @return isVoidDate
     */
    public static boolean isNotSameDay( DateRecord dateRecord )
    {
        boolean isNotSameDay = false;
        if( ObjectUtils.notEqual( dateRecord.getRecordEffectiveDate(),
                                  dateRecord.getRecordEndDate() ) )
        {
            isNotSameDay = true;
        }
        return isNotSameDay;
    }

}
