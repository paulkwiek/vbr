package com.hcsc.vbr.common.validator.provider;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.util.ObjectUtils;

import com.hcsc.vbr.common.constant.CommonServiceErrorMessageConstant;
import com.hcsc.vbr.common.constant.ComponentIdConstant;
import com.hcsc.vbr.common.constant.FieldIdConstant;
import com.hcsc.vbr.common.dto.ReturnMessageDTO;
import com.hcsc.vbr.common.validator.base.VbrBaseValidationUnit;
import com.hcsc.vbr.web.response.ProviderAPIAuthResponse;

@Component
public class PRV002CheckProviderAPIJwtToken extends VbrBaseValidationUnit
{
    final Logger LOGGER = LoggerFactory.getLogger( PRV002CheckProviderAPIJwtToken.class );

    public boolean validateProviderAPIJwtToken( ProviderAPIAuthResponse providerAPIAuthResponse,
            ReturnMessageDTO returnMessageDTO ) throws Exception
    {
        LOGGER.debug( "validateProviderAPIJwtToken : START" );

        boolean isProviderAPIJwtToken = true;

        if( ObjectUtils.isEmpty( providerAPIAuthResponse ) )
        {
            isProviderAPIJwtToken = false;
            LOGGER.debug( "validateProviderAPIJwtToken : Token Response empty" );
            addToReturnMessage( CommonServiceErrorMessageConstant.NO_PAYEE_RECORDS_FOUND,
                                FieldIdConstant.JWT_TKN,
                                ComponentIdConstant.PRV,
                                this.getClass().getSimpleName(),
                                returnMessageDTO );

        }
        LOGGER.debug( "validateProviderAPIJwtToken : isProviderAPIJwtToken Not Null" + isProviderAPIJwtToken );
        LOGGER.debug( "validateProviderAPIJwtToken : END" );
        return isProviderAPIJwtToken;
    }

}
