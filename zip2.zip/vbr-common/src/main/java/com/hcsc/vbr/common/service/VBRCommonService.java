package com.hcsc.vbr.common.service;


public class VBRCommonService {

}
