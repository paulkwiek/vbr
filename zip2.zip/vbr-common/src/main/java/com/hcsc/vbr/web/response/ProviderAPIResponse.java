package com.hcsc.vbr.web.response;

import java.io.Serializable;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonUnwrapped;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter

public class ProviderAPIResponse implements Serializable
{

    private static final long serialVersionUID = 7608748377299176350L;

    @JsonUnwrapped
    private List<ProviderAPIResponseDTO> providers;

}
