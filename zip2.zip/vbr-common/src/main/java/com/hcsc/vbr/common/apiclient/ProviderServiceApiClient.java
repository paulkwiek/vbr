package com.hcsc.vbr.common.apiclient;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.util.MultiValueMap;
import org.springframework.util.ObjectUtils;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.hcsc.vbr.common.constant.ComponentIdConstant;
import com.hcsc.vbr.common.dto.PayToPFINPayeeAddressDTO;
import com.hcsc.vbr.common.dto.PayeeAddressDTO;
import com.hcsc.vbr.common.dto.ProviderDTO;
import com.hcsc.vbr.common.dto.ReturnMessageDTO;
import com.hcsc.vbr.common.mapper.ProviderMapper;
import com.hcsc.vbr.common.utils.ProviderUtils;
import com.hcsc.vbr.common.validator.provider.ProviderServiceValidator;
import com.hcsc.vbr.web.request.ProviderAPIRequest;
import com.hcsc.vbr.web.request.ProviderApiRetrievePinGrpRequest;
import com.hcsc.vbr.web.response.ProviderAPIAuthResponse;
import com.hcsc.vbr.web.response.ProviderAPIResponse;
import com.hcsc.vbr.web.response.ProviderAPIResponseDTO;
import com.hcsc.vbr.web.response.ProviderAPISearchResponseDTO;
import com.hcsc.vbr.web.response.ProviderApiAddressDTO;
import com.hcsc.vbr.web.response.ProviderApiAddressesResponse;
import com.hcsc.vbr.web.response.ProviderApiDemographicsResponse;
import com.hcsc.vbr.web.response.ProviderApiTaxIdResponse;

@Component
@Scope( value = ConfigurableBeanFactory.SCOPE_PROTOTYPE, proxyMode = ScopedProxyMode.TARGET_CLASS )
public class ProviderServiceApiClient
{
    private static final Logger LOGGER = LoggerFactory.getLogger( ProviderServiceApiClient.class );

    private static final String DEFAULT_END_DATE = "2999-12-31";

    @Autowired
    @Qualifier( "restRequestHeaderMap" )
    MultiValueMap<String, String> defaultClientHeadersMap;

    // Needs to be a new map for each API client unless we do pooling and worry about refreshing tokens
    MultiValueMap<String, String> providerClientHeadersMap = new HttpHeaders();

    @PostConstruct
    public void init()
    {
        providerClientHeadersMap.addAll( defaultClientHeadersMap );
        providerClientHeadersMap.add( "Authorization",
                                      "Bearer " + getProviderAPIJwtToken() );
    }

    @Autowired
    private RestTemplate restTemplate;

    @Value( "${provider.actual.service.client.url}" )
    private String providerServiceClientUrl;

    @Value( "${provider.actual.service.search.resource}" )
    private String searchServiceTarget;

    @Value( "${provider.actual.service.addresses.resource}" )
    private String addressesServiceTarget;

    @Value( "${provider.actual.service.taxids.resource}" )
    private String taxIdServiceTarget;

    @Value( "${provider.actual.service.demographics.resource}" )
    private String demographicsServiceTarget;

    @Value( "${auth.service.client.url}" )
    private String authServiceClientUrl;

    @Value( "${auth.service.providerapi.jwt}" )
    private String authServiceProviderApiJwt;

    @Autowired
    private ProviderMapper providerMapper;

    @Autowired
    private ProviderServiceValidator providerServiceValidator;

    /**
    * 
    * Method: getProviders - Original method to call Provider API before split into 4 API services
    * @param providerAPIRequest
    * @return
    * @throws Exception
    */
    /**
     * Method: getProviders
     * @param providerAPIRequest
     * @return
     * @throws Exception
     */
    public ProviderAPIResponse getProviders( ProviderAPIRequest providerAPIRequest ) throws Exception

    {
        LOGGER.debug( "In ProviderServiceApiClient::getProviders" );
        LOGGER.error( "Request for premier provider API = " + new ObjectMapper().writeValueAsString( providerAPIRequest ) );

        ProviderAPIResponse response = new ProviderAPIResponse();
        List<ProviderAPIResponseDTO> responseDTOs = new ArrayList<ProviderAPIResponseDTO>();
        ReturnMessageDTO returnMessageDTO = new ReturnMessageDTO( ComponentIdConstant.PRV );

        try
        {
            int numberOfRequests = 0;
            if( !CollectionUtils.isEmpty( providerAPIRequest.getProvider() ) )
            {
                numberOfRequests = providerAPIRequest.getProvider().size();
                LOGGER.debug( "Number of PIN Groups in request: {}",
                              numberOfRequests );
            }

            for( ProviderDTO aProviderDTO : providerAPIRequest.getProvider() )
            {
                ProviderApiRetrievePinGrpRequest aProviderApiRetrievePinGrpRequest = new ProviderApiRetrievePinGrpRequest();
                aProviderApiRetrievePinGrpRequest.setCorpEntityCode( aProviderDTO.getCorpCode() );
                aProviderApiRetrievePinGrpRequest.setPinGroupID( aProviderDTO.getPinGroupID() );
                //Call the initial service and retrieve list of PFINs
                List<ProviderAPISearchResponseDTO> capitationPinGroupResponse =
                    this.getPinGroupProviders( aProviderApiRetrievePinGrpRequest );

                if( ObjectUtils.isEmpty( capitationPinGroupResponse ) )
                {
                    providerServiceValidator.validateProviderPinGroupResponse( capitationPinGroupResponse,
                                                                               returnMessageDTO );
                }

                ProviderAPIResponseDTO aResponseDTO = null;

                int numberOfProvidersInResponse = 0;
                if( !CollectionUtils.isEmpty( capitationPinGroupResponse ) )
                {
                    numberOfProvidersInResponse = capitationPinGroupResponse.size();
                    LOGGER.debug( "Number of PFINs in response: {}",
                                  numberOfProvidersInResponse );

                    for( ProviderAPISearchResponseDTO aProvider : capitationPinGroupResponse )
                    {
                        aResponseDTO = providerMapper.toProviderAPIResponseDTO( aProvider );
                        aResponseDTO.setCorpEntityCode( aProviderDTO.getCorpCode() );
                        aResponseDTO.setPingroupID( aProviderDTO.getPinGroupID() );

                        //If Pfin is null then we are not proceeding further
                        if( !StringUtils.isBlank( aProvider.getPfin() ) )
                        {
                            // Call the subsequent 3 service endpoints to retrieve additional information by PFIN
                            // Start by calling Tax Id endpoint to retrieve TIN information
                            List<ProviderApiTaxIdResponse> taxIdByPfinResponse = this.getTaxIdsByPfin( aProvider.getPfin() );
                            for( ProviderApiTaxIdResponse aTaxIdResponse : taxIdByPfinResponse )
                            {
                                aResponseDTO.setTaxId( aTaxIdResponse.getTaxId() );
                                aResponseDTO.setTinEffectiveDate( aTaxIdResponse.getTaxIdEffectiveDate() );
                                aResponseDTO.setTinEndDate( StringUtils.isBlank( aTaxIdResponse.getTaxIdEndDate() ) ? DEFAULT_END_DATE
                                    : aTaxIdResponse.getTaxIdEndDate() );
                            }
                            // Call the addresses endpoint and retrieve billing address to map to response    
                            ProviderApiAddressesResponse addressessByPfinResponse = this.getAddressesByPfin( aProvider.getPfin() );
                            ProviderApiAddressDTO aPayeeAddress = addressessByPfinResponse.getBillingAddress().getAddress();
                            PayeeAddressDTO aPayeeAddressDTO = providerMapper.toPayeeAddressDTO( aPayeeAddress );
                            aResponseDTO.setPayeeAddress( aPayeeAddressDTO );
                            PayToPFINPayeeAddressDTO payToPfinPayeeAddressDTO =
                                providerMapper.toPayToPFINPayeeAddressDTO( aPayeeAddress );
                            aResponseDTO.setPayToPFINPayeeAddress( payToPfinPayeeAddressDTO );

                            // Call the demographics endpoint and assign billing name
                            ProviderApiDemographicsResponse demographicsByPfinResponse =
                                this.getDemographicsByPfin( aProvider.getPfin() );
                            aResponseDTO.setPayToPFINName( ProviderUtils.mapBillingName( demographicsByPfinResponse ) );
                            responseDTOs.add( aResponseDTO );
                        }
                    }
                }

            }
            response.setProviders( responseDTOs );
        }
        catch( RestClientException exception )
        {
            LOGGER.error( "Received error from ProviderServiceApiClient service: " + exception );
        }

        LOGGER.debug( "Returning from ProviderServiceApiClient" );
        return response;
    }

    /**
     * 
     * Method: getPinGroupProviders - New API call to 
     * @param providerAPIRequest
     * @return
     * @throws Exception
     */
    public List<ProviderAPISearchResponseDTO> getPinGroupProviders( ProviderApiRetrievePinGrpRequest providerAPIRequest )
            throws Exception

    {
        LOGGER.debug( "In ProviderServiceApiClient::getProviders" );
        LOGGER.error( "Request for premier provider API = " + new ObjectMapper().writeValueAsString( providerAPIRequest ) );
        HttpEntity<ProviderApiRetrievePinGrpRequest> request = new HttpEntity<>( providerAPIRequest,
                                                                                 providerClientHeadersMap );

        List<ProviderAPISearchResponseDTO> response = null;

        try
        {
            LOGGER.debug( "In ProviderServiceApiClient::beforeAPIcall using: " + providerServiceClientUrl + searchServiceTarget );
            LOGGER.debug( "Headers: {}",
                          request.getHeaders() );
            LOGGER.debug( "Body: {}",
                          request.getBody() );
            ResponseEntity<List<ProviderAPISearchResponseDTO>> pinGroupResponse =
                restTemplate.exchange( providerServiceClientUrl + searchServiceTarget,
                                       HttpMethod.POST,
                                       request,
                                       new ParameterizedTypeReference<List<ProviderAPISearchResponseDTO>>()
                                       {
                                       } );
            LOGGER.info( "#### Rest template no error" );
            response = pinGroupResponse.getBody();
            LOGGER.info( "In ProviderServiceApiClient::afterAPIcall" + new ObjectMapper().writeValueAsString( response ) );
        }
        catch( RestClientException e )
        {
            LOGGER.debug( "Received error from ProviderServiceApiClient service: {}:: {}",
                          e.getMessage(),
                          e );

        }
        catch( Exception exception )
        {
            LOGGER.error( "A runtime error occurred during Provider API call" );
            exception.printStackTrace();
        }

        return response;
    }

    /**
     * 
     * Method: getTaxIdsByPfin
     * @param pfin
     * @return
     */
    public List<ProviderApiTaxIdResponse> getTaxIdsByPfin( String pfin )
    {

        HttpEntity<String> request = new HttpEntity<>( providerClientHeadersMap );

        StringBuilder sb = new StringBuilder( 256 );
        sb.append( providerServiceClientUrl ).append( taxIdServiceTarget );

        Map<String, String> parameterMap = new HashMap<String, String>();
        parameterMap.put( "pfin",
                          pfin );
        String uri = sb.toString();
        ResponseEntity<List<ProviderApiTaxIdResponse>> response = null;

        try
        {
            LOGGER.debug( "In ProviderServiceApiClient::beforeTaxId" + uri );

            response = restTemplate.exchange( uri,
                                              HttpMethod.GET,
                                              request,
                                              new ParameterizedTypeReference<List<ProviderApiTaxIdResponse>>()
                                              {
                                              },
                                              parameterMap );
            LOGGER.debug( "In ProviderServiceApiClient::afterTaxId" + new ObjectMapper().writeValueAsString( response ) );

        }
        catch( RestClientException exception )
        {
            exception.printStackTrace();
        }
        catch( Exception exception )
        {

        }
        return response.getBody();

    }

    /**
     * 
     * Method: getDemographicsByPfin
     * @param pfin
     * @return
     */
    public ProviderApiDemographicsResponse getDemographicsByPfin( String pfin )
    {
        HttpEntity<ProviderApiRetrievePinGrpRequest> request = new HttpEntity<>( null,
                                                                                 providerClientHeadersMap );

        StringBuilder sb = new StringBuilder( 256 );
        sb.append( providerServiceClientUrl ).append( demographicsServiceTarget );

        Map<String, String> parameterMap = new HashMap<String, String>();
        parameterMap.put( "pfin",
                          pfin );
        String uri = sb.toString();
        ResponseEntity<ProviderApiDemographicsResponse> response = null;

        try
        {
            LOGGER.debug( "In ProviderServiceApiClient::beforeDemographics" + uri );
            response = restTemplate.exchange( uri,
                                              HttpMethod.GET,
                                              request,
                                              ProviderApiDemographicsResponse.class,
                                              parameterMap );
            LOGGER.debug( "In ProviderServiceApiClient::afterDemographics" + new ObjectMapper().writeValueAsString( response ) );

        }
        catch( RestClientException exception )
        {
            exception.printStackTrace();
        }
        catch( Exception exception )
        {
            exception.printStackTrace();
        }
        return response.getBody();

    }

    /**
     * 
     * Method: getAddressesByPfin
     * @param pfin
     * @return
     */
    public ProviderApiAddressesResponse getAddressesByPfin( String pfin )
    {
        HttpEntity<ProviderApiRetrievePinGrpRequest> request = new HttpEntity<>( null,
                                                                                 providerClientHeadersMap );

        StringBuilder sb = new StringBuilder( 256 );
        sb.append( providerServiceClientUrl ).append( addressesServiceTarget );

        Map<String, String> parameterMap = new HashMap<String, String>();
        parameterMap.put( "pfin",
                          pfin );
        String uri = sb.toString();
        ResponseEntity<ProviderApiAddressesResponse> response = null;

        try
        {
            LOGGER.debug( "In ProviderServiceApiClient::beforeAddresses" + uri );
            response = restTemplate.exchange( uri,
                                              HttpMethod.GET,
                                              request,
                                              ProviderApiAddressesResponse.class,
                                              parameterMap );
            LOGGER.debug( "In ProviderServiceApiClient::afterAddresses" + new ObjectMapper().writeValueAsString( response ) );

        }
        catch( Exception exception )
        {
            exception.printStackTrace();
        }
        return response.getBody();

    }

    public String getProviderAPIJwtToken()
    {
        ProviderAPIAuthResponse response = null;
        ReturnMessageDTO returnMessageDTO = new ReturnMessageDTO();
        try
        {
            LOGGER.debug( "In getProviderAPIJwtToken:beforeJwtToken" );
            response = restTemplate.getForObject( authServiceClientUrl + authServiceProviderApiJwt,
                                                  ProviderAPIAuthResponse.class );
            if( ObjectUtils.isEmpty( response ) )
            {
                providerServiceValidator.validateProviderAPIJwtToken( response,
                                                                      returnMessageDTO );
            }
            LOGGER.debug( "In getProviderAPIJwtToken:afterJwtToken" );
        }
        catch( RestClientException exception )
        {
            LOGGER.debug( "Received error from ProviderApiAuthClient service: " + exception );
        }
        catch( Exception exception )
        {
            exception.printStackTrace();
        }
        return response.getJwtToken();
    }

}