package com.hcsc.vbr.common.web.request;

import java.util.List;

import com.hcsc.vbr.common.dto.ErrorMessageDTO;
import com.hcsc.vbr.common.web.request.base.VbrBaseRequest;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ErrorMessageRequest extends VbrBaseRequest
{

    private static final long serialVersionUID = 1L;

    private List<ErrorMessageDTO> errors;

}
