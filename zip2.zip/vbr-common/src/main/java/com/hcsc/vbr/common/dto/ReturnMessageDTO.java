package com.hcsc.vbr.common.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.hcsc.vbr.common.constant.VBRCommonConstant;
import com.hcsc.vbr.common.utils.MultilineRecursiveToStringStyleCustom;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter

@JsonIgnoreProperties( { "tempList" } )
public class ReturnMessageDTO implements Serializable
{

    private static final long serialVersionUID = 1L;

    private String itemName;

    private String status;

    private List<ErrorMessageDTO> errors = new ArrayList<ErrorMessageDTO>();
    private List<ErrorMessageDTO> warnings = new ArrayList<ErrorMessageDTO>();
    private List<ErrorMessageDTO> tempList = new ArrayList<ErrorMessageDTO>();

    public ReturnMessageDTO()
    {
        // TODO Auto-generated constructor stub
    }

    public ReturnMessageDTO( String itemName )
    {
        this.itemName = itemName;
    }

    /**
     * Method: add
     * @param errorMessageDTO
     */
    public void add( ErrorMessageDTO errorMessageDTO )
    {
        if( StringUtils.equals( errorMessageDTO.getSeveritylevel(),
                                VBRCommonConstant.SEVERITY_ERROR ) )
        {
            errors.add( errorMessageDTO );
        }
        else if( StringUtils.equals( errorMessageDTO.getSeveritylevel(),
                                     VBRCommonConstant.SEVERITY_WARNING ) )
        {
            warnings.add( errorMessageDTO );
        }
        else
        {
            tempList.add( errorMessageDTO );
        }
    }

    /**
     * Method: add
     * @param errorMessageDTOs
     */
    public void add( List<ErrorMessageDTO> errorMessageDTOs )
    {
        for( ErrorMessageDTO errorMessageDTO : errorMessageDTOs )
        {
            add( errorMessageDTO );
        }
    }

    /**
     * Method: add
     * @param fieldId
     * @param errorMessageDTO
     */
    public void add( String fieldId,
            ErrorMessageDTO errorMessageDTO )
    {
        if( errorMessageDTO == null )
        {
            return;
        }
        errorMessageDTO.setFieldId( fieldId );
        add( errorMessageDTO );
    }

    /**
     * Method: addToTempList
     * @param errorMessageDTO
     * @param errorMessageId
     * @param keyValues
     */
    public void addToTempList( String fieldId,
            Long errorMessageId,
            String keyValues )
    {
        ErrorMessageDTO errorMessageDTO = new ErrorMessageDTO();
        errorMessageDTO.setFieldId( fieldId );
        errorMessageDTO.setErrorMessageId( errorMessageId );
        errorMessageDTO.setKeyValues( keyValues );
        this.tempList.add( errorMessageDTO );
    }

    /**
     * Method: toString
     * @return
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString()
    {
        return new ReflectionToStringBuilder( this,
                                              new MultilineRecursiveToStringStyleCustom() ).toString();
    }
}
