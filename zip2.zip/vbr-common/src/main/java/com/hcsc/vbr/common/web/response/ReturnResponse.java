package com.hcsc.vbr.common.web.response;

import com.hcsc.vbr.common.web.response.base.VbrBaseResponse;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter

public class ReturnResponse extends VbrBaseResponse
{

    private static final long serialVersionUID = 1L;

}
