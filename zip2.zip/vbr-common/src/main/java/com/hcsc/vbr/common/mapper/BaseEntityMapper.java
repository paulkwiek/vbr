package com.hcsc.vbr.common.mapper;

import java.util.List;

import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import com.hcsc.vbr.common.domain.BaseEntity;
import com.hcsc.vbr.common.dto.BaseEntityDTO;

@Mapper( componentModel = "spring" )
public interface BaseEntityMapper
{
    BaseEntityMapper INSTANCE = Mappers.getMapper( BaseEntityMapper.class );

    public BaseEntityDTO toBaseEntityDTO( BaseEntity baseEntity );

    public List<BaseEntityDTO> toBaseEntityDTOs( List<BaseEntity> baseEntitys );

    public BaseEntity toBaseEntity( BaseEntityDTO baseEntityDTO );

    public List<BaseEntity> toBaseEntitys( List<BaseEntityDTO> baseEntityDTOs );
}
