package com.hcsc.vbr.common.dto;

import java.io.Serializable;
import java.time.LocalDateTime;

import org.apache.commons.lang3.builder.ReflectionToStringBuilder;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.hcsc.vbr.common.constant.VBRCommonConstant.RowActionTypes;
import com.hcsc.vbr.common.utils.MultilineRecursiveToStringStyleCustom;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter

public class BaseEntityDTO implements Serializable
{

    private static final long serialVersionUID = 1L;

    private String createUserId;

    private String updateUserId;

    @JsonFormat( shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss.SSS" )
    private LocalDateTime createRecordTimestamp;

    @JsonFormat( shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss.SSS" )
    private LocalDateTime updateRecordTimestamp;

    private RowActionTypes rowAction;

    @Override
    public String toString()
    {
        return new ReflectionToStringBuilder( this,
                                              new MultilineRecursiveToStringStyleCustom() ).toString();
    }
}
