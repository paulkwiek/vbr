package com.hcsc.vbr.common.apiclient;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.hcsc.vbr.common.constant.VBRCommonConstant;
import com.hcsc.vbr.common.dto.CodeSetItemDTO;
import com.hcsc.vbr.common.dto.ErrorMessageDTO;
import com.hcsc.vbr.common.utils.UserContext;
import com.hcsc.vbr.common.utils.UserContextHolder;
import com.hcsc.vbr.common.web.request.ErrorMessageRequest;
import com.hcsc.vbr.common.web.response.CodeServiceStausDescriptionResponse;
import com.hcsc.vbr.web.request.CodeSetItem;
import com.hcsc.vbr.web.request.ErrorMessage;
import com.hcsc.vbr.web.response.CodeSetListResponse;
import com.hcsc.vbr.web.response.CodeSetResponse;

@Component
public class VbrCodeServiceApiClient extends BaseApiClient
{
    @Autowired
    @Qualifier( "restRequestHeaderMap" )
    MultiValueMap<String, String> errCodeClientHeadersMap;

    @Autowired
    private RestTemplate restTemplate;

    @Value( "${code.service.client.url}" )
    private String codeServiceClientUrl;

    @Value( "${code.service.code.set.description.client.url}" )
    private String codeSetValueDescriptionClientUrl;

    @Value( "${codevalue.service.client.url}" )
    private String codeValueItemsClientUrl;

    @Value( "${codevalueitems.service.client.url}" )
    private String codeSetValueClientUrl;

    @Value( "${code.service.client.codevalueitem}" )
    private String codeValueItemServiceClientUrl;

    @Value( "${code.service.error.client.url}" )
    private String codeServiceErrorClientUrl;

    private static final Logger LOGGER = LoggerFactory.getLogger( VbrCodeServiceApiClient.class );

    /**
     * Method: getErrorAndWarningByIds
     * @param errorMessageRequest
     * @return
     * @throws Exception
     */
    public List<ErrorMessageDTO> getErrorsAndWarningsByIds( ErrorMessageRequest errorMessageRequest ) throws Exception
    {

        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.setContentType( MediaType.APPLICATION_JSON );
        httpHeaders.set( UserContext.AUTH_TOKEN,
                         UserContextHolder.getContext().getAuthToken() );

        /*
        HttpEntity<String> request = new HttpEntity<>( new ObjectMapper().writeValueAsString( errorMessageRequest ),
                                                       httpHeaders );
        */

        HttpEntity<String> request = new HttpEntity<>( new ObjectMapper().writeValueAsString( errorMessageRequest ),
                                                       getAuthorizationHeader() );

        ErrorMessageRequest response = null;
        LOGGER.info( "In getErrorsAndWarningsByIds : " + httpHeaders );
        try
        {
            response = restTemplate.postForObject( codeServiceClientUrl,
                                                   request,
                                                   ErrorMessageRequest.class );
        }
        catch( HttpClientErrorException e )
        {
            throw new Exception( "Recieved error from Code service: " + e );
        }

        return response.getErrors();
    }

    /**
     * This method will call codeServiceClient and create map using status and description.
     * Method: getAllPaymentArrangementStatusDescription
     * @param corporateEntityCode
     * @param CodeSetName
     * @return codeDescriptionMap
     * @throws Exception
     */
    public Map<String, String> getAllPaymentArrangementStatusDescription( String corporateEntityCode,
            String CodeSetName ) throws Exception
    {
        String uri = StringUtils.join( codeSetValueDescriptionClientUrl,
                                       CodeSetName );
        Map<String, String> codeDescriptionMap = new HashMap<>();

        Map<String, String> parameterMap = new HashMap<String, String>();
        parameterMap.put( "corporateEntityCode",
                          corporateEntityCode );

        UriComponentsBuilder builder = UriComponentsBuilder.fromUriString( uri );
        //CodeServiceStausDescriptionResponse codeServiceStausDescriptionResponse = null;
        ResponseEntity<CodeServiceStausDescriptionResponse> codeServiceStausDescriptionResponseEntity = null;

        HttpEntity<String> entity = new HttpEntity<>( getAuthorizationHeader() );

        try
        {
            LOGGER.info( "In CodeSetValueAPI::Before call" + uri );
            /*
            codeServiceStausDescriptionResponse = restTemplate.getForObject( uri,
                                                                             CodeServiceStausDescriptionResponse.class,
                                                                             parameterMap );
            */

            codeServiceStausDescriptionResponseEntity = restTemplate.exchange( builder.buildAndExpand( parameterMap ).toUri(),
                                                                               HttpMethod.GET,
                                                                               entity,
                                                                               CodeServiceStausDescriptionResponse.class );

            LOGGER.info( "In CodeSetValueAPI::After call"
                + new ObjectMapper().writeValueAsString( codeServiceStausDescriptionResponseEntity ) );

            /*
            codeServiceStausDescriptionResponse.getCodeSetValueItems().forEach( ( codeSetItem ) -> {
                codeDescriptionMap.put( codeSetItem.getCodeValueText(),
                                        codeSetItem.getCodeValueDescription() );
            } );
            */

            codeServiceStausDescriptionResponseEntity.getBody().getCodeSetValueItems().forEach( ( codeSetItem ) -> {
                codeDescriptionMap.put( codeSetItem.getCodeValueText(),
                                        codeSetItem.getCodeValueDescription() );
            } );

        }
        catch( RestClientException _rce )
        {
            _rce.printStackTrace();
        }
        catch( Exception _e )
        {
            _e.printStackTrace();
        }
        return codeDescriptionMap;
    }

    public List<CodeSetItemDTO> getAllCodeSetItems( CodeSetItem codeset ) throws Exception
    {
        //CodeSetItem response = null;
        HttpEntity<String> entity = new HttpEntity<>( getAuthorizationHeader() );
        ResponseEntity<CodeSetItem> cdSetItemResponseEntity = null;
        try
        {
            /*
            response = restTemplate.getForObject( codeValueItemsClientUrl,
                                                  CodeSetItem.class );
            */

            cdSetItemResponseEntity = restTemplate.exchange( codeValueItemsClientUrl,
                                                             HttpMethod.GET,
                                                             entity,
                                                             CodeSetItem.class );

        }
        catch( HttpClientErrorException e )
        {
            throw new Exception( "Recieved error from Code service: " + e );
        }

        //return response.getCodes();
        return cdSetItemResponseEntity.getBody().getCodes();
    }

    /**
     * Method: getAllCalculationRequestStatusDescription
     * @param corporateEntity
     * @param codeSetName
     * @return
     * @throws Exception
     */
    public Map<String, String> getAllCalculationRequestStatusDescription( String corporateEntity,
            String codeSetName ) throws Exception
    {
        Map<String, String> codeDescriptionMap = new HashMap<>();
        Map<String, String> parameterMap = new HashMap<String, String>();
        parameterMap.put( VBRCommonConstant.CODE_VALUE_ITEM_CORPORATE_ENTITY_ATTRIBUTE,
                          corporateEntity );
        parameterMap.put( VBRCommonConstant.CODE_VALUE_ITEM_CODE_SET_NAME_ATTRIBUTE,
                          codeSetName );
        // CodeSetListResponse response = null;

        HttpEntity<String> entity = new HttpEntity<>( getAuthorizationHeader() );

        ResponseEntity<CodeSetListResponse> codeSetListResponseEntity = null;

        UriComponentsBuilder builder = UriComponentsBuilder.fromUriString( codeSetValueClientUrl );

        try
        {
            /*
            response = restTemplate.getForObject( codeSetValueClientUrl,
                                                  CodeSetListResponse.class,
                                                  parameterMap );
            */

            codeSetListResponseEntity = restTemplate.exchange( builder.buildAndExpand( parameterMap ).toUri(),
                                                               HttpMethod.GET,
                                                               entity,
                                                               CodeSetListResponse.class );

            //List<CodeSetResponse> codeSetValueItems = response.getCodeSetValueItems();
            List<CodeSetResponse> codeSetValueItems = codeSetListResponseEntity.getBody().getCodeSetValueItems();
            for( CodeSetResponse codeSetItem : codeSetValueItems )
            {
                codeDescriptionMap.put( codeSetItem.getCodeValueText(),
                                        codeSetItem.getCodeValueDescription() );
            }
        }
        catch( RestClientException _rce )
        {
            _rce.printStackTrace();
        }
        catch( Exception _e )
        {
            _e.printStackTrace();
        }
        return codeDescriptionMap;
    }

    /**
     * Method: getCodeValueDescription
     * @param corporateEntity
     * @param codeSetName
     * @param codeValueText
     * @return
     * @throws Exception
     */
    public CodeSetItemDTO getCodeValueItem( String corporateEntity,
            String codeSetName,
            String codeValueText ) throws Exception
    {
        //CodeSetItemDTO response = null;

        String uri = StringUtils.join( codeValueItemServiceClientUrl,
                                       VBRCommonConstant.URI_SEPARATOR,
                                       corporateEntity + VBRCommonConstant.URI_SEPARATOR,
                                       codeSetName + VBRCommonConstant.URI_SEPARATOR,
                                       codeValueText );

        Map<String, String> parameterMap = new HashMap<String, String>();
        parameterMap.put( VBRCommonConstant.CODE_VALUE_ITEM_CORPORATE_ENTITY_ATTRIBUTE,
                          corporateEntity );
        parameterMap.put( VBRCommonConstant.CODE_VALUE_ITEM_CODE_SET_NAME_ATTRIBUTE,
                          codeSetName );
        parameterMap.put( VBRCommonConstant.CODE_VALUE_ITEM_CODE_VALUE_TEXT_ATTRIBUTE,
                          codeValueText );

        HttpEntity<String> entity = new HttpEntity<>( getAuthorizationHeader() );

        ResponseEntity<CodeSetItemDTO> codeSetItemResponseEntity = null;

        try
        {
            LOGGER.info( "Inside codeValueItemServiceClientUrl::Before call" + uri );

            /*
            response = restTemplate.getForObject( uri,
                                                  CodeSetItemDTO.class,
                                                  parameterMap );
            */

            codeSetItemResponseEntity = restTemplate.exchange( uri,
                                                               HttpMethod.GET,
                                                               entity,
                                                               CodeSetItemDTO.class );

            LOGGER.info( "Inside codeValueItemServiceClientUrl::After call"
                + new ObjectMapper().writeValueAsString( codeSetItemResponseEntity ) );

        }
        catch( HttpClientErrorException e )
        {
            throw new Exception( "Received error from Code service: " + e );
        }

        //return response;
        return codeSetItemResponseEntity.getBody();
    }

    public List<String> getErrorById( Long errorMessageId ) throws Exception
    {
        List<String> errors = new ArrayList<>();
        Map<String, Long> parameterMap = new HashMap<>();
        parameterMap.put( VBRCommonConstant.CODE_API_CLIENT_ERRORID_PARAMETER,
                          errorMessageId );

        //ErrorMessage response = null;
        LOGGER.info( "BEFORE CALL : getErrorById >>" + codeServiceErrorClientUrl );

        HttpEntity<String> entity = new HttpEntity<>( getAuthorizationHeader() );

        ResponseEntity<ErrorMessage> codeSetItemResponseEntity = null;

        try
        {
            /*
            response = restTemplate.getForObject( codeServiceErrorClientUrl,
                                                  ErrorMessage.class,
                                                  parameterMap );
            */

            codeSetItemResponseEntity = restTemplate.exchange( codeServiceErrorClientUrl,
                                                               HttpMethod.GET,
                                                               entity,
                                                               ErrorMessage.class );

            LOGGER.info( "AFTER CALL : getErrorById >>" + new ObjectMapper().writeValueAsString( codeSetItemResponseEntity ) );
        }
        catch( HttpClientErrorException e )
        {
            throw new Exception( "Recieved error from Code service: " + e );
        }
        /*
        for( ErrorMessageDTO errorMessage : response.getErrors() )
        {
            errors.add( errorMessage.getErrorMsgDescriptionText() );
        }
        */
        for( ErrorMessageDTO errorMessage : codeSetItemResponseEntity.getBody().getErrors() )
        {
            errors.add( errorMessage.getErrorMsgDescriptionText() );
        }

        return errors;
    }

}