package com.hcsc.vbr.common.dto;

import org.apache.commons.lang3.builder.ReflectionToStringBuilder;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.hcsc.vbr.common.utils.MultilineRecursiveToStringStyleCustom;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class DateRecordDTO extends BaseEntityDTO
{

    private static final long serialVersionUID = 1L;

    @JsonFormat( pattern = "MM/dd/yyyy" )
    private String recordEffectiveDate;

    @JsonFormat( pattern = "MM/dd/yyyy" )
    private String recordEndDate;

    @Override
    public String toString()
    {
        return new ReflectionToStringBuilder( this,
                                              new MultilineRecursiveToStringStyleCustom() ).toString();
    }

}