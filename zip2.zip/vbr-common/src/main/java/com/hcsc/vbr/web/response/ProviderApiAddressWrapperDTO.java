package com.hcsc.vbr.web.response;

import java.io.Serializable;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ProviderApiAddressWrapperDTO implements Serializable
{

    private static final long serialVersionUID = -55252339946248461L;

    private ProviderApiAddressDTO address;

}
