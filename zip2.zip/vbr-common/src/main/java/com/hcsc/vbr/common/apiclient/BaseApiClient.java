package com.hcsc.vbr.common.apiclient;

import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;

import com.hcsc.vbr.common.utils.UserContext;
import com.hcsc.vbr.common.utils.UserContextHolder;

@Component
public class BaseApiClient
{

    public HttpHeaders getAuthorizationHeader()
    {
        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.setContentType( MediaType.APPLICATION_JSON );
        httpHeaders.set( UserContext.AUTH_TOKEN,
                         UserContextHolder.getContext().getAuthToken() );
        return httpHeaders;
    }
}
