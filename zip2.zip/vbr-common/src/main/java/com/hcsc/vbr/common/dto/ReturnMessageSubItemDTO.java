package com.hcsc.vbr.common.dto;

import java.io.Serializable;

import org.apache.commons.lang3.builder.ReflectionToStringBuilder;

import com.hcsc.vbr.common.utils.MultilineRecursiveToStringStyleCustom;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter

public class ReturnMessageSubItemDTO implements Serializable
{

    private static final long serialVersionUID = 1L;

    private String subItemId;

    private Long messageId;

    private String message;

    private String values;//1=VBR,2=VBR1,3=VBR2

    @Override
    public String toString()
    {
        return new ReflectionToStringBuilder( this,
                                              new MultilineRecursiveToStringStyleCustom() ).toString();
    }
}
