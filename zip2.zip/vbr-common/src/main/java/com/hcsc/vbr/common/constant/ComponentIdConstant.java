package com.hcsc.vbr.common.constant;

public class ComponentIdConstant
{
    //Calculation Run
    public static final String PRV = "provider";

}
