package com.hcsc.vbr.common.dto;

import java.io.Serializable;

import org.apache.commons.lang3.builder.ReflectionToStringBuilder;

import com.hcsc.vbr.common.utils.MultilineRecursiveToStringStyleCustom;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PayToPFINPayeeAddressDTO implements Serializable
{
    private static final long serialVersionUID = 1L;

    private String zipCode;

    private String city;

    private String addressLine1;

    private String addressLine2;

    private String state;

    @Override
    public String toString()
    {
        return new ReflectionToStringBuilder( this,
                                              new MultilineRecursiveToStringStyleCustom() ).toString();
    }

}
