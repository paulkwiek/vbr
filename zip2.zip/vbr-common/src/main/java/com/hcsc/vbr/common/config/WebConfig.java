package com.hcsc.vbr.common.config;

import java.io.IOException;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.GenericFilterBean;

import com.hcsc.vbr.common.utils.UserContext;
import com.hcsc.vbr.common.utils.UserContextHolder;

@Component
public class WebConfig extends GenericFilterBean
{

    private static final Logger LOGGER = LoggerFactory.getLogger( WebConfig.class );

    @Override
    public void doFilter( ServletRequest request,
            ServletResponse response,
            FilterChain chain ) throws IOException, ServletException
    {
        HttpServletRequest httpServletRequest = (HttpServletRequest) request;
        HttpServletResponse httpServletResponse = (HttpServletResponse) response;

        UserContextHolder.populateAuthToken( httpServletRequest.getHeader( UserContext.AUTH_TOKEN ) );
        LOGGER.debug( "From UserContextFilter.doFilter() calling chain.doFilter" );
        chain.doFilter( httpServletRequest,
                        httpServletResponse );

    }

}
