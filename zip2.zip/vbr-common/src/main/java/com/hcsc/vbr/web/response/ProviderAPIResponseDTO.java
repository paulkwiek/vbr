package com.hcsc.vbr.web.response;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.hcsc.vbr.common.dto.PayToPFINPayeeAddressDTO;
import com.hcsc.vbr.common.dto.PayeeAddressDTO;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ProviderAPIResponseDTO implements Serializable
{

    private static final long serialVersionUID = 1L;

    @JsonFormat( pattern = "yyyy-MM-dd" )
    @JsonProperty( "pinGroupEffectiveDate" )
    private String pINGroupEffectiveDate;

    @JsonFormat( pattern = "yyyy-MM-dd" )
    @JsonProperty( "pinGroupEndDate" )
    private String pINGroupEndDate;

    @JsonFormat( pattern = "yyyy-MM-dd" )
    private String pfinEffectiveDate;

    @JsonFormat( pattern = "yyyy-MM-dd" )
    private String pfinEndDate;

    @JsonFormat( pattern = "yyyy-MM-dd" )
    private String tinEffectiveDate;

    @JsonFormat( pattern = "yyyy-MM-dd" )
    private String tinEndDate;

    @JsonFormat( pattern = "yyyy-MM-dd" )
    private String networkAssociationEffectiveDate;

    @JsonFormat( pattern = "yyyy-MM-dd" )
    private String networkAssociationEndDate;

    private String payToPFINId;

    @JsonProperty( "pinGroupName" )
    private String pingroupName;

    private String networkAssociationID;

    private PayeeAddressDTO payeeAddress;

    @JsonProperty( "pINGroupID" )
    private String pingroupID;

    private String capitationTypeCode;

    private String taxId;

    private String processCode;

    private PayToPFINPayeeAddressDTO payToPFINPayeeAddress;

    private String corpEntityCode;

    private String networkAssociationName;

    private String networkCode;

    private String payToPFINName;

    @JsonFormat( pattern = "yyyy-MM-dd" )
    private String pINGroupCapitationEffectiveDate;

    @JsonFormat( pattern = "yyyy-MM-dd" )
    private String pINGroupCapitationEndDate;

}
