package com.hcsc.vbr.common.constant;

public class FieldIdConstant
{
    //Provider API
    public static final String PRV_API = "providerApi";

    //Jwt Token
    public static final String JWT_TKN = "providerJwtToken";
}
