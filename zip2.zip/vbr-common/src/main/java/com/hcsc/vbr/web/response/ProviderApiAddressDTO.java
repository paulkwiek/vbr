package com.hcsc.vbr.web.response;

import java.io.Serializable;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ProviderApiAddressDTO implements Serializable
{

    private static final long serialVersionUID = 5579930778490115507L;

    private String addressLine1;

    private String addressLine2;

    private String city;

    private String state;

    private String zipCode;

}
