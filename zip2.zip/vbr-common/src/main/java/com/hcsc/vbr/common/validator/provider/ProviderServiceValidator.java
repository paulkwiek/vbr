package com.hcsc.vbr.common.validator.provider;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.hcsc.vbr.common.constant.CommonServiceConstant;
import com.hcsc.vbr.common.dto.ReturnMessageDTO;
import com.hcsc.vbr.common.exception.VbrApplicationException;
import com.hcsc.vbr.common.validator.base.VbrBaseValidationUnit;
import com.hcsc.vbr.web.response.ProviderAPIAuthResponse;
import com.hcsc.vbr.web.response.ProviderAPISearchResponseDTO;

@Component
public class ProviderServiceValidator extends VbrBaseValidationUnit
{
    final Logger LOGGER = LoggerFactory.getLogger( ProviderServiceValidator.class );

    @Autowired
    private PRV001CheckProviderPinGroupResponse prv001CheckProviderPinGroupResponse;

    @Autowired
    private PRV002CheckProviderAPIJwtToken prv002CheckProviderAPIJwtToken;

    public boolean validateProviderPinGroupResponse( List<ProviderAPISearchResponseDTO> providerAPIResponse,
            ReturnMessageDTO returnMessageDTO ) throws Exception
    {
        LOGGER.debug( "validateProviderPinGroupResponse : START" );

        boolean isPinGroupResponse = true;

        isPinGroupResponse = prv001CheckProviderPinGroupResponse.validateProviderPinGroupResponse( providerAPIResponse,
                                                                                                   returnMessageDTO );

        if( !isPinGroupResponse )
        {

            returnMessageDTO.setStatus( CommonServiceConstant.FAILURE_VALIDATION_STATUS );
            throw new VbrApplicationException( returnMessageDTO );
        }
        else
        {
            returnMessageDTO.setStatus( CommonServiceConstant.SUCCESS_VALIDATION_STATUS );
        }
        LOGGER.debug( "validateProviderPinGroupResponse : isPinGroupResponse Not Null" + isPinGroupResponse );
        LOGGER.debug( "validateProviderPinGroupResponse : END" );
        return isPinGroupResponse;
    }

    public boolean validateProviderAPIJwtToken( ProviderAPIAuthResponse providerAPIAuthResponse,
            ReturnMessageDTO returnMessageDTO ) throws Exception
    {
        LOGGER.debug( "validateProviderAPIJwtToken : START" );

        boolean isProviderAPIJwtToken = true;

        isProviderAPIJwtToken = prv002CheckProviderAPIJwtToken.validateProviderAPIJwtToken( providerAPIAuthResponse,
                                                                                            returnMessageDTO );

        if( !isProviderAPIJwtToken )
        {

            returnMessageDTO.setStatus( CommonServiceConstant.FAILURE_VALIDATION_STATUS );
            throw new VbrApplicationException( returnMessageDTO );
        }
        else
        {
            returnMessageDTO.setStatus( CommonServiceConstant.SUCCESS_VALIDATION_STATUS );
        }
        LOGGER.debug( "validateProviderAPIJwtToken : isProviderAPIJwtToken Not Null" + isProviderAPIJwtToken );
        LOGGER.debug( "validateProviderAPIJwtToken : END" );
        return isProviderAPIJwtToken;
    }

}
