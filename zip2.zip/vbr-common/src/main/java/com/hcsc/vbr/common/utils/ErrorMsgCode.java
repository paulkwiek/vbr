package com.hcsc.vbr.common.utils;

//This class needs to be deprecated.Error messages are to be retrieved from DB.
public enum ErrorMsgCode {

	
	NoContent(204, "Error", "The request was successful but not require the return of an entity body."),

	BadRequest(400, "Error", "The request could not be understood by the server."),
	Unauthorized(401, "Error", "The request requires authorization."),
	Forbidden(403, "Error", "Whilst the server did understand the request, the server is refusing to complete it. This is not an authorization problem."),
	NotFound(404, "Error", "The requested resource was not found."),
	MethodNotAllowed(405, "Error", "The supplied method was not allowed on the given resource."),
	UnsupportedMediaType(415, "Error", "The request was unsuccessful because the request was for an unsupported format."),

	InternalServerError(500, "Error", "The request was unsuccessful because the server encountered an unexpected error."),
	BadGateway(502, "Error", "The server, whilst acting as a proxy, received an invalid response from the server that was fulfilling the request."),
	ServiceUnavailable(503, "Error", "The request was unsuccessful as the server is down."),
	GatewayTimeout(504, "Error", "The server, whilst acting as a proxy, did not receive a response from the upstream server in an acceptable time."),
	HttpVersionNotSupported(505, "Error", "The server does not supported the HTTP protocol version specified in the request"),

	/**Specific Error Codes based on scenarios**/
	DateRecordEmptyOrNull(111,"Error","Parent,Child DateRecords null or empty"),
	EffectiveEndDateNull(112,"Error","Effective,End Dates null");

	private final int code;
	private final String severity;
	private final String description;

	private ErrorMsgCode(int code, String severity, String description) {
		this.code = code;
		this.severity = severity;
		this.description = description;

	}

	public final int getCode() {
		return code;
	}

	public final String getSeverity() {
		return severity;
	}

	public final String getDescription() {
		return description;
	}
}
