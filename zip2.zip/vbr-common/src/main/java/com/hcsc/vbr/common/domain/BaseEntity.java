package com.hcsc.vbr.common.domain;

import java.io.Serializable;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.MappedSuperclass;
import javax.persistence.Transient;
import javax.persistence.Version;
import javax.validation.constraints.NotNull;

import org.apache.commons.lang3.builder.ReflectionToStringBuilder;

import com.hcsc.vbr.common.constant.VBRCommonConstant.RowActionTypes;
import com.hcsc.vbr.common.utils.MultilineRecursiveToStringStyleCustom;

import lombok.Getter;
import lombok.Setter;

@MappedSuperclass
@Getter
@Setter
public class BaseEntity implements Serializable
{

    private static final long serialVersionUID = 1L;

    @NotNull
    @Column( name = "CRTE_USR_ID", length = 8 )
    private String createUserId;

    @NotNull
    @Column( name = "UPD_USR_ID", length = 8 )
    private String updateUserId;

    @NotNull
    @Column( name = "CRTE_TS" )
    private LocalDateTime createRecordTimestamp;

    @NotNull
    @Version
    @Column( name = "UPD_TS" )
    private LocalDateTime updateRecordTimestamp;

    @Enumerated( EnumType.STRING )
    @Transient
    private RowActionTypes rowAction = RowActionTypes.NO_ACTION;

    @Override
    public String toString()
    {
        return new ReflectionToStringBuilder( this,
                                              new MultilineRecursiveToStringStyleCustom() ).toString();
    }
}
