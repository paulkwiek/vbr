package com.hcsc.vbr.web.response;

import java.io.Serializable;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ProviderApiTaxIdResponse implements Serializable
{

    private static final long serialVersionUID = -2651998720635460248L;

    private String taxId;

    private String taxIdEffectiveDate;

    private String taxIdEndDate;

}
