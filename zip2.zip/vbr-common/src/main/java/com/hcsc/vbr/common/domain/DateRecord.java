package com.hcsc.vbr.common.domain;

import java.time.LocalDate;

import javax.persistence.MappedSuperclass;
import javax.validation.constraints.NotNull;

import org.apache.commons.lang3.builder.ReflectionToStringBuilder;

import com.hcsc.vbr.common.utils.MultilineRecursiveToStringStyleCustom;

import lombok.Getter;
import lombok.Setter;

@MappedSuperclass
@Getter
@Setter
public class DateRecord extends BaseEntity implements Comparable<DateRecord>
{

    private static final long serialVersionUID = 1L;

    @NotNull
    private LocalDate recordEffectiveDate;

    @NotNull
    private LocalDate recordEndDate;

    @Override
    public String toString()
    {
        return new ReflectionToStringBuilder( this,
                                              new MultilineRecursiveToStringStyleCustom() ).toString();
    }

    @Override
    public int compareTo( DateRecord o )
    {
        return this.recordEffectiveDate.compareTo( o.recordEffectiveDate );
    }

}