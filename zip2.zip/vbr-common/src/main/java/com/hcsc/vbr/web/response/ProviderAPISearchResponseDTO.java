package com.hcsc.vbr.web.response;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ProviderAPISearchResponseDTO implements Serializable
{

    private static final long serialVersionUID = 1L;

    private String pfin;

    @JsonFormat( pattern = "yyyy-MM-dd" )
    private String pinGroupEffectiveDate;

    @JsonFormat( pattern = "yyyy-MM-dd" )
    private String pinGroupEndDate;

    @JsonFormat( pattern = "yyyy-MM-dd" )
    private String pfinEffectiveDate;

    @JsonFormat( pattern = "yyyy-MM-dd" )
    private String pfinEndDate;

    @JsonProperty( "pinGroupName" )
    private String pingroupName;

    private String networkAssociationID;

    @JsonProperty( "pinGroupID" )
    private String pingroupID;

    private String capitationType;

    private String processCode;

    private String corpEntityCode;

    private String networkAssociationName;

    private String networkCode;

}
