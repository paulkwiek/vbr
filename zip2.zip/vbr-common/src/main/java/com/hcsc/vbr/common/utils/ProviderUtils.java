package com.hcsc.vbr.common.utils;

import org.apache.commons.lang3.StringUtils;

import com.hcsc.vbr.web.response.ProviderApiDemographicsResponse;

public class ProviderUtils
{
    /**
     * 
     * Method: mapBillingName
     * @param demographics
     * @return
     */
    public static String mapBillingName( ProviderApiDemographicsResponse demographics )
    {

        if( StringUtils.isNotBlank( demographics.getBilling().getProviderOrganizationName() ) )
        {

            return ( StringUtils.join( demographics.getBilling().getProviderOrganizationName(),
                                       " ",
                                       demographics.getBilling().getProviderOrganizationSecondName() ) );
        }
        else
        {

            return ( StringUtils.join( demographics.getBilling().getProviderFirstName(),
                                       " ",
                                       demographics.getBilling().getProviderLastName() ) );
        }
    }

}
