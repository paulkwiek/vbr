package com.hcsc.vbr.common.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CodeSetValueDTO
{
    private String codeSetName;

    private String corporateEntityCode;

    private String codeSetDescription;

    private String codeValueText;

    private String codeValueDescription;

}
