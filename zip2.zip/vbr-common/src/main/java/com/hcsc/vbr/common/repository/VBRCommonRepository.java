package com.hcsc.vbr.common.repository;


public class VBRCommonRepository {

}
