package com.hcsc.vbr.common.validator.base;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.hcsc.vbr.common.apiclient.VbrCodeServiceApiClient;
import com.hcsc.vbr.common.constant.VBRCommonConstant;
import com.hcsc.vbr.common.dto.ErrorMessageDTO;
import com.hcsc.vbr.common.dto.ReturnMessageDTO;
import com.hcsc.vbr.common.web.request.ErrorMessageRequest;

public class VbrBaseValidationUnit
{

    @Autowired
    private VbrCodeServiceApiClient vbrCodeServiceApiClient;

    /**
     * Method: addToReturnMessage
     * @param returnMessage
     * @param returnMessageSubItemEnum
     * @param messageId
     * @param keyValueMap
     * @throws Exception 
     */
    public void addToReturnMessage( Long errorMessageId,
            String fieldId,
            String componentName,
            String validationClass,
            ReturnMessageDTO returnMessage ) throws Exception
    {
        List<ErrorMessageDTO> errors = getErrorWarningMessage( errorMessageId,
                                                               fieldId,
                                                               componentName,
                                                               validationClass );
        returnMessage.add( errors );

    }

    /**
     * Method: addToReturnMessage
     * @param errorMessageId
     * @param fieldId
     * @param keyValueMap
     * @param returnMessage
     * @throws Exception
     */
    public void addToReturnMessage( Long errorMessageId,
            String fieldId,
            String componentName,
            String validationClass,
            HashMap<String, String> keyValueMap,
            ReturnMessageDTO returnMessage ) throws Exception
    {
        //Call method to retrieve error/warning message 
        List<ErrorMessageDTO> responseErrors = getErrorWarningMessage( errorMessageId,
                                                                       fieldId,
                                                                       componentName,
                                                                       validationClass );

        //Set the key/value to the error/warning message.
        setKeyValues( responseErrors,
                      keyValueMap );

        returnMessage.add( responseErrors );

    }

    /**
     * Method: getKeyValues
     * @param keyValueMap
     * @return
     */
    private void setKeyValues( List<ErrorMessageDTO> responseErrors,
            HashMap<String, String> keyValueMap )
    {
        StringBuffer keyValuesBuffer = new StringBuffer();

        for( String key : keyValueMap.keySet() )
        {
            keyValuesBuffer.append( key );
            keyValuesBuffer.append( VBRCommonConstant.EQUALS_TO );
            keyValuesBuffer.append( keyValueMap.get( key ) );
            keyValuesBuffer.append( VBRCommonConstant.COMMA );
        }
        String keyValues = null;
        if( keyValuesBuffer.length() > 0 )
        {
            keyValues = keyValuesBuffer.substring( 0,
                                                   keyValuesBuffer.length() - 1 );
        }

        //Since the returned error list doesnt have the fieldId, populate it now
        for( ErrorMessageDTO responseError : responseErrors )
        {
            responseError.setKeyValues( keyValues );
        }

    }

    /**
     * Method: getErrorWarningMessage
     * @param errorMessageId
     * @return
     * @throws Exception
     */
    private List<ErrorMessageDTO> getErrorWarningMessage( Long errorMessageId,
            String fieldId,
            String componentName,
            String validationClass ) throws Exception
    {
        ErrorMessageDTO errorMessageDTO = new ErrorMessageDTO();
        errorMessageDTO.setErrorMessageId( errorMessageId );
        List<ErrorMessageDTO> requestErrors = new ArrayList<ErrorMessageDTO>();
        requestErrors.add( errorMessageDTO );

        List<ErrorMessageDTO> responseErrors = getErrorWarningMessages( requestErrors );
        //Since the returned error list doesnt have the fieldId, populate it now
        for( ErrorMessageDTO responseError : responseErrors )
        {
            responseError.setFieldId( fieldId );
            responseError.setComponentName( componentName );
            responseError.setValidationClass( validationClass );
        }

        return responseErrors;
    }

    /**
     * Method: getErrorWarningMessages
     * @param requestErrors
     * @return
     * @throws Exception
     */
    public List<ErrorMessageDTO> getErrorWarningMessages( List<ErrorMessageDTO> requestErrors ) throws Exception
    {
        ErrorMessageRequest errorMessageRequest = new ErrorMessageRequest();
        errorMessageRequest.setErrors( requestErrors );
        //Call Rest API for reading the actual error/warning messages By passing list of errorMessageIds in the request
        List<ErrorMessageDTO> errors = vbrCodeServiceApiClient.getErrorsAndWarningsByIds( errorMessageRequest );

        return errors;

    }
}
