package com.hcsc.vbr.common.constant;

public class VBRCommonConstant
{

    public enum RowActionTypes
    {
     INSERT,
     UPDATE,
     DELETE,
     NO_ACTION;
    }

    public static final String SEVERITY_ERROR = "E";
    public static final String SEVERITY_WARNING = "W";
    public static final String EQUALS_TO = "=";
    public static final String COMMA = ",";

    // Constants added for displaying Fatal Error during DB/Application down
    public static final String DEFAULT_EXCEPTION_MESSAGE_CATEGORY_CODE = "ERR";
    public static final Long DEFAULT_EXCEPTION_ERROR_MESSAGE_ID = Long.valueOf( 10000 );
    public static final String DEFAULT_EXCEPTION_ERROR_MESSAGE_DESCRIPTION = "Data could not be saved/retrieved. Please try again.";
    public static final String DEFAULT_EXCEPTION_SEVERITY_LVL = "E";

    public static final String CODE_VALUE_ITEM_CORPORATE_ENTITY_ATTRIBUTE = "corporateEntity";
    public static final String CODE_VALUE_ITEM_CODE_SET_NAME_ATTRIBUTE = "codeSetName";
    public static final String CODE_VALUE_ITEM_CODE_VALUE_TEXT_ATTRIBUTE = "codeValueText";
    public static final String URI_SEPARATOR = "/";

    public static final String CST_TIME_ZONE_ID = "America/Chicago";

    public static final String CODE_API_CLIENT_ERRORID_PARAMETER = "id";

    public static final String CST_ZONE_ID = "America/Chicago";

}
