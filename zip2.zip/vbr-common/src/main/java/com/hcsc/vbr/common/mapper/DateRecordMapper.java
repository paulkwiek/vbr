package com.hcsc.vbr.common.mapper;

import java.util.List;

import org.mapstruct.IterableMapping;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import com.hcsc.vbr.common.domain.DateRecord;
import com.hcsc.vbr.common.dto.DateRecordDTO;

@Mapper( componentModel = "spring" )
public interface DateRecordMapper
{
    DateRecordMapper INSTANCE = Mappers.getMapper( DateRecordMapper.class );

    public DateRecordDTO toDateRecordDTO( DateRecord dateRecord );

    public List<DateRecordDTO> toDateRecordDTOs( List<DateRecord> dateRecords );

    @Mapping( target = "recordEffectiveDate", dateFormat = "MM/dd/yyyy" )
    @Mapping( target = "recordEndDate", dateFormat = "MM/dd/yyyy" )
    public DateRecord toDateRecord( DateRecordDTO dateRecordDTO );

    @IterableMapping( elementTargetType = DateRecord.class, qualifiedByName = "toDateRecord" )
    public List<DateRecord> toDateRecords( List<DateRecordDTO> dateRecordDTOs );
}
