package com.hcsc.vbr.common.constant;

public final class DateTimePattern
{
    public final static String DatePattern = "MM/dd/yyyy";
    public final static String DateTimePattern = "MM/dd/yyyy HH:mm:ss.SSSSSS";
    public final static String TimePattern = "HH:mm:ss";
}