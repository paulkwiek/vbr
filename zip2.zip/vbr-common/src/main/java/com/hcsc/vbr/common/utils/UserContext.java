package com.hcsc.vbr.common.utils;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public final class UserContext
{

    private UserContext()
    {
        /***/
    }

    public static final String AUTH_TOKEN = "Authorization";

    private String authToken;

    public static UserContext emptyContext()
    {
        return new UserContext();
    }

}