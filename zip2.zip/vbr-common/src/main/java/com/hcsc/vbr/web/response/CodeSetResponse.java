package com.hcsc.vbr.web.response;

import org.apache.commons.lang3.builder.ReflectionToStringBuilder;

import com.hcsc.vbr.common.utils.MultilineRecursiveToStringStyleCustom;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CodeSetResponse
{
    private String codeSetName;

    private String corporateEntityCode;

    private String codeSetDescription;

    private String codeValueText;

    private String codeValueDescription;

    @Override
    public String toString()
    {
        return new ReflectionToStringBuilder( this,
                                              new MultilineRecursiveToStringStyleCustom() ).toString();
    }

}
