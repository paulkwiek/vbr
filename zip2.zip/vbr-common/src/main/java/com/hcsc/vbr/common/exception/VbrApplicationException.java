package com.hcsc.vbr.common.exception;

import org.apache.commons.lang3.builder.ReflectionToStringBuilder;

import com.hcsc.vbr.common.dto.ReturnMessageDTO;
import com.hcsc.vbr.common.utils.MultilineRecursiveToStringStyleCustom;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class VbrApplicationException extends Exception
{

    private static final long serialVersionUID = 1L;

    private ReturnMessageDTO returnMessage;

    /**
     * @param message
     */

    public VbrApplicationException( String message )
    {
        super( message );
    }

    /**
     * @param message
     */
    public VbrApplicationException( Long message )
    {
        super( message.toString() );
    }

    /**
     * @param returnMessage
     */
    public VbrApplicationException( ReturnMessageDTO returnMessage )
    {
        super( returnMessage.toString() );
        this.returnMessage = returnMessage;
    }

    /**
     * @param message
     * @param cause
     */
    public VbrApplicationException( String message,
        Throwable cause )
    {
        super( message,
                cause );
    }

    /**
     * Method: toString
     * @return
     * @see java.lang.Throwable#toString()
     */
    @Override
    public String toString()
    {
        return new ReflectionToStringBuilder( this,
                                              new MultilineRecursiveToStringStyleCustom() ).toString();
    }
}
