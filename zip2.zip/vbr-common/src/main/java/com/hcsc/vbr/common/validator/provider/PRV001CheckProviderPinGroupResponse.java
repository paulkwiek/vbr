package com.hcsc.vbr.common.validator.provider;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.util.ObjectUtils;

import com.hcsc.vbr.common.constant.CommonServiceErrorMessageConstant;
import com.hcsc.vbr.common.constant.ComponentIdConstant;
import com.hcsc.vbr.common.constant.FieldIdConstant;
import com.hcsc.vbr.common.dto.ReturnMessageDTO;
import com.hcsc.vbr.common.validator.base.VbrBaseValidationUnit;
import com.hcsc.vbr.web.response.ProviderAPISearchResponseDTO;

@Component
public class PRV001CheckProviderPinGroupResponse extends VbrBaseValidationUnit
{
    final Logger LOGGER = LoggerFactory.getLogger( PRV001CheckProviderPinGroupResponse.class );

    public boolean validateProviderPinGroupResponse( List<ProviderAPISearchResponseDTO> providerAPIResponse,
            ReturnMessageDTO returnMessageDTO ) throws Exception
    {
        LOGGER.debug( "validateProviderPinGroupResponse : START" );

        boolean isPinGroupResponse = true;

        if( ObjectUtils.isEmpty( providerAPIResponse ) )
        {
            isPinGroupResponse = false;
            LOGGER.debug( "validateProviderPinGroupResponse : API Response empty" );
            addToReturnMessage( CommonServiceErrorMessageConstant.NO_PAYEE_RECORDS_FOUND,
                                FieldIdConstant.PRV_API,
                                ComponentIdConstant.PRV,
                                this.getClass().getSimpleName(),
                                returnMessageDTO );

        }
        LOGGER.debug( "validateProviderPinGroupResponse : isPinGroupResponse Not Null" + isPinGroupResponse );
        LOGGER.debug( "validateProviderPinGroupResponse : END" );
        return isPinGroupResponse;
    }

}
