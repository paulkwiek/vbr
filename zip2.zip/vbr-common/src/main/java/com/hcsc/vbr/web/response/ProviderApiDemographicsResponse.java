package com.hcsc.vbr.web.response;

import java.io.Serializable;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ProviderApiDemographicsResponse implements Serializable
{

    /**
     * 
     */
    private static final long serialVersionUID = -4558071077034436825L;

    ProviderApiDemographicsDTO office;

    ProviderApiDemographicsDTO billing;

}
