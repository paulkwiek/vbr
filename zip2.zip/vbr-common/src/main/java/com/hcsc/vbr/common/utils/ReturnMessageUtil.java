package com.hcsc.vbr.common.utils;

public class ReturnMessageUtil
{

    //TODO : Dont think this class is necessary, will delete after the error handling is implemented.

}
