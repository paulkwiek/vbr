package com.hcsc.vbr.web.response;

import java.util.List;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CodeSetListResponse
{
    private List<CodeSetResponse> codeSetValueItems;
}
