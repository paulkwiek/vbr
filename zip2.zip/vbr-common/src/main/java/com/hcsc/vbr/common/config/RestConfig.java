package com.hcsc.vbr.common.config;

import java.time.ZoneId;
import java.util.TimeZone;

import javax.annotation.PostConstruct;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Controller;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import com.hcsc.vbr.common.constant.VBRCommonConstant;

@Configuration
@Controller
public class RestConfig
{

    @Bean
    public RestTemplate restTemplate()
    {
        return new RestTemplate();
    }

    @Bean( "restRequestHeaderMap" )
    public MultiValueMap<String, String> restRequestHeaders()
    {
        MultiValueMap<String, String> headers = new LinkedMultiValueMap<>();
        headers.add( "Content-Type",
                     "application/json" );
        return headers;
    }

    @PostConstruct
    public void cstTimeZoneInject()
    {
        TimeZone.setDefault( TimeZone.getTimeZone( ZoneId.of( VBRCommonConstant.CST_TIME_ZONE_ID ) ) );
    }

}
