package com.hcsc.vbr.common.mapper;

import java.util.List;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import com.hcsc.vbr.common.dto.PayToPFINPayeeAddressDTO;
import com.hcsc.vbr.common.dto.PayeeAddressDTO;
import com.hcsc.vbr.web.response.ProviderAPIResponseDTO;
import com.hcsc.vbr.web.response.ProviderAPISearchResponseDTO;
import com.hcsc.vbr.web.response.ProviderApiAddressDTO;

@Mapper( componentModel = "spring" )
public interface ProviderMapper
{
    ProviderMapper INSTANCE = Mappers.getMapper( ProviderMapper.class );

    @Mapping( source = "capitationType", target = "capitationTypeCode" )
    @Mapping( source = "pfin", target = "payToPFINId" )
    @Mapping( source = "pinGroupEffectiveDate", target = "PINGroupEffectiveDate" )
    @Mapping( source = "pinGroupEndDate", target = "PINGroupEndDate", defaultValue = "2999-12-31" )
    @Mapping( source = "pinGroupEffectiveDate", target = "networkAssociationEffectiveDate" )
    @Mapping( source = "pinGroupEndDate", target = "networkAssociationEndDate", defaultValue = "2999-12-31" )
    @Mapping( target = "pfinEndDate", defaultValue = "2999-12-31" )
    @Mapping( source = "pfinEffectiveDate", target = "PINGroupCapitationEffectiveDate" )
    @Mapping( source = "pfinEndDate", target = "PINGroupCapitationEndDate", defaultValue = "2999-12-31" )
    public ProviderAPIResponseDTO toProviderAPIResponseDTO( ProviderAPISearchResponseDTO providerApiSearchResponseDTO );

    public List<ProviderAPIResponseDTO> toProviderAPIResponseDTOs( List<ProviderAPISearchResponseDTO> providerApiSearchResponseDTOs );

    public PayeeAddressDTO toPayeeAddressDTO( ProviderApiAddressDTO providerApiAddressDTO );

    public PayToPFINPayeeAddressDTO toPayToPFINPayeeAddressDTO( ProviderApiAddressDTO providerApiAddressDTO );

    public ProviderApiAddressDTO toProviderApiAddressDTO( PayToPFINPayeeAddressDTO payToPfinPayeeAddressDTO );

}
