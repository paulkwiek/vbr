package com.hcsc.vbr.web.response;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ProviderAPIAuthResponse implements Serializable
{
	private static final long serialVersionUID = -2651998720635460248L;
	
	@JsonProperty( "username" )
	private String username;
	
	@JsonProperty( "userDetails" )
	private String userDetails;
	
	@JsonProperty( "resultMessage" )
	private String resultMessage;
	
	@JsonProperty( "access_token" )
	private String accessToken;
	
	@JsonProperty( "token_type" )
	private String tokenType;
	
	@JsonProperty( "expires_in" )
	private String expiresIn;
	
	@JsonProperty( "refresh_token" )
	private String refreshToken;
	
	@JsonProperty( "jwt_token" )
	private String jwtToken;
}
