package com.hcsc.vbr.vbrtest.config;

import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.X509Certificate;

import javax.net.ssl.SSLContext;

import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.ssl.TrustStrategy;
import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

@Configuration
public class RestConfig
{

    //	@Value("${sts.clientid}")
    //	private String stsClientId;
    //
    //	@Value("${sts.clientsecret}")
    //	private String stsClientSecret;
    //	
    @Bean("loadBalancedRestTemplate")
    @LoadBalanced
    public RestTemplate loadBalancedRestTemplate() throws KeyManagementException, NoSuchAlgorithmException, KeyStoreException
    {

        return createRestTemplate();
    }

    @Bean("rawRestTemplate")
    public RestTemplate rawRestTemplate() throws KeyManagementException, NoSuchAlgorithmException, KeyStoreException
    {

        return createRestTemplate();
    }

    private RestTemplate createRestTemplate() throws NoSuchAlgorithmException, KeyManagementException, KeyStoreException
    {
        TrustStrategy acceptingTrustStrategy = ( X509Certificate[] chain,
                String authType ) -> true;

        SSLContext sslContext = org.apache.http.ssl.SSLContexts.custom()
                .loadTrustMaterial( null,
                                    acceptingTrustStrategy )
                .build();

        SSLConnectionSocketFactory csf = new SSLConnectionSocketFactory( sslContext );

        CloseableHttpClient httpClient = HttpClients.custom().setSSLSocketFactory( csf ).build();

        HttpComponentsClientHttpRequestFactory requestFactory = new HttpComponentsClientHttpRequestFactory();

        requestFactory.setHttpClient( httpClient );

        return new RestTemplate( requestFactory );
    }

    @Bean( "restRequestHeaderMap" )
    public MultiValueMap<String, String> restRequestHeaders()
    {
        MultiValueMap<String, String> headers = new LinkedMultiValueMap<>();
        headers.add( "Content-Type",
                     "application/json" );
        //		headers.add("ClientID", stsClientId);
        //		headers.add("ClientSecret", stsClientSecret);
        //		headers.add("scope", "oob roles profile permissions");

        return headers;
    }
}
