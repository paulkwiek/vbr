package com.hcsc.vbr.vbrtest.model;

public class ProviderSearchResponse
{

    private String providerName;
    private String networkStatus;

    public String getProviderName()
    {
        return providerName;
    }

    public void setProviderName( String providerName )
    {
        this.providerName = providerName;
    }

    public String getNetworkStatus()
    {
        return networkStatus;
    }

    public void setNetworkStatus( String networkStatus )
    {
        this.networkStatus = networkStatus;
    }
}
