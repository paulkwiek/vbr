package com.hcsc.vbr.vbrtest.repository;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpEntity;
import org.springframework.stereotype.Component;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import com.hcsc.vbr.vbrtest.config.ProviderConfig;
import com.hcsc.vbr.vbrtest.model.ProviderSearchRequest;
import com.hcsc.vbr.vbrtest.model.ProviderSearchResponse;

@Component
public class ProviderRepository
{

    @Autowired
    private AuthRepository authRepository;

    @Autowired
    @Qualifier( "rawRestTemplate" )
    private RestTemplate restTemplate;

    @Autowired
    private ProviderConfig providerConfig;

    public List<ProviderSearchResponse> search( ProviderSearchRequest provider )
    {
        String bearer = authRepository.getMemberProviderJWT();

        MultiValueMap<String, String> headers = authRepository.getAuthHeaderMap( bearer );

        HttpEntity<ProviderSearchRequest> request = new HttpEntity<>( provider,
                                                                      headers );
        List<ProviderSearchResponse> response = restTemplate.postForObject( providerConfig.getSearchURI(),
                                                                            request,
                                                                            List.class );
        return response;
    }
}
