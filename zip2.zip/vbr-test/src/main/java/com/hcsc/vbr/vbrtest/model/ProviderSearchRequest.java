package com.hcsc.vbr.vbrtest.model;

public class ProviderSearchRequest
{

    private String consumerID;
    private String corpCode;
    private String groupNumber;
    private String networkCode;
    private String region;
    private String specialty;

    public String getConsumerID()
    {
        return consumerID;
    }

    public void setConsumerID( String consumerID )
    {
        this.consumerID = consumerID;
    }

    public String getCorpCode()
    {
        return corpCode;
    }

    public void setCorpCode( String corpCode )
    {
        this.corpCode = corpCode;
    }

    public String getGroupNumber()
    {
        return groupNumber;
    }

    public void setGroupNumber( String groupNumber )
    {
        this.groupNumber = groupNumber;
    }

    public String getNetworkCode()
    {
        return networkCode;
    }

    public void setNetworkCode( String networkCode )
    {
        this.networkCode = networkCode;
    }

    public String getRegion()
    {
        return region;
    }

    public void setRegion( String region )
    {
        this.region = region;
    }

    public String getSpecialty()
    {
        return specialty;
    }

    public void setSpecialty( String specialty )
    {
        this.specialty = specialty;
    }

}
