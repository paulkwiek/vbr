package com.hcsc.vbr.vbrtest.controller;

import java.util.ArrayList;
import java.util.List;

import org.kie.api.runtime.KieContainer;
import org.kie.api.runtime.KieSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hcsc.vbr.vbrtest.model.Member;
import com.hcsc.vbr.vbrtest.repository.RedisMemberRepository;

@RestController
@RequestMapping( "/drools" )
@RefreshScope
public class RulesController
{

    @Value( "${rule.name}" )
    private String ruleName;

    @Value( "${some-key}" )
    private String testStringValueFromVault;

    @Autowired
    private KieContainer kieContainer;

    @Autowired
    private RedisMemberRepository repository;

    @GetMapping( "/apply" )
    public String drools()
    {

        runRules( ruleName );
        return "Successfully ran rules: \""
            + ruleName
            + "\", see logs for output"
            + " Value from vault is: "
            + testStringValueFromVault;
    }

    private void runRules( String sessionName )
    {

        System.out.println( "**************************" );
        System.out.println( "Running rules for session: " + sessionName );
        KieSession sess = kieContainer.newKieSession( sessionName );
        List<Member> allMembers = new ArrayList<>();
        repository.findAll().forEach( allMembers::add );
        long start = System.currentTimeMillis();
        for( Member member : allMembers )
        {
            sess.insert( member );
        }
        System.out.println( "Adding facts: " + ( System.currentTimeMillis() - start ) + "ms" );

        long start1 = System.currentTimeMillis();
        sess.fireAllRules();
        System.out.println( "Running rules: " + ( System.currentTimeMillis() - start1 ) + "ms" );
        sess.destroy();

        for( Member member : allMembers )
        {
            repository.save( member );
            System.out.println( member.getName() + " - " + member.getCapAmount() );
        }
        System.out.println( "**************************" );
    }
}
