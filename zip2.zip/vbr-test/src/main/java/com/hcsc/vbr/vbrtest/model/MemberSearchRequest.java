package com.hcsc.vbr.vbrtest.model;

public class MemberSearchRequest
{

    private String accountNumber;
    private String clientMemberId;
    private String corporationCode;
    private String firstName;
    private String groupNumber;
    private String lastName;
    private String memberRole;
    private String subscriberId;

    public String getAccountNumber()
    {
        return accountNumber;
    }

    public void setAccountNumber( String accountNumber )
    {
        this.accountNumber = accountNumber;
    }

    public String getClientMemberId()
    {
        return clientMemberId;
    }

    public void setClientMemberId( String clientMemberId )
    {
        this.clientMemberId = clientMemberId;
    }

    public String getCorporationCode()
    {
        return corporationCode;
    }

    public void setCorporationCode( String corporationCode )
    {
        this.corporationCode = corporationCode;
    }

    public String getFirstName()
    {
        return firstName;
    }

    public void setFirstName( String firstName )
    {
        this.firstName = firstName;
    }

    public String getGroupNumber()
    {
        return groupNumber;
    }

    public void setGroupNumber( String groupNumber )
    {
        this.groupNumber = groupNumber;
    }

    public String getLastName()
    {
        return lastName;
    }

    public void setLastName( String lastName )
    {
        this.lastName = lastName;
    }

    public String getMemberRole()
    {
        return memberRole;
    }

    public void setMemberRole( String memberRole )
    {
        this.memberRole = memberRole;
    }

    public String getSubscriberId()
    {
        return subscriberId;
    }

    public void setSubscriberId( String subscriberId )
    {
        this.subscriberId = subscriberId;
    }

}
