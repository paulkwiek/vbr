package com.hcsc.vbr.vbrtest.model;

import java.math.BigDecimal;

import org.springframework.data.annotation.Id;
import org.springframework.data.redis.core.RedisHash;

@RedisHash( "Member" )
public class Member
{

    @Id
    private String id;
    private String name;
    private int age;
    private String gender;
    private BigDecimal capAmount = new BigDecimal( "0" );

    public Member()
    {
        super();
    }

    public Member( String id,
        String name,
        int age,
        String gender )
    {
        super();
        this.id = id;
        this.name = name;
        this.age = age;
        this.gender = gender;
    }

    public Member( String name,
        int age,
        String gender )
    {
        super();
        this.name = name;
        this.age = age;
        this.gender = gender;
    }

    public int getAge()
    {
        return age;
    }

    public void setAge( int age )
    {
        this.age = age;
    }

    public String getGender()
    {
        return gender;
    }

    public void setGender( String gender )
    {
        this.gender = gender;
    }

    public BigDecimal getCapAmount()
    {
        return capAmount;
    }

    public void setCapAmount( BigDecimal capAmount )
    {
        this.capAmount = capAmount;
    }

    public String getName()
    {
        return name;
    }

    public void setName( String name )
    {
        this.name = name;
    }

    public String getId()
    {
        return id;
    }

    public void setId( String id )
    {
        this.id = id;
    }
}
