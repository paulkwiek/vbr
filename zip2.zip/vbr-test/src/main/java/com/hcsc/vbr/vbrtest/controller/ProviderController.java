package com.hcsc.vbr.vbrtest.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hcsc.vbr.vbrtest.model.ProviderSearchRequest;
import com.hcsc.vbr.vbrtest.model.ProviderSearchResponse;
import com.hcsc.vbr.vbrtest.repository.ProviderRepository;

@RestController
@RequestMapping( "providers" )
public class ProviderController
{

    @Autowired
    private ProviderRepository providerService;

    @PostMapping
    public List<ProviderSearchResponse> getProviders( @RequestBody ProviderSearchRequest provider )
    {

        return providerService.search( provider );
    }

}
