package com.hcsc.vbr.vbrtest.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Configuration
@ConfigurationProperties( prefix = "member" )
public class MemberConfig
{

    private String domain;
    private String searchPath;
    private String detailsPath;

    public String getSearchPath()
    {
        return searchPath;
    }

    public void setSearchPath( String searchPath )
    {
        this.searchPath = searchPath;
    }

    public String getDetailsPath()
    {
        return detailsPath;
    }

    public void setDetailsPath( String detailsPath )
    {
        this.detailsPath = detailsPath;
    }

    public String getDomain()
    {
        return domain;
    }

    public void setDomain( String domain )
    {
        this.domain = domain;
    }

    public String getSearchURI()
    {
        return domain + searchPath;
    }

    public String getDetailsURI()
    {
        return domain + detailsPath;
    }
}
