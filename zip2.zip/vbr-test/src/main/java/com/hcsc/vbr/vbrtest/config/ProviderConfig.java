package com.hcsc.vbr.vbrtest.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Configuration
@ConfigurationProperties( prefix = "provider" )
public class ProviderConfig
{

    private String domain;
    private String searchPath;

    public String getDomain()
    {
        return domain;
    }

    public void setDomain( String domain )
    {
        this.domain = domain;
    }

    public String getSearchPath()
    {
        return searchPath;
    }

    public void setSearchPath( String searchPath )
    {
        this.searchPath = searchPath;
    }

    public String getSearchURI()
    {
        return domain + searchPath;
    }
}
