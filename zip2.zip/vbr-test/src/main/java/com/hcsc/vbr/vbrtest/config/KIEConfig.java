package com.hcsc.vbr.vbrtest.config;

import org.kie.api.KieServices;
import org.kie.api.runtime.KieContainer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class KIEConfig
{

    @Bean
    public KieContainer configureKIEContainer()
    {
        KieServices ks = KieServices.Factory.get();
        return ks.getKieClasspathContainer();
    }
}
