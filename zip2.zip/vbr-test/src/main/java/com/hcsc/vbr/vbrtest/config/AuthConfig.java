package com.hcsc.vbr.vbrtest.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Configuration
@ConfigurationProperties( prefix = "auth" )
public class AuthConfig
{

    private String domain;
    private String memberJWTPath;

    public String getMemberJWTPath()
    {
        return memberJWTPath;
    }

    public void setMemberJWTPath( String memberJWTPath )
    {
        this.memberJWTPath = memberJWTPath;
    }

    public String getDomain()
    {
        return domain;
    }

    public void setDomain( String domain )
    {
        this.domain = domain;
    }

    public String getMemberJWTURI()
    {
        return domain + memberJWTPath;
    }
}
