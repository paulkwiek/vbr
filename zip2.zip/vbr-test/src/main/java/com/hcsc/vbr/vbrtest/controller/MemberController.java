package com.hcsc.vbr.vbrtest.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hcsc.vbr.vbrtest.model.MemberSearchRequest;
import com.hcsc.vbr.vbrtest.model.MemberSearchResponse;
import com.hcsc.vbr.vbrtest.repository.MemberRepository;

@RestController
@RequestMapping( "members" )
public class MemberController
{

    @Autowired
    private MemberRepository memberService;

    @PostMapping
    public List<MemberSearchResponse> getMembers( @RequestBody MemberSearchRequest search )
    {
        return memberService.memberSearch( search );
    }

    @GetMapping( "/{corporationCode}/{subscriberId}" )
    public List<MemberSearchResponse> getMembers( @PathVariable( "corporationCode" ) String corpCd,
            @PathVariable( "subscriberId" ) String subscriberId )
    {

        MemberSearchRequest memberInput = new MemberSearchRequest();
        memberInput.setCorporationCode( corpCd );
        memberInput.setSubscriberId( subscriberId );

        return memberService.memberSearch( memberInput );
    }

    @GetMapping( "/{memberId}" )
    public ResponseEntity<String> getMember( @PathVariable( "memberId" ) String memberId )
    {

        return memberService.memberDetails( memberId );

    }

}
