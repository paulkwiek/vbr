package com.hcsc.vbr.vbrtest.model;

public class MemberSearchResponse
{

    private String memberId;
    private long mid;
    private int memberNumber;

    public String getMemberId()
    {
        return memberId;
    }

    public void setMemberId( String memberId )
    {
        this.memberId = memberId;
    }

    public long getMid()
    {
        return mid;
    }

    public void setMid( long mid )
    {
        this.mid = mid;
    }

    public int getMemberNumber()
    {
        return memberNumber;
    }

    public void setMemberNumber( int memberNumber )
    {
        this.memberNumber = memberNumber;
    }

    public String getAccountNumber()
    {
        return accountNumber;
    }

    public void setAccountNumber( String accountNumber )
    {
        this.accountNumber = accountNumber;
    }

    private String accountNumber;
}
