package com.hcsc.vbr.vbrtest.repository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Repository;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import com.hcsc.vbr.vbrtest.config.AuthConfig;

@Repository
public class AuthRepository
{

    @Autowired
    private AuthConfig authConfig;

    @Autowired
    @Qualifier( "restRequestHeaderMap" )
    MultiValueMap<String, String> stsClientHeadersMap;

    @Autowired
    @Qualifier( "loadBalancedRestTemplate" )
    private RestTemplate restTemplate;

    public String getMemberProviderJWT()
    {
        //Get JWT from auth service
        HttpEntity<String> authRequest = new HttpEntity<>( stsClientHeadersMap );

        ResponseEntity<String> authRespone = restTemplate.postForEntity( authConfig.getMemberJWTURI(),
                                                                         authRequest,
                                                                         String.class );
        String bearer = authRespone.getHeaders().get( HttpHeaders.AUTHORIZATION ).get( 0 );
        return bearer;
    }

    public MultiValueMap<String, String> getAuthHeaderMap( String bearer )
    {
        //Call member API
        MultiValueMap<String, String> headers = new LinkedMultiValueMap<>();
        headers.add( "Content-Type",
                     "application/json" );
        headers.add( HttpHeaders.AUTHORIZATION,
                     bearer );
        return headers;
    }

}
