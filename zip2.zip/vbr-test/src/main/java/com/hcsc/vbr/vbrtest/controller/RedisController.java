package com.hcsc.vbr.vbrtest.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hcsc.vbr.vbrtest.model.Member;
import com.hcsc.vbr.vbrtest.repository.RedisMemberRepository;

@RestController
@RequestMapping( "/redis" )
public class RedisController
{

    @Autowired
    private RedisMemberRepository repository;

    @GetMapping( "/members/addall" )
    public void addAllMembers()
    {
        repository.save( new Member( "1",
                                     "Chuck Knox",
                                     32,
                                     "M" ) );
        repository.save( new Member( "2",
                                     "Tom Foles",
                                     40,
                                     "M" ) );
        repository.save( new Member( "3",
                                     "Charlene Gibbons",
                                     20,
                                     "F" ) );
        repository.save( new Member( "4",
                                     "Sherry Hill",
                                     30,
                                     "F" ) );
    }

    @GetMapping( "/members/{id}" )
    public Member get( @PathVariable String id )
    {
        try
        {
            return repository.findById( id ).get();
        }
        catch( NoSuchElementException e )
        {
            return new Member();
        }
    }

    @GetMapping( "/members" )
    public List<Member> getAll()
    {
        List<Member> members = new ArrayList<>();
        repository.findAll().forEach( members::add );
        return members;
    }

    @GetMapping( "/members/reset" )
    public String reset()
    {
        repository.deleteAll();
        return "All members successfully deleted";
    }

    public List<Member> getLotsOMembers()
    {

        Random r = new Random();
        int low = 10;
        int high = 60;
        List<Member> members = new ArrayList<>( 1000 );
        for( int i = 0; i < 1000; i++ )
        {
            int num = r.nextInt( high - low ) + low;
            members.add( new Member( "Member Name" + i,
                                     num,
                                     num % 3 == 0 ? "M"
                                         : "F" ) );
        }
        return members;
    }

}
