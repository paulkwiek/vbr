package com.hcsc.vbr.vbrtest.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.hcsc.vbr.vbrtest.model.Member;

@Repository
public interface RedisMemberRepository extends CrudRepository<Member, String>
{

}
