package com.hcsc.vbr.vbrtest;

import java.sql.SQLException;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.security.servlet.SecurityAutoConfiguration;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;

@EnableCaching
@SpringBootApplication( exclude = { SecurityAutoConfiguration.class } )
public class VbrTestApplication
{

    public static void main( String[] args ) throws SQLException
    {
        SpringApplication.run( VbrTestApplication.class,
                               args );
    }
}
