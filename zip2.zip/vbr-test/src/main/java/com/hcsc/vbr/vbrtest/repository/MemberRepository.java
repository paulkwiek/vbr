package com.hcsc.vbr.vbrtest.repository;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import com.hcsc.vbr.vbrtest.config.MemberConfig;
import com.hcsc.vbr.vbrtest.model.MemberSearchRequest;
import com.hcsc.vbr.vbrtest.model.MemberSearchResponse;

@Component
public class MemberRepository
{

    @Autowired
    private AuthRepository authRepository;

    @Autowired
    @Qualifier( "rawRestTemplate" )
    private RestTemplate restTemplate;

    @Autowired
    private MemberConfig memberConfig;

    public List<MemberSearchResponse> memberSearch( MemberSearchRequest memberInput)
    {
        String bearer = authRepository.getMemberProviderJWT();

        MultiValueMap<String, String> headers = authRepository.getAuthHeaderMap( bearer );

        HttpEntity<MemberSearchRequest> request = new HttpEntity<>( memberInput,
                                                                    headers );
        List<MemberSearchResponse> response = restTemplate.postForObject( memberConfig.getSearchURI(),
                                                                          request,
                                                                          List.class );
        return response;
    }

    public ResponseEntity<String> memberDetails( String memberId )
    {

        String bearer = authRepository.getMemberProviderJWT();

        HttpHeaders headers = new HttpHeaders();
        headers.set( "Content-Type",
                     "application/json" );
        headers.set( HttpHeaders.AUTHORIZATION,
                     bearer );
        HttpEntity<HttpHeaders> entity = new HttpEntity<>( headers );
        return restTemplate.exchange( memberConfig.getDetailsURI(),
                                      HttpMethod.GET,
                                      entity,
                                      String.class,
                                      memberId );

    }

}
