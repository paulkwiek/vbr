# Value Based Reimbursements
  * [Cookbooks](#cookbooks)
  * [External Properties Configuration](README-External-Properties-Config.md)
  * [UI](#vbr-ui)
  * [Microservices](#vbr-services)

# Cookbooks
1.  [PCF](https://hcsc-cookbook.cfaa.hcsctest.net/)

# VBR UI
------
## Project Setup

### Prerequisites
1. Make sure nodejs is installed (min version 8.1.0) [download here](https://nodejs.org/en/)
2. Copy  [.npmrc](https://ghe.fyiblue.com/HCSC-Pilot/VBR_Services/blob/PRV-5121/docs/.npmrc) from the docs directory to your user directory.
3. `npm install -g @angular/cli`


### Build and Watch (dev)
1. `git clone <repo>`
2. `cd value-based-reimbursements`
3. `npm install`
4. `ng server`
5. Open browser to URL http://localhost:4200/


### Project Scafollding 

* src/
    * Directory with all the developed code to make the app execute at runtime.
* angular.json
    * This is the configuration for the Angular CLI tool which drives testing, building and watching. 
        * `ng serve`
        * `ng test`
        * `ng build`
        * `ng lint`
* .gitignore
    * VBR file and directory ignores
* karma.conf.js
    * Coniguration for Karma/Jasmine unit testing
* package.json
    * Node Package Manager package configuration for our JS/TS depenedencies
* tsconfig.json
    * Configuration for Typescript build transpiling and ECMA versioning
* tslint.json
    * Lint configuration for Typescript rules


### UI Deployment

#### Manually deploying a .jar (this is the current process being used if not through the Jenkins job)
1. Open a cmd window
1. `cd <git base dir>/vbr-ui`
1. `mvn clean install -P<env>  ex.    mvn clean install -Pdev   or mvn clean install -Pqa`
1. If you are not already logged into Cloud Foundry do these steps: (Note: cf commands must be done in DOS cmd prompt.  They do not work in gitbash)
    * cf login -a api.cfss.hcsctest.net  
    * You will be prompted for for your Lan ID and password.  Enter them.
    * You will be prompted for the org.  Select 'APP00006985_Value_Based_Reimbursement'.
    * You will be prompted for the space.  Select the space you want i.e. 'VBR_POC'.

    Otherwise, If you are already logged into Cloud Foundry make sure you are pointing at the correct space (dev or qa)
    by issuing one of these commands:
    * cf target -s VBR_POC		       (For POC)
1. `cf push -f manifest-<env>.yml -p target/vbr-ui-0.0.1-SNAPSHOT-<env>.jar` <br>
   ex.  cf push -f manifest-dev.yml -p target/vbr-ui-0.0.1-SNAPSHOT-dev.jar <br>
        cf push -f manifest-qa.yml -p target/vbr-ui-0.0.1-SNAPSHOT-qa.jar`

#### Option 2: Static deploy (This was done prior to the requirement that a .jar had to be deployed)
[Pivot Static Deployment Doc](https://docs.cloudfoundry.org/buildpacks/staticfile/index.html)

1. `cd <git base dir>/vbr-hub-ui`
1. `ng build --configuration=<env ie:qa>`
1. `cd dist/vbr-ui`
1. `touch StaticFile`
1. `echo "pushstate: enable" >> StaticFile`</br>
1. If you are not already logged into Cloud Foundry do these steps: (Note: cf commands must be done in DOS cmd prompt.  They do not work in gitbash)
    * cf login -a api.cfss.hcsctest.net  
    * You will be prompted for for your Lan ID and password.  Enter them.
    * You will be prompted for the org.  Select 2 APP00006985_Value_Based_Reimbursement.
    * You will be prompted for the space.  Select 1 VBR_POC, or it might automatically choose that one.

    Otherwise, If you are already logged into Cloud Foundry make sure you are pointing at the correct space (dev or qa)
    by issuing one of these commands:
    * cf target -s VBR_POC		       (For POC)</br>
1. `cf push -b staticfile_buildpack vbr-ui-<env ie:qa>`


=======
# VBR Services

## Project Setup
### Prereqs
1. Make sure Git Bash is [installed](https://ghe.fyiblue.com/HCSC-Pilot/VBR_Services/blob/PRV-5121/docs/Installing_Git_Bash_Client_v3.pdf)

2. Make sure Git SSH Key is [configured](https://ghe.fyiblue.com/HCSC-Pilot/VBR_Services/blob/PRV-5121/docs/Setting_GitHub_SSH_Key_v2.pdf)

### Installation
1. Open Git Bash to a directory where you want the project
2. `git clone <repo>`
3. Open MyEclipse or STS
4. File -> Open Projects from File System
5. Click Directory.. Find the directory you put the project
6. Select VBR_Services, click Okay
7. Select the services you want.
8. Click Finish

### Micro service Deployment
The following microservices make up the application:
* vbr-auth
* vbr-test

#### To manually deploy a micro service to dev/qa  (Do this in a DOS command window NOT git Bash)
This assumes that all dependent services are ready to be bound to.

1. `cd <git base dir>/<name of microservice to deploy>`  
`ex.  cd <git base dir>/vbr-test`
1. mvn clean install

**If you are not already logged into Cloud Foundry do these steps:**
1. cf login -a api.cfss.hcsctest.net  
1. You will be prompted for for your Lan ID and password.  Enter them.
1. You will be prompted for the org.  Select 2 APP00006985_Value_Based_Reimbursement.
1. You will be prompted for the space.  Select 1 VBR_POC, or it might automatically choose that one.


**Otherwise, If you are already logged into Cloud Foundry make sure you are pointing at the correct space (dev or qa)
by issuing one of these commands:**
* cf target -s VBR_POC		       (For POC)

**select the proper push based on the environment and microservice and enter it**</br>
`cf push -f manifest-<env>.yml -p target/<name of microservice>-0.0.1-SNAPSHOT.jar</br>`

cf push -f manifest-dev.yml -p target/vbr-auth-0.0.1-SNAPSHOT.jar</br>
cf push -f manifest-dev.yml -p target/vbr-test-0.0.1-SNAPSHOT.jar</br>

cf push -f manifest-qa.yml -p target/vbr-auth-0.0.1-SNAPSHOT.jar</br>
cf push -f manifest-qa.yml -p target/vbr-test-0.0.1-SNAPSHOT.jar</br>


