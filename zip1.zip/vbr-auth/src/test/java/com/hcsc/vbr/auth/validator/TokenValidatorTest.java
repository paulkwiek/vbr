package com.hcsc.vbr.auth.validator;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.io.UnsupportedEncodingException;
import java.util.Date;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import com.hcsc.vbr.auth.exception.InvalidTokenException;
import com.hcsc.vbr.auth.model.STSResponse;
import com.nimbusds.jose.JOSEException;
import com.nimbusds.jose.JWSAlgorithm;
import com.nimbusds.jose.JWSHeader;
import com.nimbusds.jose.JWSSigner;
import com.nimbusds.jose.crypto.MACSigner;
import com.nimbusds.jose.crypto.RSASSAVerifier;
import com.nimbusds.jwt.JWTClaimsSet;
import com.nimbusds.jwt.SignedJWT;

@RunWith( MockitoJUnitRunner.class )
public class TokenValidatorTest
{

    @Mock
    RSASSAVerifier rsaVerifier;

    @InjectMocks
    TokenValidator validator;

    private String jwtToken =
        "eyJhbGciOiJIUzI1NiJ9.eyJtb2RlIjoidXNlciIsImlzcyI6ImRpb2dvLnJvc2FzLmZlcnJlaXJhQGdtYWlsLmNvbSJ9.I5Ysne1C79cO5B_5hIQK9iBSnQ6M8msuyVHD4kdoFSo";

    @Before
    public void setUp() throws Exception
    {
    }

    @Test
    public void validateSTSTokenShouldThrowInvalidTokenExceptionWithNotVerifiedMessage()
    {
        STSResponse stsResponse = new STSResponse();
        stsResponse.setJwtToken( jwtToken );
        try
        {
            validator.validateSTSToken( stsResponse );
        }
        catch( InvalidTokenException ex )
        {
            assertEquals( "The JWT token from the auth service could not be verified, invalid token",
                          ex.getMessage() );
        }
    }

    @Test
    public void validateSTSTokenShouldThrowInvalidTokenExceptionWithNotParsedMessage()
    {
        STSResponse stsResponse = new STSResponse();
        stsResponse.setJwtToken( "Bearer " + jwtToken );
        try
        {
            validator.validateSTSToken( stsResponse );
        }
        catch( InvalidTokenException ex )
        {
            assertTrue( ex.getMessage().startsWith( "Could not parse token, invalid token" ) );
        }
    }

    @Test
    public void validateSTSTokenShouldThrowInvalidTokenExceptionWithTokenExceptionMessage() throws JOSEException
    {
        STSResponse stsResponse = new STSResponse();
        stsResponse.setJwtToken( jwtToken );
        when( rsaVerifier.verify( any(),
                                  any(),
                                  any() ) ).thenThrow( new JOSEException( "exception" ) );
        try
        {
            validator.validateSTSToken( stsResponse );
        }
        catch( InvalidTokenException ex )
        {
            assertTrue( ex.getMessage().startsWith( "Could validate tokenexception" ) );
        }
    }

    @Test
    public void validateSTSTokenSuccess() throws JOSEException, UnsupportedEncodingException
    {
        Date exp = new Date( System.currentTimeMillis() + ( 1000 * 3600 ) ); // 1 hours

        JWTClaimsSet claimsSet = new JWTClaimsSet.Builder()

                .jwtID( "76641e10-3e11-4cd8-8fee-461e93ff5452" )
                .issueTime( new Date() )
                .expirationTime( exp )
                .build();
        SignedJWT signedJWT = new SignedJWT( new JWSHeader( JWSAlgorithm.HS256 ),
                                             claimsSet );
        JWSSigner signer = null;
        byte[] sharedKey = "aaaaaaaaabbbbbbbbbbbccccccccccnnnnnnnn".getBytes( "UTF-8" );
        signer = new MACSigner( sharedKey );

        signedJWT.sign( signer );

        String jwtString = signedJWT.serialize();

        STSResponse stsResponse = new STSResponse();
        stsResponse.setJwtToken( jwtString );
        when( rsaVerifier.verify( any(),
                                  any(),
                                  any() ) ).thenReturn( true );
        boolean result = validator.validateSTSToken( stsResponse );
        assertTrue( result );
    }

    @Test
    public void validateSTSTokenExpired() throws JOSEException, UnsupportedEncodingException
    {
        Date exp = new Date( System.currentTimeMillis() - 100 );

        JWTClaimsSet claimsSet = new JWTClaimsSet.Builder()

                .jwtID( "76641e10-3e11-4cd8-8fee-461e93ff5452" )
                .issueTime( new Date() )
                .expirationTime( exp )
                .build();
        SignedJWT signedJWT = new SignedJWT( new JWSHeader( JWSAlgorithm.HS256 ),
                                             claimsSet );
        JWSSigner signer = null;
        byte[] sharedKey = "aaaaaaaaabbbbbbbbbbbccccccccccnnnnnnnn".getBytes( "UTF-8" );
        signer = new MACSigner( sharedKey );

        signedJWT.sign( signer );
        String jwtString = signedJWT.serialize();

        STSResponse stsResponse = new STSResponse();
        stsResponse.setJwtToken( jwtString );
        when( rsaVerifier.verify( any(),
                                  any(),
                                  any() ) ).thenReturn( true );
        try {
            validator.validateSTSToken( stsResponse );
            //this should never be hit since an exception is thrown
            //we want test to fail if no exception thrown!
            assertTrue(false);
        } catch (InvalidTokenException e) {
            assertEquals( "The JWT token from the auth service has expired", e.getMessage() );
        }
    }

}
