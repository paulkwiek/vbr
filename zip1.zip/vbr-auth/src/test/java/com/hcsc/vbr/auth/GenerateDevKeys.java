package com.hcsc.vbr.auth;

import java.io.ByteArrayInputStream;
import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.security.interfaces.RSAPrivateKey;
import java.security.interfaces.RSAPublicKey;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.PKCS8EncodedKeySpec;
import java.util.Base64;

import com.nimbusds.jose.crypto.RSASSASigner;
import com.nimbusds.jose.crypto.RSASSAVerifier;

public class GenerateDevKeys
{

    public static void main( String[] args ) throws NoSuchAlgorithmException, InvalidKeySpecException, CertificateException
    {
        // RSA signatures require a public and private RSA key pair, the public key 
        // must be made known to the JWS recipient in order to verify the signatures
        KeyPairGenerator keyGenerator = KeyPairGenerator.getInstance( "RSA" );
        keyGenerator.initialize( 4096 );

        KeyPair kp = keyGenerator.genKeyPair();

        Base64.Encoder encoder = Base64.getEncoder();

        RSAPrivateKey privateKey = (RSAPrivateKey) kp.getPrivate();
        KeyFactory kf = KeyFactory.getInstance( "RSA" );
        PrivateKey key = kf.generatePrivate( new PKCS8EncodedKeySpec( privateKey.getEncoded() ) );
        new RSASSASigner( key );
        System.out.println( "PRIVATE KEY:" );
        System.out.println( encoder.encodeToString( privateKey.getEncoded() ) );

        RSAPublicKey publicKey = (RSAPublicKey) kp.getPublic();
        System.out.println( publicKey.getFormat() );
        CertificateFactory cf = CertificateFactory.getInstance( "X.509" );
        X509Certificate cert = (X509Certificate) cf.generateCertificate( new ByteArrayInputStream( publicKey.getEncoded() ) );
        RSAPublicKey pubKey = (RSAPublicKey) cert.getPublicKey();
        new RSASSAVerifier( pubKey );
        System.out.println( "" );
        System.out.println( "PUBLIC KEY:" );
        System.out.println( encoder.encodeToString( publicKey.getEncoded() ) );

    }
}
