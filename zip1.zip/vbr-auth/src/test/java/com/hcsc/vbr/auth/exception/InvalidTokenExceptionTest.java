package com.hcsc.vbr.auth.exception;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class InvalidTokenExceptionTest
{

    @Test
    public void shouldVerifyMessage()
    {
        RuntimeException ex = new InvalidTokenException( "invalid token" );
        assertEquals( "invalid token",
                      ex.getMessage() );
    }

}
