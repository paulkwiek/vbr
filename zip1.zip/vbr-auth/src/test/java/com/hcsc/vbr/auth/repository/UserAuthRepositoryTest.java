package com.hcsc.vbr.auth.repository;

import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.ArgumentMatchers.isA;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import com.hcsc.vbr.auth.config.MemberConfig;
import com.hcsc.vbr.auth.config.STSConfig;
import com.hcsc.vbr.auth.exception.InvalidTokenException;
import com.hcsc.vbr.auth.model.STSResponse;
import com.hcsc.vbr.auth.validator.TokenValidator;

@RunWith( MockitoJUnitRunner.class )
public class UserAuthRepositoryTest
{

    @Mock
    private UserDetailsRepository userDetailsRepository;

    @Mock
    private RestTemplate restTemplate;

    @Mock
    private STSConfig stsConfig;

    @Mock
    private MemberConfig memberConfig;

    @Mock
    private TokenValidator validator;

    @Mock
    MultiValueMap<String, String> stsClientHeadersMap;

    @InjectMocks
    UserAuthRepository repository;

    @Before
    public void setUp() throws Exception
    {
    }

    @Test
    public void shouldRetrieveUserTokenForInternalUrl()
    {
        STSResponse stsResponse = new STSResponse();
        stsResponse.setAccessToken( "access token" );
        when( stsConfig.getSmsessionURI() ).thenReturn( "someuri" );
        when( restTemplate.postForObject( isA( String.class ),
                                          isA( HttpEntity.class ),
                                          eq( STSResponse.class ) ) ).thenReturn( stsResponse );
        when( validator.validateSTSToken( stsResponse ) ).thenReturn( true );

        STSResponse resultSTSResponse = repository.retrieveUserToken( "smsession" );
        verify( userDetailsRepository ).getUserDetails( stsResponse );
        assertEquals( stsResponse,
                      resultSTSResponse );

    }

    @Test
    public void shouldRefreshUserToken()
    {
        String refreshToken = "refresh token";
        String jwtToken =
            "eyJhbGciOiJIUzI1NiJ9.eyJtb2RlIjoidXNlciIsImlzcyI6ImRpb2dvLnJvc2FzLmZlcnJlaXJhQGdtYWlsLmNvbSJ9.I5Ysne1C79cO5B_5hIQK9iBSnQ6M8msuyVHD4kdoFSo";

        STSResponse stsResponse = new STSResponse();
        when( stsConfig.getRefreshURI( refreshToken ) ).thenReturn( "someuri" );
        when( restTemplate.postForObject( isA( String.class ),
                                          isA( HttpEntity.class ),
                                          eq( STSResponse.class ) ) ).thenReturn( stsResponse );
        when( validator.validateSTSToken( stsResponse ) ).thenReturn( true );

        STSResponse resultSTSResponse = repository.refreshUserToken( refreshToken,
                                                                     jwtToken );
        assertEquals( stsResponse,
                      resultSTSResponse );
    }

    @Test( expected = InvalidTokenException.class )
    public void shouldRefreshUserTokenThrowsException()
    {
        String refreshToken = "refresh token";
        String jwtToken =
            "eyJhbGciOiJIUzI1NiJ9.eyJtb2RlIjoidXNlciIsImlzcyI6ImRpb2dvLnJvc2FzLmZlcnJlaXJhQGdtYWlsLmNvbSJ9.I5Ysne1C79cO5B_5hIQK9iBSnQ6M8msuyVHD4kdoFSo";
        when( stsConfig.getRefreshURI( "refresh token" ) ).thenReturn( "someuri" );
        when( restTemplate.postForObject( isA( String.class ),
                                          isA( HttpEntity.class ),
                                          eq( STSResponse.class ) ) )
                                                  .thenThrow( new HttpClientErrorException( HttpStatus.INTERNAL_SERVER_ERROR ) );
        repository.refreshUserToken( refreshToken,
                                     jwtToken );
    }

    @Test
    public void shouldRetrieveUserToken_HappyPath()
    {
        STSResponse stsResponse = new STSResponse();
        stsResponse.setAccessToken( "access token" );
        when( stsConfig.getSmsessionURI() ).thenReturn( "someuri" );
        when( restTemplate.postForObject( isA( String.class ),
                                          isA( HttpEntity.class ),
                                          eq( STSResponse.class ) ) ).thenReturn( stsResponse );
        when( validator.validateSTSToken( stsResponse ) ).thenReturn( true );

        STSResponse resultSTSResponse = repository.retrieveUserToken( "smsession" );
        verify( userDetailsRepository ).getUserDetails( stsResponse );
        assertEquals( stsResponse,
                      resultSTSResponse );

    }

    @Test
    public void shouldRetrieveJWT_HappyPath()
    {
        STSResponse stsResponse = new STSResponse();
        stsResponse.setAccessToken( "access token" );
        when( stsConfig.getJwtURI() ).thenReturn( "someuri" );
        when( restTemplate.postForObject( isA( String.class ),
                                          isA( HttpEntity.class ),
                                          eq( STSResponse.class ) ) ).thenReturn( stsResponse );
        when( validator.validateSTSToken( stsResponse ) ).thenReturn( true );

        STSResponse resultSTSResponse = repository.retrieveMemberAPIToken();
        assertEquals( stsResponse,
                      resultSTSResponse );

    }

    @Test( expected = InvalidTokenException.class )
    public void retrieveUserTokenShouldThrowHttpClientErrorException()
    {
        STSResponse stsResponse = new STSResponse();
        stsResponse.setAccessToken( "access token" );

        when( stsConfig.getSmsessionURI() ).thenReturn( "someuri" );

        when( restTemplate.postForObject( isA( String.class ),
                                          isA( HttpEntity.class ),
                                          eq( STSResponse.class ) ) ).thenThrow( HttpClientErrorException.class );

        repository.retrieveUserToken( "smsession" );
    }

    @Test( expected = InvalidTokenException.class )
    public void retrieveMemberJWTShouldThrowHttpClientErrorException()
    {
        STSResponse stsResponse = new STSResponse();
        stsResponse.setAccessToken( "access token" );

        when( stsConfig.getJwtURI() ).thenReturn( "someuri" );

        when( restTemplate.postForObject( isA( String.class ),
                                          isA( HttpEntity.class ),
                                          eq( STSResponse.class ) ) ).thenThrow( HttpClientErrorException.class );

        repository.retrieveMemberAPIToken();
    }

    @Test( expected = InvalidTokenException.class )
    public void retrieveUserTokenShouldThrowInvalidTokenException()
    {
        STSResponse stsResponse = new STSResponse();
        stsResponse.setAccessToken( "access token" );
        when( stsConfig.getSmsessionURI() ).thenReturn( "someuri" );
        when( restTemplate.postForObject( isA( String.class ),
                                          isA( HttpEntity.class ),
                                          eq( STSResponse.class ) ) ).thenThrow( new InvalidTokenException( "" ) );

        repository.retrieveUserToken( "smsession" );
    }

    @Test( expected = InvalidTokenException.class )
    public void retrieveMemberJWTShouldThrowInvalidTokenException()
    {
        STSResponse stsResponse = new STSResponse();
        stsResponse.setAccessToken( "access token" );
        when( stsConfig.getJwtURI() ).thenReturn( "someuri" );
        when( restTemplate.postForObject( isA( String.class ),
                                          isA( HttpEntity.class ),
                                          eq( STSResponse.class ) ) ).thenThrow( new InvalidTokenException( "" ) );

        repository.retrieveMemberAPIToken();
    }

}
