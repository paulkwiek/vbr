package com.hcsc.vbr.auth.config;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.security.spec.InvalidKeySpecException;

import org.junit.Assert;
import org.junit.Test;
import org.springframework.test.util.ReflectionTestUtils;

import com.nimbusds.jose.crypto.RSASSAVerifier;

public class SecurityKeysTest
{

    SecurityKeys classUnderTest = new SecurityKeys();
    
    @Test
    public void loadPEMFile() throws IOException, NoSuchAlgorithmException, InvalidKeySpecException, CertificateException {
        Path path = Paths.get("src/test/resources/sts_layer7_TEST_public_cert_AS_string_no_linefeeds.txt");
        
        String cert = Files.readAllLines(path).get(0);
        ReflectionTestUtils.setField(classUnderTest, "stsPublicKey", cert);
        
        RSASSAVerifier verifier = classUnderTest.rsaVerifier();
        Assert.assertNotNull( verifier );
    }
}
