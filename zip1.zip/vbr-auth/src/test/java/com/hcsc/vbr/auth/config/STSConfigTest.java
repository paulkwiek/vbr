package com.hcsc.vbr.auth.config;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class STSConfigTest
{

    STSConfig config = new STSConfig();

    @Before
    public void setup()
    {
        config.setClientid( "clientId" );
        config.setClientsecret( "clientSecret" );
        config.setDomain( "/domain" );
        config.setJwtPath( "/jwtPath" );
        config.setRefreshPath( "/refreshPath" );
        config.setSmsessionPath( "/smsessionPath" );
        config.setUserdetailsPath( "/userdetailspath" );
    }

    @Test
    public void gettersSucceed()
    {
        Assert.assertEquals( "/domain",
                             config.getDomain() );
        Assert.assertEquals( "clientId",
                             config.getClientid() );
        Assert.assertEquals( "clientSecret",
                             config.getClientsecret() );
        Assert.assertEquals( "/jwtPath",
                             config.getJwtPath() );
        Assert.assertEquals( "/refreshPath",
                             config.getRefreshPath() );
        Assert.assertEquals( "/smsessionPath",
                             config.getSmsessionPath() );
        Assert.assertEquals( "/userdetailspath",
                             config.getUserdetailsPath() );
        Assert.assertEquals( "/domain/smsessionPath?app_rolefilters=vbr",
                             config.getSmsessionURI() );
        Assert.assertEquals( "/domain/userdetailspath",
                             config.getUserdetailsURI() );
        Assert.assertEquals( "/domain/jwtPath",
                             config.getJwtURI() );
        Assert.assertEquals( "/domain/refreshPath?scope=oob profile roles&grant_type=refresh_token&refresh_token=token",
                             config.getRefreshURI( "token" ) );
    }

}
