package com.hcsc.vbr.auth.exception;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.hcsc.vbr.auth.controller.UserAuthController;

@RunWith( MockitoJUnitRunner.class )
public class CustomizedResponseEntityExceptionHandlerTest
{

    private MockMvc mockMvc;

    @Mock
    private UserAuthController userAuthController;

    @Before
    public void setup()
    {
        mockMvc = MockMvcBuilders.standaloneSetup( userAuthController )
                .setControllerAdvice( new CustomizedResponseEntityExceptionHandler() )
                .build();
    }

    @Test
    public void testHandleAllExceptions() throws Exception
    {
        MockHttpServletRequest request = new MockHttpServletRequest();
        MockHttpServletResponse response = new MockHttpServletResponse();
        when( userAuthController.retrieveJWTFromSMSession( any( String.class ),
                                                           any( HttpServletRequest.class ),
                                                           any( HttpServletResponse.class ) ) )
                                                                   .thenThrow( new RuntimeException( "Unexpected Exception" ) );

        Cookie smsessionCookie = new Cookie( "SMSESSION",
                                             "smsession" );
        mockMvc.perform( get( "/users/smsession" ).cookie( smsessionCookie )
                .requestAttr( "request",
                              request )
                .requestAttr( "response",
                              response ) )
                .andExpect( status().isInternalServerError() )
                .andExpect( jsonPath( "$.message" ).value( "Error Caught" ) );
    }

    @Test
    public void testHandleInvalidTokenExceptions() throws Exception
    {
        MockHttpServletRequest request = new MockHttpServletRequest();
        MockHttpServletResponse response = new MockHttpServletResponse();
        when( userAuthController.retrieveJWTFromSMSession( any( String.class ),
                                                           any( HttpServletRequest.class ),
                                                           any( HttpServletResponse.class ) ) )
                                                                   .thenThrow( new InvalidTokenException( "Invalid Token Exception" ) );

        Cookie smsessionCookie = new Cookie( "SMSESSION",
                                             "smsession" );
        mockMvc.perform( get( "/users/smsession" ).cookie( smsessionCookie )
                .requestAttr( "request",
                              request )
                .requestAttr( "response",
                              response ) )
                .andExpect( status().isUnauthorized() )
                .andExpect( jsonPath( "$.message" ).value( "Error Caught" ) );
    }

    @Test
    public void testHandleMiscFailures() throws Exception
    {
        MockHttpServletRequest request = new MockHttpServletRequest();
        MockHttpServletResponse response = new MockHttpServletResponse();
        when( userAuthController.retrieveJWTFromSMSession( any( String.class ),
                                                           any( HttpServletRequest.class ),
                                                           any( HttpServletResponse.class ) ) )
                                                                   .thenThrow( new IllegalArgumentException( "Illegal Argument Exception" ) );

        Cookie smsessionCookie = new Cookie( "SMSESSION",
                                             "smsession" );
        mockMvc.perform( get( "/users/smsession" ).cookie( smsessionCookie )
                .requestAttr( "request",
                              request )
                .requestAttr( "response",
                              response ) )
                .andExpect( status().isBadRequest() )
                .andExpect( jsonPath( "$.message" ).value( "Error Caught" ) );

    }

}
