package com.hcsc.vbr.auth.model;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import javax.naming.InvalidNameException;

import org.junit.Test;

public class UserDetailsTest
{

    @Test
    public void testSetters()
    {
        UserDetails userDetails = new UserDetails();
        userDetails.setFamilyName( "family" );
        userDetails.setGivenName( "given" );
        userDetails.setName( "name" );
        userDetails.setRoles( "role" );
        userDetails.setSub( "sub" );

        assertEquals( "family",
                      userDetails.getFamilyName() );
        assertEquals( "given",
                      userDetails.getGivenName() );
        assertEquals( "name",
                      userDetails.getName() );
        assertEquals( "role",
                      userDetails.getRoles() );
        assertEquals( "sub",
                      userDetails.getSub() );
    }

    @Test
    public void shouldVerifyGetGroupNamesForNoCNValue() throws InvalidNameException
    {
        UserDetails userDetails = new UserDetails();
        userDetails.setRoles( "ou=Roles,ou=Framework,ou=SERVICES,o=EXTLDAP" );

        assertTrue( 0 == userDetails.getGroupNames().size() );
    }

    @Test
    public void hasNoHCSCRole() throws InvalidNameException
    {
        UserDetails userDetails = new UserDetails();
        userDetails.setRoles( "cn=SCPH Fund Basic User,ou=Roles,ou=Framework,ou=SERVICES,o=EXTLDAP" );

        assertFalse( userDetails.hasHSCSRole() );
    }

    @Test
    public void hasHCSCAccountManagmentRole() throws InvalidNameException
    {
        UserDetails userDetails = new UserDetails();
        userDetails.setRoles( "cn=SCPH HCSC Account Mgmt User,ou=Roles,ou=Framework,ou=SERVICES,o=EXTLDAP" );

        assertTrue( userDetails.hasHSCSRole() );
    }

    @Test
    public void shouldVerifyGetGroupNamesForNoSCPH_Group() throws InvalidNameException
    {
        UserDetails userDetails = new UserDetails();
        userDetails.setRoles( "cn=SCPH Fund Basic User,ou=Roles,ou=Framework,ou=SERVICES,o=EXTLDAP" );

        assertTrue( 0 == userDetails.getGroupNames().size() );
    }

    @Test
    public void shouldVerifyGetGroupNamesForSCPH_Group() throws InvalidNameException
    {
        UserDetails userDetails = new UserDetails();
        userDetails
                .setRoles( "cn=SCPH Fund Basic User,ou=Roles,ou=Framework,ou=SERVICES,o=EXTLDAP;cn=SCPH Group MyGroup,ou=Roles,ou=Framework,ou=SERVICES,o=EXTLDAP" );

        assertTrue( 1 == userDetails.getGroupNames().size() );
        assertEquals( "MyGroup",
                      userDetails.getGroupNames().get( 0 ) );
    }

    @Test
    public void shouldVerifyGetRolesListForNoCNValue() throws InvalidNameException
    {
        UserDetails userDetails = new UserDetails();
        //userDetails.setPermissions("CN=Some,OU=Distribution Groups,DC=gp");
        userDetails.setRoles( "ANY=Some" );

        assertTrue( 0 == userDetails.getRolesList().size() );
    }

    @Test
    public void shouldVerifyGetRolesListForCNValue() throws InvalidNameException
    {
        UserDetails userDetails = new UserDetails();
        userDetails.setRoles( "CN=Some" );

        assertTrue( 0 == userDetails.getRolesList().size() );
    }

    @Test
    public void shouldVerifyHasHSCSRoleAsFalse() throws InvalidNameException
    {
        UserDetails userDetails = new UserDetails();
        //userDetails.setPermissions("CN=Some,OU=Distribution Groups,DC=gp");
        userDetails.setRoles( "ANY=Some" );

        assertFalse( userDetails.hasHSCSRole() );
    }

    @Test
    public void shouldVerifyHasHSCSRoleAsTrue() throws InvalidNameException
    {
        UserDetails userDetails = new UserDetails();
        userDetails.setRoles( "CN=basicuser;CN=SCPH HCSC Basic User" );

        assertTrue( userDetails.hasHSCSRole() );
    }

    @Test
    public void shouldVerifyHasHSCSRoleAsTrue2() throws InvalidNameException
    {
        UserDetails userDetails = new UserDetails();
        userDetails.setRoles( "CN=basicuser;CN=SCPH HCSC Admin User" );

        assertTrue( userDetails.hasHSCSRole() );
    }

    @Test
    public void shouldVerifyHasHSCSRoleAsTrue3() throws InvalidNameException
    {
        UserDetails userDetails = new UserDetails();
        userDetails.setRoles( "CN=basicuser;CN=SCPH HCSC Account Mgmt User" );

        assertTrue( userDetails.hasHSCSRole() );
    }

}
