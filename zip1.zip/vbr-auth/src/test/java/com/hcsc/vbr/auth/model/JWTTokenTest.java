package com.hcsc.vbr.auth.model;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class JWTTokenTest
{

    @Test
    public void testSetters()
    {
        JWTToken jWTToken = new JWTToken();
        jWTToken.setJwtToken( "token" );

        assertEquals( "token",
                      jWTToken.getJwtToken() );
    }

}
