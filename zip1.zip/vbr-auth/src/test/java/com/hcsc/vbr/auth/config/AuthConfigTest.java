package com.hcsc.vbr.auth.config;

import org.junit.Test;
import static org.junit.Assert.*;

import com.hcsc.vbr.auth.model.User;

public class AuthConfigTest
{

    @Test
    public void test()
    {
        MemberConfig config = new MemberConfig();
        config.setUsername( "user" );
        config.setPassword( "pass" );
        User user = config.getMemberAndProviderUser();
        assertEquals( "user",
                      config.getUsername() );
        assertEquals( "pass",
                      config.getPassword() );
        assertEquals( "user",
                      user.getUsername() );
        assertEquals( "pass",
                      user.getPassword() );
        User newUser = config.getMemberAndProviderUser();
        assertNotSame( newUser,
                       user );
    }
}
