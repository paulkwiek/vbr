package com.hcsc.vbr.auth.model;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class RoleTest
{

    @Test
    public void testSetters()
    {
        Role role = new Role();
        role.setRoleName( "role" );

        assertEquals( "role",
                      role.getRoleName() );
    }

}
