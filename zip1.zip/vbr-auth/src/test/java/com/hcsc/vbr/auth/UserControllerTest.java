package com.hcsc.vbr.auth;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import com.hcsc.vbr.auth.controller.UserAuthController;
import com.hcsc.vbr.auth.repository.UserAuthRepository;

@RunWith( MockitoJUnitRunner.class )
public class UserControllerTest
{

    @Mock
    private UserAuthRepository userAuthRepository;

    @InjectMocks
    private UserAuthController userAuthController;

    @Test
    public void testJunk() throws Exception
    {

    }

}
