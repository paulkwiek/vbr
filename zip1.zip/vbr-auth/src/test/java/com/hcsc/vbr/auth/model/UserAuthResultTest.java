package com.hcsc.vbr.auth.model;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class UserAuthResultTest
{

    @Test
    public void testConstructor()
    {
        UserAuthResult userAuthResult = new UserAuthResult( "message" );

        assertEquals( "message",
                      userAuthResult.getResultMessage() );
    }

    @Test
    public void testSetters()
    {
        UserAuthResult userAuthResult = new UserAuthResult( "message" );
        userAuthResult.setResultMessage( "new message" );

        assertEquals( "new message",
                      userAuthResult.getResultMessage() );
    }
}
