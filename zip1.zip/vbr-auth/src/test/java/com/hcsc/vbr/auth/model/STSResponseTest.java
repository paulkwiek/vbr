package com.hcsc.vbr.auth.model;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

import com.hcsc.vbr.auth.exception.InvalidTokenException;
import com.nimbusds.jwt.JWTClaimsSet;

public class STSResponseTest
{

    @Test
    public void testSetters()
    {
        STSResponse sTSResponse = new STSResponse();
        sTSResponse.setAccessToken( "accesstoken" );
        sTSResponse.setExpireIn( 123 );
        sTSResponse.setJwtToken( "jwttoken" );
        List<String> prefixList = new ArrayList<String>( 0 );
        prefixList.add( "prefix1" );
        sTSResponse.setRefreshToken( "refreshtoken" );
        sTSResponse.setTokenType( "tokentype" );
        UserDetails userDetails = new UserDetails();
        userDetails.setFamilyName( "familyname" );
        sTSResponse.setUserDetails( userDetails );
        sTSResponse.setUsername( "user1" );

        assertEquals( "accesstoken",
                      sTSResponse.getAccessToken() );
        assertEquals( 123,
                      sTSResponse.getExpiresIn() );
        assertEquals( "jwttoken",
                      sTSResponse.getJwtToken() );
        assertEquals( "refreshtoken",
                      sTSResponse.getRefreshToken() );
        assertEquals( "tokentype",
                      sTSResponse.getTokenType() );
        assertEquals( userDetails.getFamilyName(),
                      sTSResponse.getUserDetails().getFamilyName() );
        assertEquals( "user1",
                      sTSResponse.getUsername() );
    }

    @Test
    public void testGetClaims()
    {
        STSResponse sTSResponse = new STSResponse();
        sTSResponse.setAccessToken( "accesstoken" );
        sTSResponse.setExpireIn( 123 );
        sTSResponse
                .setJwtToken( "eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.ew0KICAic3ViIjogIlUzODYzNjEiLA0KICAiYXpwIjogImI2OGU0MGFjMmMwMzRmMTNhMjAzYWQ5NjU5NTM4NTdiIiwNCiAgImlzcyI6ICJodHRwczovL3QtZWFhc3RzLXRzdC50ZXN0Lmhjc2NpbnQubmV0L2Nvbm5lY3QiLA0KICAiaWF0IjogMTUzNDI3MDg1NywNCiAgImV4cCI6IDE1MzQyNzQ1MDcsDQogICJoY3NjX3ByaXZhdGVfY2xhaW1zIjogDQogICB7DQogCSAicGVybWlzc2lvbnMiOiAiIiwNCiAgIAkgInJvbGVzIjogImJhc2ljdXNlciINCiAgIH0NCn0.fPN8C79Dls6hjGKbTfKFDdpSGC4BbXr0coTljAjSsav7rCH3H-e34BW7SpHd56D-LyoEAso8odydy4RN9tJP2FcivYvXEPughWArbK2RrdQdJWdkJbhBSXpuKzVevN95vgadaIzGOz_71OshNLiEd7xlW5aHqBNNSLAboQLJtjiKQLrVkVsJzHWw1lToL3-bQ-qAcgq_KESjDDaHYai1oFkm75OdALbAmbGsjNlimVFetzfq4LHRQU3d6hYVtMaEhcQ2ve0RKcmjpnNKoliQb4zELfA_ze9micm5z5gvpoNqN9-hJB_t8X5HzfrpB7A2Y-_2mVAAoHsbCA9fxsfEhQ" );
        List<String> prefixList = new ArrayList<String>( 0 );
        prefixList.add( "prefix1" );
        sTSResponse.setRefreshToken( "refreshtoken" );
        sTSResponse.setTokenType( "tokentype" );
        UserDetails userDetails = new UserDetails();
        userDetails.setFamilyName( "familyname" );
        userDetails.setGivenName( "givenname" );
        userDetails.setSub( "001" );
        sTSResponse.setUserDetails( userDetails );
        sTSResponse.setUsername( "user1" );
        userDetails.setRoles( "CN=ROLE1;ou=nothing;o=something" );

        JWTClaimsSet cs = sTSResponse.createClaimSet();
        assertEquals( "76641e10-3e11-4cd8-8fee-461e93ff5452",
                      cs.getJWTID() );
        assertNotNull( cs.getIssueTime() );
        assertEquals( "001",
                      cs.getClaim( "uuid" ) );
        assertEquals( "givenname",
                      cs.getClaim( "firstName" ) );
        assertEquals( "familyname",
                      cs.getClaim( "lastName" ) );

    }

    @Test
    public void testCreateClaimsSet()
    {
        STSResponse sTSResponse = new STSResponse();
        sTSResponse.setAccessToken( "accesstoken" );
        sTSResponse.setExpireIn( 123 );
        sTSResponse
                .setJwtToken( "eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.ew0KICAic3ViIjogIlUzODYzNjEiLA0KICAiYXpwIjogImI2OGU0MGFjMmMwMzRmMTNhMjAzYWQ5NjU5NTM4NTdiIiwNCiAgImlzcyI6ICJodHRwczovL3QtZWFhc3RzLXRzdC50ZXN0Lmhjc2NpbnQubmV0L2Nvbm5lY3QiLA0KICAiaWF0IjogMTUzNDI3MDg1NywNCiAgImV4cCI6IDE1MzQyNzQ1MDcsDQogICJoY3NjX3ByaXZhdGVfY2xhaW1zIjogDQogICB7DQogCSAicGVybWlzc2lvbnMiOiAiIiwNCiAgIAkgInJvbGVzIjogImJhc2ljdXNlciINCiAgIH0NCn0.fPN8C79Dls6hjGKbTfKFDdpSGC4BbXr0coTljAjSsav7rCH3H-e34BW7SpHd56D-LyoEAso8odydy4RN9tJP2FcivYvXEPughWArbK2RrdQdJWdkJbhBSXpuKzVevN95vgadaIzGOz_71OshNLiEd7xlW5aHqBNNSLAboQLJtjiKQLrVkVsJzHWw1lToL3-bQ-qAcgq_KESjDDaHYai1oFkm75OdALbAmbGsjNlimVFetzfq4LHRQU3d6hYVtMaEhcQ2ve0RKcmjpnNKoliQb4zELfA_ze9micm5z5gvpoNqN9-hJB_t8X5HzfrpB7A2Y-_2mVAAoHsbCA9fxsfEhQ" );
        List<String> prefixList = new ArrayList<String>( 0 );
        prefixList.add( "prefix1" );
        sTSResponse.setRefreshToken( "refreshtoken" );
        sTSResponse.setTokenType( "tokentype" );
        UserDetails userDetails = new UserDetails();
        userDetails.setFamilyName( "familyname" );
        userDetails.setGivenName( "givenname" );
        userDetails.setSub( "001" );
        sTSResponse.setUserDetails( userDetails );
        sTSResponse.setUsername( "user1" );
        userDetails.setRoles( "CN=ROLE1;ou=nothing;o=something" );

        JWTClaimsSet old = sTSResponse.createClaimSet();
        JWTClaimsSet cs = sTSResponse.createClaimSet(old);
        assertEquals( "76641e10-3e11-4cd8-8fee-461e93ff5452",
                      cs.getJWTID() );
        assertNotNull( cs.getIssueTime() );
        assertEquals( "001",
                      cs.getClaim( "uuid" ) );
        assertEquals( "givenname",
                      cs.getClaim( "firstName" ) );
        assertEquals( "familyname",
                      cs.getClaim( "lastName" ) );

    }

    @Test( expected = InvalidTokenException.class )
    public void testGetClaimsException()
    {
        STSResponse sTSResponse = new STSResponse();
        sTSResponse.setAccessToken( "accesstoken" );
        sTSResponse.setExpireIn( 123 );
        sTSResponse
                .setJwtToken( "iJSUzI1NiJ9.ew0KICAic3ViIjogIlUzODYzNjEiLA0KICAiYXpwIjogImI2OGU0MGFjMmMwMzRmMTNhMjAzYWQ5NjU5NTM4NTdiIiwNCiAgImlzcyI6ICJodHRwczovL3QtZWFhc3RzLXRzdC50ZXN0Lmhjc2NpbnQubmV0L2Nvbm5lY3QiLA0KICAiaWF0IjogMTUzNDI3MDg1NywNCiAgImV4cCI6IDE1MzQyNzQ1MDcsDQogICJoY3NjX3ByaXZhdGVfY2xhaW1zIjogDQogICB7DQogCSAicGVybWlzc2lvbnMiOiAiIiwNCiAgIAkgInJvbGVzIjogImJhc2ljdXNlciINCiAgIH0NCn0.fPN8C79Dls6hjGKbTfKFDdpSGC4BbXr0coTljAjSsav7rCH3H-e34BW7SpHd56D-LyoEAso8odydy4RN9tJP2FcivYvXEPughWArbK2RrdQdJWdkJbhBSXpuKzVevN95vgadaIzGOz_71OshNLiEd7xlW5aHqBNNSLAboQLJtjiKQLrVkVsJzHWw1lToL3-bQ-qAcgq_KESjDDaHYai1oFkm75OdALbAmbGsjNlimVFetzfq4LHRQU3d6hYVtMaEhcQ2ve0RKcmjpnNKoliQb4zELfA_ze9micm5z5gvpoNqN9-hJB_t8X5HzfrpB7A2Y-_2mVAAoHsbCA9fxsfEhQ" );

        sTSResponse.createClaimSet();

    }
}
