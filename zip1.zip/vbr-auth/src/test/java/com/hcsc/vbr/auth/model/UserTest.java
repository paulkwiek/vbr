package com.hcsc.vbr.auth.model;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class UserTest
{

    @Test
    public void testSetters()
    {
        User user = new User();
        user.setPassword( "password" );
        user.setUsername( "username" );

        assertEquals( "password",
                      user.getPassword() );
        assertEquals( "username",
                      user.getUsername() );
    }

}
