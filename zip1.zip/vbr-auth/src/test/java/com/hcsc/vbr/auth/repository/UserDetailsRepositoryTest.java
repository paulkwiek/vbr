package com.hcsc.vbr.auth.repository;

import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.ArgumentMatchers.isA;
import static org.mockito.Mockito.when;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.HttpEntity;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import com.hcsc.vbr.auth.config.STSConfig;
import com.hcsc.vbr.auth.model.STSResponse;
import com.hcsc.vbr.auth.model.UserDetails;

@RunWith( MockitoJUnitRunner.class )
public class UserDetailsRepositoryTest
{

    @Mock
    MultiValueMap<String, String> stsClientHeadersMap;

    @Mock
    private RestTemplate restTemplate;

    @Mock
    private STSConfig stsConfig;

    @InjectMocks
    UserDetailsRepository repository;

    @Test
    public void shouldVerifyGetUserDetails()
    {
        STSResponse stsResponse = new STSResponse();
        stsResponse.setAccessToken( "access token" );

        UserDetails userDetails = new UserDetails();
        userDetails.setFamilyName( "family" );
        userDetails.setGivenName( "given" );
        userDetails.setName( "name" );
        userDetails.setRoles( "CN=HCSC" );
        userDetails.setSub( "sub" );

        when( stsConfig.getUserdetailsURI() ).thenReturn( "someuri" );

        when( restTemplate.postForObject( isA( String.class ),
                                          isA( HttpEntity.class ),
                                          eq( UserDetails.class ) ) ).thenReturn( userDetails );

        repository.getUserDetails( stsResponse );

        assertEquals( userDetails,
                      stsResponse.getUserDetails() );
    }

}
