package com.hcsc.vbr.auth;

import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.test.context.junit4.SpringRunner;

@Ignore
@RunWith( SpringRunner.class )
@SpringBootTest( classes = VBRAuthApplication.class, webEnvironment = WebEnvironment.RANDOM_PORT )
public class VBRAuthApplicationTests
{

    @Test
    public void contextLoads()
    {
    }

}
