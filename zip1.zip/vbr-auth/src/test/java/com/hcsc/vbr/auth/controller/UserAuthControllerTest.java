package com.hcsc.vbr.auth.controller;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.isA;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.hcsc.vbr.auth.model.STSResponse;
import com.hcsc.vbr.auth.model.UserDetails;
import com.hcsc.vbr.auth.repository.UserAuthRepository;
import com.hcsc.vbr.auth.validator.TokenValidator;

@RunWith( MockitoJUnitRunner.class )
public class UserAuthControllerTest
{

    @Mock
    private UserAuthRepository repository;

    @Mock
    private TokenValidator validator;

    private MockMvc mockMvc;

    @InjectMocks
    private UserAuthController controller;

    @Before
    public void setUp() throws Exception
    {
        mockMvc = MockMvcBuilders.standaloneSetup( controller ).build();
    }

    @Test
    public void shouldRetrieveUser() throws Exception
    {

        UserDetails userDetails = createUserDetails();

        STSResponse sTSResponse = new STSResponse();
        sTSResponse.setUserDetails( userDetails );

        String access_token = "access token";
        String refresh_token = "refresh token";
        String jwt_token =
            "eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.ew0KICAic3ViIjogIlUzODYzNjEiLA0KICAiYXpwIjogImI2OGU0MGFjMmMwMzRmMTNhMjAzYWQ5NjU5NTM4NTdiIiwNCiAgImlzcyI6ICJodHRwczovL3QtZWFhc3RzLXRzdC50ZXN0Lmhjc2NpbnQubmV0L2Nvbm5lY3QiLA0KICAiaWF0IjogMTUzNDI3MDg1NywNCiAgImV4cCI6IDE1MzQyNzQ1MDcsDQogICJoY3NjX3ByaXZhdGVfY2xhaW1zIjogDQogICB7DQogCSAicGVybWlzc2lvbnMiOiAiIiwNCiAgIAkgInJvbGVzIjogImJhc2ljdXNlciINCiAgIH0NCn0.fPN8C79Dls6hjGKbTfKFDdpSGC4BbXr0coTljAjSsav7rCH3H-e34BW7SpHd56D-LyoEAso8odydy4RN9tJP2FcivYvXEPughWArbK2RrdQdJWdkJbhBSXpuKzVevN95vgadaIzGOz_71OshNLiEd7xlW5aHqBNNSLAboQLJtjiKQLrVkVsJzHWw1lToL3-bQ-qAcgq_KESjDDaHYai1oFkm75OdALbAmbGsjNlimVFetzfq4LHRQU3d6hYVtMaEhcQ2ve0RKcmjpnNKoliQb4zELfA_ze9micm5z5gvpoNqN9-hJB_t8X5HzfrpB7A2Y-_2mVAAoHsbCA9fxsfEhQ";

        sTSResponse.setAccessToken( access_token );
        sTSResponse.setRefreshToken( refresh_token );
        sTSResponse.setJwtToken( jwt_token );

        when( repository.retrieveUserToken( isA( String.class ) ) ).thenReturn( sTSResponse );

        // MockHttpServletResponse response = new MockHttpServletResponse();
        HttpServletResponse response = Mockito.mock( HttpServletResponse.class );

        Cookie smsession = new Cookie( "SMSESSION",
                                       "some session" );
        MvcResult mvcResult = mockMvc.perform( get( "/users/smsession" ).cookie( smsession )
                .requestAttr( "httpResp",
                              response ) )
                .andReturn();

        assertEquals( 200,
                      mvcResult.getResponse().getStatus() );
        String headerValue = (String) mvcResult.getResponse().getHeaderValue( "Authorization" );
        assertTrue( headerValue.contains( "Bearer" ) );
        String content = mvcResult.getResponse().getContentAsString();
        assertEquals( "{\"username\":null,\"userDetails\":null,\"resultMessage\":\"Success\",\"access_token\":\"access token\",\"token_type\":null,\"expires_in\":0,\"refresh_token\":\"refresh token\",\"jwt_token\":\"eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.ew0KICAic3ViIjogIlUzODYzNjEiLA0KICAiYXpwIjogImI2OGU0MGFjMmMwMzRmMTNhMjAzYWQ5NjU5NTM4NTdiIiwNCiAgImlzcyI6ICJodHRwczovL3QtZWFhc3RzLXRzdC50ZXN0Lmhjc2NpbnQubmV0L2Nvbm5lY3QiLA0KICAiaWF0IjogMTUzNDI3MDg1NywNCiAgImV4cCI6IDE1MzQyNzQ1MDcsDQogICJoY3NjX3ByaXZhdGVfY2xhaW1zIjogDQogICB7DQogCSAicGVybWlzc2lvbnMiOiAiIiwNCiAgIAkgInJvbGVzIjogImJhc2ljdXNlciINCiAgIH0NCn0.fPN8C79Dls6hjGKbTfKFDdpSGC4BbXr0coTljAjSsav7rCH3H-e34BW7SpHd56D-LyoEAso8odydy4RN9tJP2FcivYvXEPughWArbK2RrdQdJWdkJbhBSXpuKzVevN95vgadaIzGOz_71OshNLiEd7xlW5aHqBNNSLAboQLJtjiKQLrVkVsJzHWw1lToL3-bQ-qAcgq_KESjDDaHYai1oFkm75OdALbAmbGsjNlimVFetzfq4LHRQU3d6hYVtMaEhcQ2ve0RKcmjpnNKoliQb4zELfA_ze9micm5z5gvpoNqN9-hJB_t8X5HzfrpB7A2Y-_2mVAAoHsbCA9fxsfEhQ\"}",
                      content );
    }

    @Test
    public void shouldRetrieveMemberJWT() throws Exception
    {

        STSResponse sTSResponse = new STSResponse();

        String access_token = "access token";
        String refresh_token = "refresh token";
        String jwt_token =
            "eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.ew0KICAic3ViIjogIlUzODYzNjEiLA0KICAiYXpwIjogImI2OGU0MGFjMmMwMzRmMTNhMjAzYWQ5NjU5NTM4NTdiIiwNCiAgImlzcyI6ICJodHRwczovL3QtZWFhc3RzLXRzdC50ZXN0Lmhjc2NpbnQubmV0L2Nvbm5lY3QiLA0KICAiaWF0IjogMTUzNDI3MDg1NywNCiAgImV4cCI6IDE1MzQyNzQ1MDcsDQogICJoY3NjX3ByaXZhdGVfY2xhaW1zIjogDQogICB7DQogCSAicGVybWlzc2lvbnMiOiAiIiwNCiAgIAkgInJvbGVzIjogImJhc2ljdXNlciINCiAgIH0NCn0.fPN8C79Dls6hjGKbTfKFDdpSGC4BbXr0coTljAjSsav7rCH3H-e34BW7SpHd56D-LyoEAso8odydy4RN9tJP2FcivYvXEPughWArbK2RrdQdJWdkJbhBSXpuKzVevN95vgadaIzGOz_71OshNLiEd7xlW5aHqBNNSLAboQLJtjiKQLrVkVsJzHWw1lToL3-bQ-qAcgq_KESjDDaHYai1oFkm75OdALbAmbGsjNlimVFetzfq4LHRQU3d6hYVtMaEhcQ2ve0RKcmjpnNKoliQb4zELfA_ze9micm5z5gvpoNqN9-hJB_t8X5HzfrpB7A2Y-_2mVAAoHsbCA9fxsfEhQ";

        sTSResponse.setAccessToken( access_token );
        sTSResponse.setRefreshToken( refresh_token );
        sTSResponse.setJwtToken( jwt_token );

        when( repository.retrieveMemberAPIToken() ).thenReturn( sTSResponse );

        // MockHttpServletResponse response = new MockHttpServletResponse();
        HttpServletResponse response = Mockito.mock( HttpServletResponse.class );

        MvcResult mvcResult = mockMvc.perform( post( "/users/memberAPIJwt" ).requestAttr( "httpResp",
                                                                                          response ) )
                .andReturn();

        assertEquals( 200,
                      mvcResult.getResponse().getStatus() );
        String headerValue = (String) mvcResult.getResponse().getHeaderValue( "Authorization" );
        assertTrue( headerValue.contains( "Bearer" ) );
        String content = mvcResult.getResponse().getContentAsString();
        assertEquals( "{\"username\":null,\"userDetails\":null,\"resultMessage\":\"Success\",\"access_token\":\"access token\",\"token_type\":null,\"expires_in\":0,\"refresh_token\":\"refresh token\",\"jwt_token\":\"eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.ew0KICAic3ViIjogIlUzODYzNjEiLA0KICAiYXpwIjogImI2OGU0MGFjMmMwMzRmMTNhMjAzYWQ5NjU5NTM4NTdiIiwNCiAgImlzcyI6ICJodHRwczovL3QtZWFhc3RzLXRzdC50ZXN0Lmhjc2NpbnQubmV0L2Nvbm5lY3QiLA0KICAiaWF0IjogMTUzNDI3MDg1NywNCiAgImV4cCI6IDE1MzQyNzQ1MDcsDQogICJoY3NjX3ByaXZhdGVfY2xhaW1zIjogDQogICB7DQogCSAicGVybWlzc2lvbnMiOiAiIiwNCiAgIAkgInJvbGVzIjogImJhc2ljdXNlciINCiAgIH0NCn0.fPN8C79Dls6hjGKbTfKFDdpSGC4BbXr0coTljAjSsav7rCH3H-e34BW7SpHd56D-LyoEAso8odydy4RN9tJP2FcivYvXEPughWArbK2RrdQdJWdkJbhBSXpuKzVevN95vgadaIzGOz_71OshNLiEd7xlW5aHqBNNSLAboQLJtjiKQLrVkVsJzHWw1lToL3-bQ-qAcgq_KESjDDaHYai1oFkm75OdALbAmbGsjNlimVFetzfq4LHRQU3d6hYVtMaEhcQ2ve0RKcmjpnNKoliQb4zELfA_ze9micm5z5gvpoNqN9-hJB_t8X5HzfrpB7A2Y-_2mVAAoHsbCA9fxsfEhQ\"}",
                      content );
    }

    @Test
    public void smSessionNoCookie() throws Exception
    {

        HttpServletResponse response = Mockito.mock( HttpServletResponse.class );

        MvcResult mvcResult = mockMvc.perform( get( "/users/smsession" ).requestAttr( "httpResp",
                                                                                      response ) )
                .andReturn();

        assertEquals( 401,
                      mvcResult.getResponse().getStatus() );
    }

    @Test
    public void shouldCallRefreshUserWithAuthorizationAndReturn200() throws Exception
    {
        String token =
            "Bearer eyJhbGciOiJIUzI1NiJ9.eyJtb2RlIjoidXNlciIsImlzcyI6ImRpb2dvLnJvc2FzLmZlcnJlaXJhQGdtYWlsLmNvbSJ9.I5Ysne1C79cO5B_5hIQK9iBSnQ6M8msuyVHD4kdoFSo";
        MockHttpServletRequest request = new MockHttpServletRequest();
        MockHttpServletResponse response = new MockHttpServletResponse();
        String refreshToken = "refresh token";

        UserDetails userDetails = createUserDetails();

        String jwt_token =
            "eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.ew0KICAic3ViIjogIlUzODYzNjEiLA0KICAiYXpwIjogImI2OGU0MGFjMmMwMzRmMTNhMjAzYWQ5NjU5NTM4NTdiIiwNCiAgImlzcyI6ICJodHRwczovL3QtZWFhc3RzLXRzdC50ZXN0Lmhjc2NpbnQubmV0L2Nvbm5lY3QiLA0KICAiaWF0IjogMTUzNDI3MDg1NywNCiAgImV4cCI6IDE1MzQyNzQ1MDcsDQogICJoY3NjX3ByaXZhdGVfY2xhaW1zIjogDQogICB7DQogCSAicGVybWlzc2lvbnMiOiAiIiwNCiAgIAkgInJvbGVzIjogImJhc2ljdXNlciINCiAgIH0NCn0.fPN8C79Dls6hjGKbTfKFDdpSGC4BbXr0coTljAjSsav7rCH3H-e34BW7SpHd56D-LyoEAso8odydy4RN9tJP2FcivYvXEPughWArbK2RrdQdJWdkJbhBSXpuKzVevN95vgadaIzGOz_71OshNLiEd7xlW5aHqBNNSLAboQLJtjiKQLrVkVsJzHWw1lToL3-bQ-qAcgq_KESjDDaHYai1oFkm75OdALbAmbGsjNlimVFetzfq4LHRQU3d6hYVtMaEhcQ2ve0RKcmjpnNKoliQb4zELfA_ze9micm5z5gvpoNqN9-hJB_t8X5HzfrpB7A2Y-_2mVAAoHsbCA9fxsfEhQ";

        STSResponse stsResponse = new STSResponse();
        stsResponse.setAccessToken( "access token" );
        stsResponse.setJwtToken( jwt_token );
        stsResponse.setUserDetails( userDetails );
        when( repository.refreshUserToken( isA( String.class ),
                                           isA( String.class ) ) ).thenReturn( stsResponse );

        Cookie cookie = new Cookie( "refresh_token",
                                    refreshToken );

        MvcResult mvcResult = mockMvc.perform( post( "/users/refresh" ).header( "Authorization",
                                                                                token )
                .requestAttr( "request",
                              request )
                .requestAttr( "httpResp",
                              response )
                .cookie( cookie ) ).andReturn();

        assertEquals( 200,
                      mvcResult.getResponse().getStatus() );
        String content = mvcResult.getResponse().getContentAsString();
        assertEquals( "{\"username\":null,\"userDetails\":null,\"resultMessage\":\"Success\",\"access_token\":\"access token\",\"token_type\":null,\"expires_in\":0,\"refresh_token\":null,\"jwt_token\":\"eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.ew0KICAic3ViIjogIlUzODYzNjEiLA0KICAiYXpwIjogImI2OGU0MGFjMmMwMzRmMTNhMjAzYWQ5NjU5NTM4NTdiIiwNCiAgImlzcyI6ICJodHRwczovL3QtZWFhc3RzLXRzdC50ZXN0Lmhjc2NpbnQubmV0L2Nvbm5lY3QiLA0KICAiaWF0IjogMTUzNDI3MDg1NywNCiAgImV4cCI6IDE1MzQyNzQ1MDcsDQogICJoY3NjX3ByaXZhdGVfY2xhaW1zIjogDQogICB7DQogCSAicGVybWlzc2lvbnMiOiAiIiwNCiAgIAkgInJvbGVzIjogImJhc2ljdXNlciINCiAgIH0NCn0.fPN8C79Dls6hjGKbTfKFDdpSGC4BbXr0coTljAjSsav7rCH3H-e34BW7SpHd56D-LyoEAso8odydy4RN9tJP2FcivYvXEPughWArbK2RrdQdJWdkJbhBSXpuKzVevN95vgadaIzGOz_71OshNLiEd7xlW5aHqBNNSLAboQLJtjiKQLrVkVsJzHWw1lToL3-bQ-qAcgq_KESjDDaHYai1oFkm75OdALbAmbGsjNlimVFetzfq4LHRQU3d6hYVtMaEhcQ2ve0RKcmjpnNKoliQb4zELfA_ze9micm5z5gvpoNqN9-hJB_t8X5HzfrpB7A2Y-_2mVAAoHsbCA9fxsfEhQ\"}",
                      content );

    }

    @Test
    public void shouldCallRefreshUserWithBadAuthHeader() throws Exception
    {
        //this is an invalid auth header
        String token = "";
        MockHttpServletRequest request = new MockHttpServletRequest();
        MockHttpServletResponse response = new MockHttpServletResponse();
        Cookie cookie = new Cookie( "refresh_token",
                                    "refresh token" );

        MvcResult mvcResult = mockMvc.perform( post( "/users/refresh" ).header( "Authorization",
                                                                                token )
                .requestAttr( "request",
                              request )
                .requestAttr( "httpResp",
                              response )
                .cookie( cookie ) ).andReturn();

        assertEquals( 401,
                      mvcResult.getResponse().getStatus() );

    }

    @Test
    public void getCookieTest()
    {

        HttpServletRequest request = Mockito.mock( HttpServletRequest.class );
        when( request.getCookies() ).thenReturn( null );
        Cookie cookie = controller.getCookie( request,
                                              "bogus" );
        assertNull( cookie );
    }

    private UserDetails createUserDetails()
    {
        UserDetails userDetails = new UserDetails();
        userDetails.setFamilyName( "family" );
        userDetails.setGivenName( "given" );
        userDetails.setName( "name" );
        userDetails.setRoles( "role" );
        userDetails.setSub( "sub1" );
        userDetails.setRoles( "CN=HCSC" );

        return userDetails;
    }

}
