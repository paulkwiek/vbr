package com.hcsc.vbr.auth.exception;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.util.Date;

import org.junit.Test;

public class ErrorDetailsTest
{

    @Test
    public void testIt()
    {
        ErrorDetails err = new ErrorDetails( new Date(),
                                             "message",
                                             "details" );
        assertEquals( "message",
                      err.getMessage() );
        assertEquals( "details",
                      err.getDetails() );
        assertNotNull( err.getTimestamp() );
    }
}
