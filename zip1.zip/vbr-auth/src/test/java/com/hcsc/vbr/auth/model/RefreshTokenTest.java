package com.hcsc.vbr.auth.model;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class RefreshTokenTest
{

    @Test
    public void testSetters()
    {
        RefreshToken refreshToken = new RefreshToken();
        refreshToken.setRefreshToken( "token" );

        assertEquals( "token",
                      refreshToken.getRefreshToken() );
    }

}
