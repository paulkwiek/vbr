package com.hcsc.vbr.auth.model;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class SMSessionTest
{

    @Test
    public void testGetters()
    {
        SMSession session = new SMSession( "hello" );
        assertEquals( "hello",
                      session.getSiteminderSession() );
    }

    @Test
    public void testSetter()
    {
        SMSession session = new SMSession( "hello" );
        session.setSiteminderSession( "goodbye" );
        assertEquals( "goodbye",
                      session.getSiteminderSession() );
    }
}
