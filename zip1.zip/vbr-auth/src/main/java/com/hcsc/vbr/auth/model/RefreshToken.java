package com.hcsc.vbr.auth.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class RefreshToken
{

    @JsonProperty("refresh_token")
    private String token;

    public String getRefreshToken()
    {
        return token;
    }

    public void setRefreshToken( String token )
    {
        this.token = token;
    }

}
