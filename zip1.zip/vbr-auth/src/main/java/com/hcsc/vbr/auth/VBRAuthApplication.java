package com.hcsc.vbr.auth;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.security.servlet.SecurityAutoConfiguration;

@SpringBootApplication( exclude = { SecurityAutoConfiguration.class } )
public class VBRAuthApplication
{

    /**
     * This is spring boots main method which takes no arguments.
     * 
     * Method: main method for spring boot
     * @param args - no args expected
     */
    public static void main( String[] args )
    {
        SpringApplication.run( VBRAuthApplication.class,
                               args );
    }
}
