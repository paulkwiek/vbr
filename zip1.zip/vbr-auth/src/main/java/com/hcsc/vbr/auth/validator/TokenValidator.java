package com.hcsc.vbr.auth.validator;

import java.text.ParseException;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.hcsc.vbr.auth.exception.InvalidTokenException;
import com.hcsc.vbr.auth.model.STSResponse;
import com.nimbusds.jose.JOSEException;
import com.nimbusds.jose.crypto.RSASSAVerifier;
import com.nimbusds.jwt.SignedJWT;

@Component
public class TokenValidator
{

    @Autowired
    RSASSAVerifier rsaVerifier;

    public boolean validateSTSToken( STSResponse stsResponse )
    {
        return validateSTSToken( stsResponse.getJwtToken() );
    }

    public boolean validateSTSToken( String jwtToken )
    {
        SignedJWT signedInnerJWT = null;

        try
        {
            signedInnerJWT = SignedJWT.parse( jwtToken );

            if( !signedInnerJWT.verify( rsaVerifier ) )
            {
                throw new InvalidTokenException( "The JWT token from the auth service could not be verified, invalid token" );
            }
            if( signedInnerJWT.getJWTClaimsSet().getExpirationTime().getTime() < new Date().getTime() )
            {
                throw new InvalidTokenException( "The JWT token from the auth service has expired" );
            }
        }
        catch( ParseException e )
        {
            throw new InvalidTokenException( "Could not parse token, invalid token" + e );
        }
        catch( JOSEException e )
        {
            throw new InvalidTokenException( "Could validate token" + e.getMessage() + e );
        }
        return true;

    }
}
