package com.hcsc.vbr.auth.config;

import org.apache.commons.lang3.StringUtils;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Configuration
@ConfigurationProperties( prefix = "sts" )
public class STSConfig
{

    String domain;
    String clientid;
    String clientsecret;
    String smsessionPath;
    String userdetailsPath;
    String refreshPath;
    String jwtPath;
    String refreshParameters;
    String smSessionParameters;
    String jwtParameters;
    String allowedCrossOriginUris;

    /**
     * @return the allowedCrossOriginUris
     */
    public String getAllowedCrossOriginUris()
    {
        return allowedCrossOriginUris;
    }

    /**
     * @param allowedCrossOriginUris the allowedCrossOriginUris to set
     */
    public void setAllowedCrossOriginUris( String allowedCrossOriginUris )
    {
        this.allowedCrossOriginUris = allowedCrossOriginUris;
    }

    public String getJwtPath()
    {
        return jwtPath;
    }

    public void setJwtPath( String jwtPath )
    {
        this.jwtPath = jwtPath;
    }

    public String getDomain()
    {
        return domain;
    }

    public void setDomain( String domain )
    {
        this.domain = domain;
    }

    public String getClientid()
    {
        return clientid;
    }

    public void setClientid( String clientid )
    {
        this.clientid = clientid;
    }

    public String getClientsecret()
    {
        return clientsecret;
    }

    public void setClientsecret( String clientsecret )
    {
        this.clientsecret = clientsecret;
    }

    public String getSmsessionPath()
    {
        return smsessionPath;
    }

    public void setSmsessionPath( String smsessionPath )
    {
        this.smsessionPath = smsessionPath;
    }

    public String getUserdetailsPath()
    {
        return userdetailsPath;
    }

    public void setUserdetailsPath( String userdetailsPath )
    {
        this.userdetailsPath = userdetailsPath;
    }

    public String getRefreshPath()
    {
        return refreshPath;
    }

    public void setRefreshPath( String refreshPath )
    {
        this.refreshPath = refreshPath;
    }

    public String getRefreshURI( String refreshToken )
    {
        return StringUtils.join( this.getDomain(),
                                 this.getRefreshPath(),
                                 "?scope=oob profile roles&grant_type=refresh_token&refresh_token=",
                                 refreshToken );
    }

    public String getSmsessionURI()
    {
        return StringUtils.join( this.getDomain(),
                                 this.getSmsessionPath(),
                                 "?app_rolefilters=vbr" );
    }

    public String getUserdetailsURI()
    {
        return StringUtils.join( this.getDomain(),
                                 this.getUserdetailsPath() );
    }

    public String getJwtURI()
    {
        return StringUtils.join( this.getDomain(),
                                 this.getJwtPath() );
    }

    /**
     * @return the refreshParameters
     */
    public String getRefreshParameters()
    {
        return refreshParameters;
    }

    /**
     * @param refreshParameters the refreshParameters to set
     */
    public void setRefreshParameters( String refreshParameters )
    {
        this.refreshParameters = refreshParameters;
    }

    /**
     * @return the smSessionParameters
     */
    public String getSmSessionParameters()
    {
        return smSessionParameters;
    }

    /**
     * @param smSessionParameters the smSessionParameters to set
     */
    public void setSmSessionParameters( String smSessionParameters )
    {
        this.smSessionParameters = smSessionParameters;
    }

    /**
     * @return the jwtParameters
     */
    public String getJwtParameters()
    {
        return jwtParameters;
    }

    /**
     * @param jwtParameters the jwtParameters to set
     */
    public void setJwtParameters( String jwtParameters )
    {
        this.jwtParameters = jwtParameters;
    }

}
