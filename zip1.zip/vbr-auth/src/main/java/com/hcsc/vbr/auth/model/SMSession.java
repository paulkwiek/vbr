package com.hcsc.vbr.auth.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class SMSession
{

    @JsonProperty("sm_session")
    private String siteminderSession;

    public SMSession( String smSession )
    {
        this.siteminderSession = smSession;
    }

    public String getSiteminderSession()
    {
        return siteminderSession;
    }

    public void setSiteminderSession( String session )
    {
        this.siteminderSession = session;
    }

}
