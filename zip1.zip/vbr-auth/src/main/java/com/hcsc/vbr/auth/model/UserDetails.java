package com.hcsc.vbr.auth.model;

import java.util.ArrayList;
import java.util.List;

import javax.naming.InvalidNameException;
import javax.naming.ldap.LdapName;
import javax.naming.ldap.Rdn;

import com.fasterxml.jackson.annotation.JsonProperty;

public class UserDetails
{

    private String sub;
    private String name;

    @JsonProperty( "given_name" )
    private String givenName;

    @JsonProperty( "family_name" )
    private String familyName;

    private String roles;

    public String getSub()
    {
        return sub;
    }

    public void setSub( String sub )
    {
        this.sub = sub;
    }

    public String getName()
    {
        return name;
    }

    public void setName( String name )
    {
        this.name = name;
    }

    public String getGivenName()
    {
        return givenName;
    }

    public void setGivenName( String givenName )
    {
        this.givenName = givenName;
    }

    public String getFamilyName()
    {
        return familyName;
    }

    public void setFamilyName( String familyName )
    {
        this.familyName = familyName;
    }

    public String getRoles()
    {
        return roles;
    }

    public void setRoles( String roles )
    {
        this.roles = roles;
    }

    public List<String> getGroupNames() throws InvalidNameException
    {

        String[] dns = getRoles().split( ";" );
        List<String> permissions = new ArrayList<>();
        for( int i = 0; i < dns.length; i++ )
        {
            LdapName ln = new LdapName( dns[i] );

            for( Rdn rdn : ln.getRdns() )
            {
                if( "CN".equalsIgnoreCase( rdn.getType() ) && ( (String) rdn.getValue() ).startsWith( "SCPH Group " ) )
                {
                    permissions.add( ( (String) rdn.getValue() ).substring( 11 ) );
                    break;
                }
            }
        }

        return permissions;

    }

    public List<String> getRolesList() throws InvalidNameException
    {

        String[] dns = getRoles().split( ";" );
        List<String> permissions = new ArrayList<>();
        for( int i = 0; i < dns.length; i++ )
        {
            LdapName ln = new LdapName( dns[i] );

            for( Rdn rdn : ln.getRdns() )
            {
                if( "CN".equalsIgnoreCase( rdn.getType() ) && ( (String) rdn.getValue() ).contains( "SCPH" ) )
                {
                    permissions.add( (String) rdn.getValue() );
                    break;
                }
            }
        }

        return permissions;

    }

    public boolean hasHSCSRole() throws InvalidNameException
    {

        for( String role : getRolesList() )
        {
            if( "SCPH HCSC Basic User".equals( role )
                || "SCPH HCSC Admin User".equals( role )
                || "SCPH HCSC Account Mgmt User".equals( role ) )
            {
                return true;
            }
        }
        return false;
    }
}
