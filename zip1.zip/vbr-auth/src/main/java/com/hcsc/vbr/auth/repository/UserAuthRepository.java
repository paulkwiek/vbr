package com.hcsc.vbr.auth.repository;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpEntity;
import org.springframework.stereotype.Repository;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import com.hcsc.vbr.auth.config.MemberConfig;
import com.hcsc.vbr.auth.config.ProviderConfig;
import com.hcsc.vbr.auth.config.STSConfig;
import com.hcsc.vbr.auth.exception.InvalidTokenException;
import com.hcsc.vbr.auth.model.JWTToken;
import com.hcsc.vbr.auth.model.SMSession;
import com.hcsc.vbr.auth.model.STSResponse;
import com.hcsc.vbr.auth.model.User;
import com.hcsc.vbr.auth.validator.TokenValidator;

@Repository
public class UserAuthRepository
{

    private static final Logger LOG = LoggerFactory.getLogger( UserAuthRepository.class );

    @Autowired
    private UserDetailsRepository repository;

    @Autowired
    private STSConfig stsConfig;

    @Autowired
    private MemberConfig memberConfig;
    
    @Autowired
    private ProviderConfig providerConfig;

    @Autowired
    private RestTemplate restTemplate;

    @Autowired
    private TokenValidator validator;

    @Autowired
    @Qualifier( "restRequestHeaderMap" )
    MultiValueMap<String, String> stsClientHeadersMap;

    public STSResponse refreshUserToken( String refreshToken,
            String jwtToken )
    {

        STSResponse response = null;
        try
        {

            JWTToken jsonToken = new JWTToken();
            jsonToken.setJwtToken( jwtToken );

            HttpEntity<JWTToken> request = new HttpEntity<>( jsonToken,
                                                             stsClientHeadersMap );
            response = restTemplate.postForObject( stsConfig.getRefreshURI( refreshToken ),
                                                   request,
                                                   STSResponse.class );
            validator.validateSTSToken( response );
            repository.getUserDetails( response );
        }
        catch( RestClientException | InvalidTokenException e )
        {
            LOG.error( "Could not refresh token from STS, message: {} ",
                       e );
            throw new InvalidTokenException( "Could not refresh token from STS, message: " + e.getMessage() );
        }

        return response;
    }

    public STSResponse retrieveUserToken( String smSession )
    {

        HttpEntity<SMSession> request = new HttpEntity<>( new SMSession( smSession ),
                                                          stsClientHeadersMap );

        STSResponse response = null;

        try
        {
            response = restTemplate.postForObject( stsConfig.getSmsessionURI(),
                                                   request,
                                                   STSResponse.class );
        }
        catch( HttpClientErrorException e )
        {
            throw new InvalidTokenException( "Recieved error from STS service: " + e );
        }
        validator.validateSTSToken( response );
        repository.getUserDetails( response );
        return response;
    }

    public STSResponse retrieveMemberAPIToken()
    {

        HttpEntity<User> request = new HttpEntity<>( memberConfig.getMemberAndProviderUser(),
                                                     stsClientHeadersMap );

        STSResponse response = null;

        try
        {
            response = restTemplate.postForObject( stsConfig.getJwtURI(),
                                                   request,
                                                   STSResponse.class );
        }
        catch( HttpClientErrorException e )
        {
            throw new InvalidTokenException( "Recieved error from STS service: " + e );
        }
        validator.validateSTSToken( response );
        return response;
    }
    
    public STSResponse retrieveProviderAPIToken()
    {
        HttpEntity<User> request = new HttpEntity<>( providerConfig.getProviderUser(),
                                                     stsClientHeadersMap );

        STSResponse response = null;
        try
        {
            response = restTemplate.postForObject( stsConfig.getJwtURI(),
                                                   request,
                                                   STSResponse.class );
        }
        catch( HttpClientErrorException e )
        {
            throw new InvalidTokenException( "Recieved error from STS service: " + e );
        }
        validator.validateSTSToken( response );
        return response;
    }

}
