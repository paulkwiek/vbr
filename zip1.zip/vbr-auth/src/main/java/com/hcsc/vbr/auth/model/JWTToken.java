package com.hcsc.vbr.auth.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class JWTToken
{

    @JsonProperty("jwt_token")
    private String token;

    public String getJwtToken()
    {
        return token;
    }

    public void setJwtToken( String token )
    {
        this.token = token;
    }

}
