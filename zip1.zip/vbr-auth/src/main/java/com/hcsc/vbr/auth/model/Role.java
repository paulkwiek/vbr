package com.hcsc.vbr.auth.model;

public class Role
{

    private String roleName;

    public String getRoleName()
    {
        return roleName;
    }

    public void setRoleName( String roleName )
    {
        this.roleName = roleName;
    }

}
