package com.hcsc.vbr.auth.controller;

import java.util.Collection;
import java.util.Enumeration;

import javax.naming.InvalidNameException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hcsc.vbr.auth.exception.InvalidTokenException;
import com.hcsc.vbr.auth.model.STSResponse;
import com.hcsc.vbr.auth.model.UserAuthResult;
import com.hcsc.vbr.auth.repository.UserAuthRepository;
import com.nimbusds.jose.JOSEException;

@RestController
@RequestMapping( "/users" )
public class UserAuthController
{

    private static final Logger logger = LoggerFactory.getLogger( UserAuthController.class );
    @Autowired
    private UserAuthRepository repository;

    @GetMapping( "/smsession" )
    public ResponseEntity<UserAuthResult> retrieveJWTFromSMSession(
            @CookieValue( name = "SMSESSION", required = false ) String smSession,
            HttpServletRequest httpReq,
            HttpServletResponse httpResp )
    {

        if( smSession == null )
        {
            throw new InvalidTokenException( "No SMSESSION cookie was sent in to....." );
        }
        Enumeration<String> headers = httpReq.getHeaderNames();
        while( headers.hasMoreElements() )
        {
            String headerName = headers.nextElement();
            logger.info( "Request Header:[{}] Value:[]{}",
                         headerName,
                         httpReq.getHeader( headerName ) );
        }

        STSResponse stsResponse = repository.retrieveUserToken( smSession );

        setResponseCookies( httpReq,
                            httpResp,
                            stsResponse );

        return creatAuthHeader( stsResponse );
    }

    @PostMapping( "/memberAPIJwt" )
    public ResponseEntity<UserAuthResult> retrieveJWTForMemberAPI( HttpServletRequest httpReq,
            HttpServletResponse httpResp )
    {

        STSResponse stsResponse = repository.retrieveMemberAPIToken();

        setResponseCookies( httpReq,
                            httpResp,
                            stsResponse );

        return creatAuthHeader( stsResponse );
    }
    
    @GetMapping( "/providerAPIJwt" )
    public ResponseEntity<UserAuthResult> retrieveJWTForProviderAPI( HttpServletRequest httpReq,
            HttpServletResponse httpResp )
    {

        STSResponse stsResponse = repository.retrieveProviderAPIToken();

        setResponseCookies( httpReq,
                            httpResp,
                            stsResponse );

        return creatAuthHeader( stsResponse );
    }

    private ResponseEntity<UserAuthResult> creatAuthHeader( STSResponse anStsResponse )
    {
        HttpHeaders headers = new HttpHeaders();
        headers.add( "Authorization",
                     "Bearer " + anStsResponse.getJwtToken() );

        UserAuthResult userAuthResult = new UserAuthResult( "Success",
                                                            anStsResponse );
        return new ResponseEntity<>( userAuthResult,
                                     headers,
                                     HttpStatus.OK );
    }

    private void setResponseCookies( HttpServletRequest httpReq,
            HttpServletResponse httpResp,
            STSResponse stsResponse )
    {
        Cookie cookie = getCookie( httpReq,
                                   "refresh_token" );
        if( cookie == null )
        {
            cookie = new Cookie( "refresh_token",
                                 stsResponse.getRefreshToken() );
        }
        else
        {
            cookie.setValue( stsResponse.getRefreshToken() );
        }
        cookie.setHttpOnly( true );
        httpResp.addCookie( cookie );
        Enumeration<String> headers = httpReq.getHeaderNames();
        while( headers.hasMoreElements() )
        {
            String headerName = headers.nextElement();
            logger.info( "Request Header:[{}] Value:[{}]",
                         headerName,
                         httpReq.getHeader( headerName ) );
        }

        Collection<String> responseHeaderNames = httpResp.getHeaderNames();
        for( String responseHeader : responseHeaderNames )
        {
            logger.info( "Response Header:[{}] Value:[{}]",
                         responseHeader,
                         httpReq.getHeader( responseHeader ) );
        }

    }

    public Cookie getCookie( HttpServletRequest request,
            String name )
    {
        if( request.getCookies() != null )
        {
            for( Cookie cookie : request.getCookies() )
            {
                if( cookie.getName().equals( name ) )
                {
                    return cookie;
                }
            }
        }

        return null;
    }

    private String getTokenFromAuthHeader( HttpServletRequest request )
    {
        String authHeader = request.getHeader( "Authorization" );
        if( !authHeader.startsWith( "Bearer " ) )
        {
            throw new InvalidTokenException( "Invalid token, invalid authorization header." );
        }
        return authHeader.substring( 7 );
    }

    @PostMapping( "/refresh" )
    public ResponseEntity<UserAuthResult> refreshUser( @CookieValue( "refresh_token" ) String refreshToken,
            HttpServletResponse httpResp,
            HttpServletRequest request ) throws JOSEException,
            InvalidNameException
    {

        String token = getTokenFromAuthHeader( request );

        STSResponse stsResponse = repository.refreshUserToken( refreshToken,
                                                               token );

        setResponseCookies( request,
                            httpResp,
                            stsResponse );
        return creatAuthHeader( stsResponse );
    }
}
