package com.hcsc.vbr.auth.model;

public class UserAuthResult extends STSResponse
{

    private String resultMessage;

    public UserAuthResult( String resultMessage )
    {
        super();
        this.resultMessage = resultMessage;
    }

    public UserAuthResult( String resultMessage,
        STSResponse anSTSResponse )
    {
        super( anSTSResponse.getJwtToken(),
                anSTSResponse.getRefreshToken(),
                anSTSResponse.getExpiresIn(),
                anSTSResponse.getAccessToken() );
        this.setUsername( anSTSResponse.getUsername() );
        this.resultMessage = resultMessage;

    }

    public String getResultMessage()
    {
        return resultMessage;
    }

    public void setResultMessage( String resultMessage )
    {
        this.resultMessage = resultMessage;
    }

}
