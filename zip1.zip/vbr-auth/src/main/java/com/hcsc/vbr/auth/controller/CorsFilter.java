/**
 * 
 */
package com.hcsc.vbr.auth.controller;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import com.hcsc.vbr.auth.config.STSConfig;

/**
 * @author i344317
 *
 */
@Component
@Order( Ordered.HIGHEST_PRECEDENCE )
public class CorsFilter implements Filter
{

    @Autowired
    STSConfig stsConfig;

    /**
     * Method: doFilter
     * @param request
     * @param response
     * @param chain
     * @throws IOException
     * @throws ServletException
     * @see javax.servlet.Filter#doFilter(javax.servlet.ServletRequest, javax.servlet.ServletResponse, javax.servlet.FilterChain)
     */
    @Override
    public void doFilter( ServletRequest request,
            ServletResponse response,
            FilterChain chain ) throws IOException,
            ServletException
    {
        final HttpServletResponse httpResponse = (HttpServletResponse) response;
        httpResponse.setHeader( "Access-Control-Allow-Origin",
                                stsConfig.getAllowedCrossOriginUris() );
        httpResponse.setHeader( "Access-Control-Allow-Methods",
                                "POST, PUT, GET, OPTIONS" );
        httpResponse.setHeader( "Access-Control-Allow-Headers",
                                "Authorization, Content-Type" );
        httpResponse.setHeader( "Access-Control-Allow-Credentials",
                                "true" );
        httpResponse.setHeader( "Access-Control-Max-Age",
                                "3600" );
        if( "OPTIONS".equalsIgnoreCase( ( (HttpServletRequest) request ).getMethod() ) )
        {
            httpResponse.setStatus( HttpServletResponse.SC_OK );
        }
        else
        {
            chain.doFilter( request,
                            response );
        }
    }

    /**
     * Method: destroy
     * @see javax.servlet.Filter#destroy()
     */
    @Override
    public void destroy()
    {

    }

    /**
     * Method: init
     * @param filterConfig
     * @throws ServletException
     * @see javax.servlet.Filter#init(javax.servlet.FilterConfig)
     */
    @Override
    public void init( FilterConfig filterConfig ) throws ServletException
    {

    }

}
