package com.hcsc.vbr.auth.repository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpEntity;
import org.springframework.stereotype.Repository;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import com.hcsc.vbr.auth.config.STSConfig;
import com.hcsc.vbr.auth.model.STSResponse;
import com.hcsc.vbr.auth.model.User;
import com.hcsc.vbr.auth.model.UserDetails;

@Repository
public class UserDetailsRepository
{

    @Autowired
    private STSConfig stsConfig;

    @Autowired
    private RestTemplate restTemplate;

    @Autowired
    @Qualifier( "restRequestHeaderMap" )
    MultiValueMap<String, String> stsClientHeadersMap;

    public void getUserDetails( STSResponse response )
    {

        MultiValueMap<String, String> headers = new LinkedMultiValueMap<>();
        headers.addAll( stsClientHeadersMap );
        headers.add( "Authorization",
                     "Bearer " + response.getAccessToken() );
        HttpEntity<User> request = new HttpEntity<>( headers );

        UserDetails details = restTemplate.postForObject( stsConfig.getUserdetailsURI(),
                                                          request,
                                                          UserDetails.class );
        response.setUserDetails( details );
    }

}
