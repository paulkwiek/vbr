package com.hcsc.vbr.auth.model;

import java.text.ParseException;
import java.util.Date;

import javax.naming.InvalidNameException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.hcsc.vbr.auth.exception.InvalidTokenException;
import com.nimbusds.jwt.JWTClaimsSet;
import com.nimbusds.jwt.SignedJWT;

public class STSResponse
{

    private static final Logger LOG = LoggerFactory.getLogger( STSResponse.class );

    private String username;

    @JsonProperty( "access_token" )
    private String accessToken;

    @JsonProperty( "token_type" )
    private String tokenType;

    @JsonProperty( "expires_in" )
    private int expiresIn;

    @JsonProperty( "refresh_token" )
    private String refreshToken;

    @JsonProperty( "jwt_token" )
    private String jwtToken;

    private UserDetails userDetails;

    public STSResponse()
    {

    }

    public STSResponse( String aJwtToken,
        String aRefreshToken,
        int jwtExpiresIn,
        String anAccessToken )
    {
        this.jwtToken = aJwtToken;
        this.refreshToken = aRefreshToken;
        this.expiresIn = jwtExpiresIn;
        this.accessToken = anAccessToken;
    }

    public String getUsername()
    {
        return username;
    }

    public void setUsername( String username )
    {
        this.username = username;
    }

    public String getAccessToken()
    {
        return accessToken;
    }

    public void setAccessToken( String accessToken )
    {
        this.accessToken = accessToken;
    }

    public String getTokenType()
    {
        return tokenType;
    }

    public void setTokenType( String tokenType )
    {
        this.tokenType = tokenType;
    }

    public int getExpiresIn()
    {
        return expiresIn;
    }

    public void setExpireIn( int expiresIn )
    {
        this.expiresIn = expiresIn;
    }

    public String getRefreshToken()
    {
        return refreshToken;
    }

    public void setRefreshToken( String refreshToken )
    {
        this.refreshToken = refreshToken;
    }

    public String getJwtToken()
    {
        return jwtToken;
    }

    public void setJwtToken( String jwtToken )
    {
        this.jwtToken = jwtToken;
    }

    public UserDetails getUserDetails()
    {
        return userDetails;
    }

    public void setUserDetails( UserDetails userDetails )
    {
        this.userDetails = userDetails;
    }

    public JWTClaimsSet createClaimSet()
    {

        JWTClaimsSet claimsSet = null;
        try
        {
            SignedJWT stsJWT = SignedJWT.parse( this.getJwtToken() );
            claimsSet = new JWTClaimsSet.Builder()

                    .expirationTime( stsJWT.getJWTClaimsSet().getExpirationTime() )
                    .jwtID( "76641e10-3e11-4cd8-8fee-461e93ff5452" )
                    .issueTime( new Date() )
                    .claim( "uuid",
                            getUserDetails().getSub() )
                    .claim( "firstName",
                            getUserDetails().getGivenName() )
                    .claim( "lastName",
                            getUserDetails().getFamilyName() )
                    .claim( "roles",
                            getUserDetails().getRolesList() )
                    .claim( "hcsc",
                            getUserDetails().hasHSCSRole() )
                    .build();

        }
        catch( InvalidNameException | ParseException e )
        {
            throw new InvalidTokenException( e.getMessage() );
        }

        return claimsSet;
    }

    public JWTClaimsSet createClaimSet( JWTClaimsSet oldClaimSet )
    {

        Date exp = new Date( System.currentTimeMillis() + ( 1000 * 3600 ) ); // 1 hours

        return new JWTClaimsSet.Builder( oldClaimSet ).expirationTime( exp ).issueTime( new Date() ).build();

    }

}
