package com.hcsc.vbr.web.exceptions;

import java.util.List;

import org.apache.commons.lang3.builder.ReflectionToStringBuilder;

import com.hcsc.vbr.arrangementconfigservice.dto.ErrorMessageDTO;
import com.hcsc.vbr.common.utils.MultilineRecursiveToStringStyleCustom;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ApplicationException extends Exception
{
    private static final long serialVersionUID = 1L;

    private List<ErrorMessageDTO> errors;

    public ApplicationException( String message )
    {
        super( message );
    }

    public ApplicationException( Long message )
    {
        super( message.toString() );
    }

    public ApplicationException( List<ErrorMessageDTO> errors )
    {
        super( errors.toString() );
        this.errors = errors;
    }

    public ApplicationException( String message,
        Throwable cause )
    {
        super( message,
                cause );
    }

    @Override
    public String toString()
    {
        //return ReflectionToStringBuilder.toString( this );
        return new ReflectionToStringBuilder( this,
                                              new MultilineRecursiveToStringStyleCustom() ).toString();
    }
}
