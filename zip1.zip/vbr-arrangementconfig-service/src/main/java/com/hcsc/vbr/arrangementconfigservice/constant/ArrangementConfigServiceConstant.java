package com.hcsc.vbr.arrangementconfigservice.constant;

public class ArrangementConfigServiceConstant
{
    public static final String DEFAULT_CORP_ENTITY_CODE = "NM1";
    public static final String DEFAULT_CLIENT_ID = "XXX (VBR)";
    public static final String APPLICATION_EXCEPTION_CLASS = "class com.hcsc.vbr.web.exceptions.ApplicationException";
    public static final String VBR_PAYEE_DEFAULT_EXCEPTION_MSG = "Payee could not be saved. Please try again.";
    public static final String DEFAULT_ARRANGEMENT_FREQUENCY = "MONT";
    public static final String ARRANGEMENT_STATUS_EXPIRED = "EX";
    public static final String ARRANGEMENT_STATUS_FUTURE_INVALID = "FI";
    public static final String ARRANGEMENT_STATUS_DRAFT = "DF";
    public static final String ARRANGEMENT_STATUS_INVALID = "IV";
    public static final String ARRANGEMENT_STATUS_VALID = "VA";
    public static final String ARRANGEMENT_STATUS_WARNING = "WA";
    public static final String ARRANGEMENT_STATUS_FUTURE_VALID = "FV";
    public static final String RATE_ROW_SAVE_MESSAGE = "Rate Table successfully updated.";
    public static final String RATE_ROW_UPDATE_MESSAGE = "Rate Table successfully updated.";
    public static final String RATE_TABLE_SAVE_MESSAGE = "New Rate Table successfully created";
    public static final String VBR_PAYEE_SAVE_MESSAGE = "has been successfully added to VBR.";
    public static final String VBR_PAYEE_UPDATE_MESSAGE = "has been successfully updated.";

    // Constants added for displaying Fatal Error during DB/Application down
    public static final String DEFAULT_EXCEPTION_MESSAGE_CATEGORY_CODE = "ERR";
    public static final String DEFAULT_EXCEPTION_ERROR_MESSAGE_DESCRIPTION = "Data could not be saved/retrieved. Please try again.";
    public static final String DEFAULT_EXCEPTION_SEVERITY_LVL = "E";
    public static final String ARRANGEMENT_STATUS_CODE_NAME = "ARNGMTSTATUS";
    public static final String GET_PROCESSING_MONTH_API_URL = "/calculationRequestStatus/getProcessingMonth/{corporateEntityCode}";

    // This user id would be replaced by user id from SMSession later
    public static final String DEFAULT_USER_ID = "U398407";
    public static final String STRING_TRUE = "true";

    // Success Message for  Save Payment Arrangement based on Validation Code
    public static final String PAYMENT_ARRANGEMENT_MESSAGE_DRAFT = "Payment Arrangement has been successfully saved in draft status.";
    public static final String PAYMENT_ARRANGEMENT_MESSAGE_EXPIRED =
        "Payment Arrangement has been successfully saved in expired status.";
    public static final String PAYMENT_ARRANGEMENT_MESSAGE_FUTURE_INVALID =
        "Payment Arrangement has been successfully saved in future invalid status.";
    public static final String PAYMENT_ARRANGEMENT_MESSAGE_INVALID =
        "Payment Arrangement has been successfully saved in invalid status.";
    public static final String PAYMENT_ARRANGEMENT_MESSAGE_WARNING =
        "Payment Arrangement has been successfully saved in warning status.";
    public static final String PAYMENT_ARRANGEMENT_MESSAGE_FUTURE_VALID =
        "Payment Arrangement has been successfully saved in future valid status.";
    public static final String PAYMENT_ARRANGEMENT_MESSAGE_VALID = "Payment Arrangement has been successfully saved in valid status.";
    public static final String PAYMENT_ARRANGEMENT_SUCCESS = "Payment Arrangement has been successfully saved";
    public static final String SUCCESS_VALIDATION_STATUS = "SUCCESS";
    public static final String FAILURE_VALIDATION_STATUS = "FAILED";

    public static final String ACCESS_DENIED_EXCEPTION_ERROR_MESSAGE_DESCRIPTION =
        "User role does not have permission to execute this function";

}