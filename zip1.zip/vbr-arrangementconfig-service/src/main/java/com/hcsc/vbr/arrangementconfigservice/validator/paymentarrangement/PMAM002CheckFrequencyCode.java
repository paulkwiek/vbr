package com.hcsc.vbr.arrangementconfigservice.validator.paymentarrangement;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.hcsc.vbr.arrangementconfigservice.constant.ArrangementConfigServiceConstant;
import com.hcsc.vbr.arrangementconfigservice.constant.ArrangementConfigServiceErrorMessageConstant;
import com.hcsc.vbr.arrangementconfigservice.constant.ComponentIdConstant;
import com.hcsc.vbr.arrangementconfigservice.constant.FieldIdConstant;
import com.hcsc.vbr.arrangementconfigservice.domain.PaymentArrangement;
import com.hcsc.vbr.arrangementconfigservice.validator.base.BaseValidationUnit;
import com.hcsc.vbr.common.dto.ReturnMessageDTO;

/**
 * @author u398411
 *
 */
@Component
public class PMAM002CheckFrequencyCode extends BaseValidationUnit
{
    final Logger LOGGER = LoggerFactory.getLogger( PMAM002CheckFrequencyCode.class );

    /**
     * Method: validateFrequencyCode
     * @param paymentArrangementSaveRequest
     * @param errors
     * @return
     * @throws Exception 
     */

    public boolean validateFrequencyCode( PaymentArrangement paymentArrangementRequest,
            ReturnMessageDTO returnMessage ) throws Exception
    {
        LOGGER.debug( "validateFrequencyCode : START" );

        boolean isFreqCodeValid = true;

        if( !StringUtils.isEmpty( paymentArrangementRequest.getArrangementFrequencyCode() ) )
        {
            if( !StringUtils.equals( paymentArrangementRequest.getArrangementFrequencyCode(),
                                     ArrangementConfigServiceConstant.DEFAULT_ARRANGEMENT_FREQUENCY ) )
            {
                addToReturnMessage( ArrangementConfigServiceErrorMessageConstant.INVALID_FREQUENCY_CODE,
                                    FieldIdConstant.PMAM_FREQ_CODE,
                                    ComponentIdConstant.PMAM,
                                    this.getClass().getSimpleName(),
                                    returnMessage );

                isFreqCodeValid = false;
            }
        }
        else
        {

            addToReturnMessage( ArrangementConfigServiceErrorMessageConstant.REQUIRED_FIELD_FREQUENCY_CODE,
                                FieldIdConstant.PMAM_FREQ_CODE,
                                ComponentIdConstant.PMAM,
                                this.getClass().getSimpleName(),
                                returnMessage );
            isFreqCodeValid = false;
        }
        LOGGER.debug( "ArrangementFrequencyCode is Valid" + isFreqCodeValid );
        LOGGER.debug( "validateFrequencyCode : END" );
        return isFreqCodeValid;
    }

}