package com.hcsc.vbr.arrangementconfigservice.validator.ratename;

import java.time.LocalDate;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.hcsc.vbr.arrangementconfigservice.constant.ArrangementConfigServiceErrorMessageConstant;
import com.hcsc.vbr.arrangementconfigservice.constant.ComponentIdConstant;
import com.hcsc.vbr.arrangementconfigservice.constant.FieldIdConstant;
import com.hcsc.vbr.arrangementconfigservice.domain.FlatRate;
import com.hcsc.vbr.arrangementconfigservice.domain.RateName;
import com.hcsc.vbr.arrangementconfigservice.validator.base.BaseValidationUnit;
import com.hcsc.vbr.common.dto.ReturnMessageDTO;
import com.hcsc.vbr.common.utils.VBRDateUtils;

@Component
public class RTNM010CheckRateEndDateIsLastDayOfMonth extends BaseValidationUnit
{
    private static final Logger LOGGER = LoggerFactory.getLogger( RTNM010CheckRateEndDateIsLastDayOfMonth.class );

    /**
     * @param rateName
     * @param returnMessage
     * @return
     * @throws Exception
     */
    public boolean isLastDayOfMonth( RateName rateName,
            ReturnMessageDTO returnMessage ) throws Exception
    {
        LOGGER.debug( "RTNM010CheckRateEndDateIsLastDayOfMonth : START" );
        boolean validateFlag = true;

        for( FlatRate flatRate : rateName.getFlatRates() )
        {
            if( !( 1 == flatRate.getRecordEffectiveDate().getDayOfMonth() ) || VBRDateUtils.isNotSameDay( flatRate ) )
            {
                LocalDate lastDateOfMonth = VBRDateUtils.getLastDayOfMonth( flatRate.getRecordEndDate() );

                //Checking for Last Day of Month
                if( !( lastDateOfMonth == flatRate.getRecordEndDate() ) )
                {
                    //Set return flag to false
                    validateFlag = false;
                    //Add Error/Warning to ReturnMessage
                    addToReturnMessage( ArrangementConfigServiceErrorMessageConstant.RATE_END_DATE_SHOULD_BE_LAST_DAY_OF_MONTH,
                                        FieldIdConstant.RTNM_END_DATE,
                                        ComponentIdConstant.RTNM,
                                        this.getClass().getSimpleName(),
                                        returnMessage );
                    break;
                }
            }
        }
        LOGGER.debug( "RTNM010CheckRateEndDateIsLastDayOfMonth : END" );
        return validateFlag;
    }

}
