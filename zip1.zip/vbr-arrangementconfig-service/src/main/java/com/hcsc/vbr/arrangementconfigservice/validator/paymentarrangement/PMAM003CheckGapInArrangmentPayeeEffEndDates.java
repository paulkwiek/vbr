package com.hcsc.vbr.arrangementconfigservice.validator.paymentarrangement;

import java.time.LocalDate;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.hcsc.vbr.arrangementconfigservice.constant.ArrangementConfigServiceErrorMessageConstant;
import com.hcsc.vbr.arrangementconfigservice.constant.ComponentIdConstant;
import com.hcsc.vbr.arrangementconfigservice.constant.FieldIdConstant;
import com.hcsc.vbr.arrangementconfigservice.domain.PaymentArrangement;
import com.hcsc.vbr.arrangementconfigservice.validator.base.BaseValidationUnit;
import com.hcsc.vbr.common.domain.DateRecord;
import com.hcsc.vbr.common.dto.ReturnMessageDTO;
import com.hcsc.vbr.common.utils.VBRDateUtils;

@Component
public class PMAM003CheckGapInArrangmentPayeeEffEndDates extends BaseValidationUnit
{

    final Logger LOGGER = LoggerFactory.getLogger( PMAM003CheckGapInArrangmentPayeeEffEndDates.class );

    @Autowired
    private PMAM028CheckGapInArrangementDates checkGapInArrangementDates;

    @Autowired
    private PMAM048CheckArrangementGapwithMultipleDates checkArrangementGapwithMultipleDates;

    /**
     * Method: validateGapInArrangmentPayeeEffEndDates
     * @param dateRecordList
     * @param errors
     * @return
     * @throws Exception
     */
    public boolean validateGapInArrangmentPayeeEffEndDates( List<? extends DateRecord> dateRecordList,
            PaymentArrangement arrangementDate,
            LocalDate processingMonth,
            ReturnMessageDTO returnMessage ) throws Exception
    {
        LOGGER.debug( "validateGapInArrangmentPayeeEffEndDates : START" );

        boolean isDateValid = false;
        LocalDate arrangementEffectiveDate = arrangementDate.getRecordEffectiveDate();
        LocalDate lastDateOfProcessingMonth = VBRDateUtils.getLastDayOfMonth( processingMonth );
        if( !VBRDateUtils.checkForNoGaps( dateRecordList ) )
        {
            if( !checkGapInArrangementDates.checkForNoArrangementGaps( dateRecordList,
                                                                       arrangementDate ) )
            {
                if( !checkArrangementGapwithMultipleDates.checkArrangementGapwithMultipleDates( dateRecordList,
                                                                                                arrangementDate ) )
                {

                    if( arrangementEffectiveDate.isAfter( lastDateOfProcessingMonth ) )
                    {
                        addToReturnMessage( ArrangementConfigServiceErrorMessageConstant.GAP_IN_ARRANGEMENT_PAYEE_EFF_END_DATES_FUTURE,
                                            FieldIdConstant.PMPY_EFF_AND_END_DATE,
                                            ComponentIdConstant.PMAM,
                                            this.getClass().getSimpleName(),
                                            returnMessage );
                        isDateValid = true;
                    }
                    else
                    {
                        addToReturnMessage( ArrangementConfigServiceErrorMessageConstant.GAP_IN_ARRANGEMENT_PAYEE_EFF_END_DATES,
                                            FieldIdConstant.PMPY_EFF_AND_END_DATE,
                                            ComponentIdConstant.PMAM,
                                            this.getClass().getSimpleName(),
                                            returnMessage );
                        isDateValid = true;
                    }

                }

            }
        }
        LOGGER.debug( "validateGapInArrangmentPayeeEffEndDates : " + isDateValid );
        LOGGER.debug( "validateGapInArrangmentPayeeEffEndDates : END" );
        return isDateValid;
    }

}