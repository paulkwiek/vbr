package com.hcsc.vbr.arrangementconfigservice.repository;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.hcsc.vbr.arrangementconfigservice.domain.PaymentArrangementMemberSubject;

@Repository
public interface PaymentArrangementMemberSubjectRepository extends JpaRepository<PaymentArrangementMemberSubject, Integer>
{
    @Query( "SELECT r FROM PaymentArrangementMemberSubject r WHERE r.paymentArrangementId=:arrangementId" )
    public List<PaymentArrangementMemberSubject> findByPaymentArrangementMemberSubject(
            @Param( "arrangementId" ) Integer arrangementId );

    /**
     * save/update/delete/NoAction for payment member subject
     * @param paymentArrangementMemberSubjects
     */
    default void savePaymentMemberSubject( PaymentArrangementMemberSubject paymentArrangementMemberSubject )
    {

        switch( paymentArrangementMemberSubject.getRowAction() )
        {
            case INSERT:
            {
                paymentArrangementMemberSubject.setCreateRecordTimestamp( LocalDateTime.now() );
                save( paymentArrangementMemberSubject );
                break;
            }
            case UPDATE:
            {
                save( paymentArrangementMemberSubject );
                break;
            }
            case DELETE:
            {
                delete( paymentArrangementMemberSubject );
                break;
            }
            default:
                break;
        }

    }
}
