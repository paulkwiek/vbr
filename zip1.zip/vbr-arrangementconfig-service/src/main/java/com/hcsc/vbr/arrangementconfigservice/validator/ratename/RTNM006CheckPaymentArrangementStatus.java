package com.hcsc.vbr.arrangementconfigservice.validator.ratename;

import java.time.LocalDate;
import java.util.List;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.ObjectUtils;

import com.hcsc.vbr.arrangementconfigservice.apiclient.CalculationServiceApiClient;
import com.hcsc.vbr.arrangementconfigservice.constant.ArrangementConfigServiceErrorMessageConstant;
import com.hcsc.vbr.arrangementconfigservice.constant.ComponentIdConstant;
import com.hcsc.vbr.arrangementconfigservice.constant.FieldIdConstant;
import com.hcsc.vbr.arrangementconfigservice.domain.FlatRate;
import com.hcsc.vbr.arrangementconfigservice.domain.PaymentArrangement;
import com.hcsc.vbr.arrangementconfigservice.domain.PaymentArrangementRate;
import com.hcsc.vbr.arrangementconfigservice.repository.PaymentArrangementRateRepository;
import com.hcsc.vbr.arrangementconfigservice.repository.PaymentArrangementRepository;
import com.hcsc.vbr.arrangementconfigservice.validator.base.BaseValidationUnit;
import com.hcsc.vbr.arrangementconfigservice.validator.paymentarrangement.PMAM019CheckValidationStatusCode;
import com.hcsc.vbr.common.constant.VBRCommonConstant.RowActionTypes;
import com.hcsc.vbr.common.domain.DateRecord;
import com.hcsc.vbr.common.dto.ReturnMessageDTO;
import com.hcsc.vbr.common.utils.VBRDateUtils;

@Component
public class RTNM006CheckPaymentArrangementStatus extends BaseValidationUnit
{

    private static final Logger LOGGER = LoggerFactory.getLogger( RTNM006CheckPaymentArrangementStatus.class );

    @Autowired
    private PaymentArrangementRateRepository paymentArrangementRateRepository;

    @Autowired
    private PaymentArrangementRepository paymentArrangementRepository;

    @Autowired
    private PMAM019CheckValidationStatusCode checkValidationStatusCode;

    @Autowired
    private CalculationServiceApiClient calculationServiceApiClient;

    /**
     * Method: validateRateDatewithPaymentArrangementStatus
     * 
     * @param flatRate
     * @param returnMessage
     * @return
     * @throws Exception
     */

    public boolean validateRateDatewithPaymentArrangementStatus( FlatRate flatRate,
            ReturnMessageDTO returnMessage ) throws Exception
    {

        LOGGER.debug( "RTNM006CheckPaymentArrangementStatus : START" );

        boolean isRateInvalid = false;
        boolean isPayeeInvalid = false;
        boolean isProcessingMonthValid = false;
        boolean validateFlag = true;

        Integer validationStatusCodeChangeCount = 0;
        String validationStatusCode = null;
        LocalDate processingMonth = calculationServiceApiClient.getCurrentProcessingMonth( flatRate.getCorporateEntityCode() );

        RowActionTypes rowAction = RowActionTypes.valueOf( flatRate.getRowAction().name() );
        switch( rowAction )
        {
            case UPDATE:
            {
                List<PaymentArrangementRate> paymentArrangementRates =
                    paymentArrangementRateRepository.findByRateName( flatRate.getRateName() );

                /** Start of ArrangementRate Validations */
                if( !CollectionUtils.isEmpty( paymentArrangementRates ) )
                {
                    for( PaymentArrangementRate paymentArrangementRate : paymentArrangementRates )
                    {
                        boolean isArrangementRateVaildForGlobalRate = isArrangementRateDurationValid( flatRate,
                                                                                                      paymentArrangementRate );

                        PaymentArrangement paymentArrangement =
                            paymentArrangementRepository.findByArrangementId( paymentArrangementRate.getPaymentArrangementId() );

                        /** Start of Arrangement Validations */
                        if( !ObjectUtils.isEmpty( paymentArrangement ) )
                        {
                            boolean isArrangementRateValidForArrangementDuration =
                                isArrangementRateDurationValid( paymentArrangementRate,
                                                                paymentArrangement );

                            if( isArrangementRateVaildForGlobalRate || isArrangementRateValidForArrangementDuration )
                            {
                                isRateInvalid = true;
                            }

                            /** Check Arrangement Rate valid for processing month */
                            isProcessingMonthValid = isArrangementRateValidForProcessingMonth( flatRate,paymentArrangementRates,
                                                                                               paymentArrangement,
                                                                                               processingMonth );

                            validationStatusCode = checkValidationStatusCode.getValidationStatusCode( paymentArrangement,
                                                                                                      isRateInvalid,
                                                                                                      isPayeeInvalid,
                                                                                                      processingMonth,
                                                                                                      isProcessingMonthValid );
                            if( !StringUtils.equalsIgnoreCase( paymentArrangement.getValidationStatusCode(),
                                                               validationStatusCode ) )
                            {

                                validationStatusCodeChangeCount++;
                                paymentArrangement.setValidationStatusCode( validationStatusCode );
                                paymentArrangementRepository.savePaymentArrangement( paymentArrangement );
                            }
                        }
                    }

                    if( validationStatusCodeChangeCount > 0 )

                    {
                        validateFlag = false;
                        // Add Error/Warning to ReturnMessage
                        addToReturnMessage( ArrangementConfigServiceErrorMessageConstant.ARRANGEMENT_STATUS_CHANGED,
                                            FieldIdConstant.PMAM_STATUS,
                                            ComponentIdConstant.RTNM,
                                            this.getClass().getSimpleName(),
                                            returnMessage );
                    }

                }

            }
            default:
                break;
        }
        LOGGER.debug( "RTNM006CheckPaymentArrangementStatus : END" );
        return validateFlag;

    }

    /**
     * Method: isArrangementRateDurationValid
     * 
     * @param parent
     * @param child
     * @return
     * @throws Exception
     */
    private boolean isArrangementRateDurationValid( DateRecord parent,
            DateRecord child ) throws Exception
    {
        boolean flag = false;

        if( !VBRDateUtils.checkDateCoverage( parent,
                                             child ) )
        {
            flag = true;
        }

        return flag;
    }

    private boolean isArrangementRateValidForProcessingMonth( FlatRate flatRate, List<? extends DateRecord> parent,
            DateRecord child,
            LocalDate processMonth ) throws Exception
    {
        boolean isDateValid = false;
        boolean isFlatRateDatesNotVoid=false;
        List<? extends DateRecord> arrangementRateDateAfterRemovingVoidDates = VBRDateUtils.removeVoidDates( parent );
        if( VBRDateUtils.isNotSameDay( flatRate ) )
        {
            isFlatRateDatesNotVoid = true;
        }
        if( CollectionUtils.isNotEmpty( arrangementRateDateAfterRemovingVoidDates ))
            
        {
            DateRecord parentArrangementrateDateRecord =
                VBRDateUtils.convertDateRecordListToDateRecordRange( arrangementRateDateAfterRemovingVoidDates );
            if( ( processMonth.isAfter( parentArrangementrateDateRecord.getRecordEffectiveDate() )
                || processMonth.isEqual( parentArrangementrateDateRecord.getRecordEffectiveDate() ) )
                && ( processMonth.isBefore( parentArrangementrateDateRecord.getRecordEndDate() )
                    || processMonth.isEqual( parentArrangementrateDateRecord.getRecordEndDate() ) )
                && isFlatRateDatesNotVoid )
            {
                isDateValid = true;
            }
        }
        LOGGER.debug( "ProcessingMonth Valid for ArrangementRate  : " + isDateValid );
        LOGGER.debug( "validateArrangementRateValidForProcessingMonth : END" );

        return isDateValid;
    }

}
