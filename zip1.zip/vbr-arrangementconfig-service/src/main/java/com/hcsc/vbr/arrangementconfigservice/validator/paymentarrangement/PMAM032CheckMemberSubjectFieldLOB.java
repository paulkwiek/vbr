package com.hcsc.vbr.arrangementconfigservice.validator.paymentarrangement;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.hcsc.vbr.arrangementconfigservice.constant.ArrangementConfigServiceErrorMessageConstant;
import com.hcsc.vbr.arrangementconfigservice.constant.ComponentIdConstant;
import com.hcsc.vbr.arrangementconfigservice.constant.FieldIdConstant;
import com.hcsc.vbr.arrangementconfigservice.domain.PaymentArrangement;
import com.hcsc.vbr.arrangementconfigservice.domain.PaymentArrangementMemberSubject;
import com.hcsc.vbr.arrangementconfigservice.validator.base.BaseValidationUnit;
import com.hcsc.vbr.common.dto.ReturnMessageDTO;

/**
 * Check for Mandatory Fields in Member Subject.
 *
 * @param paymentArrangementSaveRequest
 * @return boolean
 */
@Component
public class PMAM032CheckMemberSubjectFieldLOB extends BaseValidationUnit
{
    final Logger LOGGER = LoggerFactory.getLogger( PMAM032CheckMemberSubjectFieldLOB.class );

    /**
     * Method: checkArrangementMemberSubjectLOB
     * @param paymentArrangementSaveRequest
     * @param returnMessage
     * @return
     * @throws Exception
     */
    public boolean checkArrangementMemberSubjectLOB( PaymentArrangement paymentArrangementSaveRequest,
            ReturnMessageDTO returnMessage ) throws Exception
    {
        LOGGER.debug( "checkArrangementMemberSubjectLOB : START" );
        boolean isMemberSubjectChanged = false;

        for( PaymentArrangementMemberSubject paymentArrangementMemberSubject : paymentArrangementSaveRequest
                .getPaymentArrangementMemberSubjects() )
        {
            /* Condition to check if LOB exists. For this MVP its only one record and error message will be only for one record */
            if( StringUtils.isEmpty( StringUtils.trim( paymentArrangementMemberSubject.getLineOfBusinessCode() ) ) )
            {

                addToReturnMessage( ArrangementConfigServiceErrorMessageConstant.ARRANGEMENT_MEMBER_SUBJECT_MANDATORY_FIELD_VALIDATION_LOB,
                                    FieldIdConstant.PMAM_MBR_SBJCT,
                                    ComponentIdConstant.PMAM,
                                    this.getClass().getSimpleName(),
                                    returnMessage );
                isMemberSubjectChanged = true;

            }
        }
        LOGGER.debug( "checkArrangementMemberSubjectLOB Not  Selected  : " + isMemberSubjectChanged );
        LOGGER.debug( "checkArrangementMemberSubjectLOB : END" );

        return isMemberSubjectChanged;

    }
}