package com.hcsc.vbr.web.controller.base;

public class BaseController
{

}
