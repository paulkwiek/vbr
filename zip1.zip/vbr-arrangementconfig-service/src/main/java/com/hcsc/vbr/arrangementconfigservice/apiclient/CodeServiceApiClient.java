package com.hcsc.vbr.arrangementconfigservice.apiclient;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.hcsc.vbr.arrangementconfigservice.dto.ErrorMessageDTO;
import com.hcsc.vbr.common.apiclient.BaseApiClient;
import com.hcsc.vbr.common.web.request.ErrorMessageRequest;
import com.hcsc.vbr.web.request.ErrorMessage;
import com.hcsc.vbr.web.response.CodeServiceStausDescriptionResponse;

@Component
public class CodeServiceApiClient extends BaseApiClient
{

    @Autowired
    @Qualifier( "restRequestHeaderMap" )
    MultiValueMap<String, String> errCodeClientHeadersMap;

    MultiValueMap<String, String> codeApiClientHeadersMap = new HttpHeaders();

    @Autowired
    private RestTemplate restTemplate;

    @Value( "${code.service.client.url}" )
    private String codeServiceClientUrl;

    @Value( "${code.service.code.set.description.client.url}" )
    private String codeSetValueClientUrl;

    private static final Logger LOGGER = LoggerFactory.getLogger( CodeServiceApiClient.class );

    public List<ErrorMessageDTO> getErrorByIds( ErrorMessage errorMsg ) throws Exception
    {
        HttpEntity<String> request = new HttpEntity<>( new ObjectMapper().writeValueAsString( errorMsg ),
                                                       getAuthorizationHeader() );

        ErrorMessage response = null;

        try
        {
            response = restTemplate.postForObject( codeServiceClientUrl,
                                                   request,
                                                   ErrorMessage.class );
        }
        catch( HttpClientErrorException e )
        {
            throw new Exception( "Recieved error from Code service: " + e );
        }

        return response.getErrors();
    }

    /**
     * This method will call codeServiceClient and create map using status and description.
     * Method: getAllPaymentArrangementStatusDescription
     * @param corporateEntityCode
     * @param CodeSetName
     * @return codeDescriptionMap
     * @throws Exception
     */
    public Map<String, String> getAllPaymentArrangementStatusDescription( String corporateEntityCode,
            String CodeSetName ) throws Exception
    {
        String uri = StringUtils.join( codeSetValueClientUrl,
                                       CodeSetName );
        Map<String, String> codeDescriptionMap = new HashMap<>();

        Map<String, String> parameterMap = new HashMap<String, String>();
        parameterMap.put( "corporateEntityCode",
                          corporateEntityCode );
        HttpEntity<String> entity = new HttpEntity<>( getAuthorizationHeader() );
        UriComponentsBuilder builder = UriComponentsBuilder.fromUriString( uri );

        ResponseEntity<CodeServiceStausDescriptionResponse> codeServiceStausDescriptionResponse = null;

        try
        {
            LOGGER.info( "In CodeSetValueAPI::Before call" + uri );
            codeServiceStausDescriptionResponse = restTemplate.exchange( builder.buildAndExpand( parameterMap ).toUri(),
                                                                         HttpMethod.GET,
                                                                         entity,
                                                                         CodeServiceStausDescriptionResponse.class );
            LOGGER.info( "In CodeSetValueAPI::After call"
                + new ObjectMapper().writeValueAsString( codeServiceStausDescriptionResponse ) );

            codeServiceStausDescriptionResponse.getBody().getCodeSetValueItems().forEach( ( codeSetItem ) -> {
                codeDescriptionMap.put( codeSetItem.getCodeValueText(),
                                        codeSetItem.getCodeValueDescription() );
            } );

        }
        catch( RestClientException _rce )
        {
            _rce.printStackTrace();
        }
        catch( Exception _e )
        {
            _e.printStackTrace();
        }
        return codeDescriptionMap;
    }

    public List<com.hcsc.vbr.common.dto.ErrorMessageDTO> getErrorsAndWarningsByIds( ErrorMessageRequest errorMessageRequest )
            throws Exception
    {

        codeApiClientHeadersMap.addAll( errCodeClientHeadersMap );
        codeApiClientHeadersMap.addAll( getAuthorizationHeader() );

        HttpEntity<String> request = new HttpEntity<>( new ObjectMapper().writeValueAsString( errorMessageRequest ),
                                                       getAuthorizationHeader() );

        ErrorMessageRequest response = null;

        try
        {
            response = restTemplate.postForObject( codeServiceClientUrl,
                                                   request,
                                                   ErrorMessageRequest.class );
        }
        catch( HttpClientErrorException e )
        {
            throw new Exception( "Recieved error from Code service: " + e );
        }

        return response.getErrors();
    }
}
