package com.hcsc.vbr.arrangementconfigservice.service;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.ObjectUtils;

import com.hcsc.vbr.arrangementconfigservice.apiclient.CodeServiceApiClient;
import com.hcsc.vbr.arrangementconfigservice.constant.ArrangementConfigServiceConstant;
import com.hcsc.vbr.arrangementconfigservice.constant.ComponentIdConstant;
import com.hcsc.vbr.arrangementconfigservice.domain.PaymentArrangement;
import com.hcsc.vbr.arrangementconfigservice.domain.PaymentArrangementHistory;
import com.hcsc.vbr.arrangementconfigservice.domain.PaymentArrangementMemberSubject;
import com.hcsc.vbr.arrangementconfigservice.domain.PaymentArrangementPayee;
import com.hcsc.vbr.arrangementconfigservice.domain.PaymentArrangementRate;
import com.hcsc.vbr.arrangementconfigservice.domain.VbrPayee;
import com.hcsc.vbr.arrangementconfigservice.dto.CalculationArrangementsDTO;
import com.hcsc.vbr.arrangementconfigservice.dto.PaymentArrangementDTO;
import com.hcsc.vbr.arrangementconfigservice.dto.VbrPayeeDTO;
import com.hcsc.vbr.arrangementconfigservice.mapper.PaymentArrangementMapper;
import com.hcsc.vbr.arrangementconfigservice.mapper.VbrPayeeMapper;
import com.hcsc.vbr.arrangementconfigservice.repository.PaymentArrangementHistoryRepository;
import com.hcsc.vbr.arrangementconfigservice.repository.PaymentArrangementMemberSubjectRepository;
import com.hcsc.vbr.arrangementconfigservice.repository.PaymentArrangementPayeeRepository;
import com.hcsc.vbr.arrangementconfigservice.repository.PaymentArrangementRateRepository;
import com.hcsc.vbr.arrangementconfigservice.repository.PaymentArrangementRepository;
import com.hcsc.vbr.arrangementconfigservice.repository.VbrPayeeRepository;
import com.hcsc.vbr.arrangementconfigservice.service.base.BaseService;
import com.hcsc.vbr.arrangementconfigservice.utils.ArrangementConfigServiceUtils;
import com.hcsc.vbr.arrangementconfigservice.utils.VbrPayeeUtils;
import com.hcsc.vbr.arrangementconfigservice.validator.payee.PayeeValidator;
import com.hcsc.vbr.arrangementconfigservice.validator.paymentarrangement.PaymentArrangementValidator;
import com.hcsc.vbr.common.apiclient.ProviderServiceApiClient;
import com.hcsc.vbr.common.constant.VBRCommonConstant.RowActionTypes;
import com.hcsc.vbr.common.dto.ReturnMessageDTO;
import com.hcsc.vbr.common.utils.VBRDateUtils;
import com.hcsc.vbr.web.request.CalculationRequestSaveRequest;
import com.hcsc.vbr.web.request.PayeeSearchRequest;
import com.hcsc.vbr.web.request.PaymentArrangementSaveRequest;
import com.hcsc.vbr.web.request.ProviderAPIRequest;
import com.hcsc.vbr.web.request.ValidateArrangementPayeeRequest;
import com.hcsc.vbr.web.response.CalculationRequestPaymentArrangementResponse;
import com.hcsc.vbr.web.response.PayeeRetrieveResponse;
import com.hcsc.vbr.web.response.PaymentArrangementListResponse;
import com.hcsc.vbr.web.response.PaymentArrangementResponse;
import com.hcsc.vbr.web.response.PaymentArrangementSaveResponse;
import com.hcsc.vbr.web.response.ProviderAPIResponse;
import com.hcsc.vbr.web.response.ProviderAPIResponseDTO;
import com.hcsc.vbr.web.response.ValidateArrangementPayeeResponse;

import lombok.Setter;

@Service
@Setter
public class PaymentArrangementService extends BaseService
{
    final Logger LOGGER = LoggerFactory.getLogger( PaymentArrangementService.class );

    @Autowired
    private PaymentArrangementMapper paymentArrangementMapper;

    @Autowired
    private PaymentArrangementRepository paymentArrangementRepository;

    @Autowired
    private PaymentArrangementHistoryRepository paymentArrangementHistoryRepository;

    @Autowired
    private PaymentArrangementMemberSubjectRepository paymentArrangementMemberSubjectRepository;

    @Autowired
    private PaymentArrangementPayeeRepository paymentArrangementPayeeRepository;

    @Autowired
    private VbrPayeeRepository vbrPayeeRepository;

    @Autowired
    private PaymentArrangementValidator paymentArrangementValidator;

    @Autowired
    private PaymentArrangementRateRepository paymentArrangementRateRepository;

    @Autowired
    private CodeServiceApiClient codeServiceApiClient;

    @Autowired
    private PayeeValidator payeeValidator;

    @Autowired
    private ProviderServiceApiClient providerServiceApiClient;

    @Autowired
    private VbrPayeeMapper vbrPayeeMapper;

    @Autowired
    private VbrPayeeUtils vbrPayeeUtils;

    /**
     * Save or update payment arrangement.
     *
     * @param paymentArrangementSaveRequest
     *            the payment arrangement save request
     * @return the integer
     * @throws Exception
     *             the exception
     */

    /**
     * Method: savePaymentArrangement
     * @param paymentArrangementRequest
     * @return
     * @throws Exception
     */
    @Transactional( propagation = Propagation.REQUIRED )
    public PaymentArrangementSaveResponse savePaymentArrangement( PaymentArrangementSaveRequest paymentArrangementSaveRequest )
            throws Exception
    {
        LOGGER.debug( "savePaymentArrangement : START" );

        PaymentArrangementDTO paymentArrangementDTO = paymentArrangementSaveRequest.getArrangement();
        PaymentArrangement paymentArrangement = paymentArrangementMapper.toPaymentArrangement( paymentArrangementDTO );

        if( !StringUtils.isBlank( paymentArrangement.getPaymentArrangementName() ) )
        {
            paymentArrangement
                    .setPaymentArrangementName( StringUtils.upperCase( paymentArrangement.getPaymentArrangementName().trim() ) );
        }

        if( !StringUtils.isBlank( paymentArrangement.getPaymentArrangementDescription() ) )
        {
            paymentArrangement.setPaymentArrangementDescription( paymentArrangement.getPaymentArrangementDescription().trim() );
        }

        PaymentArrangementSaveResponse paymentArrangementSaveResponse = new PaymentArrangementSaveResponse();
        ReturnMessageDTO returnMessage = new ReturnMessageDTO( ComponentIdConstant.PMAM );
        String validationStatusCode = null;

        String status = paymentArrangementValidator.validateArrangementStatus( paymentArrangement,
                                                                               returnMessage );

        //COMPARES IF THE STATUS HAS BEEN CHANGED AFTER REVALIDATION, AND SETS THE ARRANGEMENT ROWACTION TO UPDATE IF THERE IS CHANGE IN STATUS
        if( !StringUtils.isBlank( paymentArrangementDTO.getValidationStatusCode() ) )
        {
            validationStatusCode = paymentArrangementDTO.getValidationStatusCode();

            if( !StringUtils.equalsIgnoreCase( status,
                                               validationStatusCode ) )
            {
                paymentArrangement.setValidationStatusCode( status );
                paymentArrangement.setRowAction( RowActionTypes.UPDATE );
            }
        }

        LOGGER.debug( status + "returnMessage" + returnMessage );

        if( StringUtils.equalsIgnoreCase( status,
                                          ArrangementConfigServiceConstant.ARRANGEMENT_STATUS_EXPIRED ) )
        {
            LOGGER.debug( "Warnings will be filtered for expired arrangement status" );
            returnMessage = filterExpiredWarningMessage( returnMessage );
        }

        paymentArrangementSaveResponse = savePaymentArrangementRequest( paymentArrangement );

        validationStatusCode = paymentArrangementSaveResponse.getPaymentArrangement().getValidationStatusCode();
        paymentArrangementSaveResponse.setReturnMessage( returnMessage );

        // Success Message for  Save Payment Arrangement based on Validation Code
        setArrangementSuccessMessage( returnMessage,
                                      paymentArrangementSaveResponse,
                                      validationStatusCode );

        return paymentArrangementSaveResponse;

    }

    /**
     * Method: savePaymentArrangementRequest
     * @param paymentArrangementRequest
     * @return
     */
    private PaymentArrangementSaveResponse savePaymentArrangementRequest( PaymentArrangement paymentArrangement )
    {
        LOGGER.debug( "savePaymentArrangementRequest : START" );
        PaymentArrangementSaveResponse paymentArrangementSaveResponse = new PaymentArrangementSaveResponse();

        paymentArrangementRepository.savePaymentArrangement( paymentArrangement );

        PaymentArrangementDTO paymentArrangementDTO = paymentArrangementMapper.toPaymentArrangmentDTO( paymentArrangement );
        if( !StringUtils.equalsIgnoreCase( paymentArrangementDTO.getRowAction().name(),
                                           RowActionTypes.NO_ACTION.toString() ) )

        {
            PaymentArrangementHistory paymentArrangementHistory =
                paymentArrangementMapper.toPaymentArrangementHistory( paymentArrangementDTO );

            LOGGER.debug( "Save payment arrangement history" );
            paymentArrangementHistoryRepository.savePaymentArrangementHistory( paymentArrangementHistory );
        }

        if( !ObjectUtils.isEmpty( paymentArrangement.getPaymentArrangementId() ) )
        {

            for( PaymentArrangementMemberSubject subject : paymentArrangement.getPaymentArrangementMemberSubjects() )
            {
                //As the member subject should be inserted or updated for an arrangement
                subject.setPaymentArrangementId( paymentArrangement.getPaymentArrangementId() );
                /*
                 * Save or update payment arrangement member subject.
                 * 
                 * @param list of payment arrangement member subject DTOs
                 */
                paymentArrangementMemberSubjectRepository.savePaymentMemberSubject( subject );

            }

            if( !ObjectUtils.isEmpty( paymentArrangement.getPaymentArrangementPayees() ) )
            {
                for( PaymentArrangementPayee paymentArrangementPayee : paymentArrangement.getPaymentArrangementPayees() )
                {
                    paymentArrangementPayee.setPaymentArrangementId( paymentArrangement.getPaymentArrangementId() );

                    VbrPayee payee = new VbrPayee();

                    if( ObjectUtils.isEmpty( paymentArrangementPayee.getVbrPayee().getVbrPayeeId() ) )
                    {

                        payee = vbrPayeeUtils.getProviderApiAddressAndDemographicsResponse( paymentArrangementPayee.getVbrPayee() );

                        vbrPayeeRepository.saveVbrPaye( payee );

                        paymentArrangementPayee.setVbrPayeeId( payee.getVbrPayeeId() );

                    }
                    else
                    {

                        paymentArrangementPayee.setVbrPayeeId( paymentArrangementPayee.getVbrPayee().getVbrPayeeId() );

                    }
                }
            }
            /*
             * Save or update Payment arrangement payee.
             * 
             * @param List of Payment arrangement payees
             */
            paymentArrangementPayeeRepository.savePaymentArgmtPayee( paymentArrangement.getPaymentArrangementPayees() );

            /*
             * Save or update PaymentArrangmentRate.
             * 
             * @param list of PaymentArrangmentRate DTO
             */
            if( !ObjectUtils.isEmpty( paymentArrangement.getPaymentArrangementRates() ) )
            {
                for( PaymentArrangementRate rate : paymentArrangement.getPaymentArrangementRates() )
                {

                    rate.setPaymentArrangementId( paymentArrangement.getPaymentArrangementId() );

                }
            }
            paymentArrangementRateRepository.savePaymentArrangementRate( paymentArrangement.getPaymentArrangementRates() );

        }
        PaymentArrangementDTO paymentArrDTO = paymentArrangementMapper.toPaymentArrangmentDTO( paymentArrangement );
        paymentArrangementSaveResponse.setPaymentArrangement( paymentArrDTO );
        LOGGER.debug( "savePaymentArrangementRequest : END" );
        return paymentArrangementSaveResponse;
    }

    /**
     * @method getArrangementsByCorporateEntityCode
     * @param corporateEntityCode
     * @return
     * @throws Exception
     */
    @Transactional( propagation = Propagation.SUPPORTS )
    public List<PaymentArrangementListResponse> getArrangementsByCorporateEntityCode( String corporateEntityCode ) throws Exception
    {
        LOGGER.debug( "getArrangementsByCorporateEntityCode : START" );

        List<PaymentArrangementListResponse> arrangementResponse = new ArrayList<PaymentArrangementListResponse>();
        ReturnMessageDTO returnMessage = new ReturnMessageDTO( ComponentIdConstant.PMAM );

        List<PaymentArrangement> paymentArrangements =
            paymentArrangementRepository.findArrangementsByCorporateEntityCode( corporateEntityCode );

        boolean isArrangementValid = paymentArrangementValidator.validateRetrieveArrangements( paymentArrangements,
                                                                                               returnMessage );

        Map<String, String> codeDescriptionMap = codeServiceApiClient.getAllPaymentArrangementStatusDescription( corporateEntityCode,
                                                                                                                 ArrangementConfigServiceConstant.ARRANGEMENT_STATUS_CODE_NAME );

        if( isArrangementValid )
        {

            for( PaymentArrangement paymentArrangement : paymentArrangements )
            {
                PaymentArrangementListResponse paymentArrangementListResponse = new PaymentArrangementListResponse();

                paymentArrangementListResponse.setPaymentArrangementName( paymentArrangement.getPaymentArrangementName() );
                paymentArrangementListResponse.setPaymentArrangementId( paymentArrangement.getPaymentArrangementId() );
                paymentArrangementListResponse.setPaymentArrangmentStatus( paymentArrangement.getValidationStatusCode() );

                paymentArrangementListResponse.setPaymentArrangementStatusDescription( codeDescriptionMap
                        .get( paymentArrangement.getValidationStatusCode() ) );

                paymentArrangementListResponse.setRecordEffectiveDate( VBRDateUtils
                        .convertLocalDateToString( paymentArrangement.getRecordEffectiveDate() ) );

                paymentArrangementListResponse
                        .setRecordEndDate( VBRDateUtils.convertLocalDateToString( paymentArrangement.getRecordEndDate() ) );

                try
                {
                    List<PaymentArrangementPayee> arrangementPayees = paymentArrangement.getPaymentArrangementPayees();

                    if( CollectionUtils.isNotEmpty( arrangementPayees ) )
                    {
                        boolean isPayeeActive = false;

                        Long difference;

                        Map<Long, VbrPayee> payeeMap = new TreeMap<Long, VbrPayee>();

                        for( PaymentArrangementPayee payee : arrangementPayees )
                        {
                            difference = ChronoUnit.DAYS.between( payee.getVbrPayee().getRecordEffectiveDate(),
                                                                  LocalDate.now() );

                            payeeMap.put( difference,
                                          payee.getVbrPayee() );

                            if( !( payee.getVbrPayee().getRecordEffectiveDate().equals( payee.getVbrPayee().getRecordEndDate() ) ) )
                            {
                                if( ( LocalDate.now().isAfter( payee.getVbrPayee().getRecordEffectiveDate() ) )
                                    && ( LocalDate.now().isBefore( payee.getVbrPayee().getRecordEndDate() ) ) )
                                {
                                    isPayeeActive = true;
                                    paymentArrangementListResponse.setPinGroupId( payee.getVbrPayee().getPinGroupId() );
                                    break;
                                }
                            }

                        }

                        if( isPayeeActive == false )
                        {
                            Set<Long> keySet = payeeMap.keySet();
                            List<Long> lst = new ArrayList<Long>( keySet );
                            Collections.sort( lst );
                            VbrPayee inactivePayee = payeeMap.get( lst.get( 0 ) );
                            paymentArrangementListResponse.setPinGroupId( inactivePayee.getPinGroupId() );

                        }
                    }
                    arrangementResponse.add( paymentArrangementListResponse );
                }
                catch( Exception e )
                {
                    LOGGER.debug( "Exception catched inside getPaymentArrangementDetails()" + e.getMessage() );
                }

            }
        }

        LOGGER.debug( "getArrangementsByCorporateEntityCode : END" );

        return arrangementResponse;
    }

    /**
     * Get Payee details by paymentArrangement name
     *@method getPaymentArrangementId
     * @param paymentArrangementId
     * @return paymentArrangementDTO
     * @throws Exception
     *             the exception
     */
    @Transactional( propagation = Propagation.SUPPORTS )
    public PaymentArrangementResponse getPaymentArrangementId( Integer paymentArrangementId ) throws Exception
    {
        LOGGER.debug( "getPayeeByArrangementId : START" );

        PaymentArrangementDTO paymentArrangementDTO = new PaymentArrangementDTO();
        PaymentArrangementResponse paymentArrangementResponse = new PaymentArrangementResponse();

        ReturnMessageDTO returnMessage = new ReturnMessageDTO( ComponentIdConstant.PMAM );

        Map<String, String> codeDescriptionMap = codeServiceApiClient.getAllPaymentArrangementStatusDescription( "NM1",
                                                                                                                 ArrangementConfigServiceConstant.ARRANGEMENT_STATUS_CODE_NAME );

        PaymentArrangement paymentArrangement = paymentArrangementRepository.findByArrangementId( paymentArrangementId );

        boolean isArrangementValid = paymentArrangementValidator.validateRetrieveArrangement( paymentArrangement,
                                                                                              returnMessage );

        if( isArrangementValid )
        {

            List<PaymentArrangementPayee> payees = paymentArrangement.getPaymentArrangementPayees();

            for( PaymentArrangementPayee payee : payees )
            {
                VbrPayee vbrPayee = payee.getVbrPayee();
                vbrPayee.setPayToPFINName( vbrPayeeUtils.mapPayToPfinName( vbrPayee ) );
                payee.setVbrPayee( vbrPayee );
            }

            Collections.sort( payees );

            Collections.reverse( payees );

            paymentArrangement.setPaymentArrangementPayees( payees );

            List<PaymentArrangementRate> paymentArrangementRates = paymentArrangement.getPaymentArrangementRates();

            Collections.sort( paymentArrangementRates );

            paymentArrangement.setPaymentArrangementRates( paymentArrangementRates );

            String status = paymentArrangementValidator.validateSave( paymentArrangement,
                                                                      returnMessage );

            LOGGER.debug( "getPayeeByArrangementId returnMessage: " + returnMessage );

            String validationStatusCode = null;

            if( !StringUtils.isBlank( paymentArrangement.getValidationStatusCode() ) )
            {

                validationStatusCode = paymentArrangement.getValidationStatusCode();

                if( !StringUtils.equalsIgnoreCase( status,
                                                   validationStatusCode ) )
                {

                    paymentArrangement.setValidationStatusCode( status );

                }
            }

            paymentArrangementDTO = paymentArrangementMapper.toPaymentArrangmentDTO( paymentArrangement );

            paymentArrangementDTO.setPaymentArrangementStatusDescription( codeDescriptionMap
                    .get( paymentArrangementDTO.getValidationStatusCode() ) );

            returnMessage.getErrors().clear();

            LOGGER.debug( "getPayeeByArrangementId after filtering Errors: " + returnMessage );

            /** Remove Warnings For Expired Status as implemented in savePaymentArrangement **/
            if( StringUtils.equalsIgnoreCase( paymentArrangementDTO.getValidationStatusCode(),
                                              ArrangementConfigServiceConstant.ARRANGEMENT_STATUS_EXPIRED ) )
            {

                returnMessage = filterExpiredWarningMessage( returnMessage );

            }

        }
        paymentArrangementResponse.setPaymentArrangement( paymentArrangementDTO );
        paymentArrangementResponse.setReturnMessage( returnMessage );

        LOGGER.debug( "getPayeeByArrangementId : END" );
        return paymentArrangementResponse;
    }

    /**
     * Method: findByArrangementName
     * @param arrangementName
     * @return
     * @throws Exception
     */
    public Boolean findByArrangementName( String arrangementName ) throws Exception
    {
        LOGGER.debug( "findByArrangementName : START" );
        Boolean isArrangemntNameValid = false;
        PaymentArrangement paymentArrangementName = paymentArrangementRepository.findByArrangementName( arrangementName );
        if( ObjectUtils.isEmpty( paymentArrangementName ) )
        {
            isArrangemntNameValid = true;
        }
        LOGGER.debug( "findByArrangementName : END" );
        return isArrangemntNameValid;
    }

    /**
     * Method: validateArrangementPayee
     * @param validateArrangementPayeeRequest
     * @return
     * @throws Exception
     */
    public ValidateArrangementPayeeResponse validateArrangementPayee( ValidateArrangementPayeeRequest validateArrangementPayeeRequest )
            throws Exception
    {
        LOGGER.debug( "validateArrangementPayee : START" );

        ValidateArrangementPayeeResponse validateArrangementPayeeResponse = new ValidateArrangementPayeeResponse();

        ReturnMessageDTO returnMessage = new ReturnMessageDTO( ComponentIdConstant.PMAM );

        paymentArrangementValidator.validateArrangementPayeeDates( validateArrangementPayeeRequest,
                                                                   returnMessage );

        validateArrangementPayeeResponse.setMessage( returnMessage.getStatus() );

        LOGGER.debug( "validateArrangementPayee : END" );

        return validateArrangementPayeeResponse;

    }

    /**
     * Method: getCalculationRequestPaymentArrangements
     * @param calculationRequestSaveRequest
     * @return
     */

    @Transactional( propagation = Propagation.SUPPORTS )
    public CalculationRequestPaymentArrangementResponse getCalculationRequestPaymentArrangements(
            CalculationRequestSaveRequest calculationRequestSaveRequest )
    {
        LOGGER.debug( "getCalculationRequestPaymentArrangements : START" );
        CalculationRequestPaymentArrangementResponse calculationRequestPaymentArrangementResponse =
            new CalculationRequestPaymentArrangementResponse();
        List<CalculationArrangementsDTO> allCalculationRequestPaymentArrangementsDTOs = new ArrayList<CalculationArrangementsDTO>();

        calculationRequestSaveRequest.getCalculationRequestDTO()
                .getCalculationRequestGroupingDTOs()
                .forEach( ( calculationGroupingsDTOs ) -> {
                    List<PaymentArrangement> paymentArrangements = paymentArrangementRepository
                            .findByCorporateEntityCodeAndLineOfBusinessCode( calculationGroupingsDTOs.getCorporateEntityCode(),
                                                                             calculationGroupingsDTOs
                                                                                     .getCalculationGroupingLevelValueText() );

                    List<CalculationArrangementsDTO> calculationRequestPaymentArrangementsDTOs =
                        paymentArrangementMapper.toRunPaymentArrangmentDTOs( paymentArrangements );
                    calculationRequestPaymentArrangementsDTOs.forEach( ( calculationArrangementsDTO ) -> {
                        calculationArrangementsDTO
                                .setLineOfBusinessCode( calculationGroupingsDTOs.getCalculationGroupingLevelValueText() );
                        calculationArrangementsDTO
                                .setCreateUserId( calculationRequestSaveRequest.getCalculationRequestDTO().getCreateUserId() );
                        calculationArrangementsDTO
                                .setRowAction( calculationRequestSaveRequest.getCalculationRequestDTO().getRowAction() );
                        calculationArrangementsDTO.setUpdateRecordTimestamp( calculationRequestSaveRequest.getCalculationRequestDTO()
                                .getUpdateRecordTimestamp() );
                        calculationArrangementsDTO
                                .setUpdateUserId( calculationRequestSaveRequest.getCalculationRequestDTO().getUpdateUserId() );
                        calculationArrangementsDTO.setCalculationRequestId( calculationRequestSaveRequest.getCalculationRequestDTO()
                                .getCalculationRequestId() );

                    } );
                    allCalculationRequestPaymentArrangementsDTOs.addAll( calculationRequestPaymentArrangementsDTOs );
                } );

        calculationRequestPaymentArrangementResponse.setCalculationArrangementsDTOs( allCalculationRequestPaymentArrangementsDTOs );
        LOGGER.debug( "getCalculationRequestPaymentArrangements : END" );
        return calculationRequestPaymentArrangementResponse;
    }

    /**
     * Find by corp id and pin group id.
     *@method searchVbrPayee
     * @param payeeSearchRequest the payee search request, search Payee in PaymentArrangement Configuration
     * @return the list
     * @throws Exception the exception
     */
    public List<PayeeRetrieveResponse> searchVbrPayee( PayeeSearchRequest payeeSearchRequest ) throws Exception
    {
        LOGGER.debug( "searchVbrPayee : START" );

        List<PayeeSearchRequest> searchRequestList = new ArrayList<PayeeSearchRequest>();

        String corporateEntityCode = payeeSearchRequest.getCorpEntityCode();
        String pinGroupId = payeeSearchRequest.getPinGroupId();

        List<VbrPayee> vbrPayeeRecord = new ArrayList<VbrPayee>();
        List<PayeeRetrieveResponse> providerResponse = new ArrayList<PayeeRetrieveResponse>();

        ReturnMessageDTO returnMessage = new ReturnMessageDTO( ComponentIdConstant.PMAM );

        payeeValidator.validateSearch( payeeSearchRequest,
                                       returnMessage );

        vbrPayeeRecord = vbrPayeeRepository.findByPinGroupId( corporateEntityCode,
                                                              pinGroupId );

        boolean isPayeeValid = paymentArrangementValidator.validateRetrievePayee( vbrPayeeRecord,
                                                                                  returnMessage );

        if( isPayeeValid )
        {
            searchRequestList.add( payeeSearchRequest );

            ProviderAPIRequest providerAPIRequest = createProviderAPIRequest( searchRequestList );

            //calls the main PPW API to get all the provider details based on pinGroupId and CorpEntityCode
            ProviderAPIResponse providerresponse = providerServiceApiClient.getProviders( providerAPIRequest );
            LOGGER.debug( "searchVbrPayee : providerresponse" + providerresponse );
            List<ProviderAPIResponseDTO> providerAPIResponseDTOs = providerresponse.getProviders();
            //            boolean isAPIResponseNotNull = paymentArrangementValidator.validateProviderAPIProviderResponse( providerAPIResponseDTOs,
            //                                                                                                            returnMessage );
            //            if( isAPIResponseNotNull )
            //            {
            for( VbrPayee payee : vbrPayeeRecord )
            {
                PayeeRetrieveResponse searchresponse = new PayeeRetrieveResponse();

                ProviderAPIResponseDTO aResponseDTO =
                    ArrangementConfigServiceUtils.getMatchingProviderFromAPI( vbrPayeeMapper.toVbrPayeeDTO( payee ),
                                                                              providerAPIResponseDTOs );

                if( !ObjectUtils.isEmpty( aResponseDTO ) )
                {
                    VbrPayeeDTO payeedetails = vbrPayeeMapper.toVbrPayeeDTO( payee );
                    searchresponse.setVbrPayee( updateDateFormat( vbrPayeeMapper.toVbrPayeeDTO( aResponseDTO,
                                                                                                payeedetails ) ) );
                    providerResponse.add( searchresponse );
                }
            }
        }
        //        }

        LOGGER.debug( "searchVbrPayee providerResponse" + providerResponse );
        paymentArrangementValidator.validateMatchingPremierProviderResponse( providerResponse,
                                                                             returnMessage );
        LOGGER.debug( "searchVbrPayee : END" );

        return providerResponse;
    }

    /**
     * sets arrangement success message based on the validation status
     * @param errorList
     * @param paymentArrangementSaveResponse
     * @param validationStatusCode
     */
    public void setArrangementSuccessMessage( ReturnMessageDTO returnMessage,
            PaymentArrangementSaveResponse paymentArrangementSaveResponse,
            String validationStatusCode )
    {
        LOGGER.debug( "setArrangementSuccessMessage : START" );
        if( ObjectUtils.isEmpty( returnMessage.getWarnings() ) )
        {
            if( StringUtils.equalsAnyIgnoreCase( validationStatusCode,
                                                 ArrangementConfigServiceConstant.ARRANGEMENT_STATUS_VALID ) )
            {
                paymentArrangementSaveResponse.setMessage( ArrangementConfigServiceConstant.PAYMENT_ARRANGEMENT_MESSAGE_VALID );
            }
            else if( StringUtils.equalsAnyIgnoreCase( validationStatusCode,
                                                      ArrangementConfigServiceConstant.ARRANGEMENT_STATUS_FUTURE_VALID ) )
            {
                paymentArrangementSaveResponse.setMessage( ArrangementConfigServiceConstant.PAYMENT_ARRANGEMENT_MESSAGE_FUTURE_VALID );
            }
            else
            {
                paymentArrangementSaveResponse.setMessage( ArrangementConfigServiceConstant.PAYMENT_ARRANGEMENT_SUCCESS );
            }
        }
        else
        {
            if( StringUtils.equalsAnyIgnoreCase( validationStatusCode,
                                                 ArrangementConfigServiceConstant.ARRANGEMENT_STATUS_DRAFT ) )
            {
                paymentArrangementSaveResponse.setMessage( ArrangementConfigServiceConstant.PAYMENT_ARRANGEMENT_MESSAGE_DRAFT );
            }
            if( StringUtils.equalsAnyIgnoreCase( validationStatusCode,
                                                 ArrangementConfigServiceConstant.ARRANGEMENT_STATUS_EXPIRED ) )
            {
                paymentArrangementSaveResponse.setMessage( ArrangementConfigServiceConstant.PAYMENT_ARRANGEMENT_MESSAGE_EXPIRED );
            }
            if( StringUtils.equalsAnyIgnoreCase( validationStatusCode,
                                                 ArrangementConfigServiceConstant.ARRANGEMENT_STATUS_INVALID ) )
            {
                paymentArrangementSaveResponse.setMessage( ArrangementConfigServiceConstant.PAYMENT_ARRANGEMENT_MESSAGE_INVALID );
            }
            if( StringUtils.equalsAnyIgnoreCase( validationStatusCode,
                                                 ArrangementConfigServiceConstant.ARRANGEMENT_STATUS_FUTURE_INVALID ) )
            {
                paymentArrangementSaveResponse
                        .setMessage( ArrangementConfigServiceConstant.PAYMENT_ARRANGEMENT_MESSAGE_FUTURE_INVALID );
            }
            if( StringUtils.equalsAnyIgnoreCase( validationStatusCode,
                                                 ArrangementConfigServiceConstant.ARRANGEMENT_STATUS_WARNING ) )
            {
                paymentArrangementSaveResponse.setMessage( ArrangementConfigServiceConstant.PAYMENT_ARRANGEMENT_MESSAGE_WARNING );
            }
        }
        LOGGER.debug( "setArrangementSuccessMessage : END" );
    }
}
