package com.hcsc.vbr.arrangementconfigservice.validator.paymentarrangement;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.util.ObjectUtils;

import com.hcsc.vbr.arrangementconfigservice.constant.ArrangementConfigServiceErrorMessageConstant;
import com.hcsc.vbr.arrangementconfigservice.constant.ComponentIdConstant;
import com.hcsc.vbr.arrangementconfigservice.constant.FieldIdConstant;
import com.hcsc.vbr.arrangementconfigservice.domain.PaymentArrangement;
import com.hcsc.vbr.arrangementconfigservice.validator.base.BaseValidationUnit;
import com.hcsc.vbr.common.dto.ReturnMessageDTO;

@Component
public class PMAM021CheckPaymentArrangementRate extends BaseValidationUnit
{
    final Logger LOGGER = LoggerFactory.getLogger( PMAM021CheckPaymentArrangementRate.class );

    public boolean validatePaymentArrangementRate( PaymentArrangement paymentArrangement,
            ReturnMessageDTO returnMessage ) throws Exception
    {
        LOGGER.debug( "validatePaymentArrangementRate : START" );

        boolean isArrangementRateValid = false;
        if( ObjectUtils.isEmpty( paymentArrangement.getPaymentArrangementRates() ) )
        {
            addToReturnMessage( ArrangementConfigServiceErrorMessageConstant.NO_ARRANGEMENT_RATE_SELECTED,
                                FieldIdConstant.PMAM_RATE,
                                ComponentIdConstant.PMAM,
                                this.getClass().getSimpleName(),
                                returnMessage );
            isArrangementRateValid = true;
        }
        LOGGER.debug( "PaymentArrangementRate Empty:" + isArrangementRateValid );
        LOGGER.debug( "validatePaymentArrangementRate : END" );

        return isArrangementRateValid;
    }

}
