package com.hcsc.vbr.arrangementconfigservice.validator.ratename;

import java.util.List;

import org.apache.commons.collections4.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.hcsc.vbr.arrangementconfigservice.constant.ArrangementConfigServiceErrorMessageConstant;
import com.hcsc.vbr.arrangementconfigservice.constant.ComponentIdConstant;
import com.hcsc.vbr.arrangementconfigservice.constant.FieldIdConstant;
import com.hcsc.vbr.arrangementconfigservice.domain.FlatRate;
import com.hcsc.vbr.arrangementconfigservice.validator.base.BaseValidationUnit;
import com.hcsc.vbr.common.dto.ReturnMessageDTO;

@Component
public class RTNM012CheckNoRecordsFoundForFlatRates extends BaseValidationUnit
{

    private static final Logger LOGGER = LoggerFactory.getLogger( RTNM012CheckNoRecordsFoundForFlatRates.class );

    /**
     * Method: isRecordsFound
     * @param flatRates
     * @param returnMessage
     * @return
     * @throws Exception
     */
    public boolean isRecordsFound( List<FlatRate> flatRates,
            ReturnMessageDTO returnMessage ) throws Exception
    {

        LOGGER.debug( "RTNM012CheckNoRecordsFoundForFlatRates : START" );

        boolean isRecordsFound = true;

        if( CollectionUtils.isEmpty( flatRates ) )
        {
            //Set return flag to false
            isRecordsFound = false;
            //Add Error/Warning to ReturnMessage
            addToReturnMessage( ArrangementConfigServiceErrorMessageConstant.NO_RATE_RECORDS_FOUND,
                                FieldIdConstant.NO_RECORDS,
                                ComponentIdConstant.RTNM,
                                this.getClass().getSimpleName(),
                                returnMessage );
        }

        LOGGER.debug( "RTNM012CheckNoRecordsFoundForFlatRates : END" );

        return isRecordsFound;

    }

}
