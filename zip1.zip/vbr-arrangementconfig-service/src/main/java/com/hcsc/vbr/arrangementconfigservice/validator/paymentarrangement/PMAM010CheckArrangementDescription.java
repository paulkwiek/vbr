package com.hcsc.vbr.arrangementconfigservice.validator.paymentarrangement;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.hcsc.vbr.arrangementconfigservice.constant.ArrangementConfigServiceErrorMessageConstant;
import com.hcsc.vbr.arrangementconfigservice.constant.ComponentIdConstant;
import com.hcsc.vbr.arrangementconfigservice.constant.FieldIdConstant;
import com.hcsc.vbr.arrangementconfigservice.domain.PaymentArrangement;
import com.hcsc.vbr.arrangementconfigservice.validator.base.BaseValidationUnit;
import com.hcsc.vbr.common.dto.ReturnMessageDTO;

@Component
public class PMAM010CheckArrangementDescription extends BaseValidationUnit
{
    final Logger LOGGER = LoggerFactory.getLogger( PMAM009CheckArrangementName.class );

    /**
     * Method: validateArrangementDescription
     * @param paymentArrangementRequest
     * @param returnMessage
     * @return
     * @throws Exception
     */
    public boolean validateArrangementDescription( PaymentArrangement paymentArrangementRequest,
            ReturnMessageDTO returnMessage ) throws Exception
    {
        LOGGER.debug( "validateArrangementDescription : START" );

        boolean isArrangementDescriptionValid = true;
        String paymentArrangementDescription = paymentArrangementRequest.getPaymentArrangementDescription();
        if( !StringUtils.isBlank( paymentArrangementDescription ) )
        {
            if( paymentArrangementDescription.length() > 500 )
            {
                addToReturnMessage( ArrangementConfigServiceErrorMessageConstant.ARRANGEMENT_DESCRIPTION_LENGTH_VALIDATION,
                                    FieldIdConstant.PMAM_DESC,
                                    ComponentIdConstant.PMAM,
                                    this.getClass().getSimpleName(),
                                    returnMessage );
                isArrangementDescriptionValid = false;
            }
        }
        else
        {
            addToReturnMessage( ArrangementConfigServiceErrorMessageConstant.ARRANGEMENT_DESCRIPTION_VALIDATION,
                                FieldIdConstant.PMAM_DESC,
                                ComponentIdConstant.PMAM,
                                this.getClass().getSimpleName(),
                                returnMessage );
            isArrangementDescriptionValid = false;
        }
        LOGGER.debug( "PaymentArrangementDescription is Valid" + isArrangementDescriptionValid );
        LOGGER.debug( "validateArrangementDescription : END" );
        return isArrangementDescriptionValid;
    }

}
