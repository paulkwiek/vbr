package com.hcsc.vbr.arrangementconfigservice.repository;

import java.time.LocalDateTime;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.hcsc.vbr.arrangementconfigservice.domain.VbrPayee;

@Repository
public interface VbrPayeeRepository extends JpaRepository<VbrPayee, Integer>
{
    public static final Logger LOGGER = LoggerFactory.getLogger( VbrPayeeRepository.class );

    /**
     * retrieving list of payees by corporateEntityCode and pinGroupId
     * Method : findByCorpIdAndPinGroupId
     * @param corporateEntityCode
     * @param pinGroupId
     * @return
     */
    @Query( " SELECT  vbrPayee "
        + "     FROM  VbrPayee vbrPayee "
        + "    WHERE  UPPER( vbrPayee.corporateEntityCode ) = UPPER( :corporateEntityCode ) "
        + "      AND  UPPER( vbrPayee.pinGroupId )          LIKE CONCAT('%', UPPER( :pinGroupId ), '%') "
        + " ORDER BY  vbrPayee.pinGroupName" )
    public List<VbrPayee> findByCorpIdAndPinGroupId( @Param( "corporateEntityCode" ) String corporateEntityCode,
            @Param( "pinGroupId" ) String pinGroupId );

    /**
     * Get List of payees by corporateEntityCode
     * Method: findByCorpId
     * @param corporateEntityCode
     * @return
     */
    @Query( " SELECT  vbrPayee "
        + "     FROM  VbrPayee vbrPayee "
        + "    WHERE  UPPER( vbrPayee.corporateEntityCode ) = UPPER( :corporateEntityCode ) "
        + " ORDER BY  vbrPayee.pinGroupName" )
    public List<VbrPayee> findByCorpId( @Param( "corporateEntityCode" ) String corporateEntityCode );

    /**
     * To find the unique payee
     * Method: findUniquePayee
     * @param payee
     * @return
     */
    @Query( " SELECT  vbrPayee "
        + "     FROM  VbrPayee vbrPayee "
        + "    WHERE  UPPER( vbrPayee.corporateEntityCode )    = UPPER( :#{#payee.corporateEntityCode} ) "
        + "      AND  UPPER( vbrPayee.pinGroupId )             = UPPER( :#{#payee.pinGroupId} ) "
        + "      AND  UPPER( vbrPayee.pinGroupName )           = UPPER( :#{#payee.pinGroupName} ) "
        + "      AND  UPPER( vbrPayee.networkAssocProviderId ) = UPPER( :#{#payee.networkAssocProviderId} ) "
        + "      AND  UPPER( vbrPayee.networkCode )            = UPPER( :#{#payee.networkCode} ) "
        + "      AND  UPPER( vbrPayee.payToPfinId )            = UPPER( :#{#payee.payToPfinId} ) "
        + "      AND  UPPER( vbrPayee.capitationCode )         = UPPER( :#{#payee.capitationCode} ) "
        + "      AND  UPPER( vbrPayee.capitationProcessCode )  = UPPER( :#{#payee.capitationProcessCode} )"
        + "      AND  UPPER( vbrPayee.taxIdNumber )            = UPPER( :#{#payee.taxIdNumber} )" )
    public List<VbrPayee> findUniquePayee( @Param( "payee" ) VbrPayee payee );

    /**
     * Method: findByPinGroupId will be called in search Payee in Payment Arrangement Flow
     * @param corporateEntityCode
     * @param pinGroupId
     * @return
     */
    @Query( " SELECT  vbrPayee "
        + "     FROM  VbrPayee vbrPayee "
        + "    WHERE  UPPER( vbrPayee.corporateEntityCode ) = UPPER( :corporateEntityCode ) "
        + "      AND  UPPER( vbrPayee.pinGroupId )          = UPPER( :pinGroupId ) " )
    public List<VbrPayee> findByPinGroupId( @Param( "corporateEntityCode" ) String corporateEntityCode,
            @Param( "pinGroupId" ) String pinGroupId );

    /**
     * save/update/delete/NoAction for vbr payee
     * @param vbrPayee
     */
    default void saveVbrPaye( VbrPayee vbrPayee )
    {

        switch( vbrPayee.getRowAction() )
        {
            case INSERT:
            {

                LOGGER.debug( "INSERT PAYEE START" );

                vbrPayee.setCreateRecordTimestamp( LocalDateTime.now() );
                save( vbrPayee );

                LOGGER.debug( "INSERT PAYEE END" );
                break;
            }
            case UPDATE:
            {
                LOGGER.debug( "UPDATE PAYEE START" );

                save( vbrPayee );

                LOGGER.debug( "UPDATE PAYEE START" );
                break;
            }
            case DELETE:
            {
                LOGGER.debug( "DELETE PAYEE START" );

                delete( vbrPayee );

                LOGGER.debug( "DELETE PAYEE END" );
                break;
            }
            default:
                break;

        }

    }
}
