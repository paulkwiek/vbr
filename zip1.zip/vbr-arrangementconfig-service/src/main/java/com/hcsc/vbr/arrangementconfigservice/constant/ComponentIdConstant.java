package com.hcsc.vbr.arrangementconfigservice.constant;

public class ComponentIdConstant
{

    //PaymentArrangement
    public static final String PMAM = "paymentArrangement";

    //RateName
    public static final String RTNM = "rateName";

    //Vbrpayee
    public static final String VBPY = "vbrPayee";

    //PaymentArrangementRate
    public static final String PMAR = "paymentArrangementRate";

    //PaymentArrangementPayee
    public static final String PMPY = "paymentArrangementPayee";
    
}
