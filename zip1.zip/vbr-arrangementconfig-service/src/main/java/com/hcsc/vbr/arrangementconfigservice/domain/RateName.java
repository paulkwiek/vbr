package com.hcsc.vbr.arrangementconfigservice.domain;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.apache.commons.lang3.builder.ReflectionToStringBuilder;

import com.hcsc.vbr.common.domain.BaseEntity;
import com.hcsc.vbr.common.utils.MultilineRecursiveToStringStyleCustom;

import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
@Table( name = "RT_NM" )
public class RateName extends BaseEntity
{
    private static final long serialVersionUID = 1L;

    @EmbeddedId
    private RateNameId rateNameId;

    @NotNull
    @Column( name = "RT_CONFIG_TYP_CD", length = 20 )
    private String rateConfigTypeName;

    @OneToMany( fetch = FetchType.LAZY, mappedBy = "parentRateName" )
    private List<FlatRate> flatRates = new ArrayList<FlatRate>();

    @OneToMany( fetch = FetchType.LAZY, mappedBy = "parentRateName" )
    private List<PaymentArrangementRate> paymentArrangementRates = new ArrayList<PaymentArrangementRate>();

    @Override
    public String toString()
    {
        return new ReflectionToStringBuilder( this,
                                              new MultilineRecursiveToStringStyleCustom() ).toString();
    }
}
