package com.hcsc.vbr.arrangementconfigservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.security.servlet.SecurityAutoConfiguration;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication( exclude = { SecurityAutoConfiguration.class } )
@ComponentScan( { "com.hcsc.vbr", "com.hcsc.claim.security" } )
public class VBRArrangementConfigserviceApplication
{

    /**
     * This is spring boots main method which takes no arguments.
     * 
     * Method: main method for spring boot
     * @param args - no args expected
     */
    public static void main( String[] args )
    {
        SpringApplication.run( VBRArrangementConfigserviceApplication.class,
                               args );
    }
}
