package com.hcsc.vbr.arrangementconfigservice.repository;

import java.time.LocalDateTime;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.hcsc.vbr.arrangementconfigservice.domain.RateName;
import com.hcsc.vbr.arrangementconfigservice.domain.RateNameId;
import com.hcsc.vbr.common.constant.VBRCommonConstant.RowActionTypes;

@Repository
public interface RateNameRepository extends JpaRepository<RateName, RateNameId>
{
    public static final Logger LOGGER = LoggerFactory.getLogger( RateNameRepository.class );

    /**
     * This method retrieves RatreName by CorporateEntityCode and RateName
     * Method: findByID
     * @param corporateEntityCode
     * @param rateName
     * @return
     */
    @Query( " SELECT  rateName "
        + "     FROM  RateName rateName "
        + "    WHERE rateName.rateNameId.corporateEntityCode  =  :corporateEntityCode "
        + "      AND rateName.rateNameId.rateName             =  :rateName " )
    public RateName findByID( @Param( "corporateEntityCode" ) String corporateEntityCode,
            @Param( "rateName" ) String rateName );

    /**
     * This method retrieves RatreName by RateName
     * Method: findByRateName
     * @param rateName
     * @return
     */
    @Query( " SELECT  rateName "
        + "     FROM  RateName rateName "
        + "    WHERE UPPER(rateName.rateNameId.rateName)     =  UPPER(:rateName) " )
    public RateName findByRateName( @Param( "rateName" ) String rateName );

    /**
     * This method retrieves List of RateName records 
     * Method: fetchRateNames
     * @return
     */
    @Query( " SELECT  rateName  "
        + "     FROM  RateName rateName "
        + "    WHERE rateName.rateNameId.corporateEntityCode  =  :corporateEntityCode "
        + " ORDER BY rateName.rateNameId.rateName " )
    public List<RateName> fetchRateNames( @Param( "corporateEntityCode" ) String corporateEntityCode );

    /**
     * This method updates RateName by UpdateRecordTimestamp, CorporateEntityCode and RateName
     * Method: updateRateName
     * @param updateRecordTimestamp
     * @param corporateEntityCode
     * @param rateName
     * @return
     */
    @Modifying( flushAutomatically = true, clearAutomatically = true )
    @Transactional
    @Query( " UPDATE RateName rateName "
        + "      SET rateName.updateRecordTimestamp            =  :updateRecordTimestamp "
        + "    WHERE rateName.rateNameId.corporateEntityCode   =  :corporateEntityCode "
        + "      AND rateName.rateNameId.rateName              =  :rateName" )
    public Integer updateRateName( @Param( "updateRecordTimestamp" ) LocalDateTime updateRecordTimestamp,
            @Param( "corporateEntityCode" ) String corporateEntityCode,
            @Param( "rateName" ) String rateName );

    /**
     * save/update/delete/NoAction for Rate
     * 
     * @param rateName
     */
    default void saveRate( RateName rateName )
    {

        RowActionTypes rowAction = RowActionTypes.valueOf( rateName.getRowAction().name() );
        switch( rowAction )
        {
            case INSERT:
            {
                LOGGER.debug( "INSERT RATENAME START" );

                rateName.setCreateRecordTimestamp( LocalDateTime.now() );
                save( rateName );

                LOGGER.debug( "INSERT RATENAME END" );
                break;
            }
            case UPDATE:
            case NO_ACTION:
            {
                // Fetch the updated user Id and check if it same user or different user.
                RateName rateNameUpdateUserFetch = findByID( rateName.getRateNameId().getCorporateEntityCode(),
                                                             rateName.getRateNameId().getRateName() );

                // If the above fetched user is same as the requested user then call the
                // updateRateName method since Save method cannot be used as @Version is used in
                // UpdatedTimeStamp field for Optimistic locking.

                // If the above fetched user is different then save method can be used. This
                // will also update the current UpdatedTimeStamp for RateName
                if( StringUtils.equalsIgnoreCase( rateName.getUpdateUserId(),
                                                  rateNameUpdateUserFetch.getUpdateUserId() ) )
                {
                    LOGGER.debug( "UPDATE RATENAME START" );

                    rateName.setUpdateRecordTimestamp( LocalDateTime.now() );
                    updateRateName( rateName.getUpdateRecordTimestamp(),
                                    rateName.getRateNameId().getCorporateEntityCode(),
                                    rateName.getRateNameId().getRateName() );

                    LOGGER.debug( "UPDATE RATENAME END" );
                }
                else
                {
                    save( rateName );
                }
                break;

            }
            case DELETE:
            {
                LOGGER.debug( "DELETE RATENAME START" );

                delete( rateName );

                LOGGER.debug( "DELETE RATENAME END" );
                break;
            }
            default:
                break;
        }
    }
}