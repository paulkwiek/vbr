package com.hcsc.vbr.arrangementconfigservice.validator.paymentarrangement;

import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.hcsc.vbr.arrangementconfigservice.constant.ArrangementConfigServiceConstant;
import com.hcsc.vbr.arrangementconfigservice.constant.ArrangementConfigServiceErrorMessageConstant;
import com.hcsc.vbr.arrangementconfigservice.constant.ComponentIdConstant;
import com.hcsc.vbr.arrangementconfigservice.constant.FieldIdConstant;
import com.hcsc.vbr.arrangementconfigservice.domain.PaymentArrangement;
import com.hcsc.vbr.arrangementconfigservice.domain.PaymentArrangementMemberSubject;
import com.hcsc.vbr.arrangementconfigservice.validator.base.BaseValidationUnit;
import com.hcsc.vbr.common.constant.VBRCommonConstant.RowActionTypes;
import com.hcsc.vbr.common.dto.ReturnMessageDTO;

@Component
public class PMAM027CheckArrangementMemberSubject extends BaseValidationUnit
{
    final Logger LOGGER = LoggerFactory.getLogger( PMAM027CheckArrangementMemberSubject.class );

    /**
     * Method: checkArrangementMemberSubject
     * @param paymentArrangementSaveRequest
     * @param returnMessage
     * @return
     * @throws Exception
     */
    public boolean checkArrangementMemberSubject( PaymentArrangement paymentArrangementSaveRequest,
            ReturnMessageDTO returnMessage ) throws Exception
    {
        LOGGER.debug( "checkArrangementMemberSubject : START" );
        boolean isMemberSubjectChanged = false;

        if( ObjectUtils.anyNotNull( paymentArrangementSaveRequest.getPaymentArrangementId() )
            && !StringUtils.equalsIgnoreCase( paymentArrangementSaveRequest.getValidationStatusCode(),
                                              ArrangementConfigServiceConstant.ARRANGEMENT_STATUS_DRAFT ) )
        {

            for( PaymentArrangementMemberSubject membersubject : paymentArrangementSaveRequest.getPaymentArrangementMemberSubjects() )
            {
                if( ObjectUtils.notEqual( membersubject.getRowAction(),
                                          RowActionTypes.NO_ACTION ) )

                {
                    addToReturnMessage( ArrangementConfigServiceErrorMessageConstant.ARRANGEMENT_MEMBER_SUBJECT_INVALID,
                                        FieldIdConstant.PMAM_MBR_SBJCT,
                                        ComponentIdConstant.PMAM,
                                        this.getClass().getSimpleName(),
                                        returnMessage );
                    isMemberSubjectChanged = true;
                }
            }
        }
        LOGGER.debug( "isMemberSubjectChanged  : " + isMemberSubjectChanged );
        LOGGER.debug( "checkArrangementMemberSubject : END" );

        return isMemberSubjectChanged;

    }
}
