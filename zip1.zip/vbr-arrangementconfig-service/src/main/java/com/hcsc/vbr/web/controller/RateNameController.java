package com.hcsc.vbr.web.controller;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hcsc.vbr.arrangementconfigservice.service.RateNameService;
import com.hcsc.vbr.web.controller.base.BaseController;
import com.hcsc.vbr.web.request.RateSaveRequest;
import com.hcsc.vbr.web.response.PaymentArrangementListResponse;
import com.hcsc.vbr.web.response.RateNameResponse;
import com.hcsc.vbr.web.response.RateSaveResponse;

/**
 * @author U398414
 *
 */
@RestController
@RequestMapping( "/rates" )
public class RateNameController extends BaseController
{

    private static final Logger LOGGER = LoggerFactory.getLogger( RateNameController.class );

    @Autowired
    private RateNameService rateNameService;

    /**
     * save/update Rate details
     * @param rateSaveRequest
     * @return
     * @throws Exception
     */
    @PreAuthorize( "hasAnyRole('ROLE_UPDATE_NM','ROLE_CALC_APPROVAL_NM')" )
    @PostMapping( "/saveRate" )
    public ResponseEntity<RateSaveResponse> saveRate( @RequestBody RateSaveRequest rateSaveRequest ) throws Exception
    {

        LOGGER.debug( "saveRate in controller start" );
        RateSaveResponse rateSaveResponse = rateNameService.saveRate( rateSaveRequest );

        LOGGER.debug( "saveRate in controller End" );
        return new ResponseEntity<RateSaveResponse>( rateSaveResponse,
                                                     HttpStatus.OK );
    }

    /**
     * fetch all the rate names
     * @return
     * @throws Exception
     */
    @GetMapping( "/retrieveRates/{corporateEntityCode}" )
    public ResponseEntity<RateNameResponse> getRateNames( @PathVariable String corporateEntityCode ) throws Exception
    {
        LOGGER.debug( "getRateNames in controller start" );
        RateNameResponse rateNameResponse = rateNameService.getRateNames( corporateEntityCode );

        LOGGER.debug( "getRateNames in controller end" );
        return new ResponseEntity<RateNameResponse>( rateNameResponse,
                                                     HttpStatus.OK );
    }

    /**
     * fetch the rate details by Rate name
     * @param rateName
     * @return
     * @throws Exception
     */
    @GetMapping( "/retrieveRate/{rateName}" )
    public ResponseEntity<RateSaveResponse> getRateNameById( @PathVariable String rateName ) throws Exception
    {
        LOGGER.debug( "getRateNameById in controller start" );
        RateSaveResponse rateSaveResponse = rateNameService.getRateByRateId( rateName );

        LOGGER.debug( "getRateNameById in controller end" );
        return new ResponseEntity<RateSaveResponse>( rateSaveResponse,
                                                     HttpStatus.OK );
    }

    /**
     * validate rate name
     * @param rateName
     * @throws Exception
     */
    @GetMapping( "/validateRateName/{rateName}" )
    public void validateRateName( @PathVariable String rateName ) throws Exception
    {
        LOGGER.debug( "validateRateName in controller start" );
        rateNameService.validateRateName( rateName );

        LOGGER.debug( "validateRateName in controller end" );
    }

    @GetMapping( "/getLinkedArrangements/{rateName}" )
    public ResponseEntity<List<PaymentArrangementListResponse>> getLinkedArrangements( @PathVariable String rateName ) throws Exception
    {

        LOGGER.debug( "getLinkedArrangements in controller Start" );
        List<PaymentArrangementListResponse> linkedArrangementsResponse = new ArrayList<PaymentArrangementListResponse>();
        linkedArrangementsResponse = rateNameService.getLinkedArrangements( rateName );

        LOGGER.debug( "getLinkedArrangements in controller end" );
        return new ResponseEntity<List<PaymentArrangementListResponse>>( linkedArrangementsResponse,
                                                                         HttpStatus.OK );

    }
}
