package com.hcsc.vbr.arrangementconfigservice.validator.paymentarrangementrate;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.util.ObjectUtils;

import com.hcsc.vbr.arrangementconfigservice.constant.ArrangementConfigServiceErrorMessageConstant;
import com.hcsc.vbr.arrangementconfigservice.constant.ComponentIdConstant;
import com.hcsc.vbr.arrangementconfigservice.constant.FieldIdConstant;
import com.hcsc.vbr.arrangementconfigservice.domain.FlatRate;
import com.hcsc.vbr.arrangementconfigservice.domain.PaymentArrangementRate;
import com.hcsc.vbr.arrangementconfigservice.utils.PaymentArrangementRateUtils;
import com.hcsc.vbr.arrangementconfigservice.validator.base.BaseValidationUnit;
import com.hcsc.vbr.common.domain.DateRecord;
import com.hcsc.vbr.common.dto.ReturnMessageDTO;
import com.hcsc.vbr.common.utils.VBRDateUtils;

@Component
public class PMRT002CheckCoverageForGlobalRateVsArrangementRate extends BaseValidationUnit
{
    private static final Logger LOGGER = LoggerFactory.getLogger( PMRT002CheckCoverageForGlobalRateVsArrangementRate.class );

    /**
     * This method will check Arrangement Rate Date Falls within VBR Rate Date without any Gap.
     * Method: CheckCoverageForGlobalRateVsArrangementRate
     * @param paymentArrangementRates
     * @param flatRates
     * @param returnMessage
     * @return isArrangementRateCovered
     * @throws Exception
     */
    public boolean CheckCoverageForGlobalRateVsArrangementRate( List<PaymentArrangementRate> paymentArrangementRates,
            List<FlatRate> flatRates,
            ReturnMessageDTO returnMessage ) throws Exception
    {
        LOGGER.debug( "CheckCoverageForGlobalRateVsArrangementRate : START" );
        boolean isArrangementRateCovered = true;
        boolean isCoveredWithSingleRange = false;
        for( FlatRate flatRate : flatRates )
        {
            if( VBRDateUtils.checkDateCoverage( flatRate,
                                                paymentArrangementRates ) )
            {
                isCoveredWithSingleRange = true;
            }
        }

        if( !isCoveredWithSingleRange )
        {
            List<DateRecord> flatRateDateRecordListInArrangeMentDuration = new ArrayList<DateRecord>();
            for( PaymentArrangementRate arrangementRate : paymentArrangementRates )
            {
                flatRateDateRecordListInArrangeMentDuration =
                    PaymentArrangementRateUtils.getFlatRatesOfArrRateDuration( VBRDateUtils.removeVoidDates( flatRates ),
                                                                               arrangementRate );
            }
            /**
             * Retrieving Records minimum of effective Date and max of End Date
             */
            DateRecord flatRateRangeForArrRate = null;
            if( !CollectionUtils.isEmpty( flatRateDateRecordListInArrangeMentDuration ) )
            {

                flatRateRangeForArrRate =
                    VBRDateUtils.convertDateRecordListToDateRecordRange( flatRateDateRecordListInArrangeMentDuration );
            }

            flatRateDateRecordListInArrangeMentDuration.sort( Comparator.comparing( DateRecord::getRecordEffectiveDate ) );
            /**
             * Check any gap between Flat rates for given duration 
             * between Arrangement Rate Effective and End Date
             */
            if( ( !ObjectUtils.isEmpty( flatRateRangeForArrRate ) && !VBRDateUtils.checkDateCoverage( flatRateRangeForArrRate,
                                                                                                      paymentArrangementRates ) )
                || !VBRDateUtils.checkForNoGaps( flatRateDateRecordListInArrangeMentDuration ) )
            {
                isArrangementRateCovered = false;
                addToReturnMessage( ArrangementConfigServiceErrorMessageConstant.GAP_IN_ARRANGEMENT_RATE_EFF_END_DATES_ERR,
                                    FieldIdConstant.PMAR_EFF_AND_END_DATE,
                                    ComponentIdConstant.PMAM,
                                    this.getClass().getSimpleName(),
                                    returnMessage );

            }

        }
        LOGGER.debug( "CheckCoverageForGlobalRateVsArrangementRate : END" );
        return isArrangementRateCovered;
    }
}
