package com.hcsc.vbr.arrangementconfigservice.validator.paymentarrangement;

import java.time.temporal.ChronoUnit;
import java.util.Collections;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.util.ObjectUtils;

import com.hcsc.vbr.common.domain.DateRecord;

@Component
public class PMAM028CheckGapInArrangementDates
{
    private static final Logger LOGGER = LoggerFactory.getLogger( PMAM028CheckGapInArrangementDates.class );

    /**
     * Method: checkForNoArrangmentGaps
     * @param dateRecords
     * @param arrangementDate
     * @return
     * @throws Exception
     */
    public boolean checkForNoArrangementGaps( List<? extends DateRecord> dateRecords,
            DateRecord arrangementDate ) throws Exception
    {
        LOGGER.debug( "checkForNoArrangementGaps  : START" );

        boolean isDateValid = false;

        if( !dateRecords.isEmpty() && !ObjectUtils.isEmpty( arrangementDate ) )
        {
            Collections.sort( dateRecords );

            for( DateRecord dateRecord : dateRecords )
            {

                if( ( dateRecord.getRecordEffectiveDate() != null
                    && dateRecord.getRecordEndDate() != null
                    && arrangementDate.getRecordEffectiveDate() != null
                    && arrangementDate.getRecordEndDate() != null ) )
                {
                    long startDays = ChronoUnit.DAYS.between( arrangementDate.getRecordEffectiveDate(),
                                                              dateRecord.getRecordEffectiveDate() );
                    long endDays = ChronoUnit.DAYS.between( arrangementDate.getRecordEndDate(),
                                                            dateRecord.getRecordEndDate() );

                    LOGGER.debug( "Difference : " + startDays );
                    LOGGER.debug( "Difference : " + endDays );

                    if( ( startDays == 0 && endDays == 0 ) )
                    {
                        isDateValid = true;

                        LOGGER.debug( "No GAP : "
                            + dateRecord.getRecordEffectiveDate()
                            + " , "
                            + dateRecord.getRecordEndDate()
                            + " :: "
                            + arrangementDate.getRecordEffectiveDate()
                            + ","
                            + arrangementDate.getRecordEndDate() );
                        break;
                    }

                }
                else
                {
                    LOGGER.debug( "Effective/End dates and Arrangement Duration are NULL" );
                    isDateValid = false;
                    break;
                }
            }
        }
        else
        {
            LOGGER.debug( "DateRecord List and Arrangement Date record empty" );
            isDateValid = false;
        }

        LOGGER.debug( "Arrangment Covering One of  EffEnd Date : " + isDateValid );
        LOGGER.debug( "checkForNoArrangementGaps : END" );

        return isDateValid;
    }
}
