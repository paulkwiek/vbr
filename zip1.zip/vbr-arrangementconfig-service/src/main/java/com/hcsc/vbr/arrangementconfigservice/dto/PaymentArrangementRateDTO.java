package com.hcsc.vbr.arrangementconfigservice.dto;

import org.apache.commons.lang3.builder.ReflectionToStringBuilder;

import com.hcsc.vbr.common.dto.DateRecordDTO;
import com.hcsc.vbr.common.utils.MultilineRecursiveToStringStyleCustom;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PaymentArrangementRateDTO extends DateRecordDTO
{
    private static final long serialVersionUID = 1L;

    private Integer paymentArrangementRateId;

    private String rateName;

    private String corporateEntityCode;

    private String rateConfigTypeName;

    private Integer paymentArrangementId;

    @Override
    public String toString()
    {
        return new ReflectionToStringBuilder( this,
                                              new MultilineRecursiveToStringStyleCustom() ).toString();
    }
}
