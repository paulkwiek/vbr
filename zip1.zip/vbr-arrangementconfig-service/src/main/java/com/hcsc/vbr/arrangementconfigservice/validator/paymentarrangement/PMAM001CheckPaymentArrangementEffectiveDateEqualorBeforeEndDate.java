package com.hcsc.vbr.arrangementconfigservice.validator.paymentarrangement;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.hcsc.vbr.arrangementconfigservice.constant.ArrangementConfigServiceErrorMessageConstant;
import com.hcsc.vbr.arrangementconfigservice.constant.ComponentIdConstant;
import com.hcsc.vbr.arrangementconfigservice.constant.FieldIdConstant;
import com.hcsc.vbr.arrangementconfigservice.domain.PaymentArrangement;
import com.hcsc.vbr.arrangementconfigservice.validator.base.BaseValidationUnit;
import com.hcsc.vbr.common.dto.ReturnMessageDTO;
import com.hcsc.vbr.common.utils.VBRDateUtils;

@Component
public class PMAM001CheckPaymentArrangementEffectiveDateEqualorBeforeEndDate extends BaseValidationUnit
{
    final Logger LOGGER = LoggerFactory.getLogger( PMAM001CheckPaymentArrangementEffectiveDateEqualorBeforeEndDate.class );

    /**
     * Arrangement Duration Effective Date and End Date Validation 
     * Method: validatePaymentArrangementEffectiveAndEndDates
     * @param dateRecord
     * @param errors
     * @return true -  when effective date is after end date
     * @return false -  when effective date is equal or before end date
     * @throws Exception
     */
    public boolean validatePaymentArrangementEffectiveDateEqualBeforeEndDate( PaymentArrangement arrangementdateRecord,
            ReturnMessageDTO returnMessage ) throws Exception
    {
        LOGGER.debug( "validatePaymentArrangementEffectiveDateEqualBeforeEndDate : START" );

        boolean isDateValid = true;

        if( !VBRDateUtils.checkEffectiveAndEndDates( arrangementdateRecord ) )
        {
            addToReturnMessage( ArrangementConfigServiceErrorMessageConstant.ARRANGEMENT_EFF_END_DATE_VALIDATION,
                                FieldIdConstant.PMAM_EFF_AND_END_DATE,
                                ComponentIdConstant.PMAM,
                                this.getClass().getSimpleName(),
                                returnMessage );
            isDateValid = false;
        }

        LOGGER.debug( "Arrangement Duration Effective Date is  Before End Date" + isDateValid );
        LOGGER.debug( "validatePaymentArrangementEffectiveDateEqualBeforeEndDate : END" );
        return isDateValid;
    }

}