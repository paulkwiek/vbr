package com.hcsc.vbr.arrangementconfigservice.validator.payee;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.hcsc.vbr.arrangementconfigservice.constant.ArrangementConfigServiceErrorMessageConstant;
import com.hcsc.vbr.arrangementconfigservice.constant.ComponentIdConstant;
import com.hcsc.vbr.arrangementconfigservice.constant.FieldIdConstant;
import com.hcsc.vbr.arrangementconfigservice.domain.VbrPayee;
import com.hcsc.vbr.arrangementconfigservice.validator.base.BaseValidationUnit;
import com.hcsc.vbr.common.dto.ReturnMessageDTO;

@Component
public class VBPY009ValidateVbrPayeeTaxIdNumber extends BaseValidationUnit
{
    private static final Logger LOGGER = LoggerFactory.getLogger( VBPY009ValidateVbrPayeeTaxIdNumber.class );

    /**
     * @param vbrPayee
     * @param returnMessage
     * @return
     * @throws Exception
     */
    public boolean validateVbrPayeeTaxIdNumberFieldLength( VbrPayee vbrPayee,
            ReturnMessageDTO returnMessage ) throws Exception
    {
        LOGGER.debug( "VBPY009ValidateVbrPayeeTaxIdNumber : Start" );

        boolean isTaxIdNumberValid = true;

        String taxIdNumber = vbrPayee.getTaxIdNumber();

        if( ( StringUtils.isNotBlank( taxIdNumber ) )
            && ( ( !StringUtils.isAlphanumeric( taxIdNumber ) ) || ( taxIdNumber.length() > 9 ) ) )
        {
            isTaxIdNumberValid = false;
            addToReturnMessage( ArrangementConfigServiceErrorMessageConstant.TAX_ID_NUMBER_VALIDATION,
                                FieldIdConstant.VBPY_TAX_ID_NUMBER,
                                ComponentIdConstant.VBPY,
                                this.getClass().getSimpleName(),
                                returnMessage );

        }

        LOGGER.debug( "VBPY009ValidateVbrPayeeTaxIdNumber : END" );

        return isTaxIdNumberValid;
    }
}
