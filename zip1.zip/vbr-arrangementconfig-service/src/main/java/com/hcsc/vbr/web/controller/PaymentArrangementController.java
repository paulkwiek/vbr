package com.hcsc.vbr.web.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hcsc.vbr.arrangementconfigservice.service.PaymentArrangementRateService;
import com.hcsc.vbr.arrangementconfigservice.service.PaymentArrangementService;
import com.hcsc.vbr.web.controller.base.BaseController;
import com.hcsc.vbr.web.request.CalculationRequestSaveRequest;
import com.hcsc.vbr.web.request.PayeeSearchRequest;
import com.hcsc.vbr.web.request.PaymentArrangementSaveRequest;
import com.hcsc.vbr.web.request.ValidateArrangementPayeeRequest;
import com.hcsc.vbr.web.request.ValidateArrangementRateRequest;
import com.hcsc.vbr.web.response.CalculationRequestPaymentArrangementResponse;
import com.hcsc.vbr.web.response.PayeeRetrieveResponse;
import com.hcsc.vbr.web.response.PaymentArrangementListResponse;
import com.hcsc.vbr.web.response.PaymentArrangementResponse;
import com.hcsc.vbr.web.response.PaymentArrangementSaveResponse;
import com.hcsc.vbr.web.response.ValidateArrangementPayeeResponse;
import com.hcsc.vbr.web.response.ValidateArrangementRateResponse;

@RestController
@RequestMapping( "paymentarrangement" )
public class PaymentArrangementController extends BaseController
{
    @Autowired
    private PaymentArrangementService paymentArrangementService;

    @Autowired
    private PaymentArrangementRateService paymentArrangementRateService;

    final Logger LOGGER = LoggerFactory.getLogger( PaymentArrangementController.class );

    /**
     * final payment arrangement save
     * @param paymentArrangementSaveRequest
     * @return paymentArrangementSaveResponse
     * @throws Exception
     */
    @PreAuthorize( "hasAnyRole('ROLE_UPDATE_NM','ROLE_CALC_APPROVAL_NM')" )
    @PostMapping( "/saveArrangement" )
    public ResponseEntity<PaymentArrangementSaveResponse> saveArrangement(
            @RequestBody PaymentArrangementSaveRequest paymentArrangementSaveRequest ) throws Exception
    {
        LOGGER.debug( "saveArrangement in PaymentArrangementController start" );

        PaymentArrangementSaveResponse paymentArrangementSaveResponse =
            paymentArrangementService.savePaymentArrangement( paymentArrangementSaveRequest );

        LOGGER.debug( "saveArrangement in PaymentArrangementController End" );

        return new ResponseEntity<PaymentArrangementSaveResponse>( paymentArrangementSaveResponse,
                                                                   HttpStatus.OK );
    }

    /**
     * fetch all payment arrangements
     * @return paymentArrangementListResponses
     * @throws Exception
     */
    @GetMapping( "/getArrangements/{corporateEntityCode}" )
    public ResponseEntity<List<PaymentArrangementListResponse>> getArrangementsByCorporateEntityCode(
            @PathVariable String corporateEntityCode ) throws Exception
    {
        LOGGER.debug( "getArrangementsByCorporateEntityCode in PaymentArrangementController start" );

        List<PaymentArrangementListResponse> paymentArrangementListResponses =
            paymentArrangementService.getArrangementsByCorporateEntityCode( corporateEntityCode );

        LOGGER.debug( "getArrangementsByCorporateEntityCode in PaymentArrangementController End" );

        return new ResponseEntity<List<PaymentArrangementListResponse>>( paymentArrangementListResponses,
                                                                         HttpStatus.OK );
    }

    /**
     * fetch payment arrangement details by arrangement name
     * @param arrangementId
     * @return paymentArrangementResponse
     * @throws Exception
     */
    @GetMapping( "/getArrangement/{arrangementId}" )
    public ResponseEntity<PaymentArrangementResponse> getArrangementById( @PathVariable Integer arrangementId ) throws Exception
    {
        LOGGER.debug( "getArrangementByArrangementId in PaymentArrangementController start" );

        PaymentArrangementResponse paymentArrangementResponse = paymentArrangementService.getPaymentArrangementId( arrangementId );

        LOGGER.debug( "getArrangementByArrangementId in PaymentArrangementController End" );

        return new ResponseEntity<PaymentArrangementResponse>( paymentArrangementResponse,
                                                               HttpStatus.OK );
    }

    /**
     * validateArrangementPayee
     * @param ValidateArrangementPayeeRequest
     * @return ValidateArrangementPayeeResponse
     * @throws Exception
     */
    @PostMapping( "/validateArrangementPayee" )
    public ResponseEntity<ValidateArrangementPayeeResponse> validateArrangementPayee(
            @RequestBody ValidateArrangementPayeeRequest validateArrangementPayee ) throws Exception
    {
        LOGGER.debug( "validateArrangementPayee in PaymentArrangementController start" );

        ValidateArrangementPayeeResponse validateArrangementPayeeResponse =
            paymentArrangementService.validateArrangementPayee( validateArrangementPayee );

        LOGGER.debug( "validateArrangementPayee in PaymentArrangementController End" );

        return new ResponseEntity<ValidateArrangementPayeeResponse>( validateArrangementPayeeResponse,
                                                                     HttpStatus.OK );
    }

    /**
     * Method: getRunArrangements
     * @param runArrangementConfigDTO
     * @return
     * @throws Exception    
     */
    @PostMapping( "/getRunArrangements" )
    public ResponseEntity<CalculationRequestPaymentArrangementResponse> getRunArrangements(
            @RequestBody CalculationRequestSaveRequest calculationRequestSaveRequest ) throws Exception
    {
        LOGGER.debug( "getRunArrangements in PaymentArrangementController start" );

        CalculationRequestPaymentArrangementResponse calculationRequestPaymentArrangementResponse =
            paymentArrangementService.getCalculationRequestPaymentArrangements( calculationRequestSaveRequest );

        LOGGER.debug( "getRunArrangements in PaymentArrangementController End" );

        return new ResponseEntity<CalculationRequestPaymentArrangementResponse>( calculationRequestPaymentArrangementResponse,
                                                                                 HttpStatus.OK );

    }

    /**
     * Controller will validate the Rate Name Request for Arrangement 
     * and return the corresponding Response.
     * Method: validateArrangementRate
     * @param validateArrangementRate
     * @return
     * @throws Exception
     */
    @PostMapping( "/validateArrangementRate" )
    public ResponseEntity<ValidateArrangementRateResponse> validateArrangementRate(
            @RequestBody ValidateArrangementRateRequest validateArrangementRate ) throws Exception
    {
        LOGGER.debug( "validateArrangementRate in PaymentArrangementController start" );

        ValidateArrangementRateResponse validateArrangementRateResponse =
            paymentArrangementRateService.validatePaymentArrangementRate( validateArrangementRate );

        LOGGER.debug( "validateArrangementRate in PaymentArrangementController End" );

        return new ResponseEntity<ValidateArrangementRateResponse>( validateArrangementRateResponse,
                                                                    HttpStatus.OK );
    }

    /**
     * search Payee from VBR DB in Arrangement configuration flow
     * 
     * @param payeeSearchRequest
     * @return
     * @throws Exception
     */
    @PostMapping( "/searchPayee" )
    public ResponseEntity<List<PayeeRetrieveResponse>> searchVbrPayee( @RequestBody PayeeSearchRequest payeeSearchRequest )
            throws Exception
    {
        LOGGER.debug( "searchPayee in PaymentArrangementController start" );

        List<PayeeRetrieveResponse> searchPayeeResponse = paymentArrangementService.searchVbrPayee( payeeSearchRequest );

        LOGGER.debug( "searchPayee in PaymentArrangementController End" );

        return new ResponseEntity<List<PayeeRetrieveResponse>>( searchPayeeResponse,
                                                                HttpStatus.OK );
    }

}
