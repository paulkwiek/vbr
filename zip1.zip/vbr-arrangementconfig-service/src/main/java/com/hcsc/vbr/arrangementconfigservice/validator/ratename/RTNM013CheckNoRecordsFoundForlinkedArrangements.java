package com.hcsc.vbr.arrangementconfigservice.validator.ratename;

import java.util.List;

import org.apache.commons.collections4.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.hcsc.vbr.arrangementconfigservice.constant.ArrangementConfigServiceErrorMessageConstant;
import com.hcsc.vbr.arrangementconfigservice.constant.ComponentIdConstant;
import com.hcsc.vbr.arrangementconfigservice.constant.FieldIdConstant;
import com.hcsc.vbr.arrangementconfigservice.validator.base.BaseValidationUnit;
import com.hcsc.vbr.common.dto.ReturnMessageDTO;
import com.hcsc.vbr.web.response.PaymentArrangementListResponse;

@Component
public class RTNM013CheckNoRecordsFoundForlinkedArrangements extends BaseValidationUnit
{

    private static final Logger LOGGER = LoggerFactory.getLogger( RTNM013CheckNoRecordsFoundForlinkedArrangements.class );

    /**
     * Method: isRecordsFound
     * @param linkedArrangementResponseList
     * @param returnMessage
     * @return
     * @throws Exception
     */
    public boolean isRecordsFound( List<PaymentArrangementListResponse> linkedArrangementResponseList,
            ReturnMessageDTO returnMessage ) throws Exception
    {

        LOGGER.debug( "RTNM013CheckNoRecordsFoundForlinkedArrangements : START" );

        boolean isRecordsFound = true;

        if( CollectionUtils.isEmpty( linkedArrangementResponseList ) )
        {
            //Set return flag to false
            isRecordsFound = false;
            //Add Error/Warning to ReturnMessage
            addToReturnMessage( ArrangementConfigServiceErrorMessageConstant.NO_ARRANGEMENT_RECORDS_FOUND,
                                FieldIdConstant.VBPY_PINGROUP_ID,
                                ComponentIdConstant.VBPY,
                                this.getClass().getSimpleName(),
                                returnMessage );
        }

        LOGGER.debug( "RTNM013CheckNoRecordsFoundForlinkedArrangements : END" );

        return isRecordsFound;

    }
}
