package com.hcsc.vbr.arrangementconfigservice.validator.payee;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.hcsc.vbr.arrangementconfigservice.constant.ArrangementConfigServiceErrorMessageConstant;
import com.hcsc.vbr.arrangementconfigservice.constant.ComponentIdConstant;
import com.hcsc.vbr.arrangementconfigservice.constant.FieldIdConstant;
import com.hcsc.vbr.arrangementconfigservice.validator.base.BaseValidationUnit;
import com.hcsc.vbr.common.dto.ReturnMessageDTO;
import com.hcsc.vbr.web.request.PayeeSearchRequest;

@Component
public class VBPY001ValidatePinGroupIdInSearch extends BaseValidationUnit
{
    private static final Logger LOGGER = LoggerFactory.getLogger( VBPY001ValidatePinGroupIdInSearch.class );

    /**
     * Validating pinGroupId while searching for Payee
     * @param payeeSearchRequest
     * @param returnMessage
     * @return
     * @throws Exception
     */
    public boolean validatePinGroupId( PayeeSearchRequest payeeSearchRequest,
            ReturnMessageDTO returnMessage ) throws Exception
    {
        LOGGER.debug( "VBPY001ValidatePinGroupIdInSearch : Start" );
        String pinGroupId = payeeSearchRequest.getPinGroupId();
        boolean isPinGrpIdValid = true;

        if( ( StringUtils.isNotBlank( pinGroupId ) )
            && ( ( !StringUtils.isAlphanumeric( pinGroupId ) ) || ( pinGroupId.length() > 10 ) ) )
        {
            isPinGrpIdValid = false;
            addToReturnMessage( ArrangementConfigServiceErrorMessageConstant.EMPTY_INVALID_PINGROUP_ID,
                                FieldIdConstant.VBPY_PINGROUP_ID,
                                ComponentIdConstant.VBPY,
                                this.getClass().getSimpleName(),
                                returnMessage );

        }

        LOGGER.debug( "VBPY001ValidatePinGroupIdInSearch : END" );
        return isPinGrpIdValid;
    }
}
