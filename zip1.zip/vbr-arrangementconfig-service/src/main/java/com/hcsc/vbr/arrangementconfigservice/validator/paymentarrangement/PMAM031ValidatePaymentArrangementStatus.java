package com.hcsc.vbr.arrangementconfigservice.validator.paymentarrangement;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.hcsc.vbr.arrangementconfigservice.constant.ArrangementConfigServiceConstant;
import com.hcsc.vbr.arrangementconfigservice.constant.ArrangementConfigServiceErrorMessageConstant;
import com.hcsc.vbr.arrangementconfigservice.constant.ComponentIdConstant;
import com.hcsc.vbr.arrangementconfigservice.constant.FieldIdConstant;
import com.hcsc.vbr.arrangementconfigservice.domain.PaymentArrangement;
import com.hcsc.vbr.arrangementconfigservice.utils.ArrangementConfigServiceUtils;
import com.hcsc.vbr.arrangementconfigservice.validator.base.BaseValidationUnit;
import com.hcsc.vbr.common.dto.ReturnMessageDTO;

@Component
public class PMAM031ValidatePaymentArrangementStatus extends BaseValidationUnit
{

    @Autowired
    private ArrangementConfigServiceUtils arrangementConfigServiceUtils;

    /**
     * Method: checkValidationStatusCode
     * @param paymentArrangement
     * @param isRateInvalid
     * @param isPayeeInvalid
     * @param errors
     * @throws Exception 
     */
    public boolean checkValidationStatusCode( PaymentArrangement paymentArrangement,
            boolean isRateInvalid,
            boolean isPayeeInvalid,
            ReturnMessageDTO returnMessage ) throws Exception
    {
        boolean flag = false;
        String overwriteSaveArrangement = paymentArrangement.getOverwriteSaveArrangement();

        String validationStatusCode = paymentArrangement.getValidationStatusCode();

        boolean overwriteSaveArrangmnt = arrangementConfigServiceUtils.isOverwriteSaveArrangement( overwriteSaveArrangement );

        if( StringUtils.equalsIgnoreCase( validationStatusCode,
                                          ArrangementConfigServiceConstant.ARRANGEMENT_STATUS_DRAFT )
            && !overwriteSaveArrangmnt )
        {

            addToReturnMessage( ArrangementConfigServiceErrorMessageConstant.PAYMENT_ARRANGEMENT_SAVE_REQUEST_MESSAGE_DRAFT,
                                FieldIdConstant.PMAM_STATUS,
                                ComponentIdConstant.PMAM,
                                this.getClass().getSimpleName(),
                                returnMessage );
            flag = true;
        }
        else if( StringUtils.equalsIgnoreCase( validationStatusCode,
                                               ArrangementConfigServiceConstant.ARRANGEMENT_STATUS_EXPIRED )
            && !overwriteSaveArrangmnt )
        {

            addToReturnMessage( ArrangementConfigServiceErrorMessageConstant.PAYMENT_ARRANGEMENT_SAVE_REQUEST_MESSAGE_EXPIRED,
                                FieldIdConstant.PMAM_STATUS,
                                ComponentIdConstant.PMAM,
                                this.getClass().getSimpleName(),
                                returnMessage );
            flag = true;
        }
        else if( StringUtils.equalsIgnoreCase( validationStatusCode,
                                               ArrangementConfigServiceConstant.ARRANGEMENT_STATUS_FUTURE_INVALID )
            && !overwriteSaveArrangmnt )
        {

            if( ( isRateInvalid && !isPayeeInvalid ) )
            {
                addToReturnMessage( ArrangementConfigServiceErrorMessageConstant.PAYMENT_ARRANGEMENT_SAVE_REQUEST_MESSAGE_RATE_FUTURE_INVALID,
                                    FieldIdConstant.PMAM_STATUS,
                                    ComponentIdConstant.PMAM,
                                    this.getClass().getSimpleName(),
                                    returnMessage );
                flag = true;
            }
            else if( ( isPayeeInvalid && !isRateInvalid ) )
            {
                addToReturnMessage( ArrangementConfigServiceErrorMessageConstant.PAYMENT_ARRANGEMENT_SAVE_REQUEST_MESSAGE_PAYEE_FUTURE_INVALID,
                                    FieldIdConstant.PMAM_STATUS,
                                    ComponentIdConstant.PMAM,
                                    this.getClass().getSimpleName(),
                                    returnMessage );
                flag = true;
            }
            else
            {
                addToReturnMessage( ArrangementConfigServiceErrorMessageConstant.PAYMENT_ARRANGEMENT_SAVE_REQUEST_MESSAGE_FUTURE_INVALID,
                                    FieldIdConstant.PMAM_STATUS,
                                    ComponentIdConstant.PMAM,
                                    this.getClass().getSimpleName(),
                                    returnMessage );
                flag = true;
            }
        }

        /*WHEN The arrangement duration is valid for processing month and any rate or payee 
        validation is failing or resulting in warning message, arrangement status should be invalid */

        else if( StringUtils.equalsIgnoreCase( validationStatusCode,
                                               ArrangementConfigServiceConstant.ARRANGEMENT_STATUS_INVALID )
            && !overwriteSaveArrangmnt )
        {

            if( ( isRateInvalid && !isPayeeInvalid ) )
            {
                addToReturnMessage( ArrangementConfigServiceErrorMessageConstant.PAYMENT_ARRANGEMENT_SAVE_REQUEST_MESSAGE_RATE_INVALID,
                                    FieldIdConstant.PMAM_STATUS,
                                    ComponentIdConstant.PMAM,
                                    this.getClass().getSimpleName(),
                                    returnMessage );
                flag = true;
            }
            else if( ( isPayeeInvalid && !isRateInvalid ) )
            {
                addToReturnMessage( ArrangementConfigServiceErrorMessageConstant.PAYMENT_ARRANGEMENT_SAVE_REQUEST_MESSAGE_PAYEE_INVALID,
                                    FieldIdConstant.PMAM_STATUS,
                                    ComponentIdConstant.PMAM,
                                    this.getClass().getSimpleName(),
                                    returnMessage );
                flag = true;
            }
            else
            {
                addToReturnMessage( ArrangementConfigServiceErrorMessageConstant.PAYMENT_ARRANGEMENT_SAVE_REQUEST_MESSAGE_INVALID,
                                    FieldIdConstant.PMAM_STATUS,
                                    ComponentIdConstant.PMAM,
                                    this.getClass().getSimpleName(),
                                    returnMessage );
                flag = true;
            }
        }
        else if( StringUtils.equalsIgnoreCase( validationStatusCode,
                                               ArrangementConfigServiceConstant.ARRANGEMENT_STATUS_WARNING )
            && !overwriteSaveArrangmnt )
        {

            addToReturnMessage( ArrangementConfigServiceErrorMessageConstant.PAYMENT_ARRANGEMENT_SAVE_REQUEST_WARNING,
                                FieldIdConstant.PMAM_STATUS,
                                ComponentIdConstant.PMAM,
                                this.getClass().getSimpleName(),
                                returnMessage );
            flag = true;
        }
        return flag;

    }
}
