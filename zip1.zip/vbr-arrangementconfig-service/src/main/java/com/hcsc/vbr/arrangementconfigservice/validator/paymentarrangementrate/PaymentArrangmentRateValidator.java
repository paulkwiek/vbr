package com.hcsc.vbr.arrangementconfigservice.validator.paymentarrangementrate;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.hcsc.vbr.arrangementconfigservice.domain.FlatRate;
import com.hcsc.vbr.arrangementconfigservice.domain.PaymentArrangementRate;
import com.hcsc.vbr.arrangementconfigservice.repository.FlatRateRepository;
import com.hcsc.vbr.arrangementconfigservice.validator.base.BaseValidationUnit;
import com.hcsc.vbr.common.dto.ReturnMessageDTO;
import com.hcsc.vbr.common.exception.VbrApplicationException;

@Component
public class PaymentArrangmentRateValidator extends BaseValidationUnit
{
    private static final Logger LOGGER = LoggerFactory.getLogger( PaymentArrangmentRateValidator.class );

    @Autowired
    private FlatRateRepository flatRateRepository;

    @Autowired
    private PMRT001CheckArrangementRateEffectiveAndEndDates pmrt001CheckArrangementRateEffectiveAndEndDates;

    @Autowired
    private PMRT002CheckCoverageForGlobalRateVsArrangementRate pmrt002CheckCoverageForGlobalRateVsArrangementRate;

    @Autowired
    private PMRT003CheckFlatRateListForEmpty pmrt003CheckFlatRateListForEmpty;

    /**
     * This method will check Arrangement rate falls under correct flat Rate Date Range.
     * Method: validatePaymentArrangementRate
     * @param validateArrangementRateRequest
     * @param errors
     * @throws Exception
     */
    public boolean validatePaymentArrangementRate( PaymentArrangementRate paymentArrangementRate,
            ReturnMessageDTO returnMessage ) throws Exception
    {
        LOGGER.debug( "validatePaymentArrangementRate : START" );

        boolean validatePaymentArrangementRateFlag = true;

        List<PaymentArrangementRate> paymentArrangementRates = new ArrayList<>();
        paymentArrangementRates.add( paymentArrangementRate );

        List<FlatRate> flatRates = flatRateRepository.findByRateName( paymentArrangementRate.getRateName().trim() );
        boolean checkDateformat = checkDateFormat( paymentArrangementRate,
                                                   returnMessage );
        validatePaymentArrangementRateFlag = checkDateformat
            && pmrt001CheckArrangementRateEffectiveAndEndDates
                    .validatePaymentArrangementRateEffectiveAndEndDate( paymentArrangementRate,
                                                                        returnMessage );
        validatePaymentArrangementRateFlag = checkDateformat
            && pmrt003CheckFlatRateListForEmpty.checkFlatRateListForEmpty( flatRates,
                                                                           returnMessage )
            && validatePaymentArrangementRateFlag;

        validatePaymentArrangementRateFlag = checkDateformat
            && pmrt002CheckCoverageForGlobalRateVsArrangementRate.CheckCoverageForGlobalRateVsArrangementRate( paymentArrangementRates,
                                                                                                               flatRates,
                                                                                                               returnMessage )
            && validatePaymentArrangementRateFlag;

        if( !validatePaymentArrangementRateFlag )
        {
            throw new VbrApplicationException( returnMessage );
        }
        LOGGER.debug( "validatePaymentArrangementRate : END" );
        return validatePaymentArrangementRateFlag;

    }

}
