package com.hcsc.vbr.arrangementconfigservice.validator.payee;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.hcsc.vbr.arrangementconfigservice.constant.ArrangementConfigServiceErrorMessageConstant;
import com.hcsc.vbr.arrangementconfigservice.constant.ComponentIdConstant;
import com.hcsc.vbr.arrangementconfigservice.constant.FieldIdConstant;
import com.hcsc.vbr.arrangementconfigservice.domain.VbrPayee;
import com.hcsc.vbr.arrangementconfigservice.validator.base.BaseValidationUnit;
import com.hcsc.vbr.common.dto.ReturnMessageDTO;

@Component
public class VBPY013ValidateVbrPayeeNetworkCode extends BaseValidationUnit
{
    private static final Logger LOGGER = LoggerFactory.getLogger( VBPY013ValidateVbrPayeeNetworkCode.class );

    /**
     * @param vbrPayee
     * @param returnMessage
     * @return
     * @throws Exception
     */
    public boolean validateVbrPayeeNetworkCodeFieldLength( VbrPayee vbrPayee,
            ReturnMessageDTO returnMessage ) throws Exception
    {
        LOGGER.debug( "VBPY013ValidateVbrPayeeNetworkCode : Start" );
        boolean isNetworkCodeValid = true;
        String networkCode = vbrPayee.getNetworkCode();
        if( ( StringUtils.isNotBlank( networkCode ) )
            && ( ( !StringUtils.isAlphanumeric( networkCode ) ) || ( networkCode.length() > 20 ) ) )
        {
            isNetworkCodeValid = false;
            addToReturnMessage( ArrangementConfigServiceErrorMessageConstant.INVALID_NETWORK_CODE,
                                FieldIdConstant.VBPY_NETWORK_CODE,
                                ComponentIdConstant.VBPY,
                                this.getClass().getSimpleName(),
                                returnMessage );
        }

        LOGGER.debug( "VBPY013ValidateVbrPayeeNetworkCode : END" );
        return isNetworkCodeValid;
    }
}
