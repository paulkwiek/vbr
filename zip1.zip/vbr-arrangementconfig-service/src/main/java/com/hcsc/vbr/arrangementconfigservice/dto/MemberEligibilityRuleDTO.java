package com.hcsc.vbr.arrangementconfigservice.dto;

import org.apache.commons.lang3.builder.ReflectionToStringBuilder;

import com.hcsc.vbr.common.dto.DateRecordDTO;
import com.hcsc.vbr.common.utils.MultilineRecursiveToStringStyleCustom;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class MemberEligibilityRuleDTO extends DateRecordDTO
{

    private static final long serialVersionUID = 1L;

    private Integer memberEligibilityRuleId;

    private String corporateEntityCode;

    private String criteriaName;

    private String criteriaValueText;

    private String paymentTypeCode;

    @Override
    public String toString()
    {
        return new ReflectionToStringBuilder( this,
                                              new MultilineRecursiveToStringStyleCustom() ).toString();
    }

}
