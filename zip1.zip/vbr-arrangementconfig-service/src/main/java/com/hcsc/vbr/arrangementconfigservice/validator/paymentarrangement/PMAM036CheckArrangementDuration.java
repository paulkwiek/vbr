package com.hcsc.vbr.arrangementconfigservice.validator.paymentarrangement;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.hcsc.vbr.arrangementconfigservice.domain.PaymentArrangement;
import com.hcsc.vbr.arrangementconfigservice.validator.base.BaseValidator;
import com.hcsc.vbr.common.dto.ReturnMessageDTO;

/**
 * @author u405846
 *
 */
@Component
public class PMAM036CheckArrangementDuration extends BaseValidator
{
    final Logger LOGGER = LoggerFactory.getLogger( PMAM036CheckArrangementDuration.class );

    @Autowired
    private PMAM001CheckPaymentArrangementEffectiveDateEqualorBeforeEndDate pmam001CheckPaymentArrangementEffectiveDateEqualorBeforeEndDate;

    @Autowired
    private PMAM024CheckPaymentArrangementDurationEffAndEndDateFirstAndLastDateofMonth pmam024CheckPaymentArrangementDurationEffAndEndDateFirstAndLastDateofMonth;

    @Autowired
    private PMAM034CheckArrangementDurationEmpty pmam034CheckArrangementDurationEmpty;

    /**
     * Arrangement Duration Validation 
     * Method: validatePaymentArrangementEffectiveAndEndDates
     * @param dateRecord
     * @param errors
     * @return true -  when any  of the Arrangement Duration Validations Fails
     * @return false -  when all of the Arrangement Duration Validations Success
     * @throws Exception
     */
    public boolean validateArrangementDuration( PaymentArrangement paymentArrangementSaveRequest,
            ReturnMessageDTO returnMessage ) throws Exception
    {
        LOGGER.debug( "validateArrangementDuration : START" );

        boolean isDateValid = true;
        boolean isarrangementDurationNotEmpty = false;
        boolean isarrangementEffDateBeforeEndDate = false;
        boolean isarrangementEffEndDateFirstLast = false;

        /** Start of PaymentArrangement Effective & End date Validation **/

        /** Arrangement Duration Effective and End Dates Empty validation **/
        isarrangementDurationNotEmpty =
            pmam034CheckArrangementDurationEmpty.validateArrangementDurationEmpty( paymentArrangementSaveRequest,
                                                                                   returnMessage );

        if( isarrangementDurationNotEmpty )
        {

            /** Arrangement Duration Effective Date is equal or before End Date Validation **/
            isarrangementEffDateBeforeEndDate = pmam001CheckPaymentArrangementEffectiveDateEqualorBeforeEndDate
                    .validatePaymentArrangementEffectiveDateEqualBeforeEndDate( paymentArrangementSaveRequest,
                                                                                returnMessage );

            if( isarrangementEffDateBeforeEndDate )
            {
                /** Arrangement Duration Effective Date and End Date First Day Last Day Validation **/
                isarrangementEffEndDateFirstLast = pmam024CheckPaymentArrangementDurationEffAndEndDateFirstAndLastDateofMonth
                        .validatePaymentArrangementEffAndEndDateFirstAndLastDateofMonth( paymentArrangementSaveRequest,
                                                                                         returnMessage );
                if( isarrangementEffEndDateFirstLast )
                {
                    /** Arrangement Duration Validation  Flag
                     *  returns false -  when all of the Arrangement Duration Validations Success **/
                    isDateValid = true;
                }
                else
                {
                    /** Arrangement Duration Validation  Flag
                     *  returns true -  when any of the Arrangement Duration Validations Fails **/
                    isDateValid = false;
                }

            }
            else
            {
                /** Arrangement Duration Validation  Flag 
                 *  returns true -   when effective date is after end date **/
                isDateValid = false;
            }

        }
        else
        {
            /** Arrangement Duration Validation  Flag 
             *  returns true -   when effective date is after end date **/
            isDateValid = false;
        }

        LOGGER.debug( "Arrangement Duration Valid" + isDateValid );
        LOGGER.debug( "validateArrangementDuration : END" );
        return isDateValid;
    }

}