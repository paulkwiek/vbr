package com.hcsc.vbr.arrangementconfigservice.validator.ratename;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.ObjectUtils;

import com.hcsc.vbr.arrangementconfigservice.constant.ArrangementConfigServiceErrorMessageConstant;
import com.hcsc.vbr.arrangementconfigservice.constant.ComponentIdConstant;
import com.hcsc.vbr.arrangementconfigservice.constant.FieldIdConstant;
import com.hcsc.vbr.arrangementconfigservice.domain.FlatRate;
import com.hcsc.vbr.arrangementconfigservice.domain.RateName;
import com.hcsc.vbr.arrangementconfigservice.repository.RateNameRepository;
import com.hcsc.vbr.arrangementconfigservice.validator.base.BaseValidationUnit;
import com.hcsc.vbr.common.dto.ReturnMessageDTO;
import com.hcsc.vbr.common.utils.VBRDateUtils;

@Component
public class RTNM004CheckRateDateOverlap extends BaseValidationUnit
{

    @Autowired
    private RateNameRepository rateNameRepository;

    private static final Logger LOGGER = LoggerFactory.getLogger( RTNM004CheckRateDateOverlap.class );

    /**
     * @param rateName
     * @param returnMessage
     * @return
     * @throws Exception
     */

    public boolean validateRateDateOverlap( RateName rateName,
            ReturnMessageDTO returnMessage ) throws Exception
    {

        LOGGER.debug( "RTNM004CheckRateDateOverlap : START" );
        boolean validateFlag = true;
        List<FlatRate> flatRatesFromDB = new ArrayList<FlatRate>();
        List<FlatRate> flatRatesFromUI = new ArrayList<FlatRate>();
        List<FlatRate> flatRatesFromUIAndDB = new ArrayList<FlatRate>();
        List<FlatRate> uniqueFlatRatesFromDB = new ArrayList<FlatRate>();

        List<FlatRate> flatRates = rateName.getFlatRates();

        for( FlatRate flatRate : flatRates )
        {
            String rowAction = flatRate.getRowAction().name();
            if( !ObjectUtils.isEmpty( flatRates ) && ( StringUtils.equalsIgnoreCase( rowAction,
                                                                                     "INSERT" )
                || ( StringUtils.equalsIgnoreCase( rowAction,
                                                   "UPDATE" ) ) ) )
            {
                if( !ObjectUtils.isEmpty( flatRates.get( 0 ).getRateName() ) )
                {
                    // Obtain FlatRate dates from DB for a given rateName
                    RateName rateNameEntity = rateNameRepository.findByRateName( flatRates.get( 0 ).getRateName() );
                    if( rateNameEntity != null )
                    {

                        flatRatesFromDB = rateNameEntity.getFlatRates();

                        // Adding flat rates from both UI and DB in single list
                        if( StringUtils.equalsIgnoreCase( rowAction,
                                                          "UPDATE" ) )
                        {
                            // Need to exclude the flateRateId which is going to be
                            // edited which comes from UI to check overlapping.
                            flatRatesFromUI = rateName.getFlatRates();
                            uniqueFlatRatesFromDB = getDistinctFlatRatesFromDB( flatRatesFromUI,
                                                                                flatRatesFromDB );

                            flatRatesFromUIAndDB.addAll( uniqueFlatRatesFromDB );
                            flatRatesFromUIAndDB.addAll( flatRates );
                        }
                        else
                        {
                            flatRatesFromUIAndDB.addAll( flatRatesFromDB );
                            flatRatesFromUIAndDB.addAll( flatRates );
                        }
                    }
                }
                else
                {
                    LOGGER.debug( "Flat Rates from UI and DB for a given rateName is empty!" );
                }
            }
            else
            {
                LOGGER.debug( "FlatRate list is empty!" );
            }
        }

        // Check whether the dates from UI and DB are overlapping while
        // edit and save flow in rates.
        if( !flatRatesFromUIAndDB.isEmpty() )
        {
            if( !VBRDateUtils.checkNotIntersecting( flatRatesFromUIAndDB ) )
            {
                //Set return flag to false
                validateFlag = false;
                //Add Error/Warning to ReturnMessage
                addToReturnMessage( ArrangementConfigServiceErrorMessageConstant.RATE_OVERLAP_IN_ARRANGEMENT_PAYEE_EFF_END_DATES,
                                    FieldIdConstant.RTNM_EFF_AND_END_DATE,
                                    ComponentIdConstant.RTNM,
                                    this.getClass().getSimpleName(),
                                    returnMessage );
            }
        }
        LOGGER.debug( "RTNM004CheckRateDateOverlap : END" );
        return validateFlag;
    }

    // Need to remove the FlatRate coming from UI from List of FlatRates in DB
    // for given rateName in edit flow only
    public List<FlatRate> getDistinctFlatRatesFromDB( List<FlatRate> flatRateListFromUI,
            List<FlatRate> flatRateListFromDB )
    {
        List<FlatRate> flatRatesFromDBUnique = new ArrayList<FlatRate>();

        for( FlatRate flat : flatRateListFromDB )
        {
            if( !flat.getFlatRateId().equals( flatRateListFromUI.get( 0 ).getFlatRateId() ) )
            {
                flatRatesFromDBUnique.add( flat );
            }
        }
        return flatRatesFromDBUnique;

    }
}
