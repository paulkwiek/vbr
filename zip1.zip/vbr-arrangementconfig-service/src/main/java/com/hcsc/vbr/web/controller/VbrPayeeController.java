package com.hcsc.vbr.web.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hcsc.vbr.arrangementconfigservice.dto.VbrPayeeDTO;
import com.hcsc.vbr.arrangementconfigservice.service.VbrPayeeService;
import com.hcsc.vbr.web.controller.base.BaseController;
import com.hcsc.vbr.web.request.PayeeSaveRequest;
import com.hcsc.vbr.web.request.PayeeSearchRequest;
import com.hcsc.vbr.web.response.PayeeRetrieveResponse;
import com.hcsc.vbr.web.response.PayeeSearchResponse;
import com.hcsc.vbr.web.response.VbrPayeeResponse;

@RestController
@RequestMapping( "payee" )
public class VbrPayeeController extends BaseController
{
    private static final Logger LOGGER = LoggerFactory.getLogger( RateNameController.class );

    @Autowired
    VbrPayeeService vbrPayeeService;

    /**
     * saves or updates VbrPayee
     * 
     * @param payeeSaveRequest
     * @return
     * @throws Exception
     */
    @PreAuthorize( "hasAnyRole('ROLE_UPDATE_NM','ROLE_CALC_APPROVAL_NM')" )
    @PostMapping( "/savePayee" )
    public ResponseEntity<VbrPayeeResponse> saveVbrPayee( @RequestBody PayeeSaveRequest payeeSaveRequest ) throws Exception
    {
        LOGGER.debug( "saveVbrPayee Controller : START" );
        VbrPayeeResponse payeeSaveResponse = new VbrPayeeResponse();
        payeeSaveResponse = vbrPayeeService.saveVbrPayee( payeeSaveRequest.getPayee() );

        LOGGER.debug( "saveVbrPayee Controller : END" );
        return new ResponseEntity<VbrPayeeResponse>( payeeSaveResponse,
                                                     HttpStatus.OK );

    }

    /**
     * search Payee from VBR DB
     * 
     * @param payeeSearchRequest
     * @return
     * @throws Exception
     */
    @PostMapping( "/searchPayee" )
    public ResponseEntity<PayeeSearchResponse> searchPayee( @RequestBody PayeeSearchRequest payeeSearchRequest ) throws Exception
    {
        LOGGER.debug( "searchPayee Controller : START" );
        PayeeSearchResponse searchPayeeResponse = vbrPayeeService.searchPayee( payeeSearchRequest );

        LOGGER.debug( "searchPayee Controller : END" );
        return new ResponseEntity<PayeeSearchResponse>( searchPayeeResponse,
                                                        HttpStatus.OK );
    }

    /**
     * Retrieves Payee based on search request from providerAPI
     * 
     * @param payeeSearchRequest
     * @return
     * @throws Exception
     */
    @PostMapping( "/retrievePayee" )
    public ResponseEntity<PayeeRetrieveResponse> retrievePayee( @RequestBody PayeeSearchRequest payeeSearchRequest ) throws Exception
    {
        LOGGER.debug( "retrievePayee Controller : START" );
        PayeeRetrieveResponse searchPayeeResponse = vbrPayeeService.retrievePayee( payeeSearchRequest );

        LOGGER.debug( "retrievePayee Controller : END" );
        return new ResponseEntity<PayeeRetrieveResponse>( searchPayeeResponse,
                                                          HttpStatus.OK );
    }

    /**
     * Retrieves list of Payees based on search request
     * 
     * @param payeeSearchRequestList
     * @return
     * @throws Exception
     */
    @PostMapping( "/retrievePayees" )
    public ResponseEntity<PayeeSearchResponse> retrievePayees( @RequestBody List<PayeeSearchRequest> payeeSearchRequestList )
            throws Exception
    {
        LOGGER.debug( "retrievePayees Controller : START" );
        PayeeSearchResponse searchPayeeResponse = new PayeeSearchResponse();
        List<VbrPayeeDTO> payees = vbrPayeeService.retrievePayees( payeeSearchRequestList );
        searchPayeeResponse.setPayees( payees );

        LOGGER.debug( "retrievePayees Controller : END" );
        return new ResponseEntity<PayeeSearchResponse>( searchPayeeResponse,
                                                        HttpStatus.OK );
    }

    /**
     * validates Unique Payee
     * @param payeeRequest
     * @throws Exception
     */
    @PostMapping( "/validateUniquePayee" )
    public void validateUniquePayee( @RequestBody PayeeSaveRequest payeeRequest ) throws Exception
    {
        vbrPayeeService.validateUniquePayee( payeeRequest.getPayee() );
    }
}
