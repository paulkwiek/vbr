package com.hcsc.vbr.arrangementconfigservice.validator.payee;

import java.time.LocalDate;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.hcsc.vbr.arrangementconfigservice.constant.ArrangementConfigServiceErrorMessageConstant;
import com.hcsc.vbr.arrangementconfigservice.constant.ComponentIdConstant;
import com.hcsc.vbr.arrangementconfigservice.constant.FieldIdConstant;
import com.hcsc.vbr.arrangementconfigservice.domain.VbrPayee;
import com.hcsc.vbr.arrangementconfigservice.validator.base.BaseValidationUnit;
import com.hcsc.vbr.common.dto.ReturnMessageDTO;
import com.hcsc.vbr.common.utils.VBRDateUtils;

@Component
public class VBPY016ValidateVbrPayeeEndDateIsLastDayOfMonth extends BaseValidationUnit
{
    private static final Logger LOGGER = LoggerFactory.getLogger( VBPY016ValidateVbrPayeeEndDateIsLastDayOfMonth.class );

    public boolean isLastDayOfMonth( VbrPayee vbrPayee,
            ReturnMessageDTO returnMessage ) throws Exception
    {
        LOGGER.debug( "VBPY016ValidateVbrPayeeEndDateIsLastDayOfMonth : Start" );
        boolean isDateValid = true;
        if( !( 1 == vbrPayee.getRecordEffectiveDate().getDayOfMonth() ) || VBRDateUtils.isNotSameDay( vbrPayee ) )
        {
            LocalDate lastDateOfMonth = VBRDateUtils.getLastDayOfMonth( vbrPayee.getRecordEndDate() );

            if( !( lastDateOfMonth == vbrPayee.getRecordEndDate() ) )
            {
                isDateValid = false;
                addToReturnMessage( ArrangementConfigServiceErrorMessageConstant.VBR_PAYEE_END_DATE_SHOULD_BE_LAST_DAY_OF_MONTH,
                                    FieldIdConstant.VBPY_END_DATE,
                                    ComponentIdConstant.VBPY,
                                    this.getClass().getSimpleName(),
                                    returnMessage );

            }
        }

        LOGGER.debug( "VBPY016ValidateVbrPayeeEndDateIsLastDayOfMonth : END" );
        return isDateValid;
    }
}
