package com.hcsc.vbr.arrangementconfigservice.validator.paymentarrangement;

import java.time.LocalDate;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.hcsc.vbr.arrangementconfigservice.constant.ArrangementConfigServiceErrorMessageConstant;
import com.hcsc.vbr.arrangementconfigservice.constant.ComponentIdConstant;
import com.hcsc.vbr.arrangementconfigservice.constant.FieldIdConstant;
import com.hcsc.vbr.arrangementconfigservice.domain.PaymentArrangement;
import com.hcsc.vbr.arrangementconfigservice.validator.base.BaseValidationUnit;
import com.hcsc.vbr.common.domain.DateRecord;
import com.hcsc.vbr.common.dto.ReturnMessageDTO;
import com.hcsc.vbr.common.utils.VBRDateUtils;

@Component
public class PMAM018CheckOverlapInArrangementRateEffEndDates extends BaseValidationUnit
{

    final Logger LOGGER = LoggerFactory.getLogger( PMAM018CheckOverlapInArrangementRateEffEndDates.class );

    /**
     * This method will validate Overlaps B/W Arrangement Rate Effective and End
     * Dates.
     * 
     * @param dateRecordList
     * @param errors
     * @return flag
     * @throws Exception
     */
    public boolean validateOverlapInArrangmentRateEffEndDates( List<? extends DateRecord> dateRecordList,
            PaymentArrangement arrangementDate,
            LocalDate processingMonth,
            ReturnMessageDTO returnMessage ) throws Exception
    {
        LOGGER.debug( "validateOverlapInArrangmentRateEffEndDates : START" );

        boolean isDateValid = false;
        LocalDate lastDateOfProcessingMonth = VBRDateUtils.getLastDayOfMonth( processingMonth );
        if( !VBRDateUtils.checkNotIntersecting( dateRecordList ) )
        {

            if( arrangementDate.getRecordEffectiveDate().isAfter( lastDateOfProcessingMonth ) )
            {
                addToReturnMessage( ArrangementConfigServiceErrorMessageConstant.OVERLAP_IN_ARRANGEMENT_RATE_EFF_END_DATES_FOR_FUTURE_ARRANGEMENT,
                                    FieldIdConstant.PMAR_END_DATE,
                                    ComponentIdConstant.PMAM,
                                    this.getClass().getSimpleName(),
                                    returnMessage );
                isDateValid = true;
            }
            else
            {
                addToReturnMessage( ArrangementConfigServiceErrorMessageConstant.OVERLAP_IN_ARRANGEMENT_RATE_EFF_END_DATES,
                                    FieldIdConstant.PMAR_END_DATE,
                                    ComponentIdConstant.PMAM,
                                    this.getClass().getSimpleName(),
                                    returnMessage );
                isDateValid = true;
            }

        }
        LOGGER.debug( "OverlapInArrangmentRateEffEndDates  : " + isDateValid );
        LOGGER.debug( "validateOverlapInArrangmentRateEffEndDates : START" );
        return isDateValid;
    }

}
