package com.hcsc.vbr.arrangementconfigservice.utils;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.hcsc.vbr.arrangementconfigservice.domain.VbrPayee;
import com.hcsc.vbr.common.apiclient.ProviderServiceApiClient;
import com.hcsc.vbr.web.response.ProviderApiAddressesResponse;
import com.hcsc.vbr.web.response.ProviderApiDemographicsResponse;

@Component
public class VbrPayeeUtils
{

    @Autowired
    private ProviderServiceApiClient providerServiceApiClient;

    /**
     * @param payee
     * @return
     */
    // This method calls both Demographics and addresses endpoints to get the provider name and billing address
    public VbrPayee getProviderApiAddressAndDemographicsResponse( VbrPayee payee )
    {

        //Call demographics endpoint and retrieve provider name to map response 
        ProviderApiDemographicsResponse providerApiDemographicsResponse =
            providerServiceApiClient.getDemographicsByPfin( payee.getPayToPfinId() );
        payee.setProviderFirstName( providerApiDemographicsResponse.getBilling().getProviderFirstName() );
        payee.setProviderLastName( providerApiDemographicsResponse.getBilling().getProviderLastName() );
        payee.setProviderOrganizationName( providerApiDemographicsResponse.getBilling().getProviderOrganizationName() );
        payee.setProviderOrganizationSecondName( providerApiDemographicsResponse.getBilling().getProviderOrganizationSecondName() );
        payee.setProviderTitleCode( providerApiDemographicsResponse.getBilling().getProviderTitleCode() );

        // Call the addresses endpoint and retrieve billing address to map to response
        ProviderApiAddressesResponse addressessByPfinResponse = providerServiceApiClient.getAddressesByPfin( payee.getPayToPfinId() );
        payee.setAddressLine1Text( addressessByPfinResponse.getBillingAddress().getAddress().getAddressLine1() );
        payee.setAddressLine2Text( addressessByPfinResponse.getBillingAddress().getAddress().getAddressLine2() );
        payee.setCityName( addressessByPfinResponse.getBillingAddress().getAddress().getCity() );
        payee.setStateCode( addressessByPfinResponse.getBillingAddress().getAddress().getState() );
        payee.setZipCode( addressessByPfinResponse.getBillingAddress().getAddress().getZipCode() );

        return payee;
    }

    /**
     * @param payee
     * @return
     */
    //This method join the provider firstName and lastName and return providerName
    public String mapPayToPfinName( VbrPayee payee )
    {

        if( StringUtils.isNotBlank( payee.getProviderOrganizationName() ) )
        {

            return ( StringUtils.join( payee.getProviderOrganizationName(),
                                       " ",
                                       payee.getProviderOrganizationSecondName() ) );
        }
        else
        {

            return ( StringUtils.join( payee.getProviderFirstName(),
                                       " ",
                                       payee.getProviderLastName() ) );
        }
    }

}
