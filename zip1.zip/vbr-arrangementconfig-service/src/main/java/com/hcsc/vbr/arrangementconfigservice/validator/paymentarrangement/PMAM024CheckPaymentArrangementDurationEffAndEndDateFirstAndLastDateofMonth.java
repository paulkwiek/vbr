package com.hcsc.vbr.arrangementconfigservice.validator.paymentarrangement;

import java.time.LocalDate;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.hcsc.vbr.arrangementconfigservice.constant.ArrangementConfigServiceErrorMessageConstant;
import com.hcsc.vbr.arrangementconfigservice.constant.ComponentIdConstant;
import com.hcsc.vbr.arrangementconfigservice.constant.FieldIdConstant;
import com.hcsc.vbr.arrangementconfigservice.domain.PaymentArrangement;
import com.hcsc.vbr.arrangementconfigservice.validator.base.BaseValidationUnit;
import com.hcsc.vbr.common.dto.ReturnMessageDTO;
import com.hcsc.vbr.common.utils.VBRDateUtils;

@Component
public class PMAM024CheckPaymentArrangementDurationEffAndEndDateFirstAndLastDateofMonth extends BaseValidationUnit
{
    final Logger LOGGER = LoggerFactory.getLogger( PMAM024CheckPaymentArrangementDurationEffAndEndDateFirstAndLastDateofMonth.class );

    /**
     * Arrangement Duration Effective Date and End Date First Day Last Day Validation 
     * Method: validatePaymentArrangementEffAndEndDate
     * @param dateRecord
     * @param errors
     * @return true  -  when effective date is not First Day of the month  and 
     *                  end date is not equal to effective date or last date of month
     * @return false -  when effective date is First Day of the month  and 
     *                  end date is equal to effective date or last date of month
     * @throws Exception
     */
    public boolean validatePaymentArrangementEffAndEndDateFirstAndLastDateofMonth( PaymentArrangement paymentArrangementSaveRequest,
            ReturnMessageDTO returnMessage ) throws Exception
    {
        LOGGER.debug( "validatePaymentArrangementEffAndEndDateFirstAndLastDateofMonth : START" );

        boolean isDateValid = true;
        if( !( 1 == paymentArrangementSaveRequest.getRecordEffectiveDate().getDayOfMonth() )
            || VBRDateUtils.isNotSameDay( paymentArrangementSaveRequest ) )
        {
            LocalDate ldateOfMonth = VBRDateUtils.getLastDayOfMonth( paymentArrangementSaveRequest.getRecordEndDate() );

            if( !( 1 == paymentArrangementSaveRequest.getRecordEffectiveDate().getDayOfMonth() ) )
            {
                addToReturnMessage( ArrangementConfigServiceErrorMessageConstant.ARRANGEMENT_EFF_DATE_SHOULD_BE_FIRST_DAY_OF_MONTH_ERR,
                                    FieldIdConstant.PMAM_EFF_DATE,
                                    ComponentIdConstant.PMAM,
                                    this.getClass().getSimpleName(),
                                    returnMessage );
                isDateValid = false;
            }

            if( !( ldateOfMonth == paymentArrangementSaveRequest.getRecordEndDate() ) )
            {
                addToReturnMessage( ArrangementConfigServiceErrorMessageConstant.ARRANGEMENT_END_DATE_SHOULD_BE_LAST_DAY_OF_MONTH_ERR,
                                    FieldIdConstant.PMAM_END_DATE,
                                    ComponentIdConstant.PMAM,
                                    this.getClass().getSimpleName(),
                                    returnMessage );
                isDateValid = false;
            }
        }
        LOGGER.debug( "Arrangement Duration Effective Date and End Date  First Day Last Day of Month" + isDateValid );
        LOGGER.debug( "validatePaymentArrangementEffAndEndDateFirstAndLastDateofMonth : START" );
        return isDateValid;

    }

}
