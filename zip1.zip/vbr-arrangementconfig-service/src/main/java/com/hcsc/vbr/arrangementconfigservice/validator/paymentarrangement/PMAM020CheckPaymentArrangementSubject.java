package com.hcsc.vbr.arrangementconfigservice.validator.paymentarrangement;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.util.ObjectUtils;

import com.hcsc.vbr.arrangementconfigservice.constant.ArrangementConfigServiceErrorMessageConstant;
import com.hcsc.vbr.arrangementconfigservice.constant.ComponentIdConstant;
import com.hcsc.vbr.arrangementconfigservice.constant.FieldIdConstant;
import com.hcsc.vbr.arrangementconfigservice.domain.PaymentArrangement;
import com.hcsc.vbr.arrangementconfigservice.validator.base.BaseValidationUnit;
import com.hcsc.vbr.common.dto.ReturnMessageDTO;

@Component
public class PMAM020CheckPaymentArrangementSubject extends BaseValidationUnit
{
    final Logger LOGGER = LoggerFactory.getLogger( PMAM020CheckPaymentArrangementSubject.class );

    public boolean validatePaymentArrangementSubject( PaymentArrangement paymentArrangement,
            ReturnMessageDTO returnMessage ) throws Exception
    {
        LOGGER.debug( "validatePaymentArrangementSubject : START" );
        boolean isMemberSubjectValid = false;
        if( ObjectUtils.isEmpty( paymentArrangement.getPaymentArrangementMemberSubjects() ) )
        {
            addToReturnMessage( ArrangementConfigServiceErrorMessageConstant.NO_ARRANGEMENT_SUBJECT_SELECTED,
                                FieldIdConstant.PMAM_MBR_SBJCT,
                                ComponentIdConstant.PMAM,
                                this.getClass().getSimpleName(),
                                returnMessage );
            isMemberSubjectValid = true;
        }
        LOGGER.debug( "PaymentArrangementSubject Not Empty:" + isMemberSubjectValid );
        LOGGER.debug( "validatePaymentArrangementSubject : START" );
        return isMemberSubjectValid;
    }
}
