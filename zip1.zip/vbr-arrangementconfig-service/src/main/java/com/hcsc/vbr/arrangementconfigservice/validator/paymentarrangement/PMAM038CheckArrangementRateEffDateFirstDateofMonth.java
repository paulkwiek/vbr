package com.hcsc.vbr.arrangementconfigservice.validator.paymentarrangement;

import java.time.LocalDate;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.hcsc.vbr.arrangementconfigservice.constant.ArrangementConfigServiceErrorMessageConstant;
import com.hcsc.vbr.arrangementconfigservice.constant.ComponentIdConstant;
import com.hcsc.vbr.arrangementconfigservice.constant.FieldIdConstant;
import com.hcsc.vbr.arrangementconfigservice.domain.PaymentArrangement;
import com.hcsc.vbr.arrangementconfigservice.domain.PaymentArrangementRate;
import com.hcsc.vbr.arrangementconfigservice.validator.base.BaseValidationUnit;
import com.hcsc.vbr.common.dto.ReturnMessageDTO;
import com.hcsc.vbr.common.utils.VBRDateUtils;

@Component
public class PMAM038CheckArrangementRateEffDateFirstDateofMonth extends BaseValidationUnit
{
    final Logger LOGGER = LoggerFactory.getLogger( PMAM038CheckArrangementRateEffDateFirstDateofMonth.class );

    public boolean validateArrangementRateEffDateFirstDateofMonth( List<PaymentArrangementRate> paymentArrangementRatedateRecordList,
            PaymentArrangement arrangementDate,
            LocalDate processingMonth,
            ReturnMessageDTO returnMessage ) throws Exception
    {
        LOGGER.debug( "validateArrangementRateEffDateFirstDateofMonth : START" );

        boolean isarrangementRateEffDateNotFirstDate = false;

        LocalDate arrangementEffectiveDate = arrangementDate.getRecordEffectiveDate();
        LocalDate lastDateOfProcessingMonth = VBRDateUtils.getLastDayOfMonth( processingMonth );

        for( PaymentArrangementRate arrangementRate : paymentArrangementRatedateRecordList )
        {
            if( !( 1 == arrangementRate.getRecordEffectiveDate().getDayOfMonth() ) || VBRDateUtils.isNotSameDay( arrangementRate ) )
            {
                if( !( 1 == arrangementRate.getRecordEffectiveDate().getDayOfMonth() ) )
                {

                    if( arrangementEffectiveDate.isAfter( lastDateOfProcessingMonth ) )
                    {

                        addToReturnMessage( ArrangementConfigServiceErrorMessageConstant.ARRANGEMENT_RATE_EFF_DATE_SHOULD_BE_FIRST_DAY_OF_MONTH_ERR_FUTURE,
                                            FieldIdConstant.PMAR_EFF_DATE,
                                            ComponentIdConstant.PMAM,
                                            this.getClass().getSimpleName(),
                                            returnMessage );
                        isarrangementRateEffDateNotFirstDate = true;
                    }
                    else
                    {

                        addToReturnMessage( ArrangementConfigServiceErrorMessageConstant.ARRANGEMENT_RATE_EFF_DATE_SHOULD_BE_FIRST_DAY_OF_MONTH_ERR,
                                            FieldIdConstant.PMAR_EFF_DATE,
                                            ComponentIdConstant.PMAM,
                                            this.getClass().getSimpleName(),
                                            returnMessage );
                        isarrangementRateEffDateNotFirstDate = true;
                    }

                }
            }
        }

        LOGGER.debug( "validateArrangementRateEffDateFirstDateofMonth : END" );
        return isarrangementRateEffDateNotFirstDate;
    }

}