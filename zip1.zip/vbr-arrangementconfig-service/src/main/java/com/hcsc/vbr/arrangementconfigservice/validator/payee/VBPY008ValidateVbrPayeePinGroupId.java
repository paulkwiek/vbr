package com.hcsc.vbr.arrangementconfigservice.validator.payee;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.hcsc.vbr.arrangementconfigservice.constant.ArrangementConfigServiceErrorMessageConstant;
import com.hcsc.vbr.arrangementconfigservice.constant.ComponentIdConstant;
import com.hcsc.vbr.arrangementconfigservice.constant.FieldIdConstant;
import com.hcsc.vbr.arrangementconfigservice.domain.VbrPayee;
import com.hcsc.vbr.arrangementconfigservice.validator.base.BaseValidationUnit;
import com.hcsc.vbr.common.dto.ReturnMessageDTO;

@Component
public class VBPY008ValidateVbrPayeePinGroupId extends BaseValidationUnit
{
    private static final Logger LOGGER = LoggerFactory.getLogger( VBPY008ValidateVbrPayeePinGroupId.class );

    /**
     * Method: validateVbrPayeePinGroupIDFieldLength
     * @param payeeSearchRequest
     * @param returnMessage
     * @return
     * @throws Exception
     */
    public boolean validateVbrPayeePinGroupIDFieldLength( VbrPayee vbrPayee,
            ReturnMessageDTO returnMessage ) throws Exception
    {
        LOGGER.debug( "VBPY008ValidateVbrPayeePinGroupId : Start" );

        boolean isPinGrpIdValid = true;
        String pinGroupId = vbrPayee.getPinGroupId();

        if( ( StringUtils.isNotBlank( pinGroupId ) )
            && ( ( !StringUtils.isAlphanumeric( pinGroupId ) ) || ( pinGroupId.length() > 10 ) ) )
        {

            isPinGrpIdValid = false;
            addToReturnMessage( ArrangementConfigServiceErrorMessageConstant.EMPTY_INVALID_PINGROUP_ID,
                                FieldIdConstant.VBPY_PINGROUP_ID,
                                ComponentIdConstant.VBPY,
                                this.getClass().getSimpleName(),
                                returnMessage );

        }
        LOGGER.debug( "VBPY008ValidateVbrPayeePinGroupId : END" );
        return isPinGrpIdValid;
    }
}
