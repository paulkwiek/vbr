package com.hcsc.vbr.arrangementconfigservice.validator.payee;

import java.time.LocalDate;
import java.util.List;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.ObjectUtils;

import com.hcsc.vbr.arrangementconfigservice.apiclient.CalculationServiceApiClient;
import com.hcsc.vbr.arrangementconfigservice.constant.ArrangementConfigServiceErrorMessageConstant;
import com.hcsc.vbr.arrangementconfigservice.constant.ComponentIdConstant;
import com.hcsc.vbr.arrangementconfigservice.constant.FieldIdConstant;
import com.hcsc.vbr.arrangementconfigservice.domain.PaymentArrangement;
import com.hcsc.vbr.arrangementconfigservice.domain.PaymentArrangementPayee;
import com.hcsc.vbr.arrangementconfigservice.domain.VbrPayee;
import com.hcsc.vbr.arrangementconfigservice.repository.PaymentArrangementPayeeRepository;
import com.hcsc.vbr.arrangementconfigservice.repository.PaymentArrangementRepository;
import com.hcsc.vbr.arrangementconfigservice.validator.base.BaseValidationUnit;
import com.hcsc.vbr.arrangementconfigservice.validator.paymentarrangement.PMAM019CheckValidationStatusCode;
import com.hcsc.vbr.common.domain.DateRecord;
import com.hcsc.vbr.common.dto.ReturnMessageDTO;
import com.hcsc.vbr.common.utils.VBRDateUtils;

@Component
public class VBPY019ValidateStatusOfLinkedArrangementsInUpdatePayee extends BaseValidationUnit
{
    private static final Logger LOGGER = LoggerFactory.getLogger( VBPY019ValidateStatusOfLinkedArrangementsInUpdatePayee.class );

    @Autowired
    private CalculationServiceApiClient calculationServiceApiClient;

    @Autowired
    private PaymentArrangementPayeeRepository paymentArrangementPayeeRepository;

    @Autowired
    private PaymentArrangementRepository paymentArrangementRepository;

    @Autowired
    private PMAM019CheckValidationStatusCode checkValidationStatus;

    public boolean validateStatusOFLinkedArrangements( VbrPayee payee,
            ReturnMessageDTO returnMessage ) throws Exception
    {
        LOGGER.debug( "VBPY019ValidateStatusOfLinkedArrangementsInUpdatePayee : START" );

        boolean isStatusUpdated = true;

        boolean isRateInvalid = false;
        boolean isPayeeInvalid = false;
        boolean isProcessingMonthValid = false;

        int warningCount = 0;

        LocalDate processingMonth = calculationServiceApiClient.getCurrentProcessingMonth( payee.getCorporateEntityCode() );

        List<PaymentArrangementPayee> paymentArrangementPayees =
            paymentArrangementPayeeRepository.findByPayeeId( payee.getVbrPayeeId() );

        if( !CollectionUtils.isEmpty( paymentArrangementPayees ) )
        {
            for( PaymentArrangementPayee paymentArrangementPayee : paymentArrangementPayees )
            {

                PaymentArrangement paymentArrangement =
                    paymentArrangementRepository.findByArrangementId( paymentArrangementPayee.getPaymentArrangementId() );
                if( !ObjectUtils.isEmpty( paymentArrangement ) )
                {
                    boolean isPayeeInvalidwithGlobalPayee = isArrangementPayeeDurationValid( payee,
                                                                                             paymentArrangementPayee );

                    boolean isPayeeInvalidWithArrangementDuration = isArrangementPayeeDurationValid( paymentArrangementPayee,
                                                                                                     paymentArrangement );

                    if( isPayeeInvalidwithGlobalPayee || isPayeeInvalidWithArrangementDuration )
                    {
                        isPayeeInvalid = true;
                    }

                    isProcessingMonthValid = isArrangementPayeeValidForProcessingMonth( payee,
                                                                                        paymentArrangementPayees,
                                                                                        paymentArrangement,
                                                                                        paymentArrangement.getCorporateEntityCode() );

                    String status = checkValidationStatus.getValidationStatusCode( paymentArrangement,
                                                                                   isRateInvalid,
                                                                                   isPayeeInvalid,
                                                                                   processingMonth,
                                                                                   isProcessingMonthValid );
                    if( !StringUtils.equalsIgnoreCase( paymentArrangement.getValidationStatusCode(),
                                                       status ) )
                    {
                        warningCount++;
                        paymentArrangement.setValidationStatusCode( status );
                        paymentArrangementRepository.savePaymentArrangement( paymentArrangement );
                    }

                }
            }

            if( warningCount > 0 )
            {
                isStatusUpdated = false;
                // Add Error/Warning to ReturnMessage
                addToReturnMessage( ArrangementConfigServiceErrorMessageConstant.VBR_PAYEE_UPDATE_ARRANGEMENT_STATUS_MESSAGE,
                                    FieldIdConstant.PMAM_STATUS,
                                    ComponentIdConstant.VBPY,
                                    this.getClass().getSimpleName(),
                                    returnMessage );
            }

        }

        LOGGER.debug( "VBPY019ValidateStatusOfLinkedArrangementsInUpdatePayee : END" );

        return isStatusUpdated;

    }

    /**
     * Method: isArrangementPayeeDurationValid
     * @param parent
     * @param child
     * @return
     * @throws Exception
     */
    private boolean isArrangementPayeeDurationValid( DateRecord parent,
            DateRecord child ) throws Exception
    {
        boolean isDateValid = false;
        if( !VBRDateUtils.checkDateCoverage( parent,
                                             child ) )
        {

            isDateValid = true;
        }

        return isDateValid;
    }

    /**
     * Method: isArrangementPayeeValidForProcessingMonth
     * @param parent
     * @param child
     * @return
     * @throws Exception
     */
    private boolean isArrangementPayeeValidForProcessingMonth( VbrPayee vbrPayee,
            List<? extends DateRecord> parent,
            DateRecord child,
            String corporateEntityCode ) throws Exception
    {
        boolean isDateValid = false;
        boolean isVbrPayeDatesNotVoid = false;
        if( VBRDateUtils.isNotSameDay( vbrPayee ) )
        {
            isVbrPayeDatesNotVoid = true;
        }
        LocalDate processMonth = calculationServiceApiClient.getCurrentProcessingMonth( corporateEntityCode );

        List<? extends DateRecord> ArrangementPayeeDateAfterRemovingVoidDates = VBRDateUtils.removeVoidDates( parent );
        if( CollectionUtils.isNotEmpty( ArrangementPayeeDateAfterRemovingVoidDates ) )
        {
            DateRecord parentArrangementPayeeDateRecord =
                VBRDateUtils.convertDateRecordListToDateRecordRange( ArrangementPayeeDateAfterRemovingVoidDates );

            if( ( processMonth.isAfter( parentArrangementPayeeDateRecord.getRecordEffectiveDate() )
                || processMonth.isEqual( parentArrangementPayeeDateRecord.getRecordEffectiveDate() ) )
                && ( processMonth.isBefore( parentArrangementPayeeDateRecord.getRecordEndDate() )
                    || processMonth.isEqual( parentArrangementPayeeDateRecord.getRecordEndDate() ) )
                && isVbrPayeDatesNotVoid )
            {
                isDateValid = true;
            }
        }

        return isDateValid;
    }

}
