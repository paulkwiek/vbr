package com.hcsc.vbr.arrangementconfigservice.validator.ratename;

import org.apache.commons.lang3.ObjectUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.hcsc.vbr.arrangementconfigservice.constant.ArrangementConfigServiceErrorMessageConstant;
import com.hcsc.vbr.arrangementconfigservice.constant.ComponentIdConstant;
import com.hcsc.vbr.arrangementconfigservice.constant.FieldIdConstant;
import com.hcsc.vbr.arrangementconfigservice.domain.FlatRate;
import com.hcsc.vbr.arrangementconfigservice.domain.RateName;
import com.hcsc.vbr.arrangementconfigservice.validator.base.BaseValidationUnit;
import com.hcsc.vbr.common.dto.ReturnMessageDTO;
import com.hcsc.vbr.web.request.RateSaveRequest;

@Component
public class RTNM008CheckRateAmountGreaterThanThousand extends BaseValidationUnit
{
    private static final Logger LOGGER = LoggerFactory.getLogger( RTNM008CheckRateAmountGreaterThanThousand.class );

    /**
     * @param rateSaveRequest
     * @param rateName
     * @param returnMessage
     * @return
     * @throws Exception
     */
    public boolean isRateAmountGreaterThanThousand( RateSaveRequest rateSaveRequest,
            RateName rateName,
            ReturnMessageDTO returnMessage ) throws Exception
    {
        LOGGER.debug( "RTNM008CheckRateAmountGreaterThanThousand : START" );
        boolean validateAmountFlag = true;

        for( FlatRate flatRate : rateName.getFlatRates() )
        {
            if( ( ObjectUtils.allNotNull( flatRate.getMaleFlatRateAmount() )
                && ObjectUtils.allNotNull( flatRate.getFemaleFlatRateAmount() ) ) )
            {
                Double maleFlateRateAmt = flatRate.getMaleFlatRateAmount();
                Double femaleFlateRateAmt = flatRate.getFemaleFlatRateAmount();

                // check - Throw warning message if rate amount is greater than 999.99
                if( !rateSaveRequest.isWarningState() )
                {
                    if( ( maleFlateRateAmt >= 1000 && maleFlateRateAmt < 1000000 )
                        && ( femaleFlateRateAmt >= 1000 && femaleFlateRateAmt < 1000000 ) )

                    {
                        //Set return flag to false
                        validateAmountFlag = false;
                        //Add Error/Warning to ReturnMessage
                        addToReturnMessage( ArrangementConfigServiceErrorMessageConstant.RATE_AMOUNT_GREATER_OR_EQUAL_TO_1000_DOLLAR,
                                            FieldIdConstant.RTNM_FLAT_RATE_AMT,
                                            ComponentIdConstant.RTNM,
                                            this.getClass().getSimpleName(),
                                            returnMessage );
                        break;

                    }
                }

            }
            else
            {
                validateAmountFlag = false;
                break;
            }
        }
        LOGGER.debug( "RTNM008CheckRateAmountGreaterThanThousand : END" );
        return validateAmountFlag;

    }
}
