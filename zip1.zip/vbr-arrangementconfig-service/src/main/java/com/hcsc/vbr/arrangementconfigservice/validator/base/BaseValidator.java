package com.hcsc.vbr.arrangementconfigservice.validator.base;

import java.util.List;

import com.hcsc.vbr.arrangementconfigservice.constant.ArrangementConfigServiceErrorMessageConstant;
import com.hcsc.vbr.arrangementconfigservice.constant.ComponentIdConstant;
import com.hcsc.vbr.arrangementconfigservice.constant.FieldIdConstant;
import com.hcsc.vbr.arrangementconfigservice.domain.FlatRate;
import com.hcsc.vbr.arrangementconfigservice.domain.PaymentArrangement;
import com.hcsc.vbr.arrangementconfigservice.domain.PaymentArrangementPayee;
import com.hcsc.vbr.arrangementconfigservice.domain.PaymentArrangementRate;
import com.hcsc.vbr.arrangementconfigservice.domain.VbrPayee;
import com.hcsc.vbr.arrangementconfigservice.dto.ErrorMessageDTO;
import com.hcsc.vbr.arrangementconfigservice.dto.FlatRateDTO;
import com.hcsc.vbr.arrangementconfigservice.dto.PaymentArrangementDTO;
import com.hcsc.vbr.arrangementconfigservice.dto.PaymentArrangementPayeeDTO;
import com.hcsc.vbr.arrangementconfigservice.dto.PaymentArrangementRateDTO;
import com.hcsc.vbr.arrangementconfigservice.dto.ValidateDatesDTO;
import com.hcsc.vbr.arrangementconfigservice.dto.VbrPayeeDTO;
import com.hcsc.vbr.common.domain.DateRecord;
import com.hcsc.vbr.common.dto.DateRecordDTO;
import com.hcsc.vbr.common.dto.ReturnMessageDTO;
import com.hcsc.vbr.common.utils.VBRDateUtils;
import com.hcsc.vbr.common.validator.base.VbrBaseValidator;

public class BaseValidator extends VbrBaseValidator
{

    /**
     * Adds the to error list.
     * @param errors the errors
     * @param errorId the error id
     */

    public static void addToErrorList( List<ErrorMessageDTO> errors,
            Long errorId )
    {
        ErrorMessageDTO errorMessageDTO = new ErrorMessageDTO();
        errorMessageDTO.setErrorMessageId( errorId );
        errors.add( errorMessageDTO );
    }

    /***created these validation methods  for rate amount,eff and end date validations****/
    /**
     * Method to check amount field has decimal 
     * upto 2 digits and returns flag true 
     * if decimal digits is 2
     */
    public boolean checkAmountDecimal( Double d )
    {
        boolean flag = false;
        String text = Double.toString( Math.abs( d ) );
        int integerPlaces = text.indexOf( '.' );
        int decimalPlaces = text.length() - integerPlaces - 1;
        if( decimalPlaces == 2 || decimalPlaces == 1 || decimalPlaces == 0 )
        {
            flag = true;
        }
        return flag;
    }

    //Check date format is a common validation in all API and placing it in BaseValidator.
    public static boolean checkDateFormat( DateRecordDTO dateRecordDTO,
            List<ErrorMessageDTO> errors )

    {
        boolean effDateflag = false;
        boolean endDateFlag = false;
        boolean isDateFormatValid = false;

        String effStrDate = dateRecordDTO.getRecordEffectiveDate();
        String endStrDate = dateRecordDTO.getRecordEndDate();

        effDateflag = VBRDateUtils.isThisDateValid( effStrDate );

        endDateFlag = VBRDateUtils.isThisDateValid( endStrDate );

        if( effDateflag == false || endDateFlag == false )
        {
            isDateFormatValid = false;
        }
        else if( effDateflag == true & endDateFlag == true )
        {
            isDateFormatValid = true;
        }

        if( effDateflag == false )
        {
            if( dateRecordDTO instanceof FlatRateDTO )
            {

                addToErrorList( errors,
                                ArrangementConfigServiceErrorMessageConstant.FLAT_RT_EFF_DATE_MM_DD_YYYY_FORMAT );
            }
            else if( dateRecordDTO instanceof PaymentArrangementDTO )
            {

                addToErrorList( errors,
                                ArrangementConfigServiceErrorMessageConstant.PMT_ARR_EFF_DATE_MM_DD_YYYY_FORMAT );
            }
            else if( dateRecordDTO instanceof VbrPayeeDTO )
            {
                addToErrorList( errors,
                                ArrangementConfigServiceErrorMessageConstant.VBR_PAYEE_EFF_DATE_MM_DD_YYYY_FORMAT );
            }
            else if( dateRecordDTO instanceof PaymentArrangementRateDTO )
            {
                addToErrorList( errors,
                                ArrangementConfigServiceErrorMessageConstant.PMT_ARR_RATE_EFF_DATE_MM_DD_YYYY_FORMAT );
            }
            else if( dateRecordDTO instanceof PaymentArrangementPayeeDTO )
            {
                addToErrorList( errors,
                                ArrangementConfigServiceErrorMessageConstant.PMT_ARR_PAYEE_EFF_DATE_MM_DD_YYYY_FORMAT );
            }
            //            else if( dateRecordDTO instanceof ValidateDatesDTO )
            //            {
            //                addToErrorList( errors,
            //                                ArrangementConfigServiceConstant.PMT_ARR_RATE_EFF_DATE_MM_DD_YYYY_FORMAT );
            //            }
        }
        if( endDateFlag == false )
        {
            if( dateRecordDTO instanceof FlatRateDTO )
            {

                addToErrorList( errors,
                                ArrangementConfigServiceErrorMessageConstant.FLAT_RT_END_DATE_MM_DD_YYYY_FORMAT );
            }
            else if( dateRecordDTO instanceof PaymentArrangementDTO )
            {

                addToErrorList( errors,
                                ArrangementConfigServiceErrorMessageConstant.PMT_ARR_END_DATE_MM_DD_YYYY_FORMAT );
            }
            else if( dateRecordDTO instanceof VbrPayeeDTO )
            {
                addToErrorList( errors,
                                ArrangementConfigServiceErrorMessageConstant.VBR_PAYEE_END_DATE_MM_DD_YYYY_FORMAT );
            }
            else if( dateRecordDTO instanceof PaymentArrangementRateDTO )
            {
                addToErrorList( errors,
                                ArrangementConfigServiceErrorMessageConstant.PMT_ARR_RATE_END_DATE_MM_DD_YYYY_FORMAT );
            }
            else if( dateRecordDTO instanceof PaymentArrangementPayeeDTO )
            {
                addToErrorList( errors,
                                ArrangementConfigServiceErrorMessageConstant.PMT_ARR_PAYEE_END_DATE_MM_DD_YYYY_FORMAT );
            }
            //            else if( dateRecordDTO instanceof ValidateDatesDTO )
            //            {
            //                addToErrorList( errors,
            //                                ArrangementConfigServiceConstant.PMT_ARR_RATE_END_DATE_MM_DD_YYYY_FORMAT );
            //            }
        }
        return isDateFormatValid;
    }

    /**
     * Method: checkDateFormat
     * @param dateRecord
     * @param returnMessage
     * @return
     * @throws Exception
     */
    public boolean checkDateFormat( DateRecord dateRecord,
            ReturnMessageDTO returnMessage ) throws Exception

    {
        boolean effDateflag = false;
        boolean endDateFlag = false;
        boolean isDateFormatValid = false;

        String effStrDate = VBRDateUtils.convertLocalDateToString( dateRecord.getRecordEffectiveDate() );
        String endStrDate = VBRDateUtils.convertLocalDateToString( dateRecord.getRecordEndDate() );

        effDateflag = VBRDateUtils.isThisDateValid( effStrDate );

        endDateFlag = VBRDateUtils.isThisDateValid( endStrDate );

        if( effDateflag == false || endDateFlag == false )
        {
            isDateFormatValid = false;
        }
        else if( effDateflag == true & endDateFlag == true )
        {
            isDateFormatValid = true;
        }

        if( effDateflag == false )
        {
            if( dateRecord instanceof FlatRate )
            {

                addToReturnMessage( ArrangementConfigServiceErrorMessageConstant.FLAT_RT_EFF_DATE_MM_DD_YYYY_FORMAT,
                                    FieldIdConstant.RTNM_EFF_DATE,
                                    ComponentIdConstant.RTNM,
                                    this.getClass().getSimpleName(),
                                    returnMessage );
            }
            else if( dateRecord instanceof PaymentArrangement )
            {

                addToReturnMessage( ArrangementConfigServiceErrorMessageConstant.PMT_ARR_EFF_DATE_MM_DD_YYYY_FORMAT,
                                    FieldIdConstant.PMAM_EFF_DATE,
                                    ComponentIdConstant.PMAM,
                                    this.getClass().getSimpleName(),
                                    returnMessage );
            }
            else if( dateRecord instanceof VbrPayee )
            {
                addToReturnMessage( ArrangementConfigServiceErrorMessageConstant.VBR_PAYEE_EFF_DATE_MM_DD_YYYY_FORMAT,
                                    FieldIdConstant.VBPY_EFF_DATE,
                                    ComponentIdConstant.VBPY,
                                    this.getClass().getSimpleName(),
                                    returnMessage );
            }
            else if( dateRecord instanceof PaymentArrangementRate )
            {
                addToReturnMessage( ArrangementConfigServiceErrorMessageConstant.PMT_ARR_RATE_EFF_DATE_MM_DD_YYYY_FORMAT,
                                    FieldIdConstant.PMAR_EFF_DATE,
                                    ComponentIdConstant.PMAR,
                                    this.getClass().getSimpleName(),
                                    returnMessage );
            }
            else if( dateRecord instanceof PaymentArrangementPayee )
            {
                addToReturnMessage( ArrangementConfigServiceErrorMessageConstant.PMT_ARR_PAYEE_EFF_DATE_MM_DD_YYYY_FORMAT,
                                    FieldIdConstant.PMPY_EFF_DATE,
                                    ComponentIdConstant.PMPY,
                                    this.getClass().getSimpleName(),
                                    returnMessage );
            }
            else if( dateRecord instanceof ValidateDatesDTO )
            {
                addToReturnMessage( ArrangementConfigServiceErrorMessageConstant.PMT_ARR_RATE_EFF_DATE_MM_DD_YYYY_FORMAT,
                                    FieldIdConstant.PMAR_EFF_DATE,
                                    ComponentIdConstant.PMAR,
                                    this.getClass().getSimpleName(),
                                    returnMessage );
            }
        }
        if( endDateFlag == false )
        {
            if( dateRecord instanceof FlatRate )
            {

                addToReturnMessage( ArrangementConfigServiceErrorMessageConstant.FLAT_RT_END_DATE_MM_DD_YYYY_FORMAT,
                                    FieldIdConstant.RTNM_END_DATE,
                                    ComponentIdConstant.RTNM,
                                    this.getClass().getSimpleName(),
                                    returnMessage );
            }
            else if( dateRecord instanceof PaymentArrangement )
            {

                addToReturnMessage( ArrangementConfigServiceErrorMessageConstant.PMT_ARR_END_DATE_MM_DD_YYYY_FORMAT,
                                    FieldIdConstant.PMAM_END_DATE,
                                    ComponentIdConstant.PMAM,
                                    this.getClass().getSimpleName(),
                                    returnMessage );
            }
            else if( dateRecord instanceof VbrPayee )
            {
                addToReturnMessage( ArrangementConfigServiceErrorMessageConstant.VBR_PAYEE_END_DATE_MM_DD_YYYY_FORMAT,
                                    FieldIdConstant.VBPY_END_DATE,
                                    ComponentIdConstant.VBPY,
                                    this.getClass().getSimpleName(),
                                    returnMessage );
            }
            else if( dateRecord instanceof PaymentArrangementRate )
            {
                addToReturnMessage( ArrangementConfigServiceErrorMessageConstant.PMT_ARR_RATE_END_DATE_MM_DD_YYYY_FORMAT,
                                    FieldIdConstant.PMAR_END_DATE,
                                    ComponentIdConstant.PMAR,
                                    this.getClass().getSimpleName(),
                                    returnMessage );
            }
            else if( dateRecord instanceof PaymentArrangementPayee )
            {
                addToReturnMessage( ArrangementConfigServiceErrorMessageConstant.PMT_ARR_PAYEE_END_DATE_MM_DD_YYYY_FORMAT,
                                    FieldIdConstant.PMPY_END_DATE,
                                    ComponentIdConstant.PMPY,
                                    this.getClass().getSimpleName(),
                                    returnMessage );
            }
            else if( dateRecord instanceof ValidateDatesDTO )
            {
                addToReturnMessage( ArrangementConfigServiceErrorMessageConstant.PMT_ARR_RATE_END_DATE_MM_DD_YYYY_FORMAT,
                                    FieldIdConstant.PMAR_END_DATE,
                                    ComponentIdConstant.PMAR,
                                    this.getClass().getSimpleName(),
                                    returnMessage );
            }
        }
        return isDateFormatValid;
    }

}
