package com.hcsc.vbr.arrangementconfigservice.validator.paymentarrangement;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.util.ObjectUtils;

import com.hcsc.vbr.arrangementconfigservice.constant.ArrangementConfigServiceErrorMessageConstant;
import com.hcsc.vbr.arrangementconfigservice.constant.ComponentIdConstant;
import com.hcsc.vbr.arrangementconfigservice.constant.FieldIdConstant;
import com.hcsc.vbr.arrangementconfigservice.domain.PaymentArrangementPayee;
import com.hcsc.vbr.arrangementconfigservice.validator.base.BaseValidationUnit;
import com.hcsc.vbr.common.dto.ReturnMessageDTO;

@Component
public class PMAM029CheckForNullPaymentArrangementPayeeDuration extends BaseValidationUnit
{
    final Logger LOGGER = LoggerFactory.getLogger( PMAM029CheckForNullPaymentArrangementPayeeDuration.class );

    /**
     * Method: validatePaymentArrangementPayeeEffectiveAndEndDatesList
     * @param dateRecordList
     * @param errors
     * @return
     * @throws Exception
     */
    public boolean isPaymentArrangementPayeeDatesEmpty( List<PaymentArrangementPayee> paymentArrangementPayees,
            ReturnMessageDTO returnMessage ) throws Exception
    {
        LOGGER.debug( "isPaymentArrangementPayeeDatesEmpty : START" );

        boolean isDateValid = false;
        for( PaymentArrangementPayee payee : paymentArrangementPayees )
        {
            if( ObjectUtils.isEmpty( payee.getRecordEffectiveDate() ) || ObjectUtils.isEmpty( payee.getRecordEndDate() ) )
            {

                addToReturnMessage( ArrangementConfigServiceErrorMessageConstant.ARRNG_PAYEE_DURATION_MANDATORY_FIELD,
                                    FieldIdConstant.PMPY_EFF_AND_END_DATE,
                                    ComponentIdConstant.PMPY,
                                    this.getClass().getSimpleName(),
                                    returnMessage );
                isDateValid = true;
            }
        }
        LOGGER.debug( "PaymentArrangementPayee Dates Empty:" + isDateValid );
        LOGGER.debug( "isPaymentArrangementPayeeDatesEmpty : END" );

        return isDateValid;
    }
}