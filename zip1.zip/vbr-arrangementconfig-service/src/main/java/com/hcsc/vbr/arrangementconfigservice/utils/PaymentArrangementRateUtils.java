package com.hcsc.vbr.arrangementconfigservice.utils;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.hcsc.vbr.arrangementconfigservice.domain.PaymentArrangementRate;
import com.hcsc.vbr.common.domain.DateRecord;

@Component
public class PaymentArrangementRateUtils
{
    /**
     * This method will return all the flat Rates falls under Arrangement Rate Date Range.
     * Method: getFlatRatesOfArrRateDuration
     * @param flatRateDates
     * @param arrRateDateRecord
     * @return flatRateDateRecords
     */
    public static List<DateRecord> getFlatRatesOfArrRateDuration( List<? extends DateRecord> flatRateDates,
            PaymentArrangementRate arrRateDateRecord )
    {
        List<DateRecord> flatRates = new ArrayList<DateRecord>();
        for( DateRecord flatRateDate : flatRateDates )
        {
            if( flatRateDate.getRecordEndDate().isAfter( arrRateDateRecord.getRecordEffectiveDate() )
                && flatRateDate.getRecordEffectiveDate().isBefore( arrRateDateRecord.getRecordEndDate() ) )
            {
                flatRates.add( flatRateDate );
            }
        }
        return flatRates;
    }

}
