package com.hcsc.vbr.arrangementconfigservice.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hcsc.vbr.arrangementconfigservice.constant.ComponentIdConstant;
import com.hcsc.vbr.arrangementconfigservice.domain.PaymentArrangementRate;
import com.hcsc.vbr.arrangementconfigservice.mapper.PaymentArrangementMapper;
import com.hcsc.vbr.arrangementconfigservice.service.base.BaseService;
import com.hcsc.vbr.arrangementconfigservice.validator.paymentarrangementrate.PaymentArrangmentRateValidator;
import com.hcsc.vbr.common.dto.ReturnMessageDTO;
import com.hcsc.vbr.web.request.ValidateArrangementRateRequest;
import com.hcsc.vbr.web.response.ValidateArrangementRateResponse;

@Service
public class PaymentArrangementRateService extends BaseService
{
    @Autowired
    private PaymentArrangmentRateValidator paymentArrangmentRateValidator;

    @Autowired
    private PaymentArrangementMapper paymentArrangementMapper;

    /**
     * This method will validate and throw if error exist else the sucess Response.
     * Method: validatePaymentArrangementRate
     * @param validateArrangementRateRequest
     * @return validateArrangementRateResponse
     * @throws Exception
     */
    public ValidateArrangementRateResponse validatePaymentArrangementRate(
            ValidateArrangementRateRequest validateArrangementRateRequest ) throws Exception
    {

        ValidateArrangementRateResponse validateArrangementRateResponse = new ValidateArrangementRateResponse();
        ReturnMessageDTO returnMessage = new ReturnMessageDTO( ComponentIdConstant.PMAM );
        PaymentArrangementRate paymentArrangementRate =
            paymentArrangementMapper.toPaymentArrangementRate( validateArrangementRateRequest.getPaymentArrangementRate() );
        paymentArrangmentRateValidator.validatePaymentArrangementRate( paymentArrangementRate,
                                                                       returnMessage );
        validateArrangementRateResponse.setMessage( "SUCCESS" );
        validateArrangementRateResponse.setReturnMessage( returnMessage );
        return validateArrangementRateResponse;
    }

}