package com.hcsc.vbr.arrangementconfigservice.service.base;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.hcsc.vbr.arrangementconfigservice.constant.ArrangementConfigServiceConstant;
import com.hcsc.vbr.arrangementconfigservice.dto.VbrPayeeDTO;
import com.hcsc.vbr.arrangementconfigservice.utils.ArrangementConfigServiceUtils;
import com.hcsc.vbr.common.constant.VBRCommonConstant;
import com.hcsc.vbr.common.dto.ErrorMessageDTO;
import com.hcsc.vbr.common.dto.ProviderDTO;
import com.hcsc.vbr.common.dto.ReturnMessageDTO;
import com.hcsc.vbr.common.utils.VBRDateUtils;
import com.hcsc.vbr.web.request.PayeeSearchRequest;
import com.hcsc.vbr.web.request.ProviderAPIRequest;

public class BaseService
{

    @Autowired
    private ArrangementConfigServiceUtils arrangementConfigServiceUtils;

    final Logger LOGGER = LoggerFactory.getLogger( BaseService.class );

    /**
     * checks count of errors
     * @param errors
     * @return
     * @throws Exception
     */
    public Integer checkErrorCount( ReturnMessageDTO errors ) throws Exception
    {

        Integer count = 0;
        for( ErrorMessageDTO error : errors.getErrors() )
        {
            if( StringUtils.equalsIgnoreCase( error.getSeveritylevel(),
                                              VBRCommonConstant.SEVERITY_ERROR ) )
            {
                count++;
            }
        }
        return count;
    }

    /**
     * filters warnings from errors 
     * @param errors (Here we are giving error id's and fetching the severity level from codeServiceApiClient to filter the warnings)
     * @return
     * @throws Exception
     */
    public List<ErrorMessageDTO> filterWarnings( ReturnMessageDTO returnMessageDTO ) throws Exception
    {
        List<ErrorMessageDTO> warningsList = new ArrayList<ErrorMessageDTO>();

        for( ErrorMessageDTO error : returnMessageDTO.getErrors() )
        {
            if( StringUtils.equalsIgnoreCase( error.getSeveritylevel(),
                                              VBRCommonConstant.SEVERITY_WARNING ) )
            {
                warningsList.add( error );
            }
        }
        return warningsList;
    }

    /**
     * gets the list of warning messages
     * @param errors
     * @return
     */
    public List<ErrorMessageDTO> getWarnings( List<ErrorMessageDTO> errors )
    {
        List<ErrorMessageDTO> warningList = new ArrayList<ErrorMessageDTO>();
        for( ErrorMessageDTO list : errors )
        {
            if( StringUtils.equalsIgnoreCase( list.getSeveritylevel(),
                                              VBRCommonConstant.SEVERITY_WARNING )
                && ( !( list.getErrorMessageId() == 244 ) )
                && ( !( list.getErrorMessageId() == 291 ) ) )
            {
                warningList.add( list );
            }
        }
        return warningList;
    }

    /**
     * Method: filterErrors
     * @param errors
     * @return
     * @throws Exception
     */
    public List<ErrorMessageDTO> filterErrors( ReturnMessageDTO errors ) throws Exception
    {
        List<ErrorMessageDTO> errorsList = new ArrayList<ErrorMessageDTO>();

        for( ErrorMessageDTO error : errors.getErrors() )
        {
            if( arrangementConfigServiceUtils.isNotConfirmMessage( error ) )
            {
                errorsList.add( error );
            }
        }
        return errorsList;
    }

    /**
     * Method: checkConfirmMessageCount
     * @param errors
     * @return
     * @throws Exception
     */
    public ReturnMessageDTO filterConfirmMessageErrors( ReturnMessageDTO errors ) throws Exception
    {
        ReturnMessageDTO returnMessage = new ReturnMessageDTO();
        List<ErrorMessageDTO> filterConfirmMessage = new ArrayList<ErrorMessageDTO>();
        for( ErrorMessageDTO error : errors.getErrors() )
        {
            if( arrangementConfigServiceUtils.isConfirmMessage( error ) )
            {
                filterConfirmMessage.add( error );
                returnMessage.setErrors( filterConfirmMessage );
            }
        }
        return returnMessage;
    }

    /**
     * Method: checkConfirmMessageCount
     * @param errors
     * @return
     * @throws Exception
     */
    public Integer checkNonConfirmMessageErrorCount( ReturnMessageDTO errors ) throws Exception
    {
        Integer count = 0;

        for( ErrorMessageDTO error : errors.getErrors() )
        {
            if( arrangementConfigServiceUtils.isNotConfirmMessage( error ) )
            {
                count++;
            }
        }
        return count;
    }

    /**
     * converts date format
     * @param vbrPayeeDTO
     * @return
     */
    public VbrPayeeDTO updateDateFormat( VbrPayeeDTO vbrPayeeDTO )
    {
        vbrPayeeDTO.setPfinEffectiveDate( convertDateFormat( vbrPayeeDTO.getPfinEffectiveDate() ) );
        vbrPayeeDTO.setPfinEndDate( convertDateFormat( vbrPayeeDTO.getPfinEndDate() ) );
        vbrPayeeDTO.setTinEffectiveDate( convertDateFormat( vbrPayeeDTO.getTinEffectiveDate() ) );
        vbrPayeeDTO.setTinEndDate( convertDateFormat( vbrPayeeDTO.getTinEndDate() ) );
        vbrPayeeDTO.setPinGroupEffectiveDate( convertDateFormat( vbrPayeeDTO.getPinGroupEffectiveDate() ) );
        vbrPayeeDTO.setPinGroupEndDate( convertDateFormat( vbrPayeeDTO.getPinGroupEndDate() ) );
        vbrPayeeDTO.setNetworkAssociationEffectiveDate( convertDateFormat( vbrPayeeDTO.getNetworkAssociationEffectiveDate() ) );
        vbrPayeeDTO.setNetworkAssociationEndDate( convertDateFormat( vbrPayeeDTO.getNetworkAssociationEndDate() ) );
        vbrPayeeDTO.setPINGroupCapitationEffectiveDate( convertDateFormat( vbrPayeeDTO.getPINGroupCapitationEffectiveDate() ) );
        vbrPayeeDTO.setPINGroupCapitationEndDate( convertDateFormat( vbrPayeeDTO.getPINGroupCapitationEndDate() ) );
        return vbrPayeeDTO;
    }

    public String convertDateFormat( String date )
    {
        return VBRDateUtils.convertLocalDateToString( VBRDateUtils.convertStringToLocalDate( date ) );
    }

    /**
     * Creates the provider API request.
     * @param payeeSaveRequest the payee retrieve request
     * @return the provider API request
     */
    public ProviderAPIRequest createProviderAPIRequest( List<PayeeSearchRequest> searchRequestList )
    {
        List<ProviderDTO> list = new ArrayList<ProviderDTO>();

        for( PayeeSearchRequest searchRequest : searchRequestList )
        {
            ProviderDTO providerDTO = new ProviderDTO();
            providerDTO.setCorpCode( searchRequest.getCorpEntityCode() );
            providerDTO.setPinGroupID( searchRequest.getPinGroupId() );

            String networkCode = searchRequest.getNetworkCode();
            String payToPFIN = searchRequest.getPayToPFIN();
            String capitationTypeCode = searchRequest.getCapitationTypeCode();
            String processCode = searchRequest.getProcessCode();

            providerDTO.setNetworkAssociationID( searchRequest.getNetworkAssociationID() );
            providerDTO.setNetworkCode( StringUtils.isNotEmpty( networkCode ) ? networkCode
                : null );
            providerDTO.setPayToPFIN( StringUtils.isNotEmpty( payToPFIN ) ? payToPFIN
                : null );
            providerDTO.setCapitationTypeCode( StringUtils.isNotEmpty( capitationTypeCode ) ? capitationTypeCode
                : null );
            providerDTO.setProcessCode( StringUtils.isNotEmpty( processCode ) ? processCode
                : null );

            list.add( providerDTO );
        }

        ProviderAPIRequest providerAPIRequest = new ProviderAPIRequest();
        providerAPIRequest.setClientId( ArrangementConfigServiceConstant.DEFAULT_CLIENT_ID );
        providerAPIRequest.setProvider( list );

        return providerAPIRequest;

    }

    /**
     * Method: filterExpiredWarningMessage
     * @param returnMessage
     * @return
     */
    public ReturnMessageDTO filterExpiredWarningMessage( ReturnMessageDTO returnMessage )
    {
        LOGGER.debug( "filterExpiredWarningMessage : START" );
        LOGGER.debug( "filterExpiredWarningMessage returnMessage: " + returnMessage );

        List<ErrorMessageDTO> warnings = returnMessage.getWarnings();
        List<ErrorMessageDTO> filterwarnings = new ArrayList<ErrorMessageDTO>();

        for( ErrorMessageDTO warning : warnings )
        {
            if( StringUtils.equalsIgnoreCase( warning.getSeveritylevel(),
                                              VBRCommonConstant.SEVERITY_WARNING )
                && ( !( warning.getErrorMessageId() == 244 ) )
                && ( !( warning.getErrorMessageId() == 291 ) ) )
            {

                filterwarnings.add( warning );
            }
        }

        returnMessage.getWarnings().removeAll( filterwarnings );

        LOGGER.debug( "filterExpiredWarningMessage warningMessage: " + returnMessage );
        LOGGER.debug( "filterExpiredWarningMessage : End" );
        return returnMessage;
    }

}
