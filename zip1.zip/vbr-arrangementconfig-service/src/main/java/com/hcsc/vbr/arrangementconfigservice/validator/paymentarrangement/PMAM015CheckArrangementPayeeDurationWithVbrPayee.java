package com.hcsc.vbr.arrangementconfigservice.validator.paymentarrangement;

import java.time.LocalDate;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.hcsc.vbr.arrangementconfigservice.constant.ArrangementConfigServiceErrorMessageConstant;
import com.hcsc.vbr.arrangementconfigservice.constant.ComponentIdConstant;
import com.hcsc.vbr.arrangementconfigservice.constant.FieldIdConstant;
import com.hcsc.vbr.arrangementconfigservice.domain.PaymentArrangement;
import com.hcsc.vbr.arrangementconfigservice.domain.PaymentArrangementPayee;
import com.hcsc.vbr.arrangementconfigservice.domain.VbrPayee;
import com.hcsc.vbr.arrangementconfigservice.validator.base.BaseValidationUnit;
import com.hcsc.vbr.common.dto.ReturnMessageDTO;
import com.hcsc.vbr.common.utils.VBRDateUtils;

@Component
public class PMAM015CheckArrangementPayeeDurationWithVbrPayee extends BaseValidationUnit
{
    final Logger LOGGER = LoggerFactory.getLogger( PMAM015CheckArrangementPayeeDurationWithVbrPayee.class );

    /**
     * Method: validateArrangementPayeeDurationWithVbrPayee
     * @param payeeparentdaterecord
     * @param arrangementPayeechilddaterecord
     * @param arrangementDate
     * @param processingMonth
     * @param returnMessage
     * @return
     * @throws Exception
     */
    public boolean validateArrangementPayeeDurationWithVbrPayee( VbrPayee payeeparentdaterecord,
            PaymentArrangementPayee arrangementPayeechilddaterecord,
            PaymentArrangement arrangementDate,
            LocalDate processingMonth,
            ReturnMessageDTO returnMessage ) throws Exception
    {
        LOGGER.debug( "validateArrangementPayeeDurationWithVbrPayee : START" );

        boolean isDateValid = false;
        LocalDate arrangementEffectiveDate = arrangementDate.getRecordEffectiveDate();
        LocalDate lastDateOfProcessingMonth = VBRDateUtils.getLastDayOfMonth( processingMonth );
        if( !VBRDateUtils.checkDateCoverage( payeeparentdaterecord,
                                             arrangementPayeechilddaterecord ) )
        {
            if( arrangementEffectiveDate.isAfter( lastDateOfProcessingMonth ) )
            {
                addToReturnMessage( ArrangementConfigServiceErrorMessageConstant.VBRPAYEE_DATE_AND_ARRANGEMENTPAYEE_VALIDATION_FUTURE,
                                    FieldIdConstant.PMPY_EFF_AND_END_DATE,
                                    ComponentIdConstant.PMAM,
                                    this.getClass().getSimpleName(),
                                    returnMessage );
            }
            else
            {
                addToReturnMessage( ArrangementConfigServiceErrorMessageConstant.VBRPAYEE_DATE_AND_ARRANGEMENTPAYEE_VALIDATION,
                                    FieldIdConstant.PMPY_EFF_AND_END_DATE,
                                    ComponentIdConstant.PMAM,
                                    this.getClass().getSimpleName(),
                                    returnMessage );
            }
            isDateValid = true;
        }
        LOGGER.debug( "ArrangementPayeeDuration not within VbrPayee :" + isDateValid );
        LOGGER.debug( "validateArrangementPayeeDurationWithVbrPayee : END" );
        return isDateValid;
    }

}
