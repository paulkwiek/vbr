package com.hcsc.vbr.arrangementconfigservice.validator.paymentarrangement;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.hcsc.vbr.arrangementconfigservice.constant.ArrangementConfigServiceErrorMessageConstant;
import com.hcsc.vbr.arrangementconfigservice.constant.ComponentIdConstant;
import com.hcsc.vbr.arrangementconfigservice.constant.FieldIdConstant;
import com.hcsc.vbr.arrangementconfigservice.domain.PaymentArrangement;
import com.hcsc.vbr.arrangementconfigservice.utils.ArrangementConfigServiceUtils;
import com.hcsc.vbr.arrangementconfigservice.validator.base.BaseValidationUnit;
import com.hcsc.vbr.common.dto.ReturnMessageDTO;

@Component
public class PMAM030CheckPaymentArrangementExpiredStatus extends BaseValidationUnit
{
    final Logger LOGGER = LoggerFactory.getLogger( PMAM030CheckPaymentArrangementExpiredStatus.class );

    @Autowired
    private ArrangementConfigServiceUtils arrangementConfigServiceUtils;

    /**
     * Sets the Warning Message for the Arrangement whose Status is Expired.
     *
     * @param errors                        the errors
     * @throws Exception                    the exception
     */
    public boolean setWarningForExpiredArrangement( PaymentArrangement paymentArrangement,
            ReturnMessageDTO returnMessage ) throws Exception
    {
        LOGGER.debug( "setWarningForExpiredArrangement : START" );
        boolean isDateValid = false;
        if( ( arrangementConfigServiceUtils.checkArrangementLocalDateEffandEndDateEqual( paymentArrangement.getRecordEndDate(),
                                                                                         paymentArrangement
                                                                                                 .getRecordEffectiveDate() ) ) )
        {
            addToReturnMessage( ArrangementConfigServiceErrorMessageConstant.ARRNG_DURATION_VOIDED,
                                FieldIdConstant.PMAM_EFF_AND_END_DATE,
                                ComponentIdConstant.PMAM,
                                this.getClass().getSimpleName(),
                                returnMessage );
            isDateValid = true;
        }
        else
        {
            addToReturnMessage( ArrangementConfigServiceErrorMessageConstant.ARRANGEMENT_DURATION_IN_PAST,
                                FieldIdConstant.PMAM_EFF_AND_END_DATE,
                                ComponentIdConstant.PMAM,
                                this.getClass().getSimpleName(),
                                returnMessage );
            isDateValid = true;
        }

        LOGGER.debug( "setWarningForExpiredArrangement : END" );
        return isDateValid;
    }
}
