package com.hcsc.vbr.arrangementconfigservice.validator.paymentarrangement;

import java.time.LocalDate;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.hcsc.vbr.arrangementconfigservice.constant.ArrangementConfigServiceErrorMessageConstant;
import com.hcsc.vbr.arrangementconfigservice.constant.ComponentIdConstant;
import com.hcsc.vbr.arrangementconfigservice.constant.FieldIdConstant;
import com.hcsc.vbr.arrangementconfigservice.domain.PaymentArrangement;
import com.hcsc.vbr.arrangementconfigservice.domain.PaymentArrangementRate;
import com.hcsc.vbr.arrangementconfigservice.validator.base.BaseValidationUnit;
import com.hcsc.vbr.common.dto.ReturnMessageDTO;
import com.hcsc.vbr.common.utils.VBRDateUtils;

@Component
public class PMAM037CheckArrangementRateEffEnddateEqualorBefore extends BaseValidationUnit
{
    final Logger LOGGER = LoggerFactory.getLogger( PMAM037CheckArrangementRateEffEnddateEqualorBefore.class );

    public boolean validateArrangementRateEffEnddateEqualorBefore( List<PaymentArrangementRate> paymentArrangementRatedateRecordList,
            PaymentArrangement arrangementDate,
            LocalDate processingMonth,
            ReturnMessageDTO returnMessage ) throws Exception
    {
        LOGGER.debug( "validateArrangementRateEffEnddateEqualorBefore : START" );

        boolean isarrangementRateEffDateNotBeforeEndDate = false;

        if( !VBRDateUtils.checkEffectiveAndEndDatesList( paymentArrangementRatedateRecordList ) )
        {
            addToReturnMessage( ArrangementConfigServiceErrorMessageConstant.ARRANGEMENT_RATE_EFF_END_DATE_VALIDATION,
                                FieldIdConstant.PMAR_EFF_AND_END_DATE,
                                ComponentIdConstant.PMAM,
                                this.getClass().getSimpleName(),
                                returnMessage );
            isarrangementRateEffDateNotBeforeEndDate = true;
        }

        LOGGER.debug( "validateArrangementRateEffEnddateEqualorBefore : END" );
        return isarrangementRateEffDateNotBeforeEndDate;
    }

}