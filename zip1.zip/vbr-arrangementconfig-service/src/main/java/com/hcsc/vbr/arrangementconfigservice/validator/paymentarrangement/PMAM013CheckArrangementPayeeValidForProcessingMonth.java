package com.hcsc.vbr.arrangementconfigservice.validator.paymentarrangement;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.collections4.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.hcsc.vbr.arrangementconfigservice.domain.PaymentArrangement;
import com.hcsc.vbr.arrangementconfigservice.domain.PaymentArrangementPayee;
import com.hcsc.vbr.arrangementconfigservice.domain.VbrPayee;
import com.hcsc.vbr.arrangementconfigservice.validator.base.BaseValidationUnit;
import com.hcsc.vbr.common.domain.DateRecord;
import com.hcsc.vbr.common.dto.ReturnMessageDTO;
import com.hcsc.vbr.common.utils.VBRDateUtils;

@Component
public class PMAM013CheckArrangementPayeeValidForProcessingMonth extends BaseValidationUnit
{
    final Logger LOGGER = LoggerFactory.getLogger( PMAM015CheckArrangementPayeeDurationWithVbrPayee.class );

    /**
     * Method: validateArrangementPayeeValidForProcessingMonth
     * @param paymentArrangementPayees
     * @param arrangementchild
     * @param processMonth
     * @param returnMessage
     * @return
     * @throws Exception
     */
    public boolean validateArrangementPayeeForProcessingMonth( List<PaymentArrangementPayee> paymentArrangementPayees,
            PaymentArrangement arrangementchild,
            LocalDate processMonth,
            ReturnMessageDTO returnMessage ) throws Exception
    {
        LOGGER.debug( "validateArrangementPayeeValidForProcessingMonth : START" );
        List<VbrPayee> vbrPayees = new ArrayList<VbrPayee>();
        boolean isDateValid = false;
        for( PaymentArrangementPayee arrangementPayee : paymentArrangementPayees )
        {
            VbrPayee vbrPayee = arrangementPayee.getVbrPayee();
            vbrPayees.add( vbrPayee );
        }
        List<? extends DateRecord> globalDatesAfterRemovingVoidDates = VBRDateUtils.removeVoidDates( vbrPayees );
        List<? extends DateRecord> arrangementPayeeDateAfterRemovingVoidDates =
            VBRDateUtils.removeVoidDates( paymentArrangementPayees );
        if( CollectionUtils.isNotEmpty( arrangementPayeeDateAfterRemovingVoidDates )
            && CollectionUtils.isNotEmpty( globalDatesAfterRemovingVoidDates ) )
        {
            DateRecord parentArrangementPayeeDateRecord =
                VBRDateUtils.convertDateRecordListToDateRecordRange( arrangementPayeeDateAfterRemovingVoidDates );
            DateRecord globalPayeeDateRecord =
                VBRDateUtils.convertDateRecordListToDateRecordRange( globalDatesAfterRemovingVoidDates );

            if( ( processMonth.isAfter( parentArrangementPayeeDateRecord.getRecordEffectiveDate() )
                || processMonth.isEqual( parentArrangementPayeeDateRecord.getRecordEffectiveDate() ) )
                && ( processMonth.isBefore( parentArrangementPayeeDateRecord.getRecordEndDate() )
                    || processMonth.isEqual( parentArrangementPayeeDateRecord.getRecordEndDate() ) )
                && ( processMonth.isAfter( globalPayeeDateRecord.getRecordEffectiveDate() )
                    || processMonth.isEqual( globalPayeeDateRecord.getRecordEffectiveDate() ) )
                && ( processMonth.isBefore( globalPayeeDateRecord.getRecordEndDate() )
                    || processMonth.isEqual( globalPayeeDateRecord.getRecordEndDate() ) ) )
            {
                isDateValid = true;
            }
        }
        LOGGER.debug( "ProcessingMonth Valid for ArrangementPayee : " + isDateValid );
        LOGGER.debug( "validateArrangementPayeeValidForProcessingMonth : END" );
        return isDateValid;
    }

}
