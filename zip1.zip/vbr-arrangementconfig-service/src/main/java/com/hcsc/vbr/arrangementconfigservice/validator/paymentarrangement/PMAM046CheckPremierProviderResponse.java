package com.hcsc.vbr.arrangementconfigservice.validator.paymentarrangement;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.util.ObjectUtils;

import com.hcsc.vbr.arrangementconfigservice.constant.ArrangementConfigServiceErrorMessageConstant;
import com.hcsc.vbr.arrangementconfigservice.constant.ComponentIdConstant;
import com.hcsc.vbr.arrangementconfigservice.constant.FieldIdConstant;
import com.hcsc.vbr.arrangementconfigservice.validator.base.BaseValidationUnit;
import com.hcsc.vbr.common.dto.ReturnMessageDTO;
import com.hcsc.vbr.web.response.PayeeRetrieveResponse;

@Component
public class PMAM046CheckPremierProviderResponse extends BaseValidationUnit
{
    final Logger LOGGER = LoggerFactory.getLogger( PMAM046CheckPremierProviderResponse.class );

    public boolean validatePremierProviderResponse( List<PayeeRetrieveResponse> providerResponse,
            ReturnMessageDTO returnMessage ) throws Exception
    {
        LOGGER.debug( "validatePremierProviderResponse : START" );

        boolean isProviderResponseValid = true;

        if( ObjectUtils.isEmpty( providerResponse ) )
        {
            isProviderResponseValid = false;
            LOGGER.debug( "validatePremierProviderResponse : NO PREMIER PROVIDER RECORD" );
            addToReturnMessage( ArrangementConfigServiceErrorMessageConstant.NO_MATCHING_PREMIER_PROVIDER,
                                FieldIdConstant.PMAM_PAYEE,
                                ComponentIdConstant.PMAM,
                                this.getClass().getSimpleName(),
                                returnMessage );

        }
        LOGGER.debug( "validatePremierProviderResponse : END" );
        return isProviderResponseValid;
    }

}
