package com.hcsc.vbr.web.response;

import java.io.Serializable;
import java.util.List;

import org.apache.commons.lang3.builder.ReflectionToStringBuilder;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.hcsc.vbr.arrangementconfigservice.dto.RateNameDTO;
import com.hcsc.vbr.common.utils.MultilineRecursiveToStringStyleCustom;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class RateNameResponse implements Serializable
{
    private static final long serialVersionUID = 1L;

    @JsonIgnoreProperties( { "corporateEntityCode", "rateConfigTypeName" } )
    private List<RateNameDTO> rateNames;
    private String message;

    @Override
    public String toString()
    {
        return new ReflectionToStringBuilder( this,
                                              new MultilineRecursiveToStringStyleCustom() ).toString();
    }
}
