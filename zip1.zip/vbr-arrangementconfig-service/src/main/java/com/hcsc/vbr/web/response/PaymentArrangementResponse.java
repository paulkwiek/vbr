package com.hcsc.vbr.web.response;

import java.io.Serializable;

import org.apache.commons.lang3.builder.ReflectionToStringBuilder;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.hcsc.vbr.arrangementconfigservice.dto.PaymentArrangementDTO;
import com.hcsc.vbr.common.utils.MultilineRecursiveToStringStyleCustom;
import com.hcsc.vbr.web.response.base.BaseResponse;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonInclude( JsonInclude.Include.NON_NULL )
public class PaymentArrangementResponse extends BaseResponse implements Serializable
{

    private static final long serialVersionUID = 1L;

    private PaymentArrangementDTO paymentArrangement;
    private String message;

    @Override
    public String toString()
    {
        return new ReflectionToStringBuilder( this,
                                              new MultilineRecursiveToStringStyleCustom() ).toString();
    }

}