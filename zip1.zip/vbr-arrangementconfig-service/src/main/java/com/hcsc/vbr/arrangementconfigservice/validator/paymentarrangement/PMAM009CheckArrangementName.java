package com.hcsc.vbr.arrangementconfigservice.validator.paymentarrangement;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.ObjectUtils;

import com.hcsc.vbr.arrangementconfigservice.constant.ArrangementConfigServiceErrorMessageConstant;
import com.hcsc.vbr.arrangementconfigservice.constant.ComponentIdConstant;
import com.hcsc.vbr.arrangementconfigservice.constant.FieldIdConstant;
import com.hcsc.vbr.arrangementconfigservice.domain.PaymentArrangement;
import com.hcsc.vbr.arrangementconfigservice.repository.PaymentArrangementRepository;
import com.hcsc.vbr.arrangementconfigservice.service.PaymentArrangementService;
import com.hcsc.vbr.arrangementconfigservice.validator.base.BaseValidationUnit;
import com.hcsc.vbr.common.dto.ReturnMessageDTO;

@Component
public class PMAM009CheckArrangementName extends BaseValidationUnit
{
    final Logger LOGGER = LoggerFactory.getLogger( PMAM009CheckArrangementName.class );

    @Autowired
    private PaymentArrangementService paymentArrangementService;

    @Autowired
    private PaymentArrangementRepository paymentArrangementRepository;

    /**
     * Method: validateArrangementName
     * @param paymentArrangementRequest
     * @param returnMessage
     * @return
     * @throws Exception
     */
    public boolean validateArrangementName( PaymentArrangement paymentArrangementRequest,
            ReturnMessageDTO returnMessage ) throws Exception
    {
        LOGGER.debug( "validateArrangementName : START" );

        boolean isArrangmntNameValid = true;
        String paymentArrangementNameDB = null;
        String paymentArrangementName = paymentArrangementRequest.getPaymentArrangementName();
        if( !ObjectUtils.isEmpty( paymentArrangementRequest.getPaymentArrangementId() ) )
        {
            PaymentArrangement paymentArrangementinDB =
                paymentArrangementRepository.findByArrangementId( paymentArrangementRequest.getPaymentArrangementId() );
            paymentArrangementNameDB = paymentArrangementinDB.getPaymentArrangementName();
        }
        if( !StringUtils.isBlank( paymentArrangementName ) )
        {
            if( !StringUtils.isAlphanumericSpace( paymentArrangementName ) && !StringUtils.isAlphanumeric( paymentArrangementName ) )
            {
                addToReturnMessage( ArrangementConfigServiceErrorMessageConstant.ARRANGEMENT_NAME_ALPHANUMERIC_VALIDATION,
                                    FieldIdConstant.PMAM_NAME,
                                    ComponentIdConstant.PMAM,
                                    this.getClass().getSimpleName(),
                                    returnMessage );
                isArrangmntNameValid = false;
            }
            if( paymentArrangementName.length() > 20 )
            {
                addToReturnMessage( ArrangementConfigServiceErrorMessageConstant.ARRANGEMENT_NAME_LENGTH_VALIDATION,
                                    FieldIdConstant.PMAM_NAME,
                                    ComponentIdConstant.PMAM,
                                    this.getClass().getSimpleName(),
                                    returnMessage );
                isArrangmntNameValid = false;
            }
            if( ObjectUtils.isEmpty( paymentArrangementRequest.getPaymentArrangementId() )
                && !paymentArrangementService.findByArrangementName( paymentArrangementName ) )
            {
                addToReturnMessage( ArrangementConfigServiceErrorMessageConstant.UNIQUE_ARRANGEMENT_NAME_VALIDATION,
                                    FieldIdConstant.PMAM_NAME,
                                    ComponentIdConstant.PMAM,
                                    this.getClass().getSimpleName(),
                                    returnMessage );
                isArrangmntNameValid = false;
            }
            else if( !StringUtils.equals( StringUtils.trimToEmpty( paymentArrangementName ),
                                          StringUtils.trimToEmpty( paymentArrangementNameDB ) ) )
            {
                if( !paymentArrangementService.findByArrangementName( paymentArrangementName ) )
                {
                    addToReturnMessage( ArrangementConfigServiceErrorMessageConstant.UNIQUE_ARRANGEMENT_NAME_VALIDATION,
                                        FieldIdConstant.PMAM_NAME,
                                        ComponentIdConstant.PMAM,
                                        this.getClass().getSimpleName(),
                                        returnMessage );
                    isArrangmntNameValid = false;
                }
            }
        }
        else
        {
            addToReturnMessage( ArrangementConfigServiceErrorMessageConstant.ARRANGEMENT_NAME_VALIDATION,
                                FieldIdConstant.PMAM_NAME,
                                ComponentIdConstant.PMAM,
                                this.getClass().getSimpleName(),
                                returnMessage );
            isArrangmntNameValid = false;
        }
        LOGGER.debug( "ArrangementName is Valid" + isArrangmntNameValid );
        LOGGER.debug( "validateArrangementName : END" );
        return isArrangmntNameValid;
    }
}
