package com.hcsc.vbr.arrangementconfigservice.domain;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.validation.constraints.NotNull;

import org.apache.commons.lang3.builder.ReflectionToStringBuilder;

import com.hcsc.vbr.common.domain.DateRecord;
import com.hcsc.vbr.common.utils.MultilineRecursiveToStringStyleCustom;

import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
@AttributeOverrides( {
    @AttributeOverride( name = "recordEffectiveDate", column = @Column( name = "PMT_ARNGMT_EFF_DT" ) ),
    @AttributeOverride( name = "recordEndDate", column = @Column( name = "PMT_ARNGMT_END_DT" ) ) } )
@Table( name = "PMT_ARNGMT" )
public class PaymentArrangement extends DateRecord
{

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue( strategy = GenerationType.SEQUENCE, generator = "SEQ_GEN" )
    @SequenceGenerator( name = "SEQ_GEN", sequenceName = "PMT_ARNGMT_SQ", allocationSize = 1 )
    @Column( name = "PMT_ARNGMT_ID" )
    private Integer paymentArrangementId;

    @NotNull
    @Column( name = "CORP_ENT_CD", length = 3 )
    private String corporateEntityCode;

    @NotNull
    @Column( name = "PMT_ARNGMT_NM", length = 20 )
    private String paymentArrangementName;

    @NotNull
    @Column( name = "ARNGMT_FREQC_CD", length = 20 )
    private String arrangementFrequencyCode;

    @Column( name = "PMT_ARNGMT_TYP_CD", length = 20 )
    private String paymentArrangementTypeCode;

    @Column( name = "PMT_ARNGMT_DESC", length = 500 )
    private String paymentArrangementDescription;

    @Column( name = "PMT_ARNGMT_CONTR_ID" )
    private Integer paymentArrangementContractId;

    @NotNull
    @Column( name = "PMT_TYP_CD", length = 10 )
    private String paymentTypeCode;

    @NotNull
    @Column( name = "VLDN_STA_CD", length = 20 )
    private String validationStatusCode;

    @OneToMany( fetch = FetchType.LAZY, mappedBy = "paymentArrangement" )
    private List<PaymentArrangementPayee> paymentArrangementPayees = new ArrayList<PaymentArrangementPayee>();

    @OneToMany( fetch = FetchType.LAZY, mappedBy = "paymentArrangement" )
    private List<PaymentArrangementMemberSubject> paymentArrangementMemberSubjects = new ArrayList<PaymentArrangementMemberSubject>();

    @OneToMany( fetch = FetchType.LAZY, mappedBy = "paymentArrangement" )
    private List<RetroActivityRuleSetup> retroRuleSetups = new ArrayList<RetroActivityRuleSetup>();

    @OneToMany( fetch = FetchType.LAZY, mappedBy = "paymentArrangement" )
    private List<PaymentArrangementHistory> paymentArrangementHistories = new ArrayList<PaymentArrangementHistory>();

    @OneToMany( fetch = FetchType.LAZY, mappedBy = "paymentArrangement" )
    private List<PaymentArrangementRate> paymentArrangementRates = new ArrayList<PaymentArrangementRate>();

    @Transient
    private String overwriteSaveArrangement;

    @Transient
    private String overwriteCancelArrangement;

    public String toString()
    {
        return new ReflectionToStringBuilder( this,
                                              new MultilineRecursiveToStringStyleCustom() ).toString();
    }

}
