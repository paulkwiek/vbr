package com.hcsc.vbr.arrangementconfigservice.dto;

import org.apache.commons.lang3.builder.ReflectionToStringBuilder;

import com.hcsc.vbr.common.dto.DateRecordDTO;
import com.hcsc.vbr.common.utils.MultilineRecursiveToStringStyleCustom;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class FlatRateHistoryDTO extends DateRecordDTO
{

    private static final long serialVersionUID = 1L;

    private Integer flatRateHistoryId;

    private String corporateEntityCode;

    private String rateName;

    private Integer flatRateId;

    private Double femaleFlatRateAmount;

    private Double maleFlatRateAmount;

    private String commentText;

    @Override
    public String toString()
    {
        return new ReflectionToStringBuilder( this,
                                              new MultilineRecursiveToStringStyleCustom() ).toString();
    }

}
