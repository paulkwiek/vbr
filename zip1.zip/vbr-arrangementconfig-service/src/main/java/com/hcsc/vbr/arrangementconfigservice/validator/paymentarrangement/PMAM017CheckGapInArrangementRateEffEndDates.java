package com.hcsc.vbr.arrangementconfigservice.validator.paymentarrangement;

import java.time.LocalDate;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.hcsc.vbr.arrangementconfigservice.constant.ArrangementConfigServiceErrorMessageConstant;
import com.hcsc.vbr.arrangementconfigservice.constant.ComponentIdConstant;
import com.hcsc.vbr.arrangementconfigservice.constant.FieldIdConstant;
import com.hcsc.vbr.arrangementconfigservice.domain.PaymentArrangement;
import com.hcsc.vbr.arrangementconfigservice.validator.base.BaseValidationUnit;
import com.hcsc.vbr.common.domain.DateRecord;
import com.hcsc.vbr.common.dto.ReturnMessageDTO;
import com.hcsc.vbr.common.utils.VBRDateUtils;

@Component
public class PMAM017CheckGapInArrangementRateEffEndDates extends BaseValidationUnit
{

    final Logger LOGGER = LoggerFactory.getLogger( PMAM017CheckGapInArrangementRateEffEndDates.class );

    @Autowired
    private PMAM028CheckGapInArrangementDates checkGapInArrangementDates;

    @Autowired
    private PMAM048CheckArrangementGapwithMultipleDates checkArrangementGapwithMultipleDates;

    /**
     * This method will validate Gap B/W Arrangement Rate Effective and End
     * Dates.
     * 
     * @param dateRecordList
     * @param errors
     * @return flag
     * @throws Exception
     */
    public boolean validateGapInArrangmentRateEffEndDates( List<? extends DateRecord> dateRecordList,
            PaymentArrangement arrangementDate,
            LocalDate processingMonth,
            ReturnMessageDTO returnMessage ) throws Exception
    {
        LOGGER.debug( "validateGapInArrangmentRateEffEndDates : START" );

        boolean isDateValid = false;
        LocalDate lastDateOfProcessingMonth = VBRDateUtils.getLastDayOfMonth( processingMonth );

        if( !VBRDateUtils.checkForNoGaps( dateRecordList ) )
        {
            if( !checkGapInArrangementDates.checkForNoArrangementGaps( dateRecordList,
                                                                       arrangementDate ) )
            {
                if( !checkArrangementGapwithMultipleDates.checkArrangementGapwithMultipleDates( dateRecordList,
                                                                                                arrangementDate ) )
                {

                    if( arrangementDate.getRecordEffectiveDate().isAfter( lastDateOfProcessingMonth ) )
                    {
                        addToReturnMessage( ArrangementConfigServiceErrorMessageConstant.GAP_IN_ARRANGEMENT_RATE_EFF_END_DATES_FOR_FUTURE_ARRANGEMENT,
                                            FieldIdConstant.PMAR_EFF_DATE,
                                            ComponentIdConstant.PMAM,
                                            this.getClass().getSimpleName(),
                                            returnMessage );
                        isDateValid = true;
                    }
                    else
                    {
                        addToReturnMessage( ArrangementConfigServiceErrorMessageConstant.GAP_IN_ARRANGEMENT_RATE_EFF_END_DATES,
                                            FieldIdConstant.PMAR_EFF_DATE,
                                            ComponentIdConstant.PMAM,
                                            this.getClass().getSimpleName(),
                                            returnMessage );
                        isDateValid = true;
                    }

                }

            }
        }
        LOGGER.debug( "GapInArrangmentRateEffEndDates  : " + isDateValid );
        LOGGER.debug( "validateGapInArrangmentRateEffEndDates : START" );
        return isDateValid;
    }

}
