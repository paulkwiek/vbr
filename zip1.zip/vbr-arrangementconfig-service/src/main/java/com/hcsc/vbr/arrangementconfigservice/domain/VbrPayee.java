package com.hcsc.vbr.arrangementconfigservice.domain;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.validation.constraints.NotNull;

import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.springframework.lang.Nullable;

import com.hcsc.vbr.common.domain.DateRecord;
import com.hcsc.vbr.common.utils.MultilineRecursiveToStringStyleCustom;

import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
@AttributeOverrides( {
    @AttributeOverride( name = "recordEffectiveDate", column = @Column( name = "VBR_PAYE_EFF_DT" ) ),
    @AttributeOverride( name = "recordEndDate", column = @Column( name = "VBR_PAYE_END_DT" ) ) } )
@Table( name = "VBR_PAYE" )
public class VbrPayee extends DateRecord
{

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue( strategy = GenerationType.SEQUENCE, generator = "SEQ_GEN" )
    @SequenceGenerator( name = "SEQ_GEN", sequenceName = "VBR_PAYE_SQ", allocationSize = 1 )
    @Column( name = "VBR_PAYE_ID" )
    private Integer vbrPayeeId;

    @NotNull
    @Column( name = "CORP_ENT_CD", length = 3 )
    private String corporateEntityCode;

    @Column( name = "PIN_GRP_ID", length = 10 )
    private String pinGroupId;

    @Column( name = "PIN_GRP_NM", length = 60 )
    private String pinGroupName;

    @Column( name = "CAP_PROC_CD", length = 2 )
    private String capitationProcessCode;

    @Column( name = "NTWK_CD", length = 3 )
    private String networkCode;

    @Column( name = "TIN_NBR", length = 9 )
    private String taxIdNumber;

    @Column( name = "CAP_CD", length = 2 )
    private String capitationCode;

    @Column( name = "PAY_TO_PFIN_ID", length = 10 )
    private String payToPfinId;

    @Column( name = "NTWK_ASSN_PROV_ID" )
    private Integer networkAssocProviderId;

    @Column( name = "PROV_FST_NM", length = 12 )
    private String providerFirstName;

    @Column( name = "PROV_LST_NM", length = 12 )
    private String providerLastName;

    @Column( name = "PROV_TTL_CD", length = 12 )
    private String providerTitleCode;

    @Column( name = "PROV_ORGZN_NM", length = 12 )
    private String providerOrganizationName;

    @Column( name = "PROV_ORGZN_SCND_NM", length = 12 )
    private String providerOrganizationSecondName;

    @Column( name = "ADDR_LN_1_TXT", length = 12 )
    private String addressLine1Text;

    @Column( name = "ADDR_LN_2_TXT", length = 12 )
    private String addressLine2Text;

    @Column( name = "CTY_NM", length = 12 )
    private String cityName;

    @Column( name = "ST_PRVNC_CD", length = 12 )
    private String stateCode;

    @Column( name = "POSTL_CD", length = 12 )
    private String zipCode;

    @Nullable
    @OneToMany( fetch = FetchType.LAZY, mappedBy = "vbrPayee" )
    private List<PaymentArrangementPayee> paymentArrangementPayee = new ArrayList<PaymentArrangementPayee>();

    @Transient
    private String pinGroupEffectiveDate;

    @Transient
    private String pinGroupEndDate;

    @Transient
    private String pfinEffectiveDate;

    @Transient
    private String pfinEndDate;

    @Transient
    private String tinEffectiveDate;

    @Transient
    private String tinEndDate;

    @Transient
    private String networkAssociationEffectiveDate;

    @Transient
    private String networkAssociationEndDate;

    @Transient
    private String payToPFINName;

    @Override
    public String toString()
    {
        return new ReflectionToStringBuilder( this,
                                              new MultilineRecursiveToStringStyleCustom() ).toString();
    }

}
