package com.hcsc.vbr.arrangementconfigservice.validator.ratename;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.hcsc.vbr.arrangementconfigservice.constant.ArrangementConfigServiceErrorMessageConstant;
import com.hcsc.vbr.arrangementconfigservice.constant.ComponentIdConstant;
import com.hcsc.vbr.arrangementconfigservice.constant.FieldIdConstant;
import com.hcsc.vbr.arrangementconfigservice.domain.FlatRate;
import com.hcsc.vbr.arrangementconfigservice.domain.RateName;
import com.hcsc.vbr.arrangementconfigservice.validator.base.BaseValidationUnit;
import com.hcsc.vbr.common.dto.ReturnMessageDTO;
import com.hcsc.vbr.common.utils.VBRDateUtils;

@Component
public class RTNM009CheckRateEffDateIsFirstDayOfMonth extends BaseValidationUnit
{

    private static final Logger LOGGER = LoggerFactory.getLogger( RTNM008CheckRateAmountGreaterThanThousand.class );

    /**
     * @param rateName
     * @param returnMessage
     * @return
     * @throws Exception
     */
    public boolean isFirstDayOfMonth( RateName rateName,
            ReturnMessageDTO returnMessage ) throws Exception
    {
        LOGGER.debug( "RTNM009CheckRateEffDateIsFirstDayOfMonth : START" );
        boolean validateFlag = true;

        for( FlatRate flatRate : rateName.getFlatRates() )
        {
            if( !( 1 == flatRate.getRecordEffectiveDate().getDayOfMonth() ) || VBRDateUtils.isNotSameDay( flatRate ) )
            {
                //Checking for First Day of Month
                if( !( 1 == flatRate.getRecordEffectiveDate().getDayOfMonth() ) )
                {
                    //Set return flag to false
                    validateFlag = false;
                    //Add Error/Warning to ReturnMessage
                    addToReturnMessage( ArrangementConfigServiceErrorMessageConstant.RATE_EFF_DATE_SHOULD_BE_FIRST_DAY_OF_MONTH,
                                        FieldIdConstant.RTNM_EFF_DATE,
                                        ComponentIdConstant.RTNM,
                                        this.getClass().getSimpleName(),
                                        returnMessage );
                    break;
                }
            }
        }
        LOGGER.debug( "RTNM009CheckRateEffDateIsFirstDayOfMonth : END" );
        return validateFlag;
    }
}
