package com.hcsc.vbr.arrangementconfigservice.domain;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Embeddable
public class RateNameId implements Serializable
{

    private static final long serialVersionUID = 1L;

    @Column( name = "CORP_ENT_CD", length = 3 )
    private String corporateEntityCode;

    @Column( name = "RT_NM", length = 20 )
    private String rateName;

}
