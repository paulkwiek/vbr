package com.hcsc.vbr.arrangementconfigservice.apiclient;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.util.ObjectUtils;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.hcsc.vbr.arrangementconfigservice.constant.ArrangementConfigServiceConstant;
import com.hcsc.vbr.common.apiclient.BaseApiClient;
import com.hcsc.vbr.web.response.ProcessingMonthResponse;

@Component
public class CalculationServiceApiClient extends BaseApiClient
{
    @Autowired
    private RestTemplate restTemplate;

    @Value( "${calculation.service.client.base.url}" )
    private String calculationServiceClientBaseUrl;

    private static final Logger LOGGER = LoggerFactory.getLogger( CalculationServiceApiClient.class );

    /**
     * This method will cal calculation service and get the current process period date. Dates
     * Method: getCurrentProcessingMonth
     * @param corporateEntityCode
     * @return currentProcessingMonth
     * @throws Exception
     */
    public LocalDate getCurrentProcessingMonth( String corporateEntityCode ) throws Exception
    {
        String uri = StringUtils.join( calculationServiceClientBaseUrl,
                                       ArrangementConfigServiceConstant.GET_PROCESSING_MONTH_API_URL );

        Map<String, String> parameterMap = new HashMap<String, String>();
        parameterMap.put( "corporateEntityCode",
                          corporateEntityCode );
        UriComponentsBuilder builder = UriComponentsBuilder.fromUriString( uri );
        LocalDate currentProcessingMonth = null;
        HttpEntity<String> entity = new HttpEntity<>( getAuthorizationHeader() );

        ProcessingMonthResponse processingMonthResponse = null;

        try
        {
            LOGGER.info( "In ProcessingMonthAPI::Before call" + uri );
            //            processingMonthResponse = restTemplate.getForObject( uri,
            //                                                                 ProcessingMonthResponse.class,
            //                                                                 parameterMap,
            //                                                                 getAuthorizationHeader() );
            ResponseEntity<ProcessingMonthResponse> prResponseEntity =
                restTemplate.exchange( builder.buildAndExpand( parameterMap ).toUri(),
                                       HttpMethod.GET,
                                       entity,
                                       ProcessingMonthResponse.class );
            //            prResponseEntity.getBody().getProcessPeriodDate();

            LOGGER.info( "In ProcessingMonthAPI::After call" + new ObjectMapper().writeValueAsString( prResponseEntity ) );
            if( !ObjectUtils.isEmpty( prResponseEntity ) )
            {
                currentProcessingMonth = prResponseEntity.getBody().getProcessPeriodDate();

            }

        }
        catch( RestClientException _rce )
        {
            LOGGER.info( _rce.getMessage() );
        }
        catch( Exception _e )
        {
            LOGGER.info( _e.getMessage() );
        }
        return currentProcessingMonth;
    }

}
