package com.hcsc.vbr.arrangementconfigservice.mapper;

import java.util.List;

import org.mapstruct.IterableMapping;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;
import org.mapstruct.factory.Mappers;

import com.hcsc.vbr.arrangementconfigservice.domain.FlatRate;
import com.hcsc.vbr.arrangementconfigservice.domain.FlatRateHistory;
import com.hcsc.vbr.arrangementconfigservice.domain.PaymentArrangement;
import com.hcsc.vbr.arrangementconfigservice.domain.PaymentArrangementHistory;
import com.hcsc.vbr.arrangementconfigservice.domain.PaymentArrangementPayee;
import com.hcsc.vbr.arrangementconfigservice.domain.PaymentArrangementRate;
import com.hcsc.vbr.arrangementconfigservice.domain.RateName;
import com.hcsc.vbr.arrangementconfigservice.domain.VbrPayee;
import com.hcsc.vbr.arrangementconfigservice.dto.CalculationArrangementsDTO;
import com.hcsc.vbr.arrangementconfigservice.dto.FlatRateDTO;
import com.hcsc.vbr.arrangementconfigservice.dto.PaymentArrangementDTO;
import com.hcsc.vbr.arrangementconfigservice.dto.PaymentArrangementPayeeDTO;
import com.hcsc.vbr.arrangementconfigservice.dto.PaymentArrangementRateDTO;
import com.hcsc.vbr.arrangementconfigservice.dto.RateNameDTO;
import com.hcsc.vbr.arrangementconfigservice.dto.VbrPayeeDTO;;

@Mapper( componentModel = "spring" )
public interface PaymentArrangementMapper
{
    PaymentArrangementMapper INSTANCE = Mappers.getMapper( PaymentArrangementMapper.class );

    @Mapping( target = "recordEffectiveDate", dateFormat = "MM/dd/yyyy" )
    @Mapping( target = "recordEndDate", dateFormat = "MM/dd/yyyy" )
    @Mapping( target = "paymentArrangementStatusDescription", ignore = true )
    public PaymentArrangementDTO toPaymentArrangmentDTO( PaymentArrangement payementArrangement );

    @Mapping( target = "recordEffectiveDate", dateFormat = "MM/dd/yyyy" )
    @Mapping( target = "recordEndDate", dateFormat = "MM/dd/yyyy" )
    public PaymentArrangementPayeeDTO toPaymentArrangmentPayeeDTO( PaymentArrangementPayee payementArrangementPayee );

    @IterableMapping( elementTargetType = PaymentArrangementDTO.class, qualifiedByName = "toPaymentArrangmentDTO" )
    public List<PaymentArrangementDTO> toPaymentArrangmentDTOs( List<PaymentArrangement> paymentArrangements );

    @Mapping( target = "recordEffectiveDate", dateFormat = "MM/dd/yyyy" )
    @Mapping( target = "recordEndDate", dateFormat = "MM/dd/yyyy" )
    public PaymentArrangement toPaymentArrangement( PaymentArrangementDTO paymentArrangmentDTO );

    @Mapping( target = "recordEffectiveDate", dateFormat = "MM/dd/yyyy" )
    @Mapping( target = "recordEndDate", dateFormat = "MM/dd/yyyy" )
    public PaymentArrangementPayee toPaymentArrangementPayee( PaymentArrangementPayeeDTO paymentArrangementPayeeDTO );

    @Mapping( target = "recordEffectiveDate", dateFormat = "MM/dd/yyyy" )
    @Mapping( target = "recordEndDate", dateFormat = "MM/dd/yyyy" )
    @Mapping( source = "networkAssociationID", target = "networkAssocProviderId" )
    public VbrPayee toVbrPayee( VbrPayeeDTO vbrPayeeDTO );

    @Mapping( target = "recordEffectiveDate", dateFormat = "MM/dd/yyyy" )
    @Mapping( target = "recordEndDate", dateFormat = "MM/dd/yyyy" )
    @Mapping( source = "networkAssocProviderId", target = "networkAssociationID" )
    public VbrPayeeDTO toVbrPayeeDTO( VbrPayee vbrPayee );

    @Mapping( target = "recordEffectiveDate", dateFormat = "MM/dd/yyyy" )
    @Mapping( target = "recordEndDate", dateFormat = "MM/dd/yyyy" )
    public PaymentArrangementRate toPaymentArrangementRate( PaymentArrangementRateDTO paymentArrangementRateDTO );

    @Mapping( target = "recordEffectiveDate", dateFormat = "MM/dd/yyyy" )
    @Mapping( target = "recordEndDate", dateFormat = "MM/dd/yyyy" )
    public PaymentArrangementRateDTO toPaymentArrangementRateDTO( PaymentArrangementRate paymentArrangementRate );

    @IterableMapping( elementTargetType = PaymentArrangement.class, qualifiedByName = "toPaymentArrangement" )
    public List<PaymentArrangement> toPaymentArrangements( List<PaymentArrangementDTO> paymentArrangmentDTOs );

    @Mapping( source = "corporateEntityCode", target = "rateNameId.corporateEntityCode" )
    @Mapping( source = "rateName", target = "rateNameId.rateName" )
    public RateName toRateName( RateNameDTO rateNameDTO );

    @Mapping( target = "recordEffectiveDate", dateFormat = "MM/dd/yyyy" )
    @Mapping( target = "recordEndDate", dateFormat = "MM/dd/yyyy" )
    @Mapping( source = "femaleFlatRateAmount", target = "femaleFlatRateAmount", qualifiedByName = "stringToDouble" )
    @Mapping( source = "maleFlatRateAmount", target = "maleFlatRateAmount", qualifiedByName = "stringToDouble" )
    public FlatRate toFlatRate( FlatRateDTO flatRateDTO );

    @Mapping( target = "recordEffectiveDate", dateFormat = "MM/dd/yyyy" )
    @Mapping( target = "recordEndDate", dateFormat = "MM/dd/yyyy" )
    public FlatRateHistory toFlatRateHistory( FlatRate flatRate );

    public CalculationArrangementsDTO toRunPaymentArrangmentDTO( PaymentArrangement PayementArrangement );

    public List<CalculationArrangementsDTO> toRunPaymentArrangmentDTOs( List<PaymentArrangement> PayementArrangement );

    @Named( value = "stringToDouble" )
    default Double stringToDouble( String value )
    {
        return Double.parseDouble( value );

    }

    @Mapping( target = "recordEffectiveDate", dateFormat = "MM/dd/yyyy" )
    @Mapping( target = "recordEndDate", dateFormat = "MM/dd/yyyy" )
    public PaymentArrangementHistory toPaymentArrangementHistory( PaymentArrangementDTO paymentArrangmentDTO );

}
