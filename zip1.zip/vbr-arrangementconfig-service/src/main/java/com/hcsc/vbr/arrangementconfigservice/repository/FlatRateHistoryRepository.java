package com.hcsc.vbr.arrangementconfigservice.repository;

import java.time.LocalDateTime;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.hcsc.vbr.arrangementconfigservice.domain.FlatRateHistory;
import com.hcsc.vbr.common.constant.VBRCommonConstant.RowActionTypes;

@Repository
public interface FlatRateHistoryRepository extends JpaRepository<FlatRateHistory, Integer>
{
    /**
     * save/update/delete/NoAction for flatRate history
     * @param flatRateHistory
     */
    default void saveFlatRateHistory( FlatRateHistory flatRateHistory )
    {

        RowActionTypes rowAction = RowActionTypes.valueOf( flatRateHistory.getRowAction().name() );
        switch( rowAction )
        {
            case INSERT:
            {
                flatRateHistory.setCreateRecordTimestamp( LocalDateTime.now() );
                save( flatRateHistory );
                break;
            }
            case UPDATE:
            {
                save( flatRateHistory );
                break;
            }
            case DELETE:
            {
                delete( flatRateHistory );
                break;
            }
            default:
                break;

        }

    }

}
