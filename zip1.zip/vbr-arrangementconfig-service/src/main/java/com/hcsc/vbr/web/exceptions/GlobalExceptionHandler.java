package com.hcsc.vbr.web.exceptions;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.collections4.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.hcsc.vbr.arrangementconfigservice.apiclient.CodeServiceApiClient;
import com.hcsc.vbr.arrangementconfigservice.constant.ArrangementConfigServiceConstant;
import com.hcsc.vbr.arrangementconfigservice.constant.ArrangementConfigServiceErrorMessageConstant;
import com.hcsc.vbr.arrangementconfigservice.dto.ErrorMessageDTO;
import com.hcsc.vbr.common.exception.handler.VbrGlobalExceptionHandler;
import com.hcsc.vbr.web.request.ErrorMessage;
import com.hcsc.vbr.web.response.ErrorResponse;

@ControllerAdvice
public class GlobalExceptionHandler extends VbrGlobalExceptionHandler
{
    private static final Logger logger = LoggerFactory.getLogger( GlobalExceptionHandler.class );

    @Autowired
    private CodeServiceApiClient codeServiceApiClient;

    @ExceptionHandler( ApplicationException.class )
    @ResponseStatus( HttpStatus.BAD_REQUEST ) //400
    @ResponseBody
    public ErrorResponse handleException( ApplicationException ex ) throws Exception
    {
        ErrorResponse errorResponse = constructApplicationExceptionResponse( ex );
        logger.error( ex.getMessage() );
        return errorResponse;
    }
    //    @ExceptionHandler( Exception.class )
    //    @ResponseStatus( HttpStatus.INTERNAL_SERVER_ERROR ) //500
    //    @ResponseBody
    //    public ErrorResponse handleException( Exception ex ) throws Exception
    //    {
    //        ErrorResponse errorResponse = constructExceptionResponse( ex );
    //        logger.error( ex.getMessage() );
    //        return errorResponse;
    //    }

    private ErrorResponse constructApplicationExceptionResponse( ApplicationException ex ) throws Exception
    {
        ErrorResponse errorResponse = new ErrorResponse();
        ErrorMessage errorMsg = null;

        //Implementation for single or multiple exceptions
        if( CollectionUtils.isNotEmpty( ex.getErrors() ) )
        {
            errorMsg = new ErrorMessage();
            errorMsg.setErrors( ex.getErrors() );
        }
        else
        {
            errorMsg = createErrorMessage( new Long( ex.getMessage() ) );
        }

        //Call Rest API for error codes
        List<ErrorMessageDTO> errors = codeServiceApiClient.getErrorByIds( errorMsg );

        errorResponse.setErrors( CollectionUtils.isEmpty( errors ) ? new ArrayList<ErrorMessageDTO>()
            : errors );

        return errorResponse;

    }

    //    private ErrorResponse constructExceptionResponse( Exception ex ) throws Exception
    //    {
    //        ErrorResponse errorResponse = new ErrorResponse();
    //
    //        List<ErrorMessageDTO> errors = new ArrayList<ErrorMessageDTO>();
    //
    //        ErrorMessageDTO errorMessage = new ErrorMessageDTO();
    //        errorMessage.setErrorMessageCategoryCode( ArrangementConfigServiceConstant.DEFAULT_EXCEPTION_MESSAGE_CATEGORY_CODE );
    //        errorMessage.setErrorMessageId( ArrangementConfigServiceErrorMessageConstant.DEFAULT_EXCEPTION_ERROR_MESSAGE_ID );
    //        errorMessage.setErrorMsgDescriptionText( ArrangementConfigServiceConstant.DEFAULT_EXCEPTION_ERROR_MESSAGE_DESCRIPTION );
    //        errorMessage.setSeveritylevel( ArrangementConfigServiceConstant.DEFAULT_EXCEPTION_SEVERITY_LVL );
    //
    //        errors.add( errorMessage );
    //        errorResponse.setErrors( CollectionUtils.isEmpty( errors ) ? new ArrayList<ErrorMessageDTO>()
    //            : errors );
    //
    //        return errorResponse;
    //    }

    private ErrorMessage createErrorMessage( Long errorId )
    {
        ErrorMessage errorMsg = new ErrorMessage();
        ErrorMessageDTO errorMessageDTO = new ErrorMessageDTO();
        errorMessageDTO.setErrorMessageId( errorId );
        List<ErrorMessageDTO> reqErrors = new ArrayList<ErrorMessageDTO>();
        reqErrors.add( errorMessageDTO );
        errorMsg.setErrors( reqErrors );

        return errorMsg;
    }

    @ExceptionHandler( AccessDeniedException.class )
    @ResponseStatus( HttpStatus.UNAUTHORIZED ) // 401
    @ResponseBody
    public ErrorResponse handleUnauthorizedException( AccessDeniedException ex ) throws Exception
    {
        ErrorResponse errorResponse = constructAccessDeniedExceptionResponse( ex );
        logger.error( ex.getMessage() );
        return errorResponse;
    }

    private ErrorResponse constructAccessDeniedExceptionResponse( AccessDeniedException ex ) throws Exception
    {

        ErrorResponse errorResponse = new ErrorResponse();

        List<ErrorMessageDTO> errors = new ArrayList<ErrorMessageDTO>();
        ErrorMessageDTO errorMessage = new ErrorMessageDTO();

        errorMessage.setErrorMessageCategoryCode( ArrangementConfigServiceConstant.DEFAULT_EXCEPTION_MESSAGE_CATEGORY_CODE );
        errorMessage.setErrorMessageId( ( ArrangementConfigServiceErrorMessageConstant.ACCESS_DENIED_EXCEPTION_ERROR_MESSAGE_ID ) );
        errorMessage.setErrorMsgDescriptionText( ArrangementConfigServiceConstant.ACCESS_DENIED_EXCEPTION_ERROR_MESSAGE_DESCRIPTION );
        errorMessage.setSeveritylevel( ArrangementConfigServiceConstant.DEFAULT_EXCEPTION_SEVERITY_LVL );

        errors.add( errorMessage );
        errorResponse.setErrors( CollectionUtils.isEmpty( errors ) ? new ArrayList<ErrorMessageDTO>()
            : errors );

        return errorResponse;
    }

}
