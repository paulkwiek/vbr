/*package com.hcsc.vbr.arrangementconfigservice.mapper;

import java.util.List;

import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import com.hcsc.vbr.arrangementconfigservice.domain.FlatRateHistory;
import com.hcsc.vbr.arrangementconfigservice.dto.FlatRateHistoryDTO;

@Mapper( componentModel = "spring" )
public interface FlatRateHistoryMapper
{

    FlatRateHistoryMapper INSTANCE = Mappers.getMapper( FlatRateHistoryMapper.class );

    public FlatRateHistoryDTO toFlatRateHistoryDTO( FlatRateHistory flatRateHistory );

    public List<FlatRateHistoryDTO> toFlatRateHistoryDTOs( List<FlatRateHistory> flatRateHistories );

    public FlatRateHistory toFlatRateHistory( FlatRateHistoryDTO flatRateHistoryDTO );

    public List<FlatRateHistory> toFlatRateHistories( List<FlatRateHistoryDTO> flatRateHistoryDTOs );

}
*/