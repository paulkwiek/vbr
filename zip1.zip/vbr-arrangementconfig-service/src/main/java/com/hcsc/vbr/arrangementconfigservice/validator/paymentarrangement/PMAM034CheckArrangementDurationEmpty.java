package com.hcsc.vbr.arrangementconfigservice.validator.paymentarrangement;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.util.ObjectUtils;

import com.hcsc.vbr.arrangementconfigservice.constant.ArrangementConfigServiceErrorMessageConstant;
import com.hcsc.vbr.arrangementconfigservice.constant.ComponentIdConstant;
import com.hcsc.vbr.arrangementconfigservice.constant.FieldIdConstant;
import com.hcsc.vbr.arrangementconfigservice.domain.PaymentArrangement;
import com.hcsc.vbr.arrangementconfigservice.validator.base.BaseValidationUnit;
import com.hcsc.vbr.common.dto.ReturnMessageDTO;

@Component
public class PMAM034CheckArrangementDurationEmpty extends BaseValidationUnit
{

    final Logger LOGGER = LoggerFactory.getLogger( PMAM034CheckArrangementDurationEmpty.class );

    /**
     * Arrangement Duration Effective and End Dates Empty validation 
     * Method: validateArrangementDate
     * @param paymentArrangementSaveRequest
     * @param errors
     * @return true -  when any of effective date and end date are not empty
     * @return false -  when effective date and end date are not empty
     * @throws Exception
     */
    public boolean validateArrangementDurationEmpty( PaymentArrangement paymentArrangementSaveRequest,
            ReturnMessageDTO returnMessage ) throws Exception
    {
        LOGGER.debug( "validateArrangementDurationEmpty : START" );

        boolean isDateValid = true;
        if( ObjectUtils.isEmpty( paymentArrangementSaveRequest.getRecordEffectiveDate() )
            || ObjectUtils.isEmpty( paymentArrangementSaveRequest.getRecordEndDate() ) )
        {
            isDateValid = false;
            addToReturnMessage( ArrangementConfigServiceErrorMessageConstant.ARRNG_DURATION_MANDATORY_FIELD,
                                FieldIdConstant.PMAM_EFF_AND_END_DATE,
                                ComponentIdConstant.PMAM,
                                this.getClass().getSimpleName(),
                                returnMessage );

        }

        LOGGER.debug( "Arrangement Duration Effective and End Dates Not Empty" + isDateValid );
        LOGGER.debug( "validateArrangementDurationEmpty : END" );

        return isDateValid;
    }

}