package com.hcsc.vbr.arrangementconfigservice.validator.paymentarrangement;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.util.ObjectUtils;

import com.hcsc.vbr.arrangementconfigservice.constant.ArrangementConfigServiceErrorMessageConstant;
import com.hcsc.vbr.arrangementconfigservice.constant.ComponentIdConstant;
import com.hcsc.vbr.arrangementconfigservice.constant.FieldIdConstant;
import com.hcsc.vbr.arrangementconfigservice.validator.base.BaseValidationUnit;
import com.hcsc.vbr.common.dto.ReturnMessageDTO;
import com.hcsc.vbr.web.response.ProviderAPIResponseDTO;

@Component
public class PMAM049CheckProviderAPIProviderResponse extends BaseValidationUnit
{
    final Logger LOGGER = LoggerFactory.getLogger( PMAM049CheckProviderAPIProviderResponse.class );

    public boolean validateProviderAPIProviderResponse( List<ProviderAPIResponseDTO> providerAPIResponse,
            ReturnMessageDTO returnMessageDTO ) throws Exception
    {
        LOGGER.debug( "validateProviderAPIProviderResponse : START" );

        boolean isAPIResponseNotNull = true;

        if( ObjectUtils.isEmpty( providerAPIResponse ) )
        {
            isAPIResponseNotNull = false;
            LOGGER.debug( "validateProviderAPIProviderResponse : API Response empty" );
            addToReturnMessage( ArrangementConfigServiceErrorMessageConstant.NO_PAYEE_RECORDS_FOUND,
                                FieldIdConstant.PMAM_PAYEE,
                                ComponentIdConstant.PMAM,
                                this.getClass().getSimpleName(),
                                returnMessageDTO );

        }
        LOGGER.debug( "validateProviderAPIProviderResponse : isAPIResponseNotNull" + isAPIResponseNotNull );
        LOGGER.debug( "validateProviderAPIProviderResponse : END" );
        return isAPIResponseNotNull;
    }

}
