package com.hcsc.vbr.arrangementconfigservice.domain;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.apache.commons.lang3.builder.ReflectionToStringBuilder;

import com.hcsc.vbr.common.domain.DateRecord;
import com.hcsc.vbr.common.utils.MultilineRecursiveToStringStyleCustom;

import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
@AttributeOverrides( {
    @AttributeOverride( name = "recordEffectiveDate", column = @Column( name = "PROCG_MO_FST_DT" ) ),
    @AttributeOverride( name = "recordEndDate", column = @Column( name = "PROCG_MO_LST_DT" ) ) } )
@Table( name = "MBR_ELIG_RUL" )
public class MemberEligibilityRule extends DateRecord
{

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy=GenerationType.SEQUENCE, generator="SEQ_GEN")
    @SequenceGenerator(name="SEQ_GEN", sequenceName="MBR_ELIG_RUL_SQ", allocationSize=1)
    @Column( name = "MBR_ELIG_RUL_ID" )
    private Integer memberEligibilityRuleId;

    @NotNull
    @Column( name = "CORP_ENT_CD", length = 3 )
    private String corporateEntityCode;

    @NotNull
    @Column( name = "CRIT_NM", length = 20 )
    private String criteriaName;

    @NotNull
    @Column( name = "CRIT_VAL_TXT", length = 50 )
    private String criteriaValueText;

    @NotNull
    @Column( name = "PMT_TYP_CD", length = 10 )
    private String paymentTypeCode;

    @Override
    public String toString()
    {
        return new ReflectionToStringBuilder( this,
                                              new MultilineRecursiveToStringStyleCustom() ).toString();
    }

}
