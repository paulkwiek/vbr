package com.hcsc.vbr.arrangementconfigservice.validator.paymentarrangement;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.hcsc.vbr.arrangementconfigservice.constant.ArrangementConfigServiceErrorMessageConstant;
import com.hcsc.vbr.arrangementconfigservice.constant.ComponentIdConstant;
import com.hcsc.vbr.arrangementconfigservice.constant.FieldIdConstant;
import com.hcsc.vbr.arrangementconfigservice.domain.PaymentArrangement;
import com.hcsc.vbr.arrangementconfigservice.validator.base.BaseValidationUnit;
import com.hcsc.vbr.common.dto.ReturnMessageDTO;

@Component
public class PMAM026CheckPaymentArrangementPaymentTypeCode extends BaseValidationUnit
{
    final Logger LOGGER = LoggerFactory.getLogger( PMAM026CheckPaymentArrangementPaymentTypeCode.class );

    /**
     * Checks the Arrangement Payment Type Code.
     *
     * @param paymentArrangementSaveRequest the payment arrangement Save Request
     * @param errors                        the errors
     * @throws Exception                    the exception
     */
    public boolean validateArrangementPaymentTypeCode( PaymentArrangement paymentArrangementSaveRequest,
            ReturnMessageDTO returnMessage ) throws Exception
    {
        LOGGER.debug( "validateArrangementPaymentTypeCode : START" );

        boolean isPaymentTypeCodeValid = true;

        String paymentTypeCode = paymentArrangementSaveRequest.getPaymentTypeCode();

        boolean isEmpty = StringUtils.isBlank( paymentTypeCode );
        if( isEmpty )
        {
            addToReturnMessage( ArrangementConfigServiceErrorMessageConstant.ARRANGEMENT_PAYMENT_TYPE_CANNOT_BE_BLANK,
                                FieldIdConstant.PMAM_PMT_TYP,
                                ComponentIdConstant.PMAM,
                                this.getClass().getSimpleName(),
                                returnMessage );
            isPaymentTypeCodeValid = false;
        }
        LOGGER.debug( "PaymentTypeCode is Valid" + isPaymentTypeCodeValid );
        LOGGER.debug( "validateArrangementPaymentTypeCode : END" );
        return isPaymentTypeCodeValid;

    }

}
