package com.hcsc.vbr.arrangementconfigservice.dto;

import java.time.LocalDate;

import org.apache.commons.lang3.builder.ReflectionToStringBuilder;

import com.hcsc.vbr.common.dto.BaseEntityDTO;
import com.hcsc.vbr.common.utils.MultilineRecursiveToStringStyleCustom;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class RetroActivityRuleSetupDTO extends BaseEntityDTO
{

    private static final long serialVersionUID = 1L;

    private Integer retroActivityRuleSetupId;

    private String corporateEntityCode;

    private String paymentTypeCode;

    private String retroActivityCategoryCode;

    private String retroActivityTypeCode;

    private LocalDate lookBackPeriodDate;

    private Integer lookBackPeriodMonthCount;

    private Integer paymentArrangementId;

    @Override
    public String toString()
    {
        return new ReflectionToStringBuilder( this,
                                              new MultilineRecursiveToStringStyleCustom() ).toString();
    }
}