package com.hcsc.vbr.arrangementconfigservice.validator.paymentarrangement;

import java.time.LocalDate;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.hcsc.vbr.arrangementconfigservice.constant.ArrangementConfigServiceErrorMessageConstant;
import com.hcsc.vbr.arrangementconfigservice.constant.ComponentIdConstant;
import com.hcsc.vbr.arrangementconfigservice.constant.FieldIdConstant;
import com.hcsc.vbr.arrangementconfigservice.domain.PaymentArrangement;
import com.hcsc.vbr.arrangementconfigservice.domain.PaymentArrangementPayee;
import com.hcsc.vbr.arrangementconfigservice.validator.base.BaseValidationUnit;
import com.hcsc.vbr.common.domain.DateRecord;
import com.hcsc.vbr.common.dto.ReturnMessageDTO;
import com.hcsc.vbr.common.utils.VBRDateUtils;

@Component
public class PMAM005CheckArrangementDurationWithArrangementPayee extends BaseValidationUnit
{
    final Logger LOGGER = LoggerFactory.getLogger( PMAM005CheckArrangementDurationWithArrangementPayee.class );

    /**
     * Method: validateArrangementDateDuration
     * @param parent
     * @param child
     * @param errors
     * @return
     * @throws Exception
     */
    public boolean validateArrangementDurationWithArrangementPayee(
            List<PaymentArrangementPayee> paymentArrangementPayeesParentdaterecord,
            PaymentArrangement arrangementchilddaterecord,
            LocalDate processingMonth,
            ReturnMessageDTO returnMessage ) throws Exception
    {
        LOGGER.debug( "validateArrangementDurationWithArrangementPayee : START" );

        boolean isDateValid = false;
        LocalDate arrangementEffectiveDate = arrangementchilddaterecord.getRecordEffectiveDate();
        LocalDate lastDateOfProcessingMonth = VBRDateUtils.getLastDayOfMonth( processingMonth );

        DateRecord parentArrangementPayeeDateRecord =
            VBRDateUtils.convertDateRecordListToDateRecordRange( paymentArrangementPayeesParentdaterecord );

        if( !VBRDateUtils.checkDateCoverage( parentArrangementPayeeDateRecord,
                                             arrangementchilddaterecord ) )
        {
            if( arrangementEffectiveDate.isAfter( lastDateOfProcessingMonth ) )
            {
                addToReturnMessage( ArrangementConfigServiceErrorMessageConstant.INVALID_ARRANGEMENT_DATE_DURATION_WITH_ARRANGEMENT_PAYEE_FUTURE,
                                    FieldIdConstant.PMPY_EFF_AND_END_DATE,
                                    ComponentIdConstant.PMAM,
                                    this.getClass().getSimpleName(),
                                    returnMessage );
                isDateValid = true;
            }
            else
            {
                addToReturnMessage( ArrangementConfigServiceErrorMessageConstant.INVALID_ARRANGEMENT_DATE_DURATION_WITH_ARRANGEMENT_PAYEE,
                                    FieldIdConstant.PMPY_EFF_AND_END_DATE,
                                    ComponentIdConstant.PMAM,
                                    this.getClass().getSimpleName(),
                                    returnMessage );
                isDateValid = true;
            }

        }
        LOGGER.debug( "ArrangementDuration not within ArrangementPayee :" + isDateValid );
        LOGGER.debug( "validateArrangementDurationWithArrangementPayee : END" );
        return isDateValid;
    }

}