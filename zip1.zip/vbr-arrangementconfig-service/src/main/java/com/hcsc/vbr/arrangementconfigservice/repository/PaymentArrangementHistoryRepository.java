package com.hcsc.vbr.arrangementconfigservice.repository;

import java.time.LocalDateTime;

import org.springframework.data.jpa.repository.JpaRepository;

import com.hcsc.vbr.arrangementconfigservice.domain.PaymentArrangementHistory;

public interface PaymentArrangementHistoryRepository extends JpaRepository<PaymentArrangementHistory, Integer>
{

    /**
     * Method: savePaymentArrangementHistory
     * @param paymentArrangementHistory
     */
    default void savePaymentArrangementHistory( PaymentArrangementHistory paymentArrangementHistory )
    {

        switch( paymentArrangementHistory.getRowAction() )
        {
            case INSERT:
            {
                paymentArrangementHistory.setCreateRecordTimestamp( LocalDateTime.now() );
                save( paymentArrangementHistory );
                break;
            }
            case UPDATE:
            {
                save( paymentArrangementHistory );
                break;
            }
            case DELETE:
            {
                throw new RuntimeException( " Invalid Row Action" );
            }
            default:
                throw new RuntimeException( " Invalid Row Action" );
        }

    }
}
