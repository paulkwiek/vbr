package com.hcsc.vbr.arrangementconfigservice.validator.paymentarrangement;

import java.time.LocalDate;
import java.util.List;

import org.apache.commons.collections4.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.hcsc.vbr.arrangementconfigservice.domain.FlatRate;
import com.hcsc.vbr.arrangementconfigservice.domain.PaymentArrangement;
import com.hcsc.vbr.arrangementconfigservice.domain.PaymentArrangementRate;
import com.hcsc.vbr.arrangementconfigservice.validator.base.BaseValidationUnit;
import com.hcsc.vbr.common.domain.DateRecord;
import com.hcsc.vbr.common.dto.ReturnMessageDTO;
import com.hcsc.vbr.common.utils.VBRDateUtils;

@Component
public class PMAM014CheckArrangementRateValidForProcessingMonth extends BaseValidationUnit
{
    final Logger LOGGER = LoggerFactory.getLogger( PMAM014CheckArrangementRateValidForProcessingMonth.class );

    /**
     * Method: validateArrangementRateValidForProcessingMonth
     * @param arrangementRateparent
     * @param arrangementchild
     * @param processMonth
     * @param returnMessage
     * @return
     * @throws Exception
     */
    public boolean validateArrangementRateForProcessingMonth( List<FlatRate> flatRates,
            List<PaymentArrangementRate> arrangementRateparent,
            PaymentArrangement arrangementchild,
            LocalDate processMonth,
            ReturnMessageDTO returnMessage ) throws Exception
    {
        LOGGER.debug( "validateArrangementRateValidForProcessingMonth : START" );
        boolean isDateValid = false;
        List<? extends DateRecord> flatRateDatesAfterRemovingVoidDates = VBRDateUtils.removeVoidDates( flatRates );
        List<? extends DateRecord> arrangementRateDateAfterRemovingVoidDates = VBRDateUtils.removeVoidDates( arrangementRateparent );
        if( CollectionUtils.isNotEmpty( arrangementRateDateAfterRemovingVoidDates )
            && CollectionUtils.isNotEmpty( flatRateDatesAfterRemovingVoidDates ) )
        {
            DateRecord parentArrangementrateDateRecord =
                VBRDateUtils.convertDateRecordListToDateRecordRange( arrangementRateDateAfterRemovingVoidDates );
            DateRecord FlatRateDateRecord = VBRDateUtils.convertDateRecordListToDateRecordRange( flatRateDatesAfterRemovingVoidDates );
            if( ( processMonth.isAfter( parentArrangementrateDateRecord.getRecordEffectiveDate() )
                || processMonth.isEqual( parentArrangementrateDateRecord.getRecordEffectiveDate() ) )
                && ( processMonth.isBefore( parentArrangementrateDateRecord.getRecordEndDate() )
                    || processMonth.isEqual( parentArrangementrateDateRecord.getRecordEndDate() ) )
                && ( processMonth.isAfter( FlatRateDateRecord.getRecordEffectiveDate() )
                    || processMonth.isEqual( FlatRateDateRecord.getRecordEffectiveDate() ) )
                && ( processMonth.isBefore( FlatRateDateRecord.getRecordEndDate() )
                    || processMonth.isEqual( FlatRateDateRecord.getRecordEndDate() ) ) )
            {
                isDateValid = true;
            }
        }
        LOGGER.debug( "ProcessingMonth Valid for ArrangementRate  : " + isDateValid );
        LOGGER.debug( "validateArrangementRateValidForProcessingMonth : END" );
        return isDateValid;
    }

}
