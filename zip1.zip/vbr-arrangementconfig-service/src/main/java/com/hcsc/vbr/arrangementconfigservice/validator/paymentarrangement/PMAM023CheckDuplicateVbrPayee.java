package com.hcsc.vbr.arrangementconfigservice.validator.paymentarrangement;

import java.util.List;

import org.apache.commons.collections4.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.hcsc.vbr.arrangementconfigservice.constant.ArrangementConfigServiceErrorMessageConstant;
import com.hcsc.vbr.arrangementconfigservice.constant.ComponentIdConstant;
import com.hcsc.vbr.arrangementconfigservice.constant.FieldIdConstant;
import com.hcsc.vbr.arrangementconfigservice.domain.PaymentArrangementPayee;
import com.hcsc.vbr.arrangementconfigservice.domain.VbrPayee;
import com.hcsc.vbr.arrangementconfigservice.mapper.VbrPayeeMapper;
import com.hcsc.vbr.arrangementconfigservice.repository.VbrPayeeRepository;
import com.hcsc.vbr.arrangementconfigservice.validator.base.BaseValidationUnit;
import com.hcsc.vbr.common.dto.ReturnMessageDTO;

@Component
public class PMAM023CheckDuplicateVbrPayee extends BaseValidationUnit
{
    final Logger LOGGER = LoggerFactory.getLogger( PMAM023CheckDuplicateVbrPayee.class );

    @Autowired
    VbrPayeeRepository vbrPayeeRepository;

    @Autowired
    VbrPayeeMapper vbrPayeeMapper;

    public boolean validateVbrPaye( List<PaymentArrangementPayee> paymentArrangementPayees,
            ReturnMessageDTO returnMessage ) throws Exception
    {
        LOGGER.debug( "validateVbrPaye : START" );

        boolean isPayeeUnique = false;
        for( PaymentArrangementPayee payee : paymentArrangementPayees )
        {
            VbrPayee vbrPayee = payee.getVbrPayee();
            if( ( vbrPayee.getVbrPayeeId() == null )
                && ( CollectionUtils.isNotEmpty( vbrPayeeRepository.findUniquePayee( vbrPayee ) ) ) )
            {
                addToReturnMessage( ArrangementConfigServiceErrorMessageConstant.UNIQUE_PAYEE_VALIDATION,
                                    FieldIdConstant.VBPY_UNIQUE,
                                    ComponentIdConstant.PMAM,
                                    this.getClass().getSimpleName(),
                                    returnMessage );
                isPayeeUnique = true;
            }
        }
        LOGGER.debug( "PaymentArrangementPayee is duplicate:" + isPayeeUnique );
        LOGGER.debug( "validateVbrPaye : END" );

        return isPayeeUnique;
    }
}
