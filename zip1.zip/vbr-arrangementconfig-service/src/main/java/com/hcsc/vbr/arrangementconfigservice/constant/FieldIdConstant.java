package com.hcsc.vbr.arrangementconfigservice.constant;

public class FieldIdConstant
{

    //RateName
    public static final String RTNM_NAME = "rateName";
    public static final String RTNM_EFF_DATE = "rateEffectiveDate";
    public static final String RTNM_END_DATE = "rateEndDate";
    public static final String RTNM_EFF_AND_END_DATE = "rateEffectiveAndEndDate";
    public static final String RTNM_FLAT_RATE_AMT = "maleFlatRateAmount";
    public static final String NO_RECORDS = "NA";

    //PaymentArrangement
    public static final String PMAM_EFF_DATE = "paymentArrangementEffectiveDate";
    public static final String PMAM_END_DATE = "paymentArrangementEndDate";
    public static final String PMAM_STATUS = "paymentArrangementStatus";
    public static final String PMAM_EFF_AND_END_DATE = "paymentArrangementEffectiveAndEndDate";
    public static final String PMAM_FREQ_CODE = "paymentArrangementFrequencyCode";
    public static final String PMAM_DESC = "paymentArrangementDescription";
    public static final String PMAM_NAME = "paymentArrangementName";
    public static final String PMAM_MBR_SBJCT = "paymentArrangementMemberSubject";
    public static final String PMAM_RATE = "paymentArrangementRate";
    public static final String PMAM_PAYEE = "paymentArrangementPayee";
    public static final String PMAM_PMT_TYP = "paymentArrangementPaymentType";

    //PaymentArrangementRate
    public static final String PMAR_EFF_DATE = "paymentArrangementRateEffectiveDate";
    public static final String PMAR_END_DATE = "paymentArrangementRateEndDate";
    public static final String PMAR_EFF_AND_END_DATE = "paymentArrangementRateEffectiveAndEndDate";

    //PaymentArrangementPayee
    public static final String PMPY_EFF_DATE = "paymentArrangementPayeeEffectiveDate";
    public static final String PMPY_END_DATE = "paymentArrangementPayeeEndDate";
    public static final String PMPY_EFF_AND_END_DATE = "paymentArrangementPayeeEffectiveAndEndDate";
    public static final String PMPY_PINGRP_ID = "paymentArrangementPayeePingroupId";

    //VbrPayee
    public static final String VBPY_EFF_DATE = "vbrPayeeEffectiveDate";
    public static final String VBPY_END_DATE = "vbrPayeeEndDate";
    public static final String VBPY_PINGROUP_ID = "vbrPayeePinGroupId";
    public static final String VBPY_PFIN_ID = "vbrPayeePfinId";
    public static final String VBPY_PINGROUP_NAME = "vbrPayeePinGroupName";
    public static final String VBPY_PAYEE_ID = "vbrPayeeId";
    public static final String VBPY_TAX_ID_NUMBER = "vbrPayeeTaxIdNumber";
    public static final String VBPY_CAPTITATION_CODE = "vbrPayeeCapitationCode";
    public static final String VBPY_CAPITATION_PROCESS_CODE = "vbrPayeeCaptitationProcessCode";
    public static final String VBPY_CORPORATE_ENTITY_CODE = "vbrPayeeCorporateEntityCode";
    public static final String VBPY_NETWORK_CODE = "vbrPayeeNetworkCode";
    public static final String VBPY_PROVIDER_DATES = "vbrPayeeProviderEffectiveAndEndDates";
    public static final String VBPY_UNIQUE = "vbrPayeeUnique";
    public static final String VBPY_EFF_AND_END_DATE = "vbrPayeeEffectiveAndEndDate";
}
