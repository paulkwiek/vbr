package com.hcsc.vbr.arrangementconfigservice.validator.payee;

import java.util.List;

import org.apache.commons.collections4.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.hcsc.vbr.arrangementconfigservice.constant.ArrangementConfigServiceErrorMessageConstant;
import com.hcsc.vbr.arrangementconfigservice.constant.ComponentIdConstant;
import com.hcsc.vbr.arrangementconfigservice.constant.FieldIdConstant;
import com.hcsc.vbr.arrangementconfigservice.validator.base.BaseValidationUnit;
import com.hcsc.vbr.common.dto.ReturnMessageDTO;
import com.hcsc.vbr.web.response.ProviderAPIResponseDTO;

@Component
public class VBPY018ValidateNoRecordsFoundForPayeeFromProviderApi extends BaseValidationUnit
{
    private static final Logger LOGGER = LoggerFactory.getLogger( VBPY018ValidateNoRecordsFoundForPayeeFromProviderApi.class );

    /**
     * Method: isRecordsFound
     * @param payees
     * @param returnMessage
     * @return
     * @throws Exception
     */
    public boolean isRecordsFound( List<ProviderAPIResponseDTO> payees,
            ReturnMessageDTO returnMessage ) throws Exception
    {

        LOGGER.debug( "VBPY018ValidateNoRecordsFoundForPayeeFromProviderApi : START" );

        boolean isRecordsFound = true;

        if( CollectionUtils.isEmpty( payees ) )
        {
            //Set return flag to false
            isRecordsFound = false;
            //Add Error/Warning to ReturnMessage
            addToReturnMessage( ArrangementConfigServiceErrorMessageConstant.NO_RECORDS_FOUND_FOR_PAYEE,
                                FieldIdConstant.VBPY_PINGROUP_ID,
                                ComponentIdConstant.VBPY,
                                this.getClass().getSimpleName(),
                                returnMessage );
        }

        LOGGER.debug( "VBPY018ValidateNoRecordsFoundForPayeeFromProviderApi : END" );

        return isRecordsFound;

    }
}
