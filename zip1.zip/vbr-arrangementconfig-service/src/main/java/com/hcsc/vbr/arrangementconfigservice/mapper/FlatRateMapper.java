/*package com.hcsc.vbr.arrangementconfigservice.mapper;

import java.util.List;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import com.hcsc.vbr.arrangementconfigservice.domain.FlatRate;
import com.hcsc.vbr.arrangementconfigservice.domain.FlatRateHistory;
import com.hcsc.vbr.arrangementconfigservice.dto.FlatRateDTO;

@Mapper( componentModel = "spring" )
public interface FlatRateMapper
{

    FlatRateMapper INSTANCE = Mappers.getMapper( FlatRateMapper.class );

    @Mapping( target = "recordEffectiveDate", dateFormat = "MM/dd/yyyy" )
    @Mapping( target = "recordEndDate", dateFormat = "MM/dd/yyyy" )
    public FlatRateDTO toFlatRateDTO( FlatRate flatRate );

    public List<FlatRateDTO> toFlatRateDTOs( List<FlatRate> flatRates );

    public FlatRate toFlatRate( FlatRateDTO flatRateDTO );

    public List<FlatRate> toFlatRates( List<FlatRateDTO> flatRateDTOs );

    public FlatRateHistory toFlatRateHistory( FlatRate flatRate );

}
*/