package com.hcsc.vbr.arrangementconfigservice.validator.ratename;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.hcsc.vbr.arrangementconfigservice.constant.ArrangementConfigServiceConstant;
import com.hcsc.vbr.arrangementconfigservice.constant.ArrangementConfigServiceErrorMessageConstant;
import com.hcsc.vbr.arrangementconfigservice.constant.ComponentIdConstant;
import com.hcsc.vbr.arrangementconfigservice.constant.FieldIdConstant;
import com.hcsc.vbr.arrangementconfigservice.domain.RateName;
import com.hcsc.vbr.arrangementconfigservice.repository.RateNameRepository;
import com.hcsc.vbr.arrangementconfigservice.validator.base.BaseValidationUnit;
import com.hcsc.vbr.common.dto.ReturnMessageDTO;
import com.hcsc.vbr.common.exception.VbrApplicationException;

@Component
public class RTNM005CheckRateName extends BaseValidationUnit
{
    private static final Logger LOGGER = LoggerFactory.getLogger( RTNM005CheckRateName.class );

    @Autowired
    public RateNameRepository rateNameRepository;

    /**
     * @param rateName
     * @param returnMessage
     * @throws Exception
     */
    public void validateRateName( String rateName,
            ReturnMessageDTO returnMessage ) throws Exception
    {
        LOGGER.debug( "RTNM005CheckRateName : START" );

        boolean validateSaveFlag = true;

        if( ( StringUtils.isBlank( rateName ) ) || ( ( !StringUtils.isAlphanumericSpace( rateName ) ) || ( rateName.length() > 20 ) ) )
        {
            validateSaveFlag = false;
            addToReturnMessage( ArrangementConfigServiceErrorMessageConstant.RATE_NAME_VALIDATION,
                                FieldIdConstant.RTNM_NAME,
                                ComponentIdConstant.RTNM,
                                this.getClass().getSimpleName(),
                                returnMessage );
        }

        RateName rate = rateNameRepository.findByRateName( rateName.trim() );
        if( rate != null )
        {
            validateSaveFlag = false;
            addToReturnMessage( ArrangementConfigServiceErrorMessageConstant.UNIQUE_RATE_NAME_VALIDATION,
                                FieldIdConstant.RTNM_NAME,
                                ComponentIdConstant.RTNM,
                                this.getClass().getSimpleName(),
                                returnMessage );
        }

        LOGGER.debug( "RTNM005CheckRateName : END" );
        if( !validateSaveFlag )
        {
            returnMessage.setStatus( ArrangementConfigServiceConstant.FAILURE_VALIDATION_STATUS );
            throw new VbrApplicationException( returnMessage );
        }
        else
        {
            returnMessage.setStatus( ArrangementConfigServiceConstant.SUCCESS_VALIDATION_STATUS );
        }

    }

}
