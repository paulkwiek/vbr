package com.hcsc.vbr.arrangementconfigservice.validator.ratename;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.hcsc.vbr.arrangementconfigservice.constant.ArrangementConfigServiceConstant;
import com.hcsc.vbr.arrangementconfigservice.domain.FlatRate;
import com.hcsc.vbr.arrangementconfigservice.domain.RateName;
import com.hcsc.vbr.arrangementconfigservice.validator.base.BaseValidator;
import com.hcsc.vbr.common.dto.ReturnMessageDTO;
import com.hcsc.vbr.common.exception.VbrApplicationException;
import com.hcsc.vbr.web.request.RateSaveRequest;
import com.hcsc.vbr.web.response.PaymentArrangementListResponse;

@Component
public class RateNameValidator extends BaseValidator
{

    @Autowired
    private RTNM001CheckRateAmount rtnm001CheckRateAmount;

    @Autowired
    private RTNM003CheckRateDate rtnm003CheckRateDate;

    @Autowired
    private RTNM004CheckRateDateOverlap rtnm004CheckRateDateOverlap;

    @Autowired
    private RTNM007CheckRateAmountLessThanOneMillion rtnm007CheckRateAmountLessThanOneMillion;

    @Autowired
    private RTNM008CheckRateAmountGreaterThanThousand rtnm008CheckRateAmountGreaterThanThousand;

    @Autowired
    private RTNM009CheckRateEffDateIsFirstDayOfMonth rtnm009CheckRateEffDateIsFirstDayOfMonth;

    @Autowired
    private RTNM010CheckRateEndDateIsLastDayOfMonth rtnm010CheckRateEndDateIsLastDayOfMonth;

    @Autowired
    private RTNM011CheckNoRecordsFoundForRateNames rtnm011CheckNoRecordsFoundForRateNames;

    @Autowired
    private RTNM012CheckNoRecordsFoundForFlatRates rtnm012CheckNoRecordsFoundForFlatRates;

    @Autowired
    private RTNM013CheckNoRecordsFoundForlinkedArrangements rtnm013CheckNoRecordsFoundForlinkedArrangements;

    private static final Logger LOGGER = LoggerFactory.getLogger( RateNameValidator.class );

    /**
     * Method: validateSaveRateName
     * @param rateSaveRequest
     * @param rateName
     * @param returnMessage
     * @return
     * @throws Exception
     */
    public boolean validateSaveRateName( RateSaveRequest rateSaveRequest,
            RateName rateName,
            ReturnMessageDTO returnMessage ) throws Exception
    {
        LOGGER.debug( "validateSaveRateName : START" );

        boolean validateSaveFlag = true;

        validateSaveFlag = rtnm001CheckRateAmount.validateRateAmount( rateName,
                                                                      returnMessage )
            && validateSaveFlag;

        validateSaveFlag = rtnm007CheckRateAmountLessThanOneMillion.isRateAmountLessThanOneMillion( rateName,
                                                                                                    returnMessage )
            && validateSaveFlag;

        validateSaveFlag = rtnm008CheckRateAmountGreaterThanThousand.isRateAmountGreaterThanThousand( rateSaveRequest,
                                                                                                      rateName,
                                                                                                      returnMessage )
            && validateSaveFlag;

        validateSaveFlag = rtnm003CheckRateDate.IsValidRateDate( rateName,
                                                                 returnMessage )
            && validateSaveFlag;

        validateSaveFlag = rtnm009CheckRateEffDateIsFirstDayOfMonth.isFirstDayOfMonth( rateName,
                                                                                       returnMessage )
            && validateSaveFlag;

        validateSaveFlag = rtnm010CheckRateEndDateIsLastDayOfMonth.isLastDayOfMonth( rateName,
                                                                                     returnMessage )
            && validateSaveFlag;

        validateSaveFlag = rtnm004CheckRateDateOverlap.validateRateDateOverlap( rateName,
                                                                                returnMessage )
            && validateSaveFlag;

        LOGGER.debug( "validateSaveRateName : END " + returnMessage );

        /**
         * If the flag is false which means basic validations failed, we cannot save the record but throw VbrApplicationException
         * so that the errors are sent back to the UI for displaying and also highlighting the appropriate fields.
         */

        if( !validateSaveFlag )
        {
            returnMessage.setStatus( ArrangementConfigServiceConstant.FAILURE_VALIDATION_STATUS );
            throw new VbrApplicationException( returnMessage );
        }
        else
        {
            returnMessage.setStatus( ArrangementConfigServiceConstant.SUCCESS_VALIDATION_STATUS );
        }

        return validateSaveFlag;
    }

    /**
     * Method: validateGetRateNames
     * @param rateSaveRequest
     * @param rateName
     * @param returnMessage
     * @return
     * @throws Exception
     */
    public boolean validateGetRateNames( List<RateName> rateNames,
            ReturnMessageDTO returnMessage ) throws Exception
    {
        LOGGER.debug( "validateGetRateNames : START" );

        boolean validateGetRateNameFalg = true;

        validateGetRateNameFalg = rtnm011CheckNoRecordsFoundForRateNames.isRecordsFound( rateNames,
                                                                                         returnMessage )
            && validateGetRateNameFalg;

        if( !validateGetRateNameFalg )
        {
            returnMessage.setStatus( ArrangementConfigServiceConstant.FAILURE_VALIDATION_STATUS );
            throw new VbrApplicationException( returnMessage );
        }
        else
        {
            returnMessage.setStatus( ArrangementConfigServiceConstant.SUCCESS_VALIDATION_STATUS );
        }

        LOGGER.debug( "validateGetRateNames : END" );
        return validateGetRateNameFalg;
    }

    /**
     * Method: validateGetFlatRates
     * @param flatRates
     * @param returnMessage
     * @return
     * @throws Exception
     */
    public boolean validateGetFlatRates( List<FlatRate> flatRates,
            ReturnMessageDTO returnMessage ) throws Exception
    {

        LOGGER.debug( "validateGetFlatRates : START" );

        boolean validateGetRateNameFalg = true;

        validateGetRateNameFalg = rtnm012CheckNoRecordsFoundForFlatRates.isRecordsFound( flatRates,
                                                                                         returnMessage )
            && validateGetRateNameFalg;

        if( !validateGetRateNameFalg )
        {
            returnMessage.setStatus( ArrangementConfigServiceConstant.FAILURE_VALIDATION_STATUS );
            throw new VbrApplicationException( returnMessage );
        }
        else
        {
            returnMessage.setStatus( ArrangementConfigServiceConstant.SUCCESS_VALIDATION_STATUS );
        }

        LOGGER.debug( "validateGetFlatRates : END" );
        return validateGetRateNameFalg;
    }

    public boolean validateLinkedArrangements( List<PaymentArrangementListResponse> linkedArrangementResponseList,
            ReturnMessageDTO returnMessage ) throws Exception
    {

        LOGGER.debug( "validateGetFlatRates : START" );

        boolean validateGetRateNameFalg = true;

        validateGetRateNameFalg = rtnm013CheckNoRecordsFoundForlinkedArrangements.isRecordsFound( linkedArrangementResponseList,
                                                                                                  returnMessage )
            && validateGetRateNameFalg;

        if( !validateGetRateNameFalg )
        {
            returnMessage.setStatus( ArrangementConfigServiceConstant.FAILURE_VALIDATION_STATUS );
            throw new VbrApplicationException( returnMessage );
        }
        else
        {
            returnMessage.setStatus( ArrangementConfigServiceConstant.SUCCESS_VALIDATION_STATUS );
        }

        LOGGER.debug( "validateGetFlatRates : END" );
        return validateGetRateNameFalg;
    }

}