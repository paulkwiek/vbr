package com.hcsc.vbr.arrangementconfigservice.dto;

import org.apache.commons.lang3.builder.ReflectionToStringBuilder;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.hcsc.vbr.common.dto.DateRecordDTO;
import com.hcsc.vbr.common.dto.PayToPFINPayeeAddressDTO;
import com.hcsc.vbr.common.dto.PayeeAddressDTO;
import com.hcsc.vbr.common.utils.MultilineRecursiveToStringStyleCustom;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonInclude( JsonInclude.Include.NON_NULL )
public class VbrPayeeDTO extends DateRecordDTO
{

    private static final long serialVersionUID = 1L;

    private Integer vbrPayeeId;

    private String corporateEntityCode;

    private String pinGroupId;

    private String pinGroupName;

    private String capitationProcessCode;

    private String networkCode;

    private String taxIdNumber;

    private String capitationCode;

    private String payToPfinId;

    private Integer networkAssociationID;

    private PayeeAddressDTO payeeAddress;

    private PayToPFINPayeeAddressDTO payToPFINPayeeAddress;

    private String pinGroupEffectiveDate;

    private String pinGroupEndDate;

    private String pfinEffectiveDate;

    private String pfinEndDate;

    private String tinEffectiveDate;

    private String tinEndDate;

    private String networkAssociationEffectiveDate;

    private String networkAssociationEndDate;

    private String networkAssociationName;

    private String payToPFINName;

    private String pINGroupCapitationEffectiveDate;

    private String pINGroupCapitationEndDate;

    private String providerFirstName;

    private String providerLastName;

    private String providerTitleCode;

    private String providerOrganizationName;

    private String providerOrganizationSecondName;

    private String addressLine1Text;

    private String addressLine2Text;

    private String cityName;

    private String stateCode;

    private String zipCode;

    //private List<PaymentArrangementPayeeDTO> paymentArrangementPayee = new ArrayList<PaymentArrangementPayeeDTO>();

    @Override
    public String toString()
    {
        return new ReflectionToStringBuilder( this,
                                              new MultilineRecursiveToStringStyleCustom() ).toString();
    }

}
