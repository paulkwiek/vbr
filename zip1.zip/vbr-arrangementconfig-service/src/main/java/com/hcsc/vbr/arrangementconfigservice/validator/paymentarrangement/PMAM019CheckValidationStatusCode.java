package com.hcsc.vbr.arrangementconfigservice.validator.paymentarrangement;

import java.text.ParseException;
import java.time.LocalDate;
import java.time.temporal.TemporalAdjusters;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.ObjectUtils;

import com.hcsc.vbr.arrangementconfigservice.constant.ArrangementConfigServiceConstant;
import com.hcsc.vbr.arrangementconfigservice.domain.PaymentArrangement;
import com.hcsc.vbr.arrangementconfigservice.utils.ArrangementConfigServiceUtils;
import com.hcsc.vbr.common.utils.VBRDateUtils;

@Component
public class PMAM019CheckValidationStatusCode
{

    @Autowired
    private ArrangementConfigServiceUtils arrangementConfigServiceUtils;

    /**
    * gets the arrangement validation status code
    * @param paymentArrangement
    * @return
    * @throws ParseException
    */
    public String getValidationStatusCode( PaymentArrangement paymentArrangement,
            boolean isRateInvalid,
            boolean isPayeeInvalid,
            LocalDate processingMonth,
            boolean isProcessingMonthvalid ) throws ParseException
    {
        String validationStatusCode = null;
        LocalDate arrangementEndDate = paymentArrangement.getRecordEndDate();
        LocalDate arrangementEffectiveDate = paymentArrangement.getRecordEffectiveDate();
        LocalDate firstDateOfProcessingMonth = processingMonth.with( TemporalAdjusters.firstDayOfMonth() );
        LocalDate lastDateOfProcessingMonth = VBRDateUtils.getLastDayOfMonth( processingMonth );

        if( !checkAllArrangementConfigured( paymentArrangement ) )
        {
            validationStatusCode = ArrangementConfigServiceConstant.ARRANGEMENT_STATUS_DRAFT;
        }
        else
        {
            /* NRW-22457 WHEN The arrangement duration is voided the status will be EXPIRED always
             * (irrespective of the Processing Month and if the Arrangement Duration is in Past or Future) */

            if( ( arrangementConfigServiceUtils.checkArrangementLocalDateEffandEndDateEqual( arrangementEndDate,
                                                                                             arrangementEffectiveDate ) ) )
            {
                validationStatusCode = ArrangementConfigServiceConstant.ARRANGEMENT_STATUS_EXPIRED;
            }
            else if( arrangementEndDate.isBefore( firstDateOfProcessingMonth ) )
            {
                validationStatusCode = ArrangementConfigServiceConstant.ARRANGEMENT_STATUS_EXPIRED;
            }
            else if( arrangementEffectiveDate.isAfter( lastDateOfProcessingMonth ) )
            {
                if( ( isRateInvalid || isPayeeInvalid ) )
                {
                    validationStatusCode = ArrangementConfigServiceConstant.ARRANGEMENT_STATUS_FUTURE_INVALID;
                }
                else
                {
                    validationStatusCode = ArrangementConfigServiceConstant.ARRANGEMENT_STATUS_FUTURE_VALID;
                }
            }

            /*WHEN The arrangement duration is valid for processing month and any rate or payee 
            validation is failing or resulting in warning message, arrangement status should be invalid */

            else if( ( arrangementEndDate.isEqual( lastDateOfProcessingMonth )
                || arrangementEndDate.isAfter( lastDateOfProcessingMonth ) )
                && ( arrangementEffectiveDate.isEqual( firstDateOfProcessingMonth )
                    || ( arrangementEffectiveDate.isBefore( firstDateOfProcessingMonth ) ) ) )
            {
                if( isRateInvalid || isPayeeInvalid )
                {
                    if( isProcessingMonthvalid )
                    {
                        validationStatusCode = ArrangementConfigServiceConstant.ARRANGEMENT_STATUS_WARNING;
                    }
                    else
                    {
                        validationStatusCode = ArrangementConfigServiceConstant.ARRANGEMENT_STATUS_INVALID;
                    }
                }
                else
                    validationStatusCode = ArrangementConfigServiceConstant.ARRANGEMENT_STATUS_VALID;
            }

        }

        return validationStatusCode;
    }

    /**
     * checks if all arrangement elements are configured
     * @param paymentArrangement
     * @return
     */
    public boolean checkAllArrangementConfigured( PaymentArrangement paymentArrangement )
    {
        if( ObjectUtils.isEmpty( paymentArrangement.getPaymentArrangementMemberSubjects() )
            || ObjectUtils.isEmpty( paymentArrangement.getPaymentArrangementPayees() )
            || ObjectUtils.isEmpty( paymentArrangement.getPaymentArrangementRates() ) )

            return false;
        else
            return true;

    }

}
