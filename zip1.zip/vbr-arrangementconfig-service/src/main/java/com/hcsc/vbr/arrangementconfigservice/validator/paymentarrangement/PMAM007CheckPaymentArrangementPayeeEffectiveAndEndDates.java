package com.hcsc.vbr.arrangementconfigservice.validator.paymentarrangement;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.hcsc.vbr.arrangementconfigservice.constant.ArrangementConfigServiceErrorMessageConstant;
import com.hcsc.vbr.arrangementconfigservice.constant.ComponentIdConstant;
import com.hcsc.vbr.arrangementconfigservice.constant.FieldIdConstant;
import com.hcsc.vbr.arrangementconfigservice.domain.PaymentArrangementPayee;
import com.hcsc.vbr.arrangementconfigservice.validator.base.BaseValidationUnit;
import com.hcsc.vbr.common.dto.ReturnMessageDTO;
import com.hcsc.vbr.common.utils.VBRDateUtils;

@Component
public class PMAM007CheckPaymentArrangementPayeeEffectiveAndEndDates extends BaseValidationUnit
{

    final Logger LOGGER = LoggerFactory.getLogger( PMAM007CheckPaymentArrangementPayeeEffectiveAndEndDates.class );

    /**
     * Method: validatePaymentArrangementPayeeEffectiveAndEndDatesList
     * @param dateRecordList
     * @param errors
     * @return
     * @throws Exception
     */
    public boolean validatePaymentArrangementPayeeEffectiveAndEndDates(
            List<PaymentArrangementPayee> paymentArrangementPayeedateRecordList,
            ReturnMessageDTO returnMessage ) throws Exception
    {
        LOGGER.debug( "validatePaymentArrangementPayeeEffectiveAndEndDates : START" );

        boolean isArrangementPayeeEffAndEndDateInvalid = false;

        if( !VBRDateUtils.checkEffectiveAndEndDatesList( paymentArrangementPayeedateRecordList ) )
        {
            addToReturnMessage( ArrangementConfigServiceErrorMessageConstant.ARRNG_PAYEE_EFF_END_DATE_VALIDATION,
                                FieldIdConstant.PMPY_EFF_AND_END_DATE,
                                ComponentIdConstant.PMAM,
                                this.getClass().getSimpleName(),
                                returnMessage );
            isArrangementPayeeEffAndEndDateInvalid = true;
        }

        LOGGER.debug( "PaymentArrangementPayee Effective Dates is before  EndDates : " + isArrangementPayeeEffAndEndDateInvalid );
        LOGGER.debug( "validatePaymentArrangementPayeeEffectiveAndEndDates : END" );
        return isArrangementPayeeEffAndEndDateInvalid;
    }

}