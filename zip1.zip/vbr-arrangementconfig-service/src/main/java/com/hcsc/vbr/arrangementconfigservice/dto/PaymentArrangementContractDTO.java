package com.hcsc.vbr.arrangementconfigservice.dto;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.builder.ReflectionToStringBuilder;

import com.hcsc.vbr.common.dto.DateRecordDTO;
import com.hcsc.vbr.common.utils.MultilineRecursiveToStringStyleCustom;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PaymentArrangementContractDTO extends DateRecordDTO
{

    private static final long serialVersionUID = 1L;

    private Integer paymentArrangementContractId;

    private String programCode;

    private String contractDescription;

    private List<PaymentArrangementDTO> paymentArrangement = new ArrayList<PaymentArrangementDTO>();

    @Override
    public String toString()
    {
        return new ReflectionToStringBuilder( this,
                                              new MultilineRecursiveToStringStyleCustom() ).toString();
    }

}
