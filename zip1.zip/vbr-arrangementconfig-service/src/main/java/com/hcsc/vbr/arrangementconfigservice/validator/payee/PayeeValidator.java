
package com.hcsc.vbr.arrangementconfigservice.validator.payee;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.hcsc.vbr.arrangementconfigservice.constant.ArrangementConfigServiceConstant;
import com.hcsc.vbr.arrangementconfigservice.domain.VbrPayee;
import com.hcsc.vbr.arrangementconfigservice.validator.base.BaseValidator;
import com.hcsc.vbr.common.dto.ReturnMessageDTO;
import com.hcsc.vbr.common.exception.VbrApplicationException;
import com.hcsc.vbr.web.request.PayeeSearchRequest;
import com.hcsc.vbr.web.response.ProviderAPIResponseDTO;
import com.hcsc.vbr.web.response.ProviderAPISearchResponseDTO;

@Component
public class PayeeValidator extends BaseValidator
{

    @Autowired
    private VBPY001ValidatePinGroupIdInSearch vbpy001ValidatePinGroupIdInSearch;

    @Autowired
    private VBPY002ValidateVbrEfffectiveAndEndDate vbpy002ValidateVbrEfffectiveAndEndDate;

    @Autowired
    private VBPY004ValidateVbrPayeePfinId vbpy004ValidateVbrPayeePfinId;

    @Autowired
    private VBPY005ProviderAPIValidations vbpy005ProviderAPIValidations;

    @Autowired
    private VBPY007ValidateUniquePayee vbpy007ValidateUniquePayee;

    @Autowired
    private VBPY008ValidateVbrPayeePinGroupId vbpy008ValidateVbrPayeePinGroupId;

    @Autowired
    private VBPY009ValidateVbrPayeeTaxIdNumber vbpy009ValidateVbrPayeeTaxIdNumber;

    @Autowired
    private VBPY010ValidateVbrPayeeCapitationCode vbpy010ValidateVbrPayeeCapitationCode;

    @Autowired
    private VBPY011ValidateVbrPayeeCaptitationProcessCode vbpy011ValidateVbrPayeeCaptitationProcessCode;

    @Autowired
    private VBPY012ValidateVbrPayeeCorporateEntityCode vbpy012ValidateVbrPayeeCorporateEntityCode;

    @Autowired
    private VBPY013ValidateVbrPayeeNetworkCode vbpy013ValidateVbrPayeeNetworkCode;

    @Autowired
    private VBPY014ValidateVbrPayeePinGroupName vbpy014ValidateVbrPayeePinGroupName;

    @Autowired
    private VBPY015ValidateVbrPayeeEffDateIsFirstDayOfMonth vbpy015ValidateVbrPayeeEffDateIsFirstDayOfMonth;

    @Autowired
    private VBPY016ValidateVbrPayeeEndDateIsLastDayOfMonth vbpy016ValidateVbrPayeeEndDateIsLastDayOfMonth;

    @Autowired
    VBPY017ValidateNoRecordsFoundForPayee vbpy017ValidateNoRecordsFoundForPayee;

    @Autowired
    VBPY018ValidateNoRecordsFoundForPayeeFromProviderApi vbpy018ValidateNoRecordsFoundForPayeeFromProviderApi;

    @Autowired
    VBPY019ValidateStatusOfLinkedArrangementsInUpdatePayee vbpy019ValidateStatusOfLinkedArrangementsInUpdatePayee;

    @Autowired
    VBPY020ValidateRetrievePayee vbpy020ValidateRetrievePayee;

    @Autowired
    VBPY021ValidateNoMatchingRecordFoundForPayeeFromProviderApi vbpy021ValidateNoMatchingRecordFoundForPayeeFromProviderApi;

    @Autowired
    private VBPY022ValidatePingroupIdInSearchPayee validateSearch;
    private static final Logger LOGGER = LoggerFactory.getLogger( PayeeValidator.class );

    /**
     * Method: validateSearchPayee
     * @param payeeSearchRequest
     * @param returnMessage
     * @return
     * @throws Exception
     */
    public boolean validateSearchPayee( PayeeSearchRequest payeeSearchRequest,
            ReturnMessageDTO returnMessage ) throws Exception
    {
        LOGGER.debug( "validateSearchPayee : START" );
        boolean isPinGrpIdValid = true;
        isPinGrpIdValid = vbpy001ValidatePinGroupIdInSearch.validatePinGroupId( payeeSearchRequest,
                                                                                returnMessage );
        LOGGER.debug( "validateSearchPayee : END " + returnMessage );

        /**
         * If the flag is false which means basic validations failed, we cannot save the record but throw VbrApplicationException
         * so that the errors are sent back to the UI for displaying and also highlighting the appropriate fields.
         */

        if( !isPinGrpIdValid )
        {
            returnMessage.setStatus( ArrangementConfigServiceConstant.FAILURE_VALIDATION_STATUS );
            throw new VbrApplicationException( returnMessage );
        }
        else
        {
            returnMessage.setStatus( ArrangementConfigServiceConstant.SUCCESS_VALIDATION_STATUS );
        }
        return isPinGrpIdValid;
    }

    /**
     * @param payeeSearchRequest
     * @param returnMessage
     * @return
     * @throws Exception
     */
    public boolean validateRetrievePayee( PayeeSearchRequest payeeSearchRequest,
            ReturnMessageDTO returnMessage ) throws Exception
    {
        LOGGER.debug( "validateRetrievePayee : START" );
        boolean isPinGrpIdValid = true;
        isPinGrpIdValid = vbpy020ValidateRetrievePayee.validatePinGroupId( payeeSearchRequest,
                                                                           returnMessage );
        LOGGER.debug( "validateRetrievePayee : END " + returnMessage );

        /**
         * If the flag is false which means basic validations failed, we cannot save the record but throw VbrApplicationException
         * so that the errors are sent back to the UI for displaying and also highlighting the appropriate fields.
         */

        if( !isPinGrpIdValid )
        {
            returnMessage.setStatus( ArrangementConfigServiceConstant.FAILURE_VALIDATION_STATUS );
            throw new VbrApplicationException( returnMessage );
        }
        else
        {
            returnMessage.setStatus( ArrangementConfigServiceConstant.SUCCESS_VALIDATION_STATUS );
        }
        return isPinGrpIdValid;
    }

    /**
     * Method: validateSavePayee
     * @param vbrPayee
     * @param returnMessage
     * @return
     * @throws Exception
     */
    public boolean validateSavePayee( VbrPayee vbrPayee,
            ReturnMessageDTO returnMessage ) throws Exception
    {
        LOGGER.debug( "validateSavePayee : START" );

        boolean validateSaveFlag = true;

        validateSaveFlag = vbpy002ValidateVbrEfffectiveAndEndDate.validateVBRPayeeEffAndEndDate( vbrPayee,
                                                                                                 returnMessage )
            && validateSaveFlag;

        validateSaveFlag = vbpy015ValidateVbrPayeeEffDateIsFirstDayOfMonth.isFirstDayOfMonth( vbrPayee,
                                                                                              returnMessage )
            && validateSaveFlag;

        validateSaveFlag = vbpy016ValidateVbrPayeeEndDateIsLastDayOfMonth.isLastDayOfMonth( vbrPayee,
                                                                                            returnMessage )
            && validateSaveFlag;

        validateSaveFlag = vbpy007ValidateUniquePayee.validateUniquePayee( vbrPayee,
                                                                           returnMessage )
            && validateSaveFlag;
        validateSaveFlag = vbpy005ProviderAPIValidations.providerAPIValidations( vbrPayee,
                                                                                 returnMessage )
            && validateSaveFlag;
        validateSaveFlag = vbpy004ValidateVbrPayeePfinId.validateVbrPayeePfinIdFieldLength( vbrPayee,
                                                                                            returnMessage )
            && validateSaveFlag;

        validateSaveFlag = vbpy008ValidateVbrPayeePinGroupId.validateVbrPayeePinGroupIDFieldLength( vbrPayee,
                                                                                                    returnMessage )
            && validateSaveFlag;
        validateSaveFlag = vbpy009ValidateVbrPayeeTaxIdNumber.validateVbrPayeeTaxIdNumberFieldLength( vbrPayee,
                                                                                                      returnMessage )
            && validateSaveFlag;
        validateSaveFlag = vbpy010ValidateVbrPayeeCapitationCode.validateVbrPayeeCapitationCodeFieldLength( vbrPayee,
                                                                                                            returnMessage )
            && validateSaveFlag;
        validateSaveFlag = vbpy011ValidateVbrPayeeCaptitationProcessCode.validateVbrPayeeCapitationProcessCodeFieldLength( vbrPayee,
                                                                                                                           returnMessage )
            && validateSaveFlag;
        validateSaveFlag = vbpy012ValidateVbrPayeeCorporateEntityCode.validateVbrPayeeCorporateEntityCodeFieldLength( vbrPayee,
                                                                                                                      returnMessage )
            && validateSaveFlag;
        validateSaveFlag = vbpy013ValidateVbrPayeeNetworkCode.validateVbrPayeeNetworkCodeFieldLength( vbrPayee,
                                                                                                      returnMessage )
            && validateSaveFlag;
        validateSaveFlag = vbpy014ValidateVbrPayeePinGroupName.validateVbrPayeePinGroupNameFieldLength( vbrPayee,
                                                                                                        returnMessage )
            && validateSaveFlag;

        LOGGER.debug( "validateSavePayee : END " + returnMessage );

        /**
         * If the flag is false which means basic validations failed, we cannot save the record but throw VbrApplicationException
         * so that the errors are sent back to the UI for displaying and also highlighting the appropriate fields.
         */

        if( !validateSaveFlag )
        {
            System.out.println( "Failed" );
            returnMessage.setStatus( ArrangementConfigServiceConstant.FAILURE_VALIDATION_STATUS );
            throw new VbrApplicationException( returnMessage );
        }
        else
        {
            returnMessage.setStatus( ArrangementConfigServiceConstant.SUCCESS_VALIDATION_STATUS );
        }

        return validateSaveFlag;
    }

    /**
     * Method: validateUniquePayee
     * @param vbrPayee
     * @param returnMessage
     * @return
     * @throws Exception
     */
    public boolean validateUniquePayee( VbrPayee vbrPayee,
            ReturnMessageDTO returnMessage ) throws Exception
    {
        LOGGER.debug( "validateUniquePayee : Start " );
        boolean isPayeeUnique = true;
        isPayeeUnique = vbpy007ValidateUniquePayee.validateUniquePayee( vbrPayee,
                                                                        returnMessage );
        LOGGER.debug( "validateUniquePayee : END " + returnMessage );

        /**
         * If the flag is false which means basic validations failed, we cannot save the record but throw VbrApplicationException
         * so that the errors are sent back to the UI for displaying and also highlighting the appropriate fields.
         */

        if( !isPayeeUnique )
        {
            returnMessage.setStatus( ArrangementConfigServiceConstant.FAILURE_VALIDATION_STATUS );
            throw new VbrApplicationException( returnMessage );
        }
        else
        {
            returnMessage.setStatus( ArrangementConfigServiceConstant.SUCCESS_VALIDATION_STATUS );
        }
        return isPayeeUnique;
    }

    /**
     * @param payee
     * @param returnMessage
     * @return
     * @throws Exception
     */
    public boolean validateStatusOfLinkedArrangementsInUpdatePayee( VbrPayee payee,
            ReturnMessageDTO returnMessage ) throws Exception
    {
        LOGGER.debug( "validateStatusOfLinkedArrangementsInUpdatePayee : START" );

        boolean validateStatusOfLinkedArrangements = true;

        validateStatusOfLinkedArrangements =
            vbpy019ValidateStatusOfLinkedArrangementsInUpdatePayee.validateStatusOFLinkedArrangements( payee,
                                                                                                       returnMessage )
                && validateStatusOfLinkedArrangements;

        LOGGER.debug( "validateStatusOfLinkedArrangementsInUpdatePayee : END" );
        return validateStatusOfLinkedArrangements;

    }

    /**
     * @param payees
     * @param returnMessage
     * @return
     * @throws Exception
     */
    public boolean validateGetPayees( List<VbrPayee> payees,
            ReturnMessageDTO returnMessage ) throws Exception
    {

        LOGGER.debug( "validateGetFlatRates : START" );

        boolean validateGetPayeesFalg = true;

        validateGetPayeesFalg = vbpy017ValidateNoRecordsFoundForPayee.isRecordsFound( payees,
                                                                                      returnMessage )
            && validateGetPayeesFalg;

        if( !validateGetPayeesFalg )
        {
            returnMessage.setStatus( ArrangementConfigServiceConstant.FAILURE_VALIDATION_STATUS );
            throw new VbrApplicationException( returnMessage );
        }
        else
        {
            returnMessage.setStatus( ArrangementConfigServiceConstant.SUCCESS_VALIDATION_STATUS );
        }

        LOGGER.debug( "validateGetFlatRates : END" );
        return validateGetPayeesFalg;
    }

    /**
     * @param payees
     * @param returnMessage
     * @return
     * @throws Exception
     */
    public boolean validateGetPayeesFromProviderApi( List<ProviderAPIResponseDTO> payees,
            ReturnMessageDTO returnMessage ) throws Exception
    {

        LOGGER.debug( "validateGetFlatRates : START" );

        boolean validateGetPayeesFromProvidersFalg = true;

        validateGetPayeesFromProvidersFalg = vbpy018ValidateNoRecordsFoundForPayeeFromProviderApi.isRecordsFound( payees,
                                                                                                                  returnMessage )
            && validateGetPayeesFromProvidersFalg;

        if( !validateGetPayeesFromProvidersFalg )
        {
            returnMessage.setStatus( ArrangementConfigServiceConstant.FAILURE_VALIDATION_STATUS );
            throw new VbrApplicationException( returnMessage );
        }
        else
        {
            returnMessage.setStatus( ArrangementConfigServiceConstant.SUCCESS_VALIDATION_STATUS );
        }

        LOGGER.debug( "validateGetFlatRates : END" );
        return validateGetPayeesFromProvidersFalg;
    }

    public void validateSearch( PayeeSearchRequest payeeSearchRequest,
            ReturnMessageDTO returnMessage ) throws Exception
    {
        LOGGER.debug( "validateSearch : START" );

        boolean validatePinGroup = true;

        validatePinGroup = validateSearch.validateSearch( payeeSearchRequest,
                                                          returnMessage )
            && validatePinGroup;

        if( validatePinGroup )
        {
            returnMessage.setStatus( ArrangementConfigServiceConstant.FAILURE_VALIDATION_STATUS );
            throw new VbrApplicationException( returnMessage );
        }
        else
        {
            returnMessage.setStatus( ArrangementConfigServiceConstant.SUCCESS_VALIDATION_STATUS );
        }
        LOGGER.debug( "validateSearch : validatePinGroup" + validatePinGroup );
        LOGGER.debug( "validateSearch : END" );

    }

    /**
     * @param capitationPinGroupResponse
     * @param returnMessage
     * @return
     * @throws Exception
     */
    public boolean validateGetPayeesMatchingFromProviderApi( List<ProviderAPISearchResponseDTO> capitationPinGroupResponse,
            ReturnMessageDTO returnMessage ) throws Exception
    {

        LOGGER.debug( "validateGetFlatRates : START" );

        boolean validateGetPayeesFromProvidersFalg = true;

        validateGetPayeesFromProvidersFalg =
            vbpy021ValidateNoMatchingRecordFoundForPayeeFromProviderApi.isRecordsFound( capitationPinGroupResponse,
                                                                                        returnMessage )
                && validateGetPayeesFromProvidersFalg;

        if( !validateGetPayeesFromProvidersFalg )
        {
            returnMessage.setStatus( ArrangementConfigServiceConstant.FAILURE_VALIDATION_STATUS );
            throw new VbrApplicationException( returnMessage );
        }
        else
        {
            returnMessage.setStatus( ArrangementConfigServiceConstant.SUCCESS_VALIDATION_STATUS );
        }

        LOGGER.debug( "validateGetFlatRates : END" );
        return validateGetPayeesFromProvidersFalg;
    }

}
