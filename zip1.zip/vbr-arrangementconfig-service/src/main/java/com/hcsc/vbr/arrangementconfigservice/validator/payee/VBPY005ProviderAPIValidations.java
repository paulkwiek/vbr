package com.hcsc.vbr.arrangementconfigservice.validator.payee;

import java.time.LocalDate;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.hcsc.vbr.arrangementconfigservice.constant.ArrangementConfigServiceErrorMessageConstant;
import com.hcsc.vbr.arrangementconfigservice.constant.ComponentIdConstant;
import com.hcsc.vbr.arrangementconfigservice.constant.FieldIdConstant;
import com.hcsc.vbr.arrangementconfigservice.domain.VbrPayee;
import com.hcsc.vbr.arrangementconfigservice.validator.base.BaseValidationUnit;
import com.hcsc.vbr.common.domain.DateRecord;
import com.hcsc.vbr.common.dto.ReturnMessageDTO;
import com.hcsc.vbr.common.utils.VBRDateUtils;

@Component
public class VBPY005ProviderAPIValidations extends BaseValidationUnit
{

    private static final Logger LOGGER = LoggerFactory.getLogger( VBPY005ProviderAPIValidations.class );

    /**
     * Method: providerAPIValidations
     * @param vbrPayee
     * @param returnMessage
     * @return
     * @throws Exception
     */
    public boolean providerAPIValidations( VbrPayee vbrPayee,
            ReturnMessageDTO returnMessage ) throws Exception
    {
        LOGGER.debug( "VBPY005ProviderAPIValidations : Start" );
        boolean isProviderDatesValid = true;

        //Parent DateRecords
        DateRecord pinGroupParentRecord =
            createDateRecord( VBRDateUtils.convertStringToLocalDateDefaultFormat( vbrPayee.getPinGroupEffectiveDate() ),
                              VBRDateUtils.convertStringToLocalDateDefaultFormat( vbrPayee.getPinGroupEndDate() ) );

        DateRecord networkAssociationParentRecord =
            createDateRecord( VBRDateUtils.convertStringToLocalDateDefaultFormat( vbrPayee.getNetworkAssociationEffectiveDate() ),
                              VBRDateUtils.convertStringToLocalDateDefaultFormat( vbrPayee.getNetworkAssociationEndDate() ) );

        DateRecord pfinParentRecord =
            createDateRecord( VBRDateUtils.convertStringToLocalDateDefaultFormat( vbrPayee.getPfinEffectiveDate() ),
                              VBRDateUtils.convertStringToLocalDateDefaultFormat( vbrPayee.getPfinEndDate() ) );

        DateRecord tinParentRecord =
            createDateRecord( VBRDateUtils.convertStringToLocalDateDefaultFormat( vbrPayee.getTinEffectiveDate() ),
                              VBRDateUtils.convertStringToLocalDateDefaultFormat( vbrPayee.getTinEndDate() ) );

        boolean validatePinGroupDateCoverage = VBRDateUtils.checkDateCoverage( pinGroupParentRecord,
                                                                               vbrPayee );
        boolean validateNetworkAssociationDateCoverage = VBRDateUtils.checkDateCoverage( networkAssociationParentRecord,
                                                                                         vbrPayee );
        boolean validatePfinDatecoverage = VBRDateUtils.checkDateCoverage( pfinParentRecord,
                                                                           vbrPayee );
        boolean validateTinDateCoverage = VBRDateUtils.checkDateCoverage( tinParentRecord,
                                                                          vbrPayee );

        if( !validatePinGroupDateCoverage
            || !validateNetworkAssociationDateCoverage
            || !validatePfinDatecoverage
            || !validateTinDateCoverage )
        {
            isProviderDatesValid = false;

            addToReturnMessage( ArrangementConfigServiceErrorMessageConstant.PROVIDER_API_DATES_VALIDATION,
                                FieldIdConstant.VBPY_PROVIDER_DATES,
                                ComponentIdConstant.VBPY,
                                this.getClass().getSimpleName(),
                                returnMessage );
        }

        LOGGER.debug( "VBPY005ProviderAPIValidations : END" );
        return isProviderDatesValid;

    }

    /**
     * Creates the date record.
     *
     * @param recordEffectiveDate the record effective date
     * @param recordEndDate       the record end date
     * @return the date record
     */
    private DateRecord createDateRecord( LocalDate recordEffectiveDate,
            LocalDate recordEndDate )
    {
        DateRecord dateRecord = new DateRecord();
        dateRecord.setRecordEffectiveDate( recordEffectiveDate );
        dateRecord.setRecordEndDate( recordEndDate );
        return dateRecord;
    }

}
