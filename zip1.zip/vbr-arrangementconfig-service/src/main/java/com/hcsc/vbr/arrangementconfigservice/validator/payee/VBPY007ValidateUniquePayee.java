package com.hcsc.vbr.arrangementconfigservice.validator.payee;

import org.apache.commons.collections4.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.hcsc.vbr.arrangementconfigservice.constant.ArrangementConfigServiceErrorMessageConstant;
import com.hcsc.vbr.arrangementconfigservice.constant.ComponentIdConstant;
import com.hcsc.vbr.arrangementconfigservice.constant.FieldIdConstant;
import com.hcsc.vbr.arrangementconfigservice.domain.VbrPayee;
import com.hcsc.vbr.arrangementconfigservice.repository.VbrPayeeRepository;
import com.hcsc.vbr.arrangementconfigservice.validator.base.BaseValidationUnit;
import com.hcsc.vbr.common.dto.ReturnMessageDTO;

@Component
public class VBPY007ValidateUniquePayee extends BaseValidationUnit
{
    private static final Logger LOGGER = LoggerFactory.getLogger( VBPY007ValidateUniquePayee.class );

    @Autowired
    private VbrPayeeRepository vbrPayeeRepository;

    /**
     * Check for duplicate Payee in VBR D
     * Method: validateUniquePayee
     * @param payeeSaveRequest
     * @param returnMessage
     * @return
     * @throws Exception
     */
    public boolean validateUniquePayee( VbrPayee vbrPayee,
            ReturnMessageDTO returnMessage ) throws Exception
    {
        LOGGER.debug( "VBPY007ValidateUniquePayee : Start" );

        boolean isPayeeUnique = true;

        if( ( vbrPayee.getVbrPayeeId() == null ) && ( CollectionUtils.isNotEmpty( vbrPayeeRepository.findUniquePayee( vbrPayee ) ) ) )
        {
            isPayeeUnique = false;
            addToReturnMessage( ArrangementConfigServiceErrorMessageConstant.UNIQUE_PAYEE_VALIDATION,
                                FieldIdConstant.VBPY_PAYEE_ID,
                                ComponentIdConstant.VBPY,
                                this.getClass().getSimpleName(),
                                returnMessage );

        }
        LOGGER.debug( "VBPY007ValidateUniquePayee : END" );
        return isPayeeUnique;

    }

}
