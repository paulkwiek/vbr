package com.hcsc.vbr.arrangementconfigservice.validator.paymentarrangement;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.util.ObjectUtils;

import com.hcsc.vbr.arrangementconfigservice.constant.ArrangementConfigServiceErrorMessageConstant;
import com.hcsc.vbr.arrangementconfigservice.constant.ComponentIdConstant;
import com.hcsc.vbr.arrangementconfigservice.constant.FieldIdConstant;
import com.hcsc.vbr.arrangementconfigservice.domain.VbrPayee;
import com.hcsc.vbr.arrangementconfigservice.validator.base.BaseValidationUnit;
import com.hcsc.vbr.common.dto.ReturnMessageDTO;

@Component
public class PMAM045CheckRetrievePayee extends BaseValidationUnit
{
    final Logger LOGGER = LoggerFactory.getLogger( PMAM045CheckRetrievePayee.class );

    public boolean validateRetrievePayee( List<VbrPayee> vbrPayeeRecord,
            ReturnMessageDTO returnMessage ) throws Exception
    {
        LOGGER.debug( "validateRetrievePayee : START" );

        boolean isArrangementValid = true;

        if( ObjectUtils.isEmpty( vbrPayeeRecord ) )
        {
            isArrangementValid = false;
            LOGGER.debug( "validateRetrievePayee : NO ARRANGEMENT RECORD" );
            addToReturnMessage( ArrangementConfigServiceErrorMessageConstant.NO_PAYEE_RECORDS_FOUND,
                                FieldIdConstant.PMAM_PAYEE,
                                ComponentIdConstant.PMAM,
                                this.getClass().getSimpleName(),
                                returnMessage );

        }
        LOGGER.debug( "validateRetrievePayee : END" );
        return isArrangementValid;
    }

}
