package com.hcsc.vbr.arrangementconfigservice.validator.payee;

import java.util.List;

import org.apache.commons.collections4.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.hcsc.vbr.arrangementconfigservice.constant.ArrangementConfigServiceErrorMessageConstant;
import com.hcsc.vbr.arrangementconfigservice.constant.ComponentIdConstant;
import com.hcsc.vbr.arrangementconfigservice.constant.FieldIdConstant;
import com.hcsc.vbr.arrangementconfigservice.domain.VbrPayee;
import com.hcsc.vbr.arrangementconfigservice.validator.base.BaseValidationUnit;
import com.hcsc.vbr.common.dto.ReturnMessageDTO;

@Component
public class VBPY017ValidateNoRecordsFoundForPayee extends BaseValidationUnit
{

    private static final Logger LOGGER = LoggerFactory.getLogger( VBPY017ValidateNoRecordsFoundForPayee.class );

    /**
     * Method: isRecordsFound
     * @param payees
     * @param returnMessage
     * @return
     * @throws Exception
     */
    public boolean isRecordsFound( List<VbrPayee> payees,
            ReturnMessageDTO returnMessage ) throws Exception
    {

        LOGGER.debug( "VBPY017ValidateNoRecordsFoundForPayee : START" );

        boolean isRecordsFound = true;

        if( CollectionUtils.isEmpty( payees ) )
        {
            isRecordsFound = false;
            addToReturnMessage( ArrangementConfigServiceErrorMessageConstant.NO_PAYEE_RECORDS_FOUND,
                                FieldIdConstant.NO_RECORDS,
                                ComponentIdConstant.VBPY,
                                this.getClass().getSimpleName(),
                                returnMessage );
        }

        LOGGER.debug( "VBPY017ValidateNoRecordsFoundForPayee : END" );

        return isRecordsFound;

    }
}
