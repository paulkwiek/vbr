package com.hcsc.vbr.arrangementconfigservice.dto;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import com.hcsc.vbr.common.dto.BaseEntityDTO;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CalculationRequestDTO extends BaseEntityDTO
{

    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    private Integer calculationRequestId;

    private String calculationRunName;

    private String corporateEntityCode;

    private String calculationRequestName;

    //    @JsonFormat( shape = JsonFormat.Shape.STRING, pattern = DateTimePattern.DatePattern )
    private LocalDate processPeriodDate;

    //    @JsonFormat( shape = JsonFormat.Shape.STRING, pattern = DateTimePattern.DateTimePattern )
    private LocalDateTime requestSubmittedTimestamp;

    private String requestSubmittedUserId;

    private String validationStatusCode;

    private String requestCommentText;

    private String lineOfBusinessCode;

    private List<CalculationRequestGroupingDTO> calculationRequestGroupingDTOs = new ArrayList<CalculationRequestGroupingDTO>();

}
