package com.hcsc.vbr.web.response;

import java.io.Serializable;
import java.util.List;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CodeServiceStausDescriptionResponse implements Serializable
{

    private static final long serialVersionUID = 1L;

    private List<CodeSetValueDTO> codeSetValueItems;
}
