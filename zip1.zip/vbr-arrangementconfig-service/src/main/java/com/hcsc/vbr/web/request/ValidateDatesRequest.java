package com.hcsc.vbr.web.request;

import java.io.Serializable;

import org.apache.commons.lang3.builder.ReflectionToStringBuilder;

import com.hcsc.vbr.arrangementconfigservice.dto.ValidateDatesDTO;
import com.hcsc.vbr.common.utils.MultilineRecursiveToStringStyleCustom;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ValidateDatesRequest implements Serializable
{
    private static final long serialVersionUID = 1L;
    
    private ValidateDatesDTO validateDates;

    private boolean warningState;

    @Override
    public String toString()
    {
        return new ReflectionToStringBuilder( this,
                                              new MultilineRecursiveToStringStyleCustom() ).toString();
    }

}
