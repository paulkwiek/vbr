package com.hcsc.vbr.arrangementconfigservice.utils;

import java.text.ParseException;
import java.time.LocalDate;
import java.time.temporal.TemporalAdjusters;
import java.util.List;

import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.hcsc.vbr.arrangementconfigservice.constant.ArrangementConfigServiceConstant;
import com.hcsc.vbr.arrangementconfigservice.constant.ArrangementConfigServiceErrorMessageConstant;
import com.hcsc.vbr.arrangementconfigservice.dto.PaymentArrangementDTO;
import com.hcsc.vbr.arrangementconfigservice.dto.VbrPayeeDTO;
import com.hcsc.vbr.common.constant.VBRCommonConstant;
import com.hcsc.vbr.common.domain.DateRecord;
import com.hcsc.vbr.common.dto.ErrorMessageDTO;
import com.hcsc.vbr.common.utils.VBRDateUtils;
import com.hcsc.vbr.web.response.ProviderAPIResponseDTO;

@Component
public class ArrangementConfigServiceUtils
{
    final Logger LOGGER = LoggerFactory.getLogger( ArrangementConfigServiceUtils.class );

    /***  Get the last day of the month for given LocalDate ******/
    public static LocalDate getLastDayOfMonth( LocalDate endDate ) throws ParseException
    {
        LocalDate lastDate = null;

        lastDate = endDate.with( TemporalAdjusters.lastDayOfMonth() );

        return lastDate;
    }

    /**
     * Method: getMatchingProviderFromAPI
     * @param payee
     * @param providerAPIResponseDTOs
     * @return
     */
    public static ProviderAPIResponseDTO getMatchingProviderFromAPI( VbrPayeeDTO payee,
            List<ProviderAPIResponseDTO> providerAPIResponseDTOs )
    {
        ProviderAPIResponseDTO finalresponse = null;
        for( ProviderAPIResponseDTO prApiResponseDTO : providerAPIResponseDTOs )
        {
            if( StringUtils.equalsIgnoreCase( StringUtils.trimToEmpty( payee.getPinGroupName() ),
                                              StringUtils.trimToEmpty( prApiResponseDTO.getPingroupName() ) )

                && StringUtils.equalsIgnoreCase( StringUtils.trimToEmpty( payee.getNetworkAssociationID().toString() ),
                                                 StringUtils.trimToEmpty( prApiResponseDTO.getNetworkAssociationID() ) )

                && StringUtils.equalsIgnoreCase( StringUtils.trimToEmpty( payee.getNetworkCode() ),
                                                 StringUtils.trimToEmpty( prApiResponseDTO.getNetworkCode() ) )

                && StringUtils.equalsIgnoreCase( StringUtils.trimToEmpty( payee.getPayToPfinId() ),
                                                 StringUtils.trimToEmpty( prApiResponseDTO.getPayToPFINId() ) )

                && StringUtils.equalsIgnoreCase( StringUtils.trimToEmpty( payee.getCapitationProcessCode() ),
                                                 StringUtils.trimToEmpty( prApiResponseDTO.getProcessCode() ) )

                && StringUtils.equalsIgnoreCase( StringUtils.trimToEmpty( payee.getCapitationCode() ),
                                                 StringUtils.trimToEmpty( prApiResponseDTO.getCapitationTypeCode() ) ) )
            {
                finalresponse = prApiResponseDTO;
            }

        }

        return finalresponse;

    }

    /**
     * Method: isOverwriteSaveArrangement
     * @param overwriteSaveArrangement
     * @return
     */
    public boolean isOverwriteSaveArrangement( String overwriteSaveArrangement )
    {
        boolean overwriteArrangement = false;
        if( StringUtils.equalsIgnoreCase( overwriteSaveArrangement,
                                          ArrangementConfigServiceConstant.STRING_TRUE ) )
        {
            overwriteArrangement = true;
        }
        return overwriteArrangement;
    }

    // NRW-22098 - VBR USER CLICK SAVE ARRANGEMENT ON POP UP CONFIRM MESSAGE IF CLICKS CANCEL THEN THIS  FLAG WILL BE SET TRUE AND WARNINGS WILL BE DISPLAYED
    /**
     * Method: isOverwriteCancelArrangementStatus
     * @param paymentArrangementRequest
     * @return
     */
    public boolean isOverwriteCancelArrangementStatus( PaymentArrangementDTO paymentArrangementRequest )
    {
        String overwriteCancelArrangement = paymentArrangementRequest.getOverwriteCancelArrangement();
        boolean isoverwriteCancelArrangement = false;
        if( !isOverwriteSaveArrangementStatus( paymentArrangementRequest ) && StringUtils.equalsIgnoreCase( overwriteCancelArrangement,
                                                                                                            ArrangementConfigServiceConstant.STRING_TRUE ) )
        {
            isoverwriteCancelArrangement = true;
        }
        return isoverwriteCancelArrangement;
    }

    /**
     * Method: isOverwriteSaveArrangementStatus
     * @param paymentArrangementRequest
     * @return
     */
    public boolean isOverwriteSaveArrangementStatus( PaymentArrangementDTO paymentArrangementRequest )
    {
        String overwriteSaveArrangement = paymentArrangementRequest.getOverwriteSaveArrangement();
        boolean overwriteArrangement = false;
        if( StringUtils.equalsIgnoreCase( overwriteSaveArrangement,
                                          ArrangementConfigServiceConstant.STRING_TRUE ) )
        {
            overwriteArrangement = true;
        }
        return overwriteArrangement;
    }

    /**
     * Method: isConfirmMessage
     * @param paymentArrangementRequest
     * @return
     */
    public boolean isConfirmMessageDraft( ErrorMessageDTO error )
    {
        Long errorId = error.getErrorMessageId();

        if( ( errorId.compareTo( ArrangementConfigServiceErrorMessageConstant.PAYMENT_ARRANGEMENT_SAVE_REQUEST_MESSAGE_DRAFT ) == 0 ) )
        {

            return true;
        }
        else
        {

            return false;
        }

    }

    /**
     * Method: isConfirmMessageExpired
     * @param error
     * @return
     */
    public boolean isConfirmMessageExpired( ErrorMessageDTO error )
    {
        Long errorId = error.getErrorMessageId();

        if( ( errorId
                .compareTo( ArrangementConfigServiceErrorMessageConstant.PAYMENT_ARRANGEMENT_SAVE_REQUEST_MESSAGE_EXPIRED ) == 0 ) )
        {

            return true;
        }
        else
        {

            return false;
        }

    }

    /**
     * Method: isConfirmMessageRateFutureInvalid
     * @param error
     * @return
     */
    public boolean isConfirmMessageRateFutureInvalid( ErrorMessageDTO error )
    {
        Long errorId = error.getErrorMessageId();

        if( ( errorId
                .compareTo( ArrangementConfigServiceErrorMessageConstant.PAYMENT_ARRANGEMENT_SAVE_REQUEST_MESSAGE_RATE_FUTURE_INVALID ) == 0 ) )
        {

            return true;
        }
        else
        {

            return false;
        }

    }

    /**
     * Method: isConfirmMessagePayeeFutureInvalid
     * @param error
     * @return
     */
    public boolean isConfirmMessagePayeeFutureInvalid( ErrorMessageDTO error )
    {
        Long errorId = error.getErrorMessageId();

        if( ( errorId
                .compareTo( ArrangementConfigServiceErrorMessageConstant.PAYMENT_ARRANGEMENT_SAVE_REQUEST_MESSAGE_PAYEE_FUTURE_INVALID ) == 0 ) )
        {

            return true;
        }
        else
        {

            return false;
        }

    }

    public boolean isConfirmMessageFutureInvalid( ErrorMessageDTO error )
    {
        Long errorId = error.getErrorMessageId();

        if( ( errorId
                .compareTo( ArrangementConfigServiceErrorMessageConstant.PAYMENT_ARRANGEMENT_SAVE_REQUEST_MESSAGE_FUTURE_INVALID ) == 0 ) )
        {

            return true;
        }
        else
        {

            return false;
        }

    }

    public boolean isConfirmMessageRateInvalid( ErrorMessageDTO error )
    {
        Long errorId = error.getErrorMessageId();

        if( ( errorId
                .compareTo( ArrangementConfigServiceErrorMessageConstant.PAYMENT_ARRANGEMENT_SAVE_REQUEST_MESSAGE_RATE_INVALID ) == 0 ) )
        {

            return true;
        }
        else
        {

            return false;
        }

    }

    public boolean isConfirmMessagePayeeInvalid( ErrorMessageDTO error )
    {
        Long errorId = error.getErrorMessageId();

        if( ( errorId
                .compareTo( ArrangementConfigServiceErrorMessageConstant.PAYMENT_ARRANGEMENT_SAVE_REQUEST_MESSAGE_PAYEE_INVALID ) == 0 ) )
        {

            return true;
        }
        else
        {

            return false;
        }

    }

    public boolean isConfirmMessageInvalid( ErrorMessageDTO error )
    {
        Long errorId = error.getErrorMessageId();

        if( ( errorId
                .compareTo( ArrangementConfigServiceErrorMessageConstant.PAYMENT_ARRANGEMENT_SAVE_REQUEST_MESSAGE_INVALID ) == 0 ) )
        {

            return true;
        }
        else
        {

            return false;
        }

    }

    public boolean isConfirmMessageWarning( ErrorMessageDTO error )
    {
        Long errorId = error.getErrorMessageId();

        if( ( errorId.compareTo( ArrangementConfigServiceErrorMessageConstant.PAYMENT_ARRANGEMENT_SAVE_REQUEST_WARNING ) == 0 ) )
        {

            return true;
        }
        else
        {

            return false;
        }

    }

    public boolean isNotConfirmMessage( ErrorMessageDTO error )
    {
        boolean isNotConfirmMessage = false;
        if( StringUtils.equalsIgnoreCase( error.getSeveritylevel(),
                                          VBRCommonConstant.SEVERITY_ERROR )
            && !isConfirmMessageDraft( error )
            && !isConfirmMessageExpired( error )
            && !isConfirmMessageRateFutureInvalid( error )
            && !isConfirmMessagePayeeFutureInvalid( error )
            && !isConfirmMessageFutureInvalid( error )
            && !isConfirmMessageRateInvalid( error )
            && !isConfirmMessagePayeeInvalid( error )
            && !isConfirmMessageInvalid( error )
            && !isConfirmMessageWarning( error ) )
        {
            isNotConfirmMessage = true;
        }
        return isNotConfirmMessage;
    }

    public boolean isConfirmMessage( ErrorMessageDTO error )
    {
        boolean isConfirmMessage = false;
        if( StringUtils.equalsIgnoreCase( error.getSeveritylevel(),
                                          VBRCommonConstant.SEVERITY_ERROR )
            && ( isConfirmMessageDraft( error )
                || isConfirmMessageExpired( error )
                || isConfirmMessageRateFutureInvalid( error )
                || isConfirmMessagePayeeFutureInvalid( error )
                || isConfirmMessageFutureInvalid( error )
                || isConfirmMessageRateInvalid( error )
                || isConfirmMessagePayeeInvalid( error )
                || isConfirmMessageInvalid( error )
                || isConfirmMessageWarning( error ) ) )
        {
            isConfirmMessage = true;
        }
        return isConfirmMessage;
    }

    /**
     * Method: convertArrangementDurationToDateRecord
     * @param paymentArrangementSaveRequest
     * @return
     */
    public DateRecord convertArrangementDurationToDateRecord( PaymentArrangementDTO paymentArrangementSaveRequest )
    {
        LOGGER.debug( "Start of Method convertArrangementDurationToDateRecord" );
        DateRecord arrangementDate = new DateRecord();

        String effStrDate = paymentArrangementSaveRequest.getRecordEffectiveDate();
        String endStrDate = paymentArrangementSaveRequest.getRecordEndDate();

        /** Converting StringToLocalDateDefaultFormat  **/
        LocalDate effDate = VBRDateUtils.convertStringToLocalDateDefaultFormat( effStrDate );
        LocalDate endDate = VBRDateUtils.convertStringToLocalDateDefaultFormat( endStrDate );

        /** Creating ArrangementDate record  **/
        arrangementDate.setRecordEffectiveDate( effDate );
        arrangementDate.setRecordEndDate( endDate );

        LOGGER.debug( "End of Method convertArrangementDurationToDateRecord" );
        return arrangementDate;
    }

    /**
     * Method: checkArrangementLocalDateEffandEndDateEqual
     * @param arrangementEndDate
     * @param arrangementEffectiveDate
     * @return
     */
    public boolean checkArrangementLocalDateEffandEndDateEqual( LocalDate arrangementEndDate,
            LocalDate arrangementEffectiveDate )
    {
        LOGGER.debug( "Start of Method checkArrangementLocalDateEffandEndDateEqual" );
        boolean arrangementEffandEndDateEqual = false;
        if( ObjectUtils.allNotNull( arrangementEffectiveDate ) && ObjectUtils.allNotNull( arrangementEffectiveDate ) )
        {
            if( arrangementEndDate.isEqual( arrangementEffectiveDate ) )
            {
                arrangementEffandEndDateEqual = true;
            }
        }

        LOGGER.debug( "End of Method checkArrangementLocalDateEffandEndDateEqual" );
        return arrangementEffandEndDateEqual;
    }

}
