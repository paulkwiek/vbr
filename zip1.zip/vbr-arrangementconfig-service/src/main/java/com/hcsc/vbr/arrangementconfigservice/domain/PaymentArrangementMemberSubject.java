package com.hcsc.vbr.arrangementconfigservice.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.apache.commons.lang3.builder.ReflectionToStringBuilder;

import com.hcsc.vbr.common.domain.BaseEntity;
import com.hcsc.vbr.common.utils.MultilineRecursiveToStringStyleCustom;

import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
@Table( name = "PMT_ARNGMT_MBR_SBJCT" )
public class PaymentArrangementMemberSubject extends BaseEntity
{

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue( strategy = GenerationType.SEQUENCE, generator = "SEQ_GEN" )
    @SequenceGenerator( name = "SEQ_GEN", sequenceName = "PMT_ARNGMT_MBR_SBJCT_SQ", allocationSize = 1 )
    @Column( name = "MBR_SBJCT_ID" )
    private Integer paymentArrangementMemberSubjectId;

    @Column( name = "PROD_TYP_CD", length = 6 )
    private String productTypeCode;

    @Column( name = "BNFT_PLN_STA_CD", length = 20 )
    private String benefitPlanStateCode;

    @Column( name = "BNFT_PLN_NBR", length = 6 )
    private String benefitPlanNumber;

    @Column( name = "LOB_CD", length = 10 )
    private String lineOfBusinessCode;

    @Column( name = "ACCT_NBR", length = 10 )
    private String accountnumber;

    @Column( name = "GRP_ID", length = 6 )
    private String groupId;

    @Column( name = "SECT_NBR", length = 4 )
    private String sectionNumber;

    @Column( name = "CAP_ENT_CD", length = 6 )
    private String captitationEntityCode;

    @Column( name = "SITE_ID", length = 3 )
    private String siteId;

    @Column( name = "BNFT_AGRMT_NBR" )
    private Integer benefitArrangementNumber;

    @Column( name = "MBR_LOC_ID", length = 10 )
    private String memberLocationId;

    @Column( name = "NTWK_RSK_LVL_CD", length = 6 )
    private String networkRiskLevelCode;

    @NotNull
    @Column( name = "PMT_ARNGMT_ID" )
    private Integer paymentArrangementId;

    @NotNull
    @Column( name = "CORP_ENT_CD", length = 3 )
    private String corporateEntityCode;

    @Column( name = "FUNDG_TYP_CD", length = 6 )
    private String fundingTypeCode;

    @Column( name = "CONTR_ID", length = 10 )
    private String contractId;

    @ManyToOne( fetch = FetchType.LAZY )
    @JoinColumn( name = "PMT_ARNGMT_ID", insertable = false, updatable = false )
    private PaymentArrangement paymentArrangement;

    public String toString()
    {
        return new ReflectionToStringBuilder( this,
                                              new MultilineRecursiveToStringStyleCustom() ).toString();
    }

}
