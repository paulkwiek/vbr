package com.hcsc.vbr.arrangementconfigservice.validator.payee;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.hcsc.vbr.arrangementconfigservice.constant.ArrangementConfigServiceErrorMessageConstant;
import com.hcsc.vbr.arrangementconfigservice.constant.ComponentIdConstant;
import com.hcsc.vbr.arrangementconfigservice.constant.FieldIdConstant;
import com.hcsc.vbr.arrangementconfigservice.domain.VbrPayee;
import com.hcsc.vbr.arrangementconfigservice.validator.base.BaseValidationUnit;
import com.hcsc.vbr.common.dto.ReturnMessageDTO;

@Component
public class VBPY011ValidateVbrPayeeCaptitationProcessCode extends BaseValidationUnit
{
    private static final Logger LOGGER = LoggerFactory.getLogger( VBPY011ValidateVbrPayeeCaptitationProcessCode.class );

    /**
     * @param vbrPayee
     * @param returnMessage
     * @return
     * @throws Exception
     */
    public boolean validateVbrPayeeCapitationProcessCodeFieldLength( VbrPayee vbrPayee,
            ReturnMessageDTO returnMessage ) throws Exception
    {
        LOGGER.debug( "VBPY011ValidateVbrPayeeCaptitationProcessCode : Start" );
        boolean isCapitationProcessCodeValid = true;

        String capitationProcessCode = vbrPayee.getCapitationProcessCode();
        if( ( StringUtils.isNotBlank( capitationProcessCode ) )
            && ( ( !StringUtils.isAlphanumeric( capitationProcessCode ) ) || ( capitationProcessCode.length() > 2 ) ) )
        {
            isCapitationProcessCodeValid = false;
            addToReturnMessage( ArrangementConfigServiceErrorMessageConstant.CAPITATION_PROCESS_CODE_VALIDATION,
                                FieldIdConstant.VBPY_CAPITATION_PROCESS_CODE,
                                ComponentIdConstant.VBPY,
                                this.getClass().getSimpleName(),
                                returnMessage );
        }

        LOGGER.debug( "VBPY011ValidateVbrPayeeCaptitationProcessCode : END" );
        return isCapitationProcessCodeValid;
    }
}