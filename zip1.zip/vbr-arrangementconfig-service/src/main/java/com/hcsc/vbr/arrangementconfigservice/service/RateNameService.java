package com.hcsc.vbr.arrangementconfigservice.service;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;
import org.springframework.util.ObjectUtils;

import com.hcsc.vbr.arrangementconfigservice.apiclient.CodeServiceApiClient;
import com.hcsc.vbr.arrangementconfigservice.constant.ArrangementConfigServiceConstant;
import com.hcsc.vbr.arrangementconfigservice.constant.ComponentIdConstant;
import com.hcsc.vbr.arrangementconfigservice.domain.FlatRate;
import com.hcsc.vbr.arrangementconfigservice.domain.PaymentArrangement;
import com.hcsc.vbr.arrangementconfigservice.domain.PaymentArrangementPayee;
import com.hcsc.vbr.arrangementconfigservice.domain.PaymentArrangementRate;
import com.hcsc.vbr.arrangementconfigservice.domain.RateName;
import com.hcsc.vbr.arrangementconfigservice.domain.RateNameId;
import com.hcsc.vbr.arrangementconfigservice.domain.VbrPayee;
import com.hcsc.vbr.arrangementconfigservice.dto.RateNameDTO;
import com.hcsc.vbr.arrangementconfigservice.mapper.RateNameListMapper;
import com.hcsc.vbr.arrangementconfigservice.mapper.RateNameMapper;
import com.hcsc.vbr.arrangementconfigservice.repository.FlatRateHistoryRepository;
import com.hcsc.vbr.arrangementconfigservice.repository.FlatRateRepository;
import com.hcsc.vbr.arrangementconfigservice.repository.PaymentArrangementRateRepository;
import com.hcsc.vbr.arrangementconfigservice.repository.PaymentArrangementRepository;
import com.hcsc.vbr.arrangementconfigservice.repository.RateNameRepository;
import com.hcsc.vbr.arrangementconfigservice.service.base.BaseService;
import com.hcsc.vbr.arrangementconfigservice.validator.ratename.RTNM005CheckRateName;
import com.hcsc.vbr.arrangementconfigservice.validator.ratename.RTNM006CheckPaymentArrangementStatus;
import com.hcsc.vbr.arrangementconfigservice.validator.ratename.RateNameValidator;
import com.hcsc.vbr.common.constant.VBRCommonConstant.RowActionTypes;
import com.hcsc.vbr.common.dto.ReturnMessageDTO;
import com.hcsc.vbr.common.utils.VBRDateUtils;
import com.hcsc.vbr.web.exceptions.ApplicationException;
import com.hcsc.vbr.web.request.RateSaveRequest;
import com.hcsc.vbr.web.response.PaymentArrangementListResponse;
import com.hcsc.vbr.web.response.RateNameResponse;
import com.hcsc.vbr.web.response.RateSaveResponse;

@Service
public class RateNameService extends BaseService
{

    final Logger LOGGER = LoggerFactory.getLogger( RateNameService.class );

    @Autowired
    private RateNameRepository rateNameRepository;

    @Autowired
    private FlatRateRepository flatRateRepository;

    @Autowired
    private FlatRateHistoryRepository flatRateHistoryRepository;

    @Autowired
    private RateNameMapper rateNameMapper;

    @Autowired
    private RateNameListMapper rateNameListMapper;

    @Autowired
    private RateNameValidator rateNameValidator;

    @Autowired
    private RTNM005CheckRateName rtnm005CheckRateName;

    @Autowired
    private RTNM006CheckPaymentArrangementStatus rtnm006CheckPaymentArrangementstatus;

    @Autowired
    private PaymentArrangementRateRepository paymentArrangementRateRepo;

    @Autowired
    private PaymentArrangementRepository paymentArrangementRepo;

    @Autowired
    private CodeServiceApiClient codeServiceApiClient;

    /**
     * Save or update rate name.
     *
     * @param rateNameDTO
     *            the rate dto
     * @return the rate name
     * @throws Exception
     */
    @Transactional( propagation = Propagation.REQUIRED )
    public RateSaveResponse saveRate( RateSaveRequest rateSaveRequest ) throws Exception
    {

        LOGGER.debug( "saveRate : START" );
        LOGGER.debug( "RateSaveRequest : " + rateSaveRequest );

        // Read the DTO from request
        RateNameDTO rateNameDTO = rateSaveRequest.getRate();

        // Map the DTO to Entity
        RateName rateName = rateNameMapper.toRateName( rateNameDTO );

        ReturnMessageDTO returnMessage = new ReturnMessageDTO( ComponentIdConstant.RTNM );

        // call the Validator
        rateNameValidator.validateSaveRateName( rateSaveRequest,
                                                rateName,
                                                returnMessage );
        //Create ReturnMessageDTO
        RateSaveResponse rateSaveResponse = new RateSaveResponse();

        //Converting RateName to upperCase
        RateNameId rateNameId = rateName.getRateNameId();
        rateNameId.setRateName( StringUtils.upperCase( rateNameId.getRateName() ) );
        rateName.setRateNameId( rateNameId );
        // save the rateName
        rateNameRepository.saveRate( rateName );

        // save in the flatRate
        flatRateRepository.saveFlatRate( rateName.getFlatRates() );

        // Save in the FaltRateHistory
        for( FlatRate flatRate : rateName.getFlatRates() )
        {
            flatRate.setRateName( StringUtils.upperCase( flatRate.getRateName() ) );
            flatRateHistoryRepository.saveFlatRateHistory( rateNameMapper.toFlatRateHistory( flatRate ) );
        }

        // We have implemented validation RTNM002CheckPaymentArrangementRateDate
        // but with Jira Story 16026 implemented
        // rtnm006CheckPaymentArrangementstatus
        for( FlatRate flatRate : rateName.getFlatRates() )
        {
            LOGGER.debug( "Validate Payment arrangement status with FlatRate dates change" );
            rtnm006CheckPaymentArrangementstatus.validateRateDatewithPaymentArrangementStatus( flatRate,
                                                                                               returnMessage );
        }

        rateSaveResponse.setRateName( rateNameMapper.toRateNameDTO( rateName ) );
        RowActionTypes rowAction = RowActionTypes.valueOf( rateName.getRowAction().name() );
        switch( rowAction )
        {
            case INSERT:
            {
                rateSaveResponse.setMessage( ArrangementConfigServiceConstant.RATE_TABLE_SAVE_MESSAGE );
                break;
            }
            case NO_ACTION:
            {
                for( int iCount = 0; iCount < rateName.getFlatRates().size(); iCount++ )
                {
                    if( StringUtils.equalsIgnoreCase( rateName.getFlatRates().get( iCount ).getRowAction().toString(),
                                                      "INSERT" ) )
                    {
                        rateSaveResponse.setMessage( ArrangementConfigServiceConstant.RATE_ROW_SAVE_MESSAGE );
                    }
                    else
                    {
                        rateSaveResponse.setMessage( ArrangementConfigServiceConstant.RATE_ROW_UPDATE_MESSAGE );
                    }
                }
                break;
            }
            default:
                break;
        }

        LOGGER.debug( "saveRate : END" );
        rateSaveResponse.setReturnMessage( returnMessage );
        return rateSaveResponse;
    }

    /**
     * Get list of rate names.
     *
     * @param nothing
     * @return list of rate names
     * @throws Exception 
     */
    @Transactional( propagation = Propagation.SUPPORTS )
    public RateNameResponse getRateNames( String corporateEntityCode ) throws Exception
    {
        LOGGER.debug( "getRateNames : START" );
        List<RateNameDTO> rateNameDTOs = null;
        RateNameResponse rateNameResponse = new RateNameResponse();
        List<RateName> rateNames = rateNameRepository.fetchRateNames( corporateEntityCode );
        ReturnMessageDTO returnMessage = new ReturnMessageDTO( ComponentIdConstant.RTNM );
        rateNameValidator.validateGetRateNames( rateNames,
                                                returnMessage );

        rateNameDTOs = rateNameListMapper.toRateNameDTOs( rateNames );

        rateNameResponse.setRateNames( rateNameDTOs );
        rateNameResponse.setMessage( "Rates fetched successfully" );

        LOGGER.debug( "getRateNames : END" );
        return rateNameResponse;

    }

    /**
     * Get Rate name details by RateName input.
     *
     * @param Rate
     *            name
     * @return rateName details
     * @throws Exception 
     */
    @Transactional( propagation = Propagation.SUPPORTS )
    public RateSaveResponse getRateByRateId( String name ) throws Exception
    {
        LOGGER.debug( "getRateByRateId : START" );
        RateNameDTO rateNameDTO = null;
        RateSaveResponse rateSaveResponse = new RateSaveResponse();
        ReturnMessageDTO returnMessage = new ReturnMessageDTO( ComponentIdConstant.RTNM );
        RateName rateName = rateNameRepository.findByRateName( name );
        List<FlatRate> flatRates = flatRateRepository.findByRateName( name );
        rateNameValidator.validateGetFlatRates( flatRates,
                                                returnMessage );
        rateName.setFlatRates( flatRates );
        rateNameDTO = rateNameMapper.toRateNameDTO( rateName );
        rateSaveResponse.setRateName( rateNameDTO );
        rateSaveResponse.setMessage( "Rate fetched successfully." );

        LOGGER.debug( "getRateByRateId : END" );
        return rateSaveResponse;
    }

    /**
     * validates RateName
     * 
     * @param rateName
     * @throws Exception
     */
    public void validateRateName( String rateName ) throws Exception
    {
        LOGGER.debug( "validateRateName : START" );
        ReturnMessageDTO returnMessage = new ReturnMessageDTO( ComponentIdConstant.RTNM );

        rtnm005CheckRateName.validateRateName( rateName,
                                               returnMessage );
        LOGGER.debug( "validateRateName : END" );

    }

    /**
     * This method will fetch linked paymentArrangement for particular Rate
     * Name. Method: getLinkedArrangements
     * 
     * @param name
     * @return linkedArrangementResponseList
     * @throws ApplicationException
     * @throws Exception
     */
    public List<PaymentArrangementListResponse> getLinkedArrangements( String name ) throws ApplicationException, Exception
    {
        LOGGER.debug( "getLinkedArrangements : START" );
        ReturnMessageDTO returnMessage = new ReturnMessageDTO( ComponentIdConstant.RTNM );
        List<PaymentArrangementListResponse> linkedArrangementResponseList = new ArrayList<PaymentArrangementListResponse>();
        List<PaymentArrangementRate> paymentArrangementRates = paymentArrangementRateRepo.findByRateName( name );
        Map<String, String> codeDescriptionMap = codeServiceApiClient.getAllPaymentArrangementStatusDescription( "NM1",
                                                                                                                 ArrangementConfigServiceConstant.ARRANGEMENT_STATUS_CODE_NAME );
        if( !CollectionUtils.isEmpty( paymentArrangementRates ) )
        {
            for( PaymentArrangementRate paymentArrangementRate : paymentArrangementRates )
            {
                PaymentArrangement paymentArrangement =
                    paymentArrangementRepo.findByArrangementId( paymentArrangementRate.getPaymentArrangementId() );

                if( !ObjectUtils.isEmpty( paymentArrangement ) )
                {
                    PaymentArrangementListResponse linkedArrangementListResponse = new PaymentArrangementListResponse();
                    linkedArrangementListResponse.setPaymentArrangementId( paymentArrangement.getPaymentArrangementId() );
                    linkedArrangementListResponse.setPaymentArrangementName( paymentArrangement.getPaymentArrangementName() );
                    linkedArrangementListResponse.setPaymentArrangmentStatus( paymentArrangement.getValidationStatusCode() );
                    linkedArrangementListResponse.setRecordEffectiveDate( VBRDateUtils
                            .convertLocalDateToString( paymentArrangement.getRecordEffectiveDate() ) );
                    linkedArrangementListResponse
                            .setRecordEndDate( VBRDateUtils.convertLocalDateToString( paymentArrangement.getRecordEndDate() ) );
                    linkedArrangementListResponse.setPaymentArrangementStatusDescription( codeDescriptionMap
                            .get( paymentArrangement.getValidationStatusCode() ) );
                    List<PaymentArrangementPayee> paymentArrangementPayees = paymentArrangement.getPaymentArrangementPayees();

                    if( !CollectionUtils.isEmpty( paymentArrangementPayees ) )
                    {
                        boolean isActivePayee = false;
                        Long difference;
                        Map<Long, VbrPayee> payeeMap = new TreeMap<Long, VbrPayee>();

                        // Incase of multiple payees to pick Active Payee
                        for( PaymentArrangementPayee payee : paymentArrangementPayees )
                        {
                            difference = ChronoUnit.DAYS.between( payee.getVbrPayee().getRecordEffectiveDate(),
                                                                  LocalDate.now() );
                            payeeMap.put( difference,
                                          payee.getVbrPayee() );

                            if( ( LocalDate.now().isAfter( payee.getVbrPayee().getRecordEffectiveDate() ) )
                                && ( LocalDate.now().isBefore( payee.getVbrPayee().getRecordEndDate() ) ) )
                            {
                                isActivePayee = true;
                                linkedArrangementListResponse.setPinGroupId( payee.getVbrPayee().getPinGroupId() );

                                break;
                            }

                        }

                        if( isActivePayee == false )
                        {
                            Set<Long> keySet = payeeMap.keySet();
                            List<Long> list = new ArrayList<Long>( keySet );
                            Collections.sort( list );
                            VbrPayee payee = payeeMap.get( list.get( 0 ) );
                            linkedArrangementListResponse.setPinGroupId( payee.getPinGroupId() );

                        }

                    }
                    linkedArrangementResponseList.add( linkedArrangementListResponse );
                }
            }
        }

        if( CollectionUtils.isEmpty( linkedArrangementResponseList ) )
        {
            rateNameValidator.validateLinkedArrangements( linkedArrangementResponseList,
                                                          returnMessage );
        }

        // Creating List to remove Duplicate from the payment arrangement
        // response list
        List<PaymentArrangementListResponse> linkedArrangementResponseWithoutDupList =
            removeDuplicatePaymentArrangementResponse( linkedArrangementResponseList );

        LOGGER.debug( "getLinkedArrangements : END" );
        return linkedArrangementResponseWithoutDupList;
    }

    /*
     * Remove Duplicate Payment Arrangement from the consolidated Response
     */
    private List<PaymentArrangementListResponse> removeDuplicatePaymentArrangementResponse(
            List<PaymentArrangementListResponse> paymentArrangementResponseList )
    {

        LOGGER.debug( "removeDuplicatePaymentArrangementResponse : START" );
        Set<PaymentArrangementListResponse> paymentArrangementListResponseSet =
            new TreeSet<PaymentArrangementListResponse>( new Comparator<PaymentArrangementListResponse>()
            {
                @Override
                public int compare( PaymentArrangementListResponse obj1,
                        PaymentArrangementListResponse obj2 )
                {
                    if( ( (PaymentArrangementListResponse) obj1 )
                            .getPaymentArrangementId() == ( ( (PaymentArrangementListResponse) obj2 ).getPaymentArrangementId() ) )
                    {
                        return 0;
                    }
                    return 1;
                }
            } );
        paymentArrangementListResponseSet.addAll( paymentArrangementResponseList );
        final List<PaymentArrangementListResponse> newPaymentArrangementResponseList =
            new ArrayList<PaymentArrangementListResponse>( paymentArrangementListResponseSet );

        LOGGER.debug( "removeDuplicatePaymentArrangementResponse : END" );
        return newPaymentArrangementResponseList;
    }
}
