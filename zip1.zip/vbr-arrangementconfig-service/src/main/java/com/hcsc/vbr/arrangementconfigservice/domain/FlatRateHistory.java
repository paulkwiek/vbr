package com.hcsc.vbr.arrangementconfigservice.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import com.hcsc.vbr.common.utils.MultilineRecursiveToStringStyleCustom;

import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
@Table( name = "FL_RT_HIST" )
public class FlatRateHistory extends FlatRateRecord
{
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy=GenerationType.SEQUENCE, generator="SEQ_GEN")
    @SequenceGenerator(name="SEQ_GEN", sequenceName="FL_RT_HIST_SQ", allocationSize=1)
    @Column( name = "FL_RT_HIST_ID" )
    private Integer flatRateHistoryId;

    @NotNull
    @Column( name = "FL_RT_ID" )
    private Integer flatRateId;

    @ManyToOne( fetch = FetchType.LAZY )
    @JoinColumn( name = "FL_RT_ID", insertable = false, updatable = false )
    private FlatRate flatRate;

    @Override
    public String toString()
    {
        return new ReflectionToStringBuilder( this,
                                              new MultilineRecursiveToStringStyleCustom() ).toString();
    }

}
