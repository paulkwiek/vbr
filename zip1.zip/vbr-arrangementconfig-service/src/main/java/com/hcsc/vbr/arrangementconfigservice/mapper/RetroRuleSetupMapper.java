package com.hcsc.vbr.arrangementconfigservice.mapper;

import java.util.List;

import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import com.hcsc.vbr.arrangementconfigservice.domain.RetroActivityRuleSetup;
import com.hcsc.vbr.arrangementconfigservice.dto.RetroActivityRuleSetupDTO;

@Mapper( componentModel = "spring" )
public interface RetroRuleSetupMapper
{
    RetroRuleSetupMapper INSTANCE = Mappers.getMapper( RetroRuleSetupMapper.class );

    public RetroActivityRuleSetupDTO toRetroRuleDTO( RetroActivityRuleSetup retroRule );

    public List<RetroActivityRuleSetupDTO> toRetroRuleDTOs( List<RetroActivityRuleSetup> retroRules );

    public RetroActivityRuleSetup toRetroRule( RetroActivityRuleSetupDTO retroRuleDTO );

    public List<RetroActivityRuleSetup> toRetroRules( List<RetroActivityRuleSetupDTO> retroRuleDTOs );

}
