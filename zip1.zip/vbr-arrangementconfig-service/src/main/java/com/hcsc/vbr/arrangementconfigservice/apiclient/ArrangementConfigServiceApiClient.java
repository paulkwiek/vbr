package com.hcsc.vbr.arrangementconfigservice.apiclient;


public class ArrangementConfigServiceApiClient {

}
