package com.hcsc.vbr.arrangementconfigservice.validator.paymentarrangement;

import java.time.LocalDate;
import java.util.List;

import org.springframework.stereotype.Component;

import com.hcsc.vbr.arrangementconfigservice.constant.ArrangementConfigServiceErrorMessageConstant;
import com.hcsc.vbr.arrangementconfigservice.constant.ComponentIdConstant;
import com.hcsc.vbr.arrangementconfigservice.constant.FieldIdConstant;
import com.hcsc.vbr.arrangementconfigservice.domain.PaymentArrangementRate;
import com.hcsc.vbr.arrangementconfigservice.utils.ArrangementConfigServiceUtils;
import com.hcsc.vbr.arrangementconfigservice.validator.base.BaseValidationUnit;
import com.hcsc.vbr.common.dto.ReturnMessageDTO;
import com.hcsc.vbr.common.utils.VBRDateUtils;

@Component
public class PMAM012CheckArrangementRateEffEndDates extends BaseValidationUnit
{
    public boolean validatePaymentArrangementRateEffectiveAndEndDatesList( List<PaymentArrangementRate> paymentArrangementRates,
            ReturnMessageDTO returnMessage ) throws Exception
    {
        boolean isDateValid = false;

        if( !VBRDateUtils.checkEffectiveAndEndDatesList( paymentArrangementRates ) )
        {
            addToReturnMessage( ArrangementConfigServiceErrorMessageConstant.ARRANGEMENT_RATE_EFF_END_DATE_VALIDATION,
                                FieldIdConstant.PMAR_EFF_AND_END_DATE,
                                ComponentIdConstant.PMAM,
                                this.getClass().getSimpleName(),
                                returnMessage );
            isDateValid = true;
        }

        for( PaymentArrangementRate arrangementRate : paymentArrangementRates )
        {
            if( !( 1 == arrangementRate.getRecordEffectiveDate().getDayOfMonth() ) || VBRDateUtils.isNotSameDay( arrangementRate ) )
            {
                LocalDate lastDateOfMonth = ArrangementConfigServiceUtils.getLastDayOfMonth( arrangementRate.getRecordEndDate() );

                if( !( 1 == arrangementRate.getRecordEffectiveDate().getDayOfMonth() ) )
                {
                    addToReturnMessage( ArrangementConfigServiceErrorMessageConstant.ARRANGEMENT_RATE_EFF_DATE_SHOULD_BE_FIRST_DAY_OF_MONTH_ERR,
                                        FieldIdConstant.PMAR_EFF_DATE,
                                        ComponentIdConstant.PMAM,
                                        this.getClass().getSimpleName(),
                                        returnMessage );
                    isDateValid = true;
                }

                if( !( lastDateOfMonth == arrangementRate.getRecordEndDate() ) )
                {
                    addToReturnMessage( ArrangementConfigServiceErrorMessageConstant.ARRANGEMENT_RATE_END_DATE_SHOULD_BE_LAST_DAY_OF_MONTH_ERR,
                                        FieldIdConstant.PMAR_END_DATE,
                                        ComponentIdConstant.PMAM,
                                        this.getClass().getSimpleName(),
                                        returnMessage );
                    isDateValid = true;
                }
            }

        }

        return isDateValid;
    }
}
