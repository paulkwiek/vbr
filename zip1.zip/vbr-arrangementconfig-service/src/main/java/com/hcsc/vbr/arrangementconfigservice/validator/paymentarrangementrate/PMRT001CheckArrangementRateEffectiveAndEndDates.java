package com.hcsc.vbr.arrangementconfigservice.validator.paymentarrangementrate;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.hcsc.vbr.arrangementconfigservice.constant.ArrangementConfigServiceErrorMessageConstant;
import com.hcsc.vbr.arrangementconfigservice.constant.ComponentIdConstant;
import com.hcsc.vbr.arrangementconfigservice.constant.FieldIdConstant;
import com.hcsc.vbr.arrangementconfigservice.domain.PaymentArrangementRate;
import com.hcsc.vbr.arrangementconfigservice.utils.ArrangementConfigServiceUtils;
import com.hcsc.vbr.arrangementconfigservice.validator.base.BaseValidationUnit;
import com.hcsc.vbr.common.dto.ReturnMessageDTO;
import com.hcsc.vbr.common.utils.VBRDateUtils;

@Component
public class PMRT001CheckArrangementRateEffectiveAndEndDates extends BaseValidationUnit
{
    private static final Logger LOGGER = LoggerFactory.getLogger( PMRT001CheckArrangementRateEffectiveAndEndDates.class );

    /**
     * This method will check Arrangement Rate Effective and End date Coverage.
     * Method: validatePaymentArrangementRateEffectiveAndEndDate
     * @param paymentArrangementRate
     * @param returnMessage
     * @return isValidDates
     * @throws Exception
     */
    public boolean validatePaymentArrangementRateEffectiveAndEndDate( PaymentArrangementRate paymentArrangementRate,
            ReturnMessageDTO returnMessage ) throws Exception
    {
        boolean isValidDates = true;

        LOGGER.debug( "validatePaymentArrangementRateEffectiveAndEndDate : START" );
        List<PaymentArrangementRate> paymentArrangementRates = new ArrayList<PaymentArrangementRate>();
        paymentArrangementRates.add( paymentArrangementRate );

        if( !VBRDateUtils.checkEffectiveAndEndDatesList( paymentArrangementRates ) )
        {
            addToReturnMessage( ArrangementConfigServiceErrorMessageConstant.ARRANGEMENT_RATE_EFF_END_DATE_VALIDATION_ERR,
                                FieldIdConstant.PMAR_EFF_AND_END_DATE,
                                ComponentIdConstant.PMAM,
                                this.getClass().getSimpleName(),
                                returnMessage );
            isValidDates = false;
        }
        if( !( 1 == paymentArrangementRate.getRecordEffectiveDate().getDayOfMonth() )
            || VBRDateUtils.isNotSameDay( paymentArrangementRate ) )
        {
            LocalDate lastDateOfMonth = ArrangementConfigServiceUtils.getLastDayOfMonth( paymentArrangementRate.getRecordEndDate() );

            if( !( 1 == paymentArrangementRate.getRecordEffectiveDate().getDayOfMonth() ) )
            {
                addToReturnMessage( ArrangementConfigServiceErrorMessageConstant.ARRANGEMENT_RATE_EFF_DATE_SHOULD_BE_FIRST_DAY_OF_MONTH,
                                    FieldIdConstant.PMAR_EFF_DATE,
                                    ComponentIdConstant.PMAM,
                                    this.getClass().getSimpleName(),
                                    returnMessage );
                isValidDates = false;
            }

            if( !( lastDateOfMonth == paymentArrangementRate.getRecordEndDate() ) )
            {
                addToReturnMessage( ArrangementConfigServiceErrorMessageConstant.ARRANGEMENT_RATE_END_DATE_SHOULD_BE_LAST_DAY_OF_MONTH,
                                    FieldIdConstant.PMAR_END_DATE,
                                    ComponentIdConstant.PMAM,
                                    this.getClass().getSimpleName(),
                                    returnMessage );
                isValidDates = false;
            }
        }
        LOGGER.debug( "validatePaymentArrangementRateEffectiveAndEndDate : END" );
        return isValidDates;
    }
}
