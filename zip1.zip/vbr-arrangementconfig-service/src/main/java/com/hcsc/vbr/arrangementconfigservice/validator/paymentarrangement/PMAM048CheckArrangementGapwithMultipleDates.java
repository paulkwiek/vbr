package com.hcsc.vbr.arrangementconfigservice.validator.paymentarrangement;

import java.time.temporal.ChronoUnit;
import java.util.Collections;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.util.ObjectUtils;

import com.hcsc.vbr.common.domain.DateRecord;
import com.hcsc.vbr.common.utils.VBRDateUtils;

@Component
public class PMAM048CheckArrangementGapwithMultipleDates
{
    private static final Logger LOGGER = LoggerFactory.getLogger( PMAM048CheckArrangementGapwithMultipleDates.class );

    /**
     * Method: checkArrangementGapwithMultipleDates
     * @param dateRecords
     * @param arrangementDate
     * @return
     * @throws Exception
     */
    public boolean checkArrangementGapwithMultipleDates( List<? extends DateRecord> dateRecords,
            DateRecord arrangementDate ) throws Exception
    {
        LOGGER.debug( "checkArrangementGapwithMultipleDates  : START" );

        boolean isDateValid = false;

        if( !dateRecords.isEmpty() && !ObjectUtils.isEmpty( arrangementDate ) )
        {
            Collections.sort( dateRecords );

            DateRecord parentArrangementRecord = VBRDateUtils.convertDateRecordListToDateRecordRange( dateRecords );

            if( ( parentArrangementRecord.getRecordEffectiveDate() != null
                && parentArrangementRecord.getRecordEndDate() != null
                && arrangementDate.getRecordEffectiveDate() != null
                && arrangementDate.getRecordEndDate() != null ) )
            {
                long startDays = ChronoUnit.DAYS.between( arrangementDate.getRecordEffectiveDate(),
                                                          parentArrangementRecord.getRecordEffectiveDate() );
                long endDays = ChronoUnit.DAYS.between( arrangementDate.getRecordEndDate(),
                                                        parentArrangementRecord.getRecordEndDate() );

                LOGGER.debug( "Difference : " + startDays );
                LOGGER.debug( "Difference : " + endDays );

                if( ( parentArrangementRecord.getRecordEffectiveDate().isAfter( arrangementDate.getRecordEffectiveDate() )
                    || parentArrangementRecord.getRecordEffectiveDate().isEqual( arrangementDate.getRecordEffectiveDate() ) )
                    && ( parentArrangementRecord.getRecordEndDate().isBefore( arrangementDate.getRecordEndDate() )
                        || parentArrangementRecord.getRecordEndDate().isEqual( arrangementDate.getRecordEndDate() ) ) )
                {
                    isDateValid = true;

                    LOGGER.debug( "No GAP : "
                        + parentArrangementRecord.getRecordEffectiveDate()
                        + " , "
                        + parentArrangementRecord.getRecordEndDate()
                        + " :: "
                        + arrangementDate.getRecordEffectiveDate()
                        + ","
                        + arrangementDate.getRecordEndDate() );

                }

            }
            else
            {
                LOGGER.debug( "Effective/End dates and Arrangement Duration are NULL" );
                isDateValid = false;

            }
        }

        else
        {
            LOGGER.debug( "DateRecord List and Arrangement Date record empty" );
            isDateValid = false;
        }

        LOGGER.debug( "Arrangment Covering Entire EffEnd Date : " + isDateValid );
        LOGGER.debug( "checkArrangementGapwithMultipleDates : END" );

        return isDateValid;
    }
}
