package com.hcsc.vbr.arrangementconfigservice.validator.payee;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.hcsc.vbr.arrangementconfigservice.constant.ArrangementConfigServiceErrorMessageConstant;
import com.hcsc.vbr.arrangementconfigservice.constant.ComponentIdConstant;
import com.hcsc.vbr.arrangementconfigservice.constant.FieldIdConstant;
import com.hcsc.vbr.arrangementconfigservice.domain.VbrPayee;
import com.hcsc.vbr.arrangementconfigservice.validator.base.BaseValidationUnit;
import com.hcsc.vbr.common.dto.ReturnMessageDTO;
import com.hcsc.vbr.common.utils.VBRDateUtils;

@Component
public class VBPY002ValidateVbrEfffectiveAndEndDate extends BaseValidationUnit
{
    private static final Logger LOGGER = LoggerFactory.getLogger( VBPY002ValidateVbrEfffectiveAndEndDate.class );

    /**
     * validating Effective End dates of Payee
     * Method: validateVBRPayeeEffAndEndDate
     * @param dateRecord
     * @param returnMessage
     * @return
     * @throws Exception
     */
    public boolean validateVBRPayeeEffAndEndDate( VbrPayee vbrPayee,
            ReturnMessageDTO returnMessage ) throws Exception
    {
        LOGGER.debug( "VBPY002ValidateVbrEfffectiveAndEndDate : Start" );
        boolean isDateValid = true;

        if( !VBRDateUtils.checkEffectiveAndEndDates( vbrPayee ) )
        {
            isDateValid = false;
            addToReturnMessage( ArrangementConfigServiceErrorMessageConstant.VBR_PAYEE_EFF_END_DATE_VALIDATION,
                                FieldIdConstant.VBPY_EFF_AND_END_DATE,
                                ComponentIdConstant.VBPY,
                                this.getClass().getSimpleName(),
                                returnMessage );
        }

        LOGGER.debug( "VBPY002ValidateVbrEfffectiveAndEndDate : END" );
        return isDateValid;

    }
}
