package com.hcsc.vbr.arrangementconfigservice.dto;

import org.apache.commons.lang3.builder.ReflectionToStringBuilder;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.hcsc.vbr.common.dto.DateRecordDTO;
import com.hcsc.vbr.common.utils.MultilineRecursiveToStringStyleCustom;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonInclude( JsonInclude.Include.NON_NULL )
public class PaymentArrangementPayeeDTO extends DateRecordDTO
{

    private static final long serialVersionUID = 1L;

    private Integer paymentArrangementPayeeId;

    private Integer paymentArrangementId;

    private Integer vbrPayeeId;

    private VbrPayeeDTO vbrPayee;

    @Override
    public String toString()
    {
        return new ReflectionToStringBuilder( this,
                                              new MultilineRecursiveToStringStyleCustom() ).toString();
    }

}
