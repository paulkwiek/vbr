package com.hcsc.vbr.arrangementconfigservice.repository;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.hcsc.vbr.arrangementconfigservice.domain.FlatRate;
import com.hcsc.vbr.common.constant.VBRCommonConstant.RowActionTypes;

@Repository
public interface FlatRateRepository extends JpaRepository<FlatRate, Integer>
{
    @Query( "SELECT flatrate FROM FlatRate flatrate where flatrate.rateName=:RateName ORDER BY flatrate.recordEffectiveDate DESC,flatrate.recordEndDate DESC" )
    public List<FlatRate> findByRateName( @Param( "RateName" ) String rateName );

    /**
     * save/update/delete/NoAction for Flat Rate
     * @param flatRates
     */
    default void saveFlatRate( List<FlatRate> flatRates )
    {
        for( FlatRate flatRate : flatRates )
        {
            RowActionTypes rowAction = RowActionTypes.valueOf( flatRate.getRowAction().name() );
            switch( rowAction )
            {
                case INSERT:
                {
                    flatRate.setCreateRecordTimestamp( LocalDateTime.now() );
                    save( flatRate );
                    break;
                }
                case UPDATE:
                {
                    save( flatRate );
                    break;
                }
                case DELETE:
                {
                    delete( flatRate );
                    break;
                }
                default:
                    break;
            }
        }

    }

}
