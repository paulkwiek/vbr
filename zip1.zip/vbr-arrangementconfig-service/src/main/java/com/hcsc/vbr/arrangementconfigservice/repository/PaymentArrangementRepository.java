package com.hcsc.vbr.arrangementconfigservice.repository;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.hcsc.vbr.arrangementconfigservice.constant.ArrangementConfigServiceConstant;
import com.hcsc.vbr.arrangementconfigservice.domain.PaymentArrangement;

public interface PaymentArrangementRepository extends JpaRepository<PaymentArrangement, Integer>
{
    /**
     * This query retrieves all the arrangements for a particular corporate entity code
     * Method: findArrangementsByCorporateEntityCode
     * @param corporateEntityCode
     * @return
     */
    @Query( " SELECT  paymentArrangement "
        + "     FROM  PaymentArrangement paymentArrangement "
        + "    WHERE  UPPER( paymentArrangement.corporateEntityCode ) = UPPER( :corporateEntityCode ) "
        + " ORDER BY  paymentArrangement.paymentArrangementName" )
    public List<PaymentArrangement> findArrangementsByCorporateEntityCode(
            @Param( "corporateEntityCode" ) String corporateEntityCode );

    /**This query retireves returns particular arrangement by arrangement ID
     * Method: findByArrangementId
     * @param arrangementId
     * @return
     */
    @Query( " SELECT  paymentArrangement "
        + "     FROM  PaymentArrangement paymentArrangement "
        + "    WHERE  paymentArrangement.paymentArrangementId  = :arrangementId "
        + " ORDER BY  paymentArrangement.paymentArrangementName" )
    public PaymentArrangement findByArrangementId( @Param( "arrangementId" ) Integer arrangementId );

    /**This query returns particular arrangement by arrangement name
     * Method: findByArrangementName
     * @param arrangementName
     * @return
     */
    @Query( " SELECT  paymentArrangement "
        + "     FROM  PaymentArrangement paymentArrangement "
        + "    WHERE  paymentArrangement.paymentArrangementName  = :arrangementName " )
    public PaymentArrangement findByArrangementName( @Param( "arrangementName" ) String arrangementName );

    /**This query returns Payment arrangement by corporate entity code and Line of business code
     * Method: findByCorporateEntityCodeAndLineOfBusinessCode
     * @param corporateEntityCode
     * @param lineOfBusinessCode
     * @return
     */
    @Query( "  SELECT DISTINCT paymentArrangement "
        + "      FROM PaymentArrangement paymentArrangement "
        + "     INNER JOIN paymentArrangement.paymentArrangementMemberSubjects paymentArrangementMemberSubjects "
        + "       ON paymentArrangement.paymentArrangementId             = paymentArrangementMemberSubjects.paymentArrangementId "
        + "       AND paymentArrangement.corporateEntityCode              = :corporateEntityCode "
        + "       AND paymentArrangementMemberSubjects.lineOfBusinessCode = :lineOfBusinessCode "
        + "       AND (paymentArrangement.validationStatusCode =  '"
        + ArrangementConfigServiceConstant.ARRANGEMENT_STATUS_VALID
        + "'"
        + "        OR paymentArrangement.validationStatusCode = '"
        + ArrangementConfigServiceConstant.ARRANGEMENT_STATUS_WARNING
        + "')" )

    public List<PaymentArrangement> findByCorporateEntityCodeAndLineOfBusinessCode(
            @Param( "corporateEntityCode" ) String corporateEntityCode,
            @Param( "lineOfBusinessCode" ) String lineOfBusinessCode );

    /**This query performs insert/update/delete/no Action according to the rowAction given by user
     * Method: savePaymentArrangement
     * @param paymentArrangement
     */
    default void savePaymentArrangement( PaymentArrangement paymentArrangement )
    {

        switch( paymentArrangement.getRowAction() )
        {
            case INSERT:
            {
                paymentArrangement.setCreateRecordTimestamp( LocalDateTime.now() );
                save( paymentArrangement );
                break;
            }
            case UPDATE:
            {
                save( paymentArrangement );
                break;
            }
            case DELETE:
            {
                delete( paymentArrangement );
                break;
            }
            default:
                break;
        }

    }
}
