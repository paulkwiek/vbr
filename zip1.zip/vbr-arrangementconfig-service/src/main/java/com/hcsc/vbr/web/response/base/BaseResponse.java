package com.hcsc.vbr.web.response.base;

import com.hcsc.vbr.common.web.response.base.VbrBaseResponse;

public class BaseResponse extends VbrBaseResponse
{
    /**
     * 
     */
    private static final long serialVersionUID = 1L;

}
