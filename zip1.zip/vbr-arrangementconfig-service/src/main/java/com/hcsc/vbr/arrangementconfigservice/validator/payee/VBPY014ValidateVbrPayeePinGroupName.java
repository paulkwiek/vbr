package com.hcsc.vbr.arrangementconfigservice.validator.payee;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.hcsc.vbr.arrangementconfigservice.constant.ArrangementConfigServiceErrorMessageConstant;
import com.hcsc.vbr.arrangementconfigservice.constant.ComponentIdConstant;
import com.hcsc.vbr.arrangementconfigservice.constant.FieldIdConstant;
import com.hcsc.vbr.arrangementconfigservice.domain.VbrPayee;
import com.hcsc.vbr.arrangementconfigservice.validator.base.BaseValidationUnit;
import com.hcsc.vbr.common.dto.ReturnMessageDTO;

@Component
public class VBPY014ValidateVbrPayeePinGroupName extends BaseValidationUnit
{
    private static final Logger LOGGER = LoggerFactory.getLogger( VBPY014ValidateVbrPayeePinGroupName.class );

    /**
     * @param vbrPayee
     * @param returnMessage
     * @return
     * @throws Exception
     */
    public boolean validateVbrPayeePinGroupNameFieldLength( VbrPayee vbrPayee,
            ReturnMessageDTO returnMessage ) throws Exception
    {
        LOGGER.debug( "VBPY014ValidateVbrPayeePinGroupName : Start" );
        boolean isPinGroupNameValid = true;

        String pinGroupName = vbrPayee.getPinGroupName();
        if( ( StringUtils.isBlank( pinGroupName ) )
            || ( ( !StringUtils.isAlphanumericSpace( pinGroupName ) ) || ( pinGroupName.length() > 60 ) ) )
        {
            isPinGroupNameValid = false;
            addToReturnMessage( ArrangementConfigServiceErrorMessageConstant.INVALID_PIN_GROUP_NAME,
                                FieldIdConstant.VBPY_PINGROUP_NAME,
                                ComponentIdConstant.VBPY,
                                this.getClass().getSimpleName(),
                                returnMessage );
        }

        LOGGER.debug( "VBPY014ValidateVbrPayeePinGroupName : END" );
        return isPinGroupNameValid;
    }
}
