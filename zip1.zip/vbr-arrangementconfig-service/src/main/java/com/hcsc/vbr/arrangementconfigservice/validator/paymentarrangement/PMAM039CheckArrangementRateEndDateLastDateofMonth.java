package com.hcsc.vbr.arrangementconfigservice.validator.paymentarrangement;

import java.time.LocalDate;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.hcsc.vbr.arrangementconfigservice.constant.ArrangementConfigServiceErrorMessageConstant;
import com.hcsc.vbr.arrangementconfigservice.constant.ComponentIdConstant;
import com.hcsc.vbr.arrangementconfigservice.constant.FieldIdConstant;
import com.hcsc.vbr.arrangementconfigservice.domain.PaymentArrangement;
import com.hcsc.vbr.arrangementconfigservice.domain.PaymentArrangementRate;
import com.hcsc.vbr.arrangementconfigservice.utils.ArrangementConfigServiceUtils;
import com.hcsc.vbr.arrangementconfigservice.validator.base.BaseValidationUnit;
import com.hcsc.vbr.common.dto.ReturnMessageDTO;
import com.hcsc.vbr.common.utils.VBRDateUtils;

@Component
public class PMAM039CheckArrangementRateEndDateLastDateofMonth extends BaseValidationUnit
{
    final Logger LOGGER = LoggerFactory.getLogger( PMAM039CheckArrangementRateEndDateLastDateofMonth.class );

    public boolean validateArrangementRateEndDateLastDateofMonth( List<PaymentArrangementRate> paymentArrangementRatedateRecordList,
            PaymentArrangement arrangementDate,
            LocalDate processingMonth,
            ReturnMessageDTO returnMessage ) throws Exception
    {
        LOGGER.debug( "validateArrangementRateEndDateLastDateofMonth : START" );

        boolean isarrangementRateEffDateNotLastDate = false;

        LocalDate arrangementEffectiveDate = arrangementDate.getRecordEffectiveDate();
        LocalDate lastDateOfProcessingMonth = VBRDateUtils.getLastDayOfMonth( processingMonth );

        for( PaymentArrangementRate arrangementRate : paymentArrangementRatedateRecordList )
        {
            if( !( 1 == arrangementRate.getRecordEffectiveDate().getDayOfMonth() ) || VBRDateUtils.isNotSameDay( arrangementRate ) )
            {
                LocalDate lastDateOfMonth = ArrangementConfigServiceUtils.getLastDayOfMonth( arrangementRate.getRecordEndDate() );

                if( !( lastDateOfMonth == arrangementRate.getRecordEndDate() ) )
                {

                    if( arrangementEffectiveDate.isAfter( lastDateOfProcessingMonth ) )
                    {

                        addToReturnMessage( ArrangementConfigServiceErrorMessageConstant.ARRANGEMENT_RATE_END_DATE_SHOULD_BE_LAST_DAY_OF_MONTH_ERR_FUTURE,
                                            FieldIdConstant.PMAR_END_DATE,
                                            ComponentIdConstant.PMAM,
                                            this.getClass().getSimpleName(),
                                            returnMessage );
                        isarrangementRateEffDateNotLastDate = true;

                    }
                    else
                    {
                        addToReturnMessage( ArrangementConfigServiceErrorMessageConstant.ARRANGEMENT_RATE_END_DATE_SHOULD_BE_LAST_DAY_OF_MONTH_ERR,
                                            FieldIdConstant.PMAR_END_DATE,
                                            ComponentIdConstant.PMAM,
                                            this.getClass().getSimpleName(),
                                            returnMessage );
                        isarrangementRateEffDateNotLastDate = true;

                    }
                }
            }

        }

        LOGGER.debug( "validateArrangementRateEndDateLastDateofMonth : END" );
        return isarrangementRateEffDateNotLastDate;
    }

}