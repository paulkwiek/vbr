package com.hcsc.vbr.arrangementconfigservice.validator.paymentarrangement;

import java.time.LocalDate;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.hcsc.vbr.arrangementconfigservice.domain.PaymentArrangement;
import com.hcsc.vbr.arrangementconfigservice.domain.PaymentArrangementRate;
import com.hcsc.vbr.arrangementconfigservice.validator.base.BaseValidationUnit;
import com.hcsc.vbr.common.dto.ReturnMessageDTO;

@Component
public class PMAM025CheckArrangementRateEffEndDates extends BaseValidationUnit
{

    final Logger LOGGER = LoggerFactory.getLogger( PMAM025CheckArrangementRateEffEndDates.class );

    @Autowired
    private PMAM037CheckArrangementRateEffEnddateEqualorBefore pmam037CheckArrangementRateEffEnddateEqualorBefore;

    @Autowired
    private PMAM038CheckArrangementRateEffDateFirstDateofMonth pmam038CheckArrangementRateEffDateFirstDateofMonth;

    @Autowired
    private PMAM039CheckArrangementRateEndDateLastDateofMonth pmam039CheckArrangementRateEndDateLastDateofMonth;

    /**
     * Method: validateArrangementRateEffEndDates
     * @param paymentArrangementRatedateRecordList
     * @param arrangementDate
     * @param processingMonth
     * @param errors
     * @return
     * @throws Exception
     */
    public boolean validateArrangementRateEffEndDates( List<PaymentArrangementRate> paymentArrangementRatedateRecordList,
            PaymentArrangement arrangementDate,
            LocalDate processingMonth,
            ReturnMessageDTO returnMessage ) throws Exception
    {
        LOGGER.debug( "validateArrangementRateEffEndDates : START" );

        boolean isArrangementRateDateInvalid = false;
        boolean isarrangementRateEffDateNotBeforeEndDate = false;
        boolean isarrangementRateEffDateNotFirstDate = false;
        boolean isarrangementRateEffDateNotLastDate = false;

        isarrangementRateEffDateNotBeforeEndDate = pmam037CheckArrangementRateEffEnddateEqualorBefore
                .validateArrangementRateEffEnddateEqualorBefore( paymentArrangementRatedateRecordList,
                                                                 arrangementDate,
                                                                 processingMonth,
                                                                 returnMessage );

        isarrangementRateEffDateNotFirstDate = pmam038CheckArrangementRateEffDateFirstDateofMonth
                .validateArrangementRateEffDateFirstDateofMonth( paymentArrangementRatedateRecordList,
                                                                 arrangementDate,
                                                                 processingMonth,
                                                                 returnMessage );

        isarrangementRateEffDateNotLastDate = pmam039CheckArrangementRateEndDateLastDateofMonth
                .validateArrangementRateEndDateLastDateofMonth( paymentArrangementRatedateRecordList,
                                                                arrangementDate,
                                                                processingMonth,
                                                                returnMessage );

        if( isarrangementRateEffDateNotBeforeEndDate || isarrangementRateEffDateNotFirstDate || isarrangementRateEffDateNotLastDate )
        {

            isArrangementRateDateInvalid = true;

        }
        LOGGER.debug( "ArrangementRateEffEndDates Invalid : " + isArrangementRateDateInvalid );
        LOGGER.debug( "validateArrangementRateEffEndDates : START" );
        return isArrangementRateDateInvalid;
    }

}
