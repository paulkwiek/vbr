package com.hcsc.vbr.arrangementconfigservice.validator.paymentarrangement;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.util.ObjectUtils;

import com.hcsc.vbr.arrangementconfigservice.constant.ArrangementConfigServiceErrorMessageConstant;
import com.hcsc.vbr.arrangementconfigservice.constant.ComponentIdConstant;
import com.hcsc.vbr.arrangementconfigservice.constant.FieldIdConstant;
import com.hcsc.vbr.arrangementconfigservice.domain.PaymentArrangement;
import com.hcsc.vbr.arrangementconfigservice.validator.base.BaseValidationUnit;
import com.hcsc.vbr.common.dto.ReturnMessageDTO;

@Component
public class PMAM044CheckRetrieveArrangement extends BaseValidationUnit
{
    final Logger LOGGER = LoggerFactory.getLogger( PMAM044CheckRetrieveArrangement.class );

    /**
     * Method: validateRetrieveArrangement
     * @param paymentArrangement
     * @param returnMessage
     * @return
     * @throws Exception
     */
    public boolean validateRetrieveArrangement( PaymentArrangement paymentArrangement,
            ReturnMessageDTO returnMessage ) throws Exception
    {
        LOGGER.debug( "validateRetrieveArrangement : START" );

        boolean isArrangementValid = true;

        if( ObjectUtils.isEmpty( paymentArrangement ) )
        {
            isArrangementValid = false;
            LOGGER.debug( "validateRetrieveArrangement : NO ARRANGEMENT RECORD" );
            addToReturnMessage( ArrangementConfigServiceErrorMessageConstant.NO_ARRANGEMENT_RECORDS_FOUND,
                                FieldIdConstant.PMAM_NAME,
                                ComponentIdConstant.PMAM,
                                this.getClass().getSimpleName(),
                                returnMessage );

        }
        LOGGER.debug( "validateRetrieveArrangement : END" );

        return isArrangementValid;
    }

}
