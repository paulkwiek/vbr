package com.hcsc.vbr.web.response;

import com.hcsc.vbr.web.response.base.BaseResponse;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PaymentArrangementListResponse extends BaseResponse
{
    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    private Integer paymentArrangementId;
    private String paymentArrangementName;
    private String paymentArrangmentStatus;
    private String pinGroupId;
    private String recordEffectiveDate;
    private String recordEndDate;
    private String paymentArrangementStatusDescription;

}
