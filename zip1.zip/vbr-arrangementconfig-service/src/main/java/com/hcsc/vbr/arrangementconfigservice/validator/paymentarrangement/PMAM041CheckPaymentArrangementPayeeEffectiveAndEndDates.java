package com.hcsc.vbr.arrangementconfigservice.validator.paymentarrangement;

import java.time.LocalDate;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.hcsc.vbr.arrangementconfigservice.constant.ArrangementConfigServiceErrorMessageConstant;
import com.hcsc.vbr.arrangementconfigservice.constant.ComponentIdConstant;
import com.hcsc.vbr.arrangementconfigservice.constant.FieldIdConstant;
import com.hcsc.vbr.arrangementconfigservice.domain.PaymentArrangementPayee;
import com.hcsc.vbr.arrangementconfigservice.validator.base.BaseValidationUnit;
import com.hcsc.vbr.common.dto.ReturnMessageDTO;
import com.hcsc.vbr.common.utils.VBRDateUtils;

@Component
public class PMAM041CheckPaymentArrangementPayeeEffectiveAndEndDates extends BaseValidationUnit
{
    final Logger LOGGER = LoggerFactory.getLogger( PMAM041CheckPaymentArrangementPayeeEffectiveAndEndDates.class );

    /**
     * Method: validateArrangementPayeeEffectiveAndEndDate
     * @param dateRecord
     * @param errors
     * @return
     * @throws Exception
     */
    public boolean validateArrangementPayeeEffectiveAndEndDate( PaymentArrangementPayee dateRecord,
            ReturnMessageDTO returnMessage ) throws Exception
    {
        LOGGER.debug( "validateArrangementPayeeEffectiveAndEndDate : START" );

        boolean isDateValid = false;
        if( !( 1 == dateRecord.getRecordEffectiveDate().getDayOfMonth() ) || VBRDateUtils.isNotSameDay( dateRecord ) )
        {
            LocalDate lastDateOfMonth = VBRDateUtils.getLastDayOfMonth( dateRecord.getRecordEndDate() );
            if( !( 1 == dateRecord.getRecordEffectiveDate().getDayOfMonth() ) )
            {
                addToReturnMessage( ArrangementConfigServiceErrorMessageConstant.ARRANGEMENT_PAYEE_EFF_DATE_SHOULD_BE_FIRST_DAY_OF_MONTH_ERR,
                                    FieldIdConstant.PMPY_EFF_DATE,
                                    ComponentIdConstant.PMAM,
                                    this.getClass().getSimpleName(),
                                    returnMessage );
                isDateValid = true;
            }

            if( !( lastDateOfMonth == dateRecord.getRecordEndDate() ) )
            {
                addToReturnMessage( ArrangementConfigServiceErrorMessageConstant.ARRANGEMENT_PAYEE_END_DATE_SHOULD_BE_LAST_DAY_OF_MONTH_ERR,
                                    FieldIdConstant.PMPY_END_DATE,
                                    ComponentIdConstant.PMAM,
                                    this.getClass().getSimpleName(),
                                    returnMessage );
                isDateValid = true;
            }
        }
        LOGGER.debug( "validateArrangementPayeeEffectiveAndEndDate : END" );
        return isDateValid;

    }

}