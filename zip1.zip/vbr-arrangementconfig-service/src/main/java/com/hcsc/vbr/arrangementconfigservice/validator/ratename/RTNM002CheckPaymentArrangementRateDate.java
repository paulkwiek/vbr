package com.hcsc.vbr.arrangementconfigservice.validator.ratename;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.ObjectUtils;

import com.hcsc.vbr.arrangementconfigservice.constant.ArrangementConfigServiceErrorMessageConstant;
import com.hcsc.vbr.arrangementconfigservice.domain.PaymentArrangementRate;
import com.hcsc.vbr.arrangementconfigservice.dto.ErrorMessageDTO;
import com.hcsc.vbr.arrangementconfigservice.dto.FlatRateDTO;
import com.hcsc.vbr.arrangementconfigservice.repository.PaymentArrangementRateRepository;
import com.hcsc.vbr.arrangementconfigservice.validator.base.BaseValidator;
import com.hcsc.vbr.common.domain.DateRecord;
import com.hcsc.vbr.common.utils.VBRDateUtils;

@Component
public class RTNM002CheckPaymentArrangementRateDate
{
    @Autowired
    public RateNameValidator rateNameValidator;

    @Autowired
    PaymentArrangementRateRepository paymentArrangementRateRepository;

    /**
     * NRW-8072 implementation validate flat rate dates against arrangement rate dates
     * child-arrangement rate dates, parent - flat rate dates
     * @param flatRateDTOs
     * @param errors
     * @throws Exception
     */

    public boolean validateRateDatewithPaymentArrangementRate( FlatRateDTO flatRateDTO,
            List<ErrorMessageDTO> errors ) throws Exception
    {

        List<DateRecord> dateRecordList = new ArrayList<DateRecord>();
        DateRecord dateRecord = new DateRecord();
        dateRecord
                .setRecordEffectiveDate( VBRDateUtils.convertStringToLocalDateDefaultFormat( flatRateDTO.getRecordEffectiveDate() ) );
        dateRecord.setRecordEndDate( VBRDateUtils.convertStringToLocalDateDefaultFormat( flatRateDTO.getRecordEndDate() ) );
        dateRecordList.add( dateRecord );
        if( StringUtils.isNotEmpty( flatRateDTO.getRowAction().name() )
            && StringUtils.equalsIgnoreCase( flatRateDTO.getRowAction().name(),
                                             "UPDATE" ) )
        {

            List<PaymentArrangementRate> arrnRates =
                paymentArrangementRateRepository.getPaymenArrangementRate( flatRateDTO.getCorporateEntityCode(),
                                                                           flatRateDTO.getRateName() );

            List<DateRecord> arrRatesdateRecordList = new ArrayList<DateRecord>();

            for( PaymentArrangementRate pmtarrRate : arrnRates )
            {
                DateRecord arrRateDateRecord = new DateRecord();
                arrRateDateRecord.setRecordEffectiveDate( pmtarrRate.getRecordEffectiveDate() );
                arrRateDateRecord.setRecordEndDate( pmtarrRate.getRecordEndDate() );
                arrRatesdateRecordList.add( arrRateDateRecord );

                if( !VBRDateUtils.checkDateCoverage( dateRecordList,
                                                     arrRatesdateRecordList ) )
                {

                    BaseValidator.addToErrorList( errors,
                                                  ArrangementConfigServiceErrorMessageConstant.GLOBAL_RATE_AND_ARRANGEMENT_RATE_DATES_VALIDATION );

                }
            }

        }

        if( !ObjectUtils.isEmpty( errors ) )
            return true;
        else
            return false;

    }

}
