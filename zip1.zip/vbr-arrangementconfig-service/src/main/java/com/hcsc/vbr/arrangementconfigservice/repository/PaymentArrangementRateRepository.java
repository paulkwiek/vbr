package com.hcsc.vbr.arrangementconfigservice.repository;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.hcsc.vbr.arrangementconfigservice.domain.PaymentArrangementRate;
import com.hcsc.vbr.common.constant.VBRCommonConstant.RowActionTypes;

@Repository
public interface PaymentArrangementRateRepository extends JpaRepository<PaymentArrangementRate, Long>
{
    @Query( "SELECT rt from PaymentArrangementRate rt where rt.rateName=:RateName" )
    public List<PaymentArrangementRate> findByRateName( @Param( "RateName" ) String rateName );

    @Query( "SELECT pmtarngrt from PaymentArrangementRate pmtarngrt where pmtarngrt.corporateEntityCode=:CorpEntity and pmtarngrt.rateName=:RateName" )
    public List<PaymentArrangementRate> getPaymenArrangementRate( @Param( "CorpEntity" ) String corpEntity,
            @Param( "RateName" ) String rateName );

    /**
     * save/update/delete/NoAction for payment arrangement rate
     * @param paymentArrangementRate
     */
    default void savePaymentArrangementRate( List<PaymentArrangementRate> paymentArrangementRates )
    {
        for( PaymentArrangementRate paymentArrangementRate : paymentArrangementRates )
        {
            RowActionTypes rowAction = RowActionTypes.valueOf( paymentArrangementRate.getRowAction().name() );
            switch( rowAction )
            {
                case INSERT:
                {
                    paymentArrangementRate.setCreateRecordTimestamp( LocalDateTime.now() );
                    save( paymentArrangementRate );
                    break;
                }
                case UPDATE:
                {
                    save( paymentArrangementRate );
                    break;
                }
                case DELETE:
                {
                    delete( paymentArrangementRate );
                    break;
                }
                default:
                    break;
            }
        }
    }
}
