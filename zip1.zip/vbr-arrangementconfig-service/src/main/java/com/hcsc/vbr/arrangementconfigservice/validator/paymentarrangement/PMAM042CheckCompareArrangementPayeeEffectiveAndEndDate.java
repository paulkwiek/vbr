package com.hcsc.vbr.arrangementconfigservice.validator.paymentarrangement;

import org.springframework.stereotype.Component;

import com.hcsc.vbr.arrangementconfigservice.constant.ArrangementConfigServiceErrorMessageConstant;
import com.hcsc.vbr.arrangementconfigservice.constant.ComponentIdConstant;
import com.hcsc.vbr.arrangementconfigservice.constant.FieldIdConstant;
import com.hcsc.vbr.arrangementconfigservice.domain.PaymentArrangementPayee;
import com.hcsc.vbr.arrangementconfigservice.validator.base.BaseValidationUnit;
import com.hcsc.vbr.common.dto.ReturnMessageDTO;
import com.hcsc.vbr.common.utils.VBRDateUtils;

@Component
public class PMAM042CheckCompareArrangementPayeeEffectiveAndEndDate extends BaseValidationUnit
{

    /**
     * Method: compareArrangementPayeeEffectiveAndEndDate
     * @param dateRecord
     * @param errors
     * @return
     * @throws Exception
     */
    public boolean compareArrangementPayeeEffectiveAndEndDate( PaymentArrangementPayee dateRecord,
            ReturnMessageDTO returnMessage ) throws Exception
    {
        boolean isDateValid = false;
        if( !VBRDateUtils.checkEffectiveAndEndDates( dateRecord ) )
        {
            addToReturnMessage( ArrangementConfigServiceErrorMessageConstant.ARRNG_PAYEE_EFF_END_DATE_VALIDATION,
                                FieldIdConstant.PMPY_EFF_AND_END_DATE,
                                ComponentIdConstant.PMAM,
                                this.getClass().getSimpleName(),
                                returnMessage );
            isDateValid = true;
        }
        return isDateValid;
    }

}