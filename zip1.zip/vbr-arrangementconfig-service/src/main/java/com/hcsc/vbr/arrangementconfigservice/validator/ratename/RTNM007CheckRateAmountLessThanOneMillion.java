package com.hcsc.vbr.arrangementconfigservice.validator.ratename;

import org.apache.commons.lang3.ObjectUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.hcsc.vbr.arrangementconfigservice.constant.ArrangementConfigServiceErrorMessageConstant;
import com.hcsc.vbr.arrangementconfigservice.constant.ComponentIdConstant;
import com.hcsc.vbr.arrangementconfigservice.constant.FieldIdConstant;
import com.hcsc.vbr.arrangementconfigservice.domain.FlatRate;
import com.hcsc.vbr.arrangementconfigservice.domain.RateName;
import com.hcsc.vbr.arrangementconfigservice.validator.base.BaseValidationUnit;
import com.hcsc.vbr.common.dto.ReturnMessageDTO;

@Component
public class RTNM007CheckRateAmountLessThanOneMillion extends BaseValidationUnit
{
    private static final Logger LOGGER = LoggerFactory.getLogger( RTNM007CheckRateAmountLessThanOneMillion.class );

    /**
     * @param rateName
     * @param returnMessage
     * @return
     * @throws Exception
     */
    public boolean isRateAmountLessThanOneMillion( RateName rateName,
            ReturnMessageDTO returnMessage ) throws Exception
    {
        LOGGER.debug( "RTNM007CheckRateAmountLessThanOneMillion : START" );
        boolean validateAmountFlag = true;

        for( FlatRate flatRate : rateName.getFlatRates() )
        {
            if( ( ObjectUtils.allNotNull( flatRate.getMaleFlatRateAmount() )
                && ObjectUtils.allNotNull( flatRate.getFemaleFlatRateAmount() ) ) )
            {
                Double maleFlateRateAmt = flatRate.getMaleFlatRateAmount();
                Double femaleFlateRateAmt = flatRate.getFemaleFlatRateAmount();

                //checking rate amount should be less than  1 Million
                if( maleFlateRateAmt >= 1000000 || femaleFlateRateAmt >= 1000000 )
                {
                    //Set return flag to false
                    validateAmountFlag = false;
                    //Add Error/Warning to ReturnMessage
                    addToReturnMessage( ArrangementConfigServiceErrorMessageConstant.RATE_AMOUNT_LESS_THAN_1MILLION,
                                        FieldIdConstant.RTNM_FLAT_RATE_AMT,
                                        ComponentIdConstant.RTNM,
                                        this.getClass().getSimpleName(),
                                        returnMessage );
                    break;

                }

            }
            else
            {
                validateAmountFlag = false;
                break;
            }
        }

        LOGGER.debug( "RTNM007CheckRateAmountLessThanOneMillion : END" );
        return validateAmountFlag;

    }
}
