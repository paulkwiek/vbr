package com.hcsc.vbr.arrangementconfigservice.validator.payee;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.hcsc.vbr.arrangementconfigservice.constant.ArrangementConfigServiceErrorMessageConstant;
import com.hcsc.vbr.arrangementconfigservice.constant.ComponentIdConstant;
import com.hcsc.vbr.arrangementconfigservice.constant.FieldIdConstant;
import com.hcsc.vbr.arrangementconfigservice.validator.base.BaseValidationUnit;
import com.hcsc.vbr.common.dto.ReturnMessageDTO;
import com.hcsc.vbr.web.request.PayeeSearchRequest;

@Component
public class VBPY022ValidatePingroupIdInSearchPayee extends BaseValidationUnit
{

    private static final Logger LOGGER = LoggerFactory.getLogger( VBPY022ValidatePingroupIdInSearchPayee.class );

    /**
     * Validate search. Example for handling single exception.
     *
     * @param payeeSearchRequest the payee search request
     * @throws Exception the exception
     */
    public boolean validateSearch( PayeeSearchRequest payeeSearchRequest,
            ReturnMessageDTO returnMessage ) throws Exception
    {
        LOGGER.debug( "VBPY022ValidatePingroupIdInSearchPayee : Start" );
        String pinGroupId = payeeSearchRequest.getPinGroupId();
        boolean isPinGrpIdValid = false;

        if( StringUtils.isNotBlank( pinGroupId ) )
        {
            if( ( ( !StringUtils.isAlphanumeric( pinGroupId ) ) || ( pinGroupId.length() > 10 ) ) )

            {
                addToReturnMessage( ArrangementConfigServiceErrorMessageConstant.EMPTY_INVALID_PINGROUP_ID,
                                    FieldIdConstant.PMPY_PINGRP_ID,
                                    ComponentIdConstant.PMAM,
                                    this.getClass().getSimpleName(),
                                    returnMessage );
                isPinGrpIdValid = true;

            }
        }
        else
        {
            addToReturnMessage( ArrangementConfigServiceErrorMessageConstant.PINGROUP_ID_EMPTY,
                                FieldIdConstant.PMPY_PINGRP_ID,
                                ComponentIdConstant.PMAM,
                                this.getClass().getSimpleName(),
                                returnMessage );
            isPinGrpIdValid = true;

        }
        LOGGER.debug( "VBPY022ValidatePingroupIdInSearchPayee : isPinGrpId Invalid" + isPinGrpIdValid );
        LOGGER.debug( "VBPY022ValidatePingroupIdInSearchPayee : End" );
        return isPinGrpIdValid;
    }
}
