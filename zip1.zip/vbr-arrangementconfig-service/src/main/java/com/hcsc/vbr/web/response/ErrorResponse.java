package com.hcsc.vbr.web.response;

import java.io.Serializable;
import java.util.List;

import com.hcsc.vbr.arrangementconfigservice.dto.ErrorMessageDTO;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ErrorResponse implements Serializable
{
    private static final long serialVersionUID = 1L;

    private List<ErrorMessageDTO> errors;

}
