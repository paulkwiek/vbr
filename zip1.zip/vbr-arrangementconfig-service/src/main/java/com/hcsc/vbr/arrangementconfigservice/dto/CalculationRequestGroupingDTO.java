package com.hcsc.vbr.arrangementconfigservice.dto;

import org.apache.commons.lang3.builder.ReflectionToStringBuilder;

import com.hcsc.vbr.common.dto.BaseEntityDTO;
import com.hcsc.vbr.common.utils.MultilineRecursiveToStringStyleCustom;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CalculationRequestGroupingDTO extends BaseEntityDTO
{

    private static final long serialVersionUID = 1L;

    private String calculationGroupingLevelCode;

    private String calculationRunName;

    private String calculationGroupingLevelValueText;

    private String corporateEntityCode;

    //As the length is 1 in backend changed from boolean to String
    private String selectedIndicator;

    // private CalculationRunNameDTO parentCalculationRunName;

    @Override
    public String toString()
    {
        return new ReflectionToStringBuilder( this,
                                              new MultilineRecursiveToStringStyleCustom() ).toString();
    }

}
