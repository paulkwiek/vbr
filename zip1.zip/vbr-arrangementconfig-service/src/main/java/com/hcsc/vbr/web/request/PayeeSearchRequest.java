package com.hcsc.vbr.web.request;

import java.io.Serializable;

import org.apache.commons.lang3.builder.ReflectionToStringBuilder;

import com.hcsc.vbr.common.utils.MultilineRecursiveToStringStyleCustom;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PayeeSearchRequest implements Serializable
{

    private static final long serialVersionUID = 1L;

    private String corpEntityCode;

    private String pinGroupId;

    private String networkCode;

    private String payToPFIN;

    private String capitationTypeCode;

    private String processCode;

    private Integer networkAssociationID;

    private String pinGroupName;

    private String taxIdNumber;

    private Integer vbrPayeeId;

    @Override
    public String toString()
    {
        return new ReflectionToStringBuilder( this,
                                              new MultilineRecursiveToStringStyleCustom() ).toString();
    }

}
