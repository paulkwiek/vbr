package com.hcsc.vbr.arrangementconfigservice.domain;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.MappedSuperclass;
import javax.validation.constraints.NotNull;

import org.apache.commons.lang3.builder.ReflectionToStringBuilder;

import com.hcsc.vbr.common.domain.DateRecord;
import com.hcsc.vbr.common.utils.MultilineRecursiveToStringStyleCustom;

import lombok.Getter;
import lombok.Setter;

@MappedSuperclass
@Getter
@Setter
@AttributeOverrides( {
    @AttributeOverride( name = "recordEffectiveDate", column = @Column( name = "FL_RT_EFF_DT" ) ),
    @AttributeOverride( name = "recordEndDate", column = @Column( name = "FL_RT_END_DT" ) ) } )
public class FlatRateRecord extends DateRecord
{
    private static final long serialVersionUID = 1L;

    @NotNull
    @Column( name = "CORP_ENT_CD", length = 3 )
    private String corporateEntityCode;

    /*
    @NotNull
    @Column( name = "RT_TYP_CD", length = 20 )
    private String rateTypeCode;
    */

    @NotNull
    @Column( name = "RT_NM", length = 20 )
    private String rateName;

    @NotNull
    @Column( name = "FMAL_FL_RT_AMT", precision = 11, scale = 2 )
    private Double femaleFlatRateAmount;

    @NotNull
    @Column( name = "MAL_FL_RT_AMT", precision = 11, scale = 2 )
    private Double maleFlatRateAmount;

    @Column( name = "CMT_TXT", length = 1000 )
    private String commentText;

    @Override
    public String toString()
    {
        return new ReflectionToStringBuilder( this,
                                              new MultilineRecursiveToStringStyleCustom() ).toString();
    }

}
