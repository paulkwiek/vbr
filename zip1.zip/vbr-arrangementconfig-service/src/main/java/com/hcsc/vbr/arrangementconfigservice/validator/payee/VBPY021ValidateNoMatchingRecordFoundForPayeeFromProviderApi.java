package com.hcsc.vbr.arrangementconfigservice.validator.payee;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.util.ObjectUtils;

import com.hcsc.vbr.arrangementconfigservice.constant.ArrangementConfigServiceErrorMessageConstant;
import com.hcsc.vbr.arrangementconfigservice.constant.ComponentIdConstant;
import com.hcsc.vbr.arrangementconfigservice.constant.FieldIdConstant;
import com.hcsc.vbr.arrangementconfigservice.validator.base.BaseValidationUnit;
import com.hcsc.vbr.common.dto.ReturnMessageDTO;
import com.hcsc.vbr.web.response.ProviderAPISearchResponseDTO;

@Component
public class VBPY021ValidateNoMatchingRecordFoundForPayeeFromProviderApi extends BaseValidationUnit
{

    private static final Logger LOGGER = LoggerFactory.getLogger( VBPY021ValidateNoMatchingRecordFoundForPayeeFromProviderApi.class );

    /**
     * Method: isRecordsFound
     * @param payees
     * @param returnMessage
     * @return
     * @throws Exception
     */
    public boolean isRecordsFound( List<ProviderAPISearchResponseDTO> capitationPinGroupResponse,
            ReturnMessageDTO returnMessage ) throws Exception
    {

        LOGGER.debug( "VBPY021ValidateNoMatchingRecordFoundForPayeeFromProviderApi : START" );

        boolean isRecordsFound = true;

        if( ObjectUtils.isEmpty( capitationPinGroupResponse ) )
        {
            isRecordsFound = false;
            //Add Error/Warning to ReturnMessage
            addToReturnMessage( ArrangementConfigServiceErrorMessageConstant.NO_PAYEE_RECORDS_FOUND,
                                FieldIdConstant.NO_RECORDS,
                                ComponentIdConstant.VBPY,
                                this.getClass().getSimpleName(),
                                returnMessage );
        }

        LOGGER.debug( "VBPY021ValidateNoMatchingRecordFoundForPayeeFromProviderApi : END" );

        return isRecordsFound;

    }
}
