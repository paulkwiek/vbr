package com.hcsc.vbr.arrangementconfigservice.mapper;

import java.util.List;

import org.mapstruct.IterableMapping;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;
import org.mapstruct.factory.Mappers;

import com.hcsc.vbr.arrangementconfigservice.domain.FlatRate;
import com.hcsc.vbr.arrangementconfigservice.domain.FlatRateHistory;
import com.hcsc.vbr.arrangementconfigservice.domain.RateName;
import com.hcsc.vbr.arrangementconfigservice.dto.FlatRateDTO;
import com.hcsc.vbr.arrangementconfigservice.dto.RateNameDTO;

@Mapper( componentModel = "spring" )
public interface RateNameMapper
{
    RateNameMapper INSTANCE = Mappers.getMapper( RateNameMapper.class );

    @Mapping( source = "corporateEntityCode", target = "rateNameId.corporateEntityCode" )
    @Mapping( source = "rateName", target = "rateNameId.rateName" )
    public RateName toRateName( RateNameDTO rateNameDTO );

    @Mapping( source = "rateNameId.corporateEntityCode", target = "corporateEntityCode" )
    @Mapping( source = "rateNameId.rateName", target = "rateName" )
    public RateNameDTO toRateNameDTO( RateName rateName );

    public List<RateName> toRateNames( List<RateNameDTO> rateNameDTOs );

    public List<RateNameDTO> toRateNameDTOs( List<RateName> rateNames );

    @Mapping( target = "recordEffectiveDate", dateFormat = "MM/dd/yyyy" )
    @Mapping( target = "recordEndDate", dateFormat = "MM/dd/yyyy" )
    public FlatRateDTO toFlatRateDTO( FlatRate flatRate );

    @IterableMapping( elementTargetType = FlatRateDTO.class, qualifiedByName = "toFlatRateDTO" )
    public List<FlatRateDTO> toFlatRateDTOs( List<FlatRate> flatRates );

    @Mapping( target = "recordEffectiveDate", dateFormat = "MM/dd/yyyy" )
    @Mapping( target = "recordEndDate", dateFormat = "MM/dd/yyyy" )
    @Mapping( source = "femaleFlatRateAmount", target = "femaleFlatRateAmount", qualifiedByName = "stringToDouble" )
    @Mapping( source = "maleFlatRateAmount", target = "maleFlatRateAmount", qualifiedByName = "stringToDouble" )
    public FlatRate toFlatRate( FlatRateDTO flatRateDTO );

    @IterableMapping( elementTargetType = FlatRate.class, qualifiedByName = "toFlatRate" )
    public List<FlatRate> toFlatRates( List<FlatRateDTO> flatRateDTOs );

    public FlatRateHistory toFlatRateHistory( FlatRate flatRate );

    @Named( value = "stringToDouble" )
    default Double stringToDouble( String value )
    {
        return Double.parseDouble( value );

    }

}
