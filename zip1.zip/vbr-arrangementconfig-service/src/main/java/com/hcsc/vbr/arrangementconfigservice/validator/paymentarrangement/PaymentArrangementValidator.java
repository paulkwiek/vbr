package com.hcsc.vbr.arrangementconfigservice.validator.paymentarrangement;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.ObjectUtils;

import com.hcsc.vbr.arrangementconfigservice.apiclient.CalculationServiceApiClient;
import com.hcsc.vbr.arrangementconfigservice.constant.ArrangementConfigServiceConstant;
import com.hcsc.vbr.arrangementconfigservice.constant.ComponentIdConstant;
import com.hcsc.vbr.arrangementconfigservice.domain.FlatRate;
import com.hcsc.vbr.arrangementconfigservice.domain.PaymentArrangement;
import com.hcsc.vbr.arrangementconfigservice.domain.PaymentArrangementPayee;
import com.hcsc.vbr.arrangementconfigservice.domain.PaymentArrangementRate;
import com.hcsc.vbr.arrangementconfigservice.domain.VbrPayee;
import com.hcsc.vbr.arrangementconfigservice.mapper.PaymentArrangementMapper;
import com.hcsc.vbr.arrangementconfigservice.repository.FlatRateRepository;
import com.hcsc.vbr.arrangementconfigservice.validator.base.BaseValidator;
import com.hcsc.vbr.common.dto.ErrorMessageDTO;
import com.hcsc.vbr.common.dto.ReturnMessageDTO;
import com.hcsc.vbr.common.exception.VbrApplicationException;
import com.hcsc.vbr.common.utils.VBRDateUtils;
import com.hcsc.vbr.web.request.ValidateArrangementPayeeRequest;
import com.hcsc.vbr.web.response.PayeeRetrieveResponse;
import com.hcsc.vbr.web.response.ProviderAPIResponseDTO;

@Component
public class PaymentArrangementValidator extends BaseValidator
{
    final Logger LOGGER = LoggerFactory.getLogger( PaymentArrangementValidator.class );

    @Autowired
    private CalculationServiceApiClient calculationServiceApiClient;

    @Autowired
    private PMAM002CheckFrequencyCode pmam002CheckFrequencyCode;

    @Autowired
    private PMAM003CheckGapInArrangmentPayeeEffEndDates pmam003CheckGapInArrangmentPayeeEffEndDates;

    @Autowired
    private PMAM004CheckOverlapInArrangmentPayeeEffEndDates pmam004CheckOverlapInArrangmentPayeeEffEndDates;

    @Autowired
    private PMAM005CheckArrangementDurationWithArrangementPayee pmam005CheckArrangementDurationWithArrangementPayee;

    @Autowired
    private PMAM006CheckArrangementPayeeVBRPayeeProviderDates pmam006CheckArrangementPayeeVBRPayeeProviderDates;

    @Autowired
    private PMAM007CheckPaymentArrangementPayeeEffectiveAndEndDates pmam007CheckPaymentArrangementPayeeEffectiveAndEndDates;

    @Autowired
    private PMAM009CheckArrangementName pmam009CheckArrangementName;

    @Autowired
    private PMAM010CheckArrangementDescription pmam010CheckArrangementDescription;

    @Autowired
    private PMAM011CheckArrangementDurationWithArrangementRate pmam011CheckArrangementDurationWithArrangementRate;

    @Autowired
    private PMAM013CheckArrangementPayeeValidForProcessingMonth pmam013CheckArrangementPayeeValidForProcessingMonth;

    @Autowired
    private PMAM014CheckArrangementRateValidForProcessingMonth pmam014CheckArrangementRateValidForProcessingMonth;

    @Autowired
    private PMAM015CheckArrangementPayeeDurationWithVbrPayee pmam015CheckArrangementPayeeDurationWithVbrPayee;

    @Autowired
    private PMAM016CheckArrangementRateDurationWithFlatRates pmam016CheckArrangementRateDurationWithFlatRates;

    @Autowired
    private FlatRateRepository flatRateRepository;

    @Autowired
    private PMAM017CheckGapInArrangementRateEffEndDates pmam017CheckGapInArrangementRateEffEndDates;

    @Autowired
    private PMAM018CheckOverlapInArrangementRateEffEndDates pmam018CheckOverlapInArrangementRateEffEndDates;

    @Autowired
    private PMAM019CheckValidationStatusCode pmam019CheckValidationStatusCode;

    @Autowired
    private PMAM020CheckPaymentArrangementSubject pmam020CheckPaymentArrangementSubject;

    @Autowired
    private PMAM021CheckPaymentArrangementRate pmam021CheckPaymentArrangementRate;

    @Autowired
    private PMAM022CheckPaymentArrangementPayee pmam022CheckPaymentArrangementPayee;

    @Autowired
    private PMAM023CheckDuplicateVbrPayee pmam023CheckDuplicateVbrPayee;

    @Autowired
    private PMAM025CheckArrangementRateEffEndDates pmam025CheckArrangementRateEffEndDates;

    @Autowired
    private PMAM026CheckPaymentArrangementPaymentTypeCode pmam026CheckPaymentArrangementPaymentTypeCode;

    @Autowired
    private PMAM027CheckArrangementMemberSubject pmam027CheckArrangementMemberSubject;

    @Autowired
    private PMAM030CheckPaymentArrangementExpiredStatus pmam030CheckPaymentArrangementExpiredStatus;

    @Autowired
    private PMAM029CheckForNullPaymentArrangementPayeeDuration pmam029CheckForNullPaymentArrangementPayeeDuration;

    @Autowired
    private PMAM031ValidatePaymentArrangementStatus pmam031ValidatePaymentArrangementStatus;

    @Autowired
    private PMAM032CheckMemberSubjectFieldLOB pmam032CheckMemberSubjectFieldLOB;

    @Autowired
    private PMAM033CheckMemberSubjectFieldContractId pmam033CheckMemberSubjectFieldContractId;

    @Autowired
    private PMAM036CheckArrangementDuration pmam036CheckArrangementDuration;

    @Autowired
    private PMAM040CheckArrangementPayeeDurationWithVbrPayee pmam040CheckArrangementPayeeDurationWithVbrPayee;

    @Autowired
    private PMAM041CheckPaymentArrangementPayeeEffectiveAndEndDates pmam041CheckPaymentArrangementPayeeEffectiveAndEndDates;

    @Autowired
    private PMAM042CheckCompareArrangementPayeeEffectiveAndEndDate pmam042CheckCompareArrangementPayeeEffectiveAndEndDate;

    @Autowired
    private PMAM044CheckRetrieveArrangement pmam044CheckRetrieveArrangement;

    @Autowired
    private PMAM045CheckRetrievePayee pmam045CheckRetrievePayee;

    @Autowired
    private PMAM046CheckPremierProviderResponse pmam046CheckPremierProviderResponse;

    @Autowired
    private PMAM047CheckFetchArrangements pmam047CheckFetchArrangements;

    @Autowired
    private PMAM049CheckProviderAPIProviderResponse pmam049CheckProviderAPIProviderResponse;

    @Autowired
    private PaymentArrangementMapper paymentArrangementMapper;

    /**
     * validates save
     * 
     * @param paymentArrangementSaveRequest
     * @throws Exception
     */
    public String validateSave( PaymentArrangement paymentArrangementSaveRequest,
            ReturnMessageDTO returnMessage ) throws Exception
    {
        LOGGER.debug( "Start of Method validateSave" );

        boolean isarrangementValid = false;
        boolean isRateInvalid = false;
        boolean arrangementRateDateHasGap = false;
        boolean arrangementRateDateHasOverlap = false;
        boolean isArrangementRateAndArrangementDateInvalid = false;
        boolean isArrangementRateDateInvalid = false;
        boolean isArrangementRateAndGlobalDateInvalid = false;
        boolean isPayeeInvalid = false;
        boolean isArrangementPayeeDateListInvalid = false;
        boolean isArrangementPayeeEffAndEndDateInvalid = false;
        boolean arrangementPayeeDateHasGap = false;
        boolean arrangementPayeeDateHasOverlap = false;
        boolean isArrangementPayeeDurationWithVbrPayeeInvalid = false;
        boolean isArrangementDurationWithArrangementPayeeInvalid = false;
        boolean isProcessingMonthvalid = false;
        boolean isArrangementPayeevalidForProcessingMonth = false;
        boolean isArrangementRatevalidForProcessingMonth = false;
        String validationStatus = null;
        boolean validateSaveFlag = true;
        List<FlatRate> flatRates = new ArrayList<FlatRate>();
        List<FlatRate> flatRatesforallarrangementRates = new ArrayList<FlatRate>();
        /** Arrangement MandatoryFields Validation  **/
        isarrangementValid = validateArrangementForMandatoryFields( paymentArrangementSaveRequest,
                                                                    returnMessage );

        if( ( isarrangementValid ) == true )
        {
            List<PaymentArrangementPayee> paymentArrangementPayees = paymentArrangementSaveRequest.getPaymentArrangementPayees();
            List<PaymentArrangementRate> paymentArrangementRates = paymentArrangementSaveRequest.getPaymentArrangementRates();

            LocalDate processingMonth =
                calculationServiceApiClient.getCurrentProcessingMonth( paymentArrangementSaveRequest.getCorporateEntityCode() );

            /**  Arrangement Subject Selected  Validation   **/
            validateSaveFlag = pmam020CheckPaymentArrangementSubject.validatePaymentArrangementSubject( paymentArrangementSaveRequest,
                                                                                                        returnMessage )
                || validateSaveFlag;

            /**  Arrangement Rate Selected  Validation   **/
            validateSaveFlag = pmam021CheckPaymentArrangementRate.validatePaymentArrangementRate( paymentArrangementSaveRequest,
                                                                                                  returnMessage )
                || validateSaveFlag;

            /**  Arrangement Payee Selected  Validation   **/
            validateSaveFlag = pmam022CheckPaymentArrangementPayee.validatePaymentArrangementPayees( paymentArrangementSaveRequest,
                                                                                                     returnMessage )
                || validateSaveFlag;

            /** START - Arrangement Payee  Validation - START  **/
            if( !CollectionUtils.isEmpty( paymentArrangementPayees ) )
            {

                validateSaveFlag =
                    pmam029CheckForNullPaymentArrangementPayeeDuration.isPaymentArrangementPayeeDatesEmpty( paymentArrangementPayees,
                                                                                                            returnMessage )
                        || validateSaveFlag;

                validateSaveFlag = pmam023CheckDuplicateVbrPayee.validateVbrPaye( paymentArrangementPayees,
                                                                                  returnMessage )
                    || validateSaveFlag;

                /**  Arrangement Duration With in ArrangementPayee   **/
                isArrangementDurationWithArrangementPayeeInvalid = pmam005CheckArrangementDurationWithArrangementPayee
                        .validateArrangementDurationWithArrangementPayee( paymentArrangementPayees,
                                                                          paymentArrangementSaveRequest,
                                                                          processingMonth,
                                                                          returnMessage );

                validateSaveFlag = isArrangementDurationWithArrangementPayeeInvalid || validateSaveFlag;

                for( PaymentArrangementPayee payee : paymentArrangementPayees )
                {
                    /**  Arrangement Payee With in VBR Payee   **/
                    isArrangementPayeeDurationWithVbrPayeeInvalid = pmam015CheckArrangementPayeeDurationWithVbrPayee
                            .validateArrangementPayeeDurationWithVbrPayee( payee.getVbrPayee(),
                                                                           payee,
                                                                           paymentArrangementSaveRequest,
                                                                           processingMonth,
                                                                           returnMessage );

                    validateSaveFlag = isArrangementPayeeDurationWithVbrPayeeInvalid || validateSaveFlag;

                    /**  VBR Payee Validation for Premier Provider Dates   **/

                    if( null == payee.getVbrPayee().getVbrPayeeId() )
                    {
                        isArrangementPayeeDateListInvalid = pmam006CheckArrangementPayeeVBRPayeeProviderDates
                                .validateArrangementPayeeVBRPayeeDates( paymentArrangementSaveRequest,
                                                                        processingMonth,
                                                                        returnMessage );

                        validateSaveFlag = isArrangementPayeeDateListInvalid || validateSaveFlag;

                    }
                }

                /**  ArrangementPayee Valid For ProcessingMonth   **/
                isArrangementPayeevalidForProcessingMonth = pmam013CheckArrangementPayeeValidForProcessingMonth
                        .validateArrangementPayeeForProcessingMonth( paymentArrangementPayees,
                                                                     paymentArrangementSaveRequest,
                                                                     processingMonth,
                                                                     returnMessage );

                validateSaveFlag = isArrangementPayeevalidForProcessingMonth || validateSaveFlag;

                /** PaymentArrangementPayee Effective & End Dates validation */
                isArrangementPayeeEffAndEndDateInvalid = pmam007CheckPaymentArrangementPayeeEffectiveAndEndDates
                        .validatePaymentArrangementPayeeEffectiveAndEndDates( paymentArrangementPayees,
                                                                              returnMessage );

                validateSaveFlag = isArrangementPayeeEffAndEndDateInvalid || validateSaveFlag;

                /**  Arrangement Payee Validation for Effective and End Dates   **/
                if( CollectionUtils.size( paymentArrangementPayees ) > 1 )
                {
                    arrangementPayeeDateHasGap = pmam003CheckGapInArrangmentPayeeEffEndDates
                            .validateGapInArrangmentPayeeEffEndDates( VBRDateUtils.removeVoidDates( paymentArrangementPayees ),
                                                                      paymentArrangementSaveRequest,
                                                                      processingMonth,
                                                                      returnMessage );

                    validateSaveFlag = arrangementPayeeDateHasGap || validateSaveFlag;

                    arrangementPayeeDateHasOverlap = pmam004CheckOverlapInArrangmentPayeeEffEndDates
                            .validateOverlapInArrangmentPayeeEffEndDates( VBRDateUtils.removeVoidDates( paymentArrangementPayees ),
                                                                          paymentArrangementSaveRequest,
                                                                          processingMonth,
                                                                          returnMessage );

                    validateSaveFlag = arrangementPayeeDateHasOverlap || validateSaveFlag;

                }
            }
            /** END - Arrangement Payee  Validation - END  **/

            /** START - Arrangement Rate  Validation - START  **/
            if( !CollectionUtils.isEmpty( paymentArrangementRates ) )

            {
                /** PaymentArrangementRate Effective & End Dates validation */
                isArrangementRateDateInvalid =
                    pmam025CheckArrangementRateEffEndDates.validateArrangementRateEffEndDates( paymentArrangementRates,
                                                                                               paymentArrangementSaveRequest,
                                                                                               processingMonth,
                                                                                               returnMessage );

                validateSaveFlag = isArrangementRateDateInvalid || validateSaveFlag;

                /**  Arrangement Rate With in Flat Rate   **/
                for( PaymentArrangementRate arrangementRate : paymentArrangementRates )
                {
                    flatRates = flatRateRepository.findByRateName( arrangementRate.getRateName() );
                    flatRatesforallarrangementRates.addAll( flatRates );

                    isArrangementRateAndGlobalDateInvalid =
                        pmam016CheckArrangementRateDurationWithFlatRates.validateArrangementRateDurationWithFlatRates( flatRates,
                                                                                                                       arrangementRate,
                                                                                                                       paymentArrangementSaveRequest,
                                                                                                                       processingMonth,
                                                                                                                       returnMessage );

                    validateSaveFlag = isArrangementRateAndGlobalDateInvalid || validateSaveFlag;

                }

                /**  Arrangement Rate  Gap and Overlap Validation   **/
                if( CollectionUtils.size( paymentArrangementRates ) > 1 )
                {

                    /**  Arrangement Rate  Gap Validation   **/
                    arrangementRateDateHasGap = pmam017CheckGapInArrangementRateEffEndDates
                            .validateGapInArrangmentRateEffEndDates( VBRDateUtils.removeVoidDates( paymentArrangementRates ),
                                                                     paymentArrangementSaveRequest,
                                                                     processingMonth,
                                                                     returnMessage );

                    validateSaveFlag = arrangementRateDateHasGap || validateSaveFlag;

                    /**  Arrangement Rate  Overlap Validation   **/
                    arrangementRateDateHasOverlap = pmam018CheckOverlapInArrangementRateEffEndDates
                            .validateOverlapInArrangmentRateEffEndDates( VBRDateUtils.removeVoidDates( paymentArrangementRates ),
                                                                         paymentArrangementSaveRequest,
                                                                         processingMonth,
                                                                         returnMessage );

                    validateSaveFlag = arrangementRateDateHasOverlap || validateSaveFlag;

                }

                /**  Arrangement Duration With in ArrangementRate   **/
                isArrangementRateAndArrangementDateInvalid = pmam011CheckArrangementDurationWithArrangementRate
                        .validateArrangementDurationWithArrangementRate( paymentArrangementRates,
                                                                         paymentArrangementSaveRequest,
                                                                         processingMonth,
                                                                         returnMessage );

                validateSaveFlag = isArrangementRateAndArrangementDateInvalid || validateSaveFlag;

                /**  Arrangement Rate Valid For ProcessingMonth   **/
                isArrangementRatevalidForProcessingMonth = pmam014CheckArrangementRateValidForProcessingMonth
                        .validateArrangementRateForProcessingMonth( flatRatesforallarrangementRates,
                                                                    paymentArrangementRates,
                                                                    paymentArrangementSaveRequest,
                                                                    processingMonth,
                                                                    returnMessage );

                validateSaveFlag = isArrangementRatevalidForProcessingMonth || validateSaveFlag;
            }
            /** END - Arrangement Rate  Validation - END  **/

            if( isArrangementRateAndGlobalDateInvalid
                || isArrangementRateDateInvalid
                || arrangementRateDateHasOverlap
                || arrangementRateDateHasGap
                || isArrangementRateAndArrangementDateInvalid )
            {
                isRateInvalid = true;
            }

            if( isArrangementPayeeDateListInvalid
                || isArrangementPayeeEffAndEndDateInvalid
                || arrangementPayeeDateHasGap
                || arrangementPayeeDateHasOverlap
                || isArrangementPayeeDurationWithVbrPayeeInvalid
                || isArrangementDurationWithArrangementPayeeInvalid )
            {
                isPayeeInvalid = true;
            }

            if( isArrangementPayeevalidForProcessingMonth && isArrangementRatevalidForProcessingMonth )
            {
                isProcessingMonthvalid = true;
            }

            validationStatus = pmam019CheckValidationStatusCode.getValidationStatusCode( paymentArrangementSaveRequest,
                                                                                         isRateInvalid,
                                                                                         isPayeeInvalid,
                                                                                         processingMonth,
                                                                                         isProcessingMonthvalid );

            /* Arrangement Member Subject Validation based on validationStatus*/
            validateSaveFlag = pmam027CheckArrangementMemberSubject.checkArrangementMemberSubject( paymentArrangementSaveRequest,
                                                                                                   returnMessage )
                || validateSaveFlag;

            paymentArrangementSaveRequest.setValidationStatusCode( validationStatus );

            /* Arrangement Member Subject Validation based on validationStatus*/
            validateSaveFlag = pmam032CheckMemberSubjectFieldLOB.checkArrangementMemberSubjectLOB( paymentArrangementSaveRequest,
                                                                                                   returnMessage )
                || validateSaveFlag;

            validateSaveFlag =
                pmam033CheckMemberSubjectFieldContractId.checkArrangementMemberSubjectContractId( paymentArrangementSaveRequest,
                                                                                                  returnMessage )
                    || validateSaveFlag;

            if( StringUtils.equalsIgnoreCase( validationStatus,
                                              ArrangementConfigServiceConstant.ARRANGEMENT_STATUS_EXPIRED ) )
            {
                validateSaveFlag =
                    pmam030CheckPaymentArrangementExpiredStatus.setWarningForExpiredArrangement( paymentArrangementSaveRequest,
                                                                                                 returnMessage )
                        || validateSaveFlag;
            }

            validateSaveFlag = pmam031ValidatePaymentArrangementStatus.checkValidationStatusCode( paymentArrangementSaveRequest,
                                                                                                  isRateInvalid,
                                                                                                  isPayeeInvalid,
                                                                                                  returnMessage )
                || validateSaveFlag;
        }

        LOGGER.debug( "returnMessage " + returnMessage );
        LOGGER.debug( "End of Method validateSave: validationStatus" + validationStatus );
        LOGGER.debug( "End of Method validateSave" );
        return validationStatus;

    }

    /**
     * Method: validateArrangementForMandatoryFields
     * @param paymentArrangementSaveRequest
     * @param returnMessage
     * @return
     * @throws Exception
     */
    public boolean validateArrangementForMandatoryFields( PaymentArrangement paymentArrangementSaveRequest,
            ReturnMessageDTO returnMessage ) throws Exception
    {
        LOGGER.debug( "validateArrangementForMandatoryFields : START" );

        boolean isArrangementMandatoryFieldsValid = true;

        /** Start of Arrangement Validations **/
        /** ArrangementName Validation  **/
        isArrangementMandatoryFieldsValid = pmam009CheckArrangementName.validateArrangementName( paymentArrangementSaveRequest,
                                                                                                 returnMessage )
            && isArrangementMandatoryFieldsValid;

        /** Arrangement Frequency code validation **/
        isArrangementMandatoryFieldsValid = pmam002CheckFrequencyCode.validateFrequencyCode( paymentArrangementSaveRequest,
                                                                                             returnMessage )
            && isArrangementMandatoryFieldsValid;

        /** ArrangementDescription validation **/
        isArrangementMandatoryFieldsValid =
            pmam010CheckArrangementDescription.validateArrangementDescription( paymentArrangementSaveRequest,
                                                                               returnMessage )
                && isArrangementMandatoryFieldsValid;

        /** Arrangement Payment Type Code validation **/
        isArrangementMandatoryFieldsValid =
            pmam026CheckPaymentArrangementPaymentTypeCode.validateArrangementPaymentTypeCode( paymentArrangementSaveRequest,
                                                                                              returnMessage )
                && isArrangementMandatoryFieldsValid;

        /** PaymentArrangement Effective & End date Validation **/
        isArrangementMandatoryFieldsValid = pmam036CheckArrangementDuration.validateArrangementDuration( paymentArrangementSaveRequest,
                                                                                                         returnMessage )
            && isArrangementMandatoryFieldsValid;

        if( !isArrangementMandatoryFieldsValid )
        {
            /** PaymentArrangement Validation validation fails  Flag is false*/
            LOGGER.debug( "validateArrangementForMandatoryFields : Valid" + isArrangementMandatoryFieldsValid );
            returnMessage.setStatus( ArrangementConfigServiceConstant.FAILURE_VALIDATION_STATUS );
            throw new VbrApplicationException( returnMessage );
        }
        LOGGER.debug( "validateArrangementForMandatoryFields : Valid" + isArrangementMandatoryFieldsValid );
        LOGGER.debug( "validateArrangementForMandatoryFields : END" );
        return isArrangementMandatoryFieldsValid;
    }

    /**
     * Method: validateArrangementPayeeDates
     * @param validateArrangementPayeeRequest
     * @param returnMessage
     * @return
     * @throws Exception
     */
    public boolean validateArrangementPayeeDates( ValidateArrangementPayeeRequest validateArrangementPayeeRequest,
            ReturnMessageDTO returnMessage ) throws Exception
    {
        boolean isPayeeDatesInvalid = false;

        PaymentArrangementPayee arrangementPayee =
            paymentArrangementMapper.toPaymentArrangementPayee( validateArrangementPayeeRequest.getValidateArrangementPayee() );

        isPayeeDatesInvalid =
            pmam041CheckPaymentArrangementPayeeEffectiveAndEndDates.validateArrangementPayeeEffectiveAndEndDate( arrangementPayee,
                                                                                                                 returnMessage )
                || isPayeeDatesInvalid;

        isPayeeDatesInvalid =
            pmam042CheckCompareArrangementPayeeEffectiveAndEndDate.compareArrangementPayeeEffectiveAndEndDate( arrangementPayee,
                                                                                                               returnMessage )
                || isPayeeDatesInvalid;

        isPayeeDatesInvalid =
            pmam040CheckArrangementPayeeDurationWithVbrPayee.validateArrangementPayeeDatesWithVbrPayee( arrangementPayee.getVbrPayee(),
                                                                                                        arrangementPayee,
                                                                                                        returnMessage )
                || isPayeeDatesInvalid;

        if( isPayeeDatesInvalid )
        {
            returnMessage.setStatus( ArrangementConfigServiceConstant.FAILURE_VALIDATION_STATUS );
            throw new VbrApplicationException( returnMessage );
        }
        else
        {
            returnMessage.setStatus( ArrangementConfigServiceConstant.SUCCESS_VALIDATION_STATUS );
        }

        return isPayeeDatesInvalid;
    }

    /**
     * Method: validateRetrieveArrangement
     * @param paymentArrangementId
     * @param returnMessage
     * @return
     * @throws Exception
     */
    public boolean validateRetrieveArrangement( PaymentArrangement paymentArrangement,
            ReturnMessageDTO returnMessage ) throws Exception
    {
        LOGGER.debug( "validateRetrieveArrangement : START" );
        boolean isArrangementValid = true;

        isArrangementValid = pmam044CheckRetrieveArrangement.validateRetrieveArrangement( paymentArrangement,
                                                                                          returnMessage );

        if( !isArrangementValid )
        {
            LOGGER.debug( "validateRetrieveArrangement : NO ARRANGEMENT RECORD" );
            returnMessage.setStatus( ArrangementConfigServiceConstant.FAILURE_VALIDATION_STATUS );
            throw new VbrApplicationException( returnMessage );
        }
        else
        {
            returnMessage.setStatus( ArrangementConfigServiceConstant.SUCCESS_VALIDATION_STATUS );
        }

        LOGGER.debug( "validateRetrieveArrangement : END" );
        return isArrangementValid;
    }

    /**
    * Method: isArrangementSaveEnabled
    * @param paymentArrangementSaveRequest
    * @param returnMessage
    * @return
    */
    private boolean isArrangementSaveEnabled( PaymentArrangement paymentArrangementSaveRequest,
            ReturnMessageDTO returnMessage )
    {
        LOGGER.debug( "isArrangementSaveEnabled : START" );
        boolean overwriteArrangement = false;

        String paymentSave = paymentArrangementSaveRequest.getOverwriteSaveArrangement();

        if( StringUtils.equalsIgnoreCase( paymentSave,
                                          ArrangementConfigServiceConstant.STRING_TRUE ) )
        {
            if( ObjectUtils.isEmpty( returnMessage.getErrors() ) )
            {
                overwriteArrangement = true;
            }
        }
        LOGGER.debug( "isArrangementSaveEnabled : " + overwriteArrangement );
        LOGGER.debug( "isArrangementSaveEnabled : END" );
        return overwriteArrangement;
    }

    /**
     * Method: isArrangementCancelEnabled
     * @param paymentArrangementSaveRequest
     * @param returnMessage
     * @return
     */
    private boolean isArrangementCancelEnabled( PaymentArrangement paymentArrangementSaveRequest,
            ReturnMessageDTO returnMessage )
    {
        LOGGER.debug( "isArrangementCancelEnabled : START" );
        boolean arrangementCancel = false;

        String paymentCancel = paymentArrangementSaveRequest.getOverwriteCancelArrangement();

        if( !isArrangementSaveEnabled( paymentArrangementSaveRequest,
                                       returnMessage )
            && StringUtils.equalsIgnoreCase( paymentCancel,
                                             ArrangementConfigServiceConstant.STRING_TRUE ) )
        {
            arrangementCancel = true;
        }

        LOGGER.debug( "isArrangementCancelEnabled : " + arrangementCancel );
        LOGGER.debug( "isArrangementCancelEnabled : END" );
        return arrangementCancel;
    }

    /**
     * Method: returnErrorMessage
     * @param returnMessage
     * @return
     * @throws Exception
     */
    private ReturnMessageDTO returnErrorMessage( ReturnMessageDTO returnMessage ) throws Exception
    {
        LOGGER.debug( "returnErrorMessage : START" );

        List<ErrorMessageDTO> errors = returnMessage.getErrors();
        ReturnMessageDTO returnErrorMessage = new ReturnMessageDTO( ComponentIdConstant.PMAM );

        for( ErrorMessageDTO error : errors )
        {
            if( !StringUtils.equalsIgnoreCase( error.getValidationClass(),
                                               "PMAM031ValidatePaymentArrangementStatus" ) )
            {
                returnErrorMessage.add( error );
            }
        }

        LOGGER.debug( "returnErrorMessage : " + returnErrorMessage );
        LOGGER.debug( "returnErrorMessage : END" );
        return returnErrorMessage;
    }

    /**
     * Method: returnConfirmMessage
     * @param returnMessage
     * @return
     * @throws Exception
     */
    private ReturnMessageDTO returnConfirmMessage( ReturnMessageDTO returnMessage ) throws Exception
    {
        LOGGER.debug( "returnErrorMessage : START" );

        List<ErrorMessageDTO> errors = returnMessage.getErrors();
        ReturnMessageDTO returnConfirmMessage = new ReturnMessageDTO( ComponentIdConstant.PMAM );

        for( ErrorMessageDTO error : errors )
        {
            if( StringUtils.equalsIgnoreCase( error.getValidationClass(),
                                              "PMAM031ValidatePaymentArrangementStatus" ) )
            {
                returnConfirmMessage.add( error );
            }
        }

        returnConfirmMessage.add( returnMessage.getWarnings() );
        LOGGER.debug( "returnConfirmMessage : " + returnConfirmMessage );
        LOGGER.debug( "returnConfirmMessage : END" );
        return returnConfirmMessage;
    }

    /**
     * @method validateRetrievePayee
     * @param vbrPayeeRecord
     * @param returnMessage
     * @return
     * @throws Exception
     */
    public boolean validateRetrievePayee( List<VbrPayee> vbrPayeeRecord,
            ReturnMessageDTO returnMessage ) throws Exception
    {
        LOGGER.debug( "validateRetrievePayee : START" );
        boolean isPayeeValid = true;

        isPayeeValid = pmam045CheckRetrievePayee.validateRetrievePayee( vbrPayeeRecord,
                                                                        returnMessage );

        if( !isPayeeValid )
        {
            LOGGER.debug( "validateRetrievePayee : NO ARRANGEMENT RECORD" );
            returnMessage.setStatus( ArrangementConfigServiceConstant.FAILURE_VALIDATION_STATUS );
            throw new VbrApplicationException( returnMessage );
        }
        else
        {
            returnMessage.setStatus( ArrangementConfigServiceConstant.SUCCESS_VALIDATION_STATUS );
        }

        LOGGER.debug( "validateRetrievePayee : END" );
        return isPayeeValid;
    }

    /**
     * @method validateMatchingPremierProviderResponse
     * @param providerResponse
     * @param returnMessage
     * @return
     * @throws Exception
     */
    public boolean validateMatchingPremierProviderResponse( List<PayeeRetrieveResponse> providerResponse,
            ReturnMessageDTO returnMessage ) throws Exception
    {
        LOGGER.debug( "validateMatchingPremierProviderResponse : START" );
        boolean isProviderResponseValid = true;

        isProviderResponseValid = pmam046CheckPremierProviderResponse.validatePremierProviderResponse( providerResponse,
                                                                                                       returnMessage );

        if( !isProviderResponseValid )
        {
            LOGGER.debug( "validatePremierProviderResponse : NO PREMIER PROVIDER RECORD" );
            returnMessage.setStatus( ArrangementConfigServiceConstant.FAILURE_VALIDATION_STATUS );
            throw new VbrApplicationException( returnMessage );
        }

        LOGGER.debug( "validateMatchingPremierProviderResponse : END" );
        return isProviderResponseValid;
    }

    /**
     * Method: validateArrangementStatus
     * @param paymentArrangementSaveRequest
     * @param returnMessage
     * @return
     * @throws Exception
     */
    public String validateArrangementStatus( PaymentArrangement paymentArrangement,
            ReturnMessageDTO returnMessage ) throws Exception
    {

        LOGGER.debug( "validateArrangementStatus - START" );

        String validationStatusCode = validateSave( paymentArrangement,
                                                    returnMessage );

        boolean arrangementSave = isArrangementSaveEnabled( paymentArrangement,
                                                            returnMessage );

        boolean arrangementCancel = isArrangementCancelEnabled( paymentArrangement,
                                                                returnMessage );

        LOGGER.debug( "arrangementSave before " + arrangementSave );
        LOGGER.debug( "arrangementCancel before " + paymentArrangement.getOverwriteCancelArrangement() );

        if( !arrangementSave && !ObjectUtils.isEmpty( returnMessage.getErrors() ) )
        {

            if( !arrangementCancel )
            {
                ReturnMessageDTO returnErrorMessage = returnErrorMessage( returnMessage );

                if( !ObjectUtils.isEmpty( returnErrorMessage.getErrors() ) )
                {

                    LOGGER.debug( " validateSave returnErrorMessage : " + returnErrorMessage );
                    returnErrorMessage.setStatus( ArrangementConfigServiceConstant.FAILURE_VALIDATION_STATUS );
                    throw new VbrApplicationException( returnErrorMessage );

                }
                else
                {
                    ReturnMessageDTO returnConfirmMessage = returnConfirmMessage( returnMessage );
                    LOGGER.debug( " validateSave returnConfirmMessage : " + returnConfirmMessage );
                    returnConfirmMessage.setStatus( ArrangementConfigServiceConstant.FAILURE_VALIDATION_STATUS );
                    throw new VbrApplicationException( returnConfirmMessage );
                }
            }
            else
            {

                returnMessage.getErrors().clear();
                LOGGER.debug( " validateSave returnWarningMessage : " + returnMessage );
                returnMessage.setStatus( ArrangementConfigServiceConstant.FAILURE_VALIDATION_STATUS );
                throw new VbrApplicationException( returnMessage );

            }

        }
        else
        {
            returnMessage.setStatus( ArrangementConfigServiceConstant.SUCCESS_VALIDATION_STATUS );
        }

        LOGGER.debug( "validateArrangementStatus - END" );
        return validationStatusCode;

    }

    /**
     * Method: validateRetrieveArrangements
     * @param paymentArrangementId
     * @param returnMessage
     * @return
     * @throws Exception
     */
    public boolean validateRetrieveArrangements( List<PaymentArrangement> paymentArrangements,
            ReturnMessageDTO returnMessage ) throws Exception
    {
        LOGGER.debug( "validateRetrieveArrangements : START" );
        boolean isArrangementValid = true;

        isArrangementValid = pmam047CheckFetchArrangements.validateFetchArrangements( paymentArrangements,
                                                                                      returnMessage );

        if( !isArrangementValid )
        {
            LOGGER.debug( "validateRetrieveArrangement : NO ARRANGEMENT RECORD" );
            returnMessage.setStatus( ArrangementConfigServiceConstant.FAILURE_VALIDATION_STATUS );
            throw new VbrApplicationException( returnMessage );
        }
        else
        {
            returnMessage.setStatus( ArrangementConfigServiceConstant.SUCCESS_VALIDATION_STATUS );
        }

        LOGGER.debug( "validateRetrieveArrangements : END" );
        return isArrangementValid;
    }

    /**
     * Method: validateProviderAPIProviderResponse
     * @param providerAPIResponseDTO
     * @param returnMessage
     * @return
     * @throws Exception 
     */
    public boolean validateProviderAPIProviderResponse( List<ProviderAPIResponseDTO> providerAPIResponse,
            ReturnMessageDTO returnMessageDTO ) throws Exception
    {
        LOGGER.debug( "validateProviderAPIProviderResponse : START" );
        boolean isAPIResponseNotNull = true;

        isAPIResponseNotNull = pmam049CheckProviderAPIProviderResponse.validateProviderAPIProviderResponse( providerAPIResponse,
                                                                                                            returnMessageDTO );

        if( !isAPIResponseNotNull )
        {

            returnMessageDTO.setStatus( ArrangementConfigServiceConstant.FAILURE_VALIDATION_STATUS );
            throw new VbrApplicationException( returnMessageDTO );
        }
        else
        {
            returnMessageDTO.setStatus( ArrangementConfigServiceConstant.SUCCESS_VALIDATION_STATUS );
        }

        LOGGER.debug( "validateProviderAPIProviderResponse : isAPIResponseNotNull" + isAPIResponseNotNull );
        LOGGER.debug( "validateProviderAPIProviderResponse : END" );
        return false;
    }
}
