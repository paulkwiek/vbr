package com.hcsc.vbr.arrangementconfigservice.validator.paymentarrangement;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.ObjectUtils;

import com.hcsc.vbr.arrangementconfigservice.constant.ArrangementConfigServiceErrorMessageConstant;
import com.hcsc.vbr.arrangementconfigservice.constant.ComponentIdConstant;
import com.hcsc.vbr.arrangementconfigservice.constant.FieldIdConstant;
import com.hcsc.vbr.arrangementconfigservice.domain.PaymentArrangement;
import com.hcsc.vbr.arrangementconfigservice.domain.PaymentArrangementPayee;
import com.hcsc.vbr.arrangementconfigservice.domain.VbrPayee;
import com.hcsc.vbr.arrangementconfigservice.validator.base.BaseValidationUnit;
import com.hcsc.vbr.common.domain.DateRecord;
import com.hcsc.vbr.common.dto.ErrorMessageDTO;
import com.hcsc.vbr.common.dto.ReturnMessageDTO;
import com.hcsc.vbr.common.utils.VBRDateUtils;

@Component
public class PMAM006CheckArrangementPayeeVBRPayeeProviderDates extends BaseValidationUnit
{
    final Logger LOGGER = LoggerFactory.getLogger( PMAM006CheckArrangementPayeeVBRPayeeProviderDates.class );

    @Autowired
    private PMAM043CheckArrangementPayeeProviderAPIValidation pmam043CheckArrangementPayeeProviderAPIValidation;

    /**
     * Method: validateArrangementPayeeVBRPayeeDates
     * @param paymentArrangementRequest
     * @param processingMonth
     * @param errors
     * @return
     * @throws Exception
     */
    public boolean validateArrangementPayeeVBRPayeeDates( PaymentArrangement paymentArrangementRequest,
            LocalDate processingMonth,
            ReturnMessageDTO returnMessage ) throws Exception
    {
        LOGGER.debug( "validateArrangementPayeeVBRPayeeDates : START" );

        boolean isArrangementPayeeDateListInvalid = false;

        LocalDate arrangementEffectiveDate = paymentArrangementRequest.getRecordEffectiveDate();
        LocalDate lastDateOfProcessingMonth = VBRDateUtils.getLastDayOfMonth( processingMonth );

        List<VbrPayee> vbrPayeeList = new ArrayList<VbrPayee>();
        List<PaymentArrangementPayee> paymentArrangementPayees = paymentArrangementRequest.getPaymentArrangementPayees();

        for( PaymentArrangementPayee payee : paymentArrangementPayees )
        {

            if( ObjectUtils.isEmpty( payee.getVbrPayeeId() ) )
            {

                vbrPayeeList.add( payee.getVbrPayee() );

            }

        }

        validateArrangementPayeeWithVBRPayeeDates( vbrPayeeList,
                                                   returnMessage );

        if( CollectionUtils.isNotEmpty( returnMessage.getErrors() ) )
        {
            isArrangementPayeeDateListInvalid = true;
            //If there are errors other than VBR Payee Record empty and Arrangement Duration is empty Future Warning message for Premier Provider wil be shown
            if( arrangementEffectiveDate.isAfter( lastDateOfProcessingMonth )
                && checkPayeeProviderAPIErrorCount( returnMessage ) != 1 )
            {

                returnMessage.getErrors().clear();

                addToReturnMessage( ArrangementConfigServiceErrorMessageConstant.VBRPAYEE_DATE_PREMIER_PROVIDER_VALIDATION_FUTURE,
                                    FieldIdConstant.VBPY_EFF_AND_END_DATE,
                                    ComponentIdConstant.PMAM,
                                    this.getClass().getSimpleName(),
                                    returnMessage );

            }

        }
        LOGGER.debug( "ArrangementPayee Dates not With in VBRPayee Provider Dates : " + isArrangementPayeeDateListInvalid );
        LOGGER.debug( "validateArrangementPayeeVBRPayeeDates : END" );
        return isArrangementPayeeDateListInvalid;
    }

    /**
     * validate dates
     * @param vbrDTOList
     * @return
     * @throws Exception
     */
    private boolean validateArrangementPayeeWithVBRPayeeDates( List<VbrPayee> vbrPayeeList,
            ReturnMessageDTO returnMessage ) throws Exception
    {
        LOGGER.debug( "validateArrangementPayeeWithVBRPayeeDates : START" );

        boolean isArrangementPayeeDateListInvalid = false;

        if( CollectionUtils.isNotEmpty( vbrPayeeList ) )
        {
            for( VbrPayee vbrPayee : vbrPayeeList )
            {
                DateRecord dateRecord = new DateRecord();
                dateRecord.setRecordEffectiveDate( vbrPayee.getRecordEffectiveDate() );
                dateRecord.setRecordEndDate( vbrPayee.getRecordEndDate() );

                pmam043CheckArrangementPayeeProviderAPIValidation.validationArrangementPayeeProviderAPI( vbrPayee,
                                                                                                         returnMessage );

            }
        }

        if( CollectionUtils.isNotEmpty( returnMessage.getErrors() ) )
        {
            isArrangementPayeeDateListInvalid = true;
        }
        LOGGER.debug( "validateArrangementPayeeWithVBRPayeeDates ArrangementPayee Dates not With in VBRPayee Provider Dates : "
            + isArrangementPayeeDateListInvalid );
        LOGGER.debug( "validateArrangementPayeeWithVBRPayeeDates : END" );
        return isArrangementPayeeDateListInvalid;

    }

    /**
     * Method: checkPayeeProviderAPIErrorCount
     * @param errors
     * @return
     * @throws Exception
     */
    public Integer checkPayeeProviderAPIErrorCount( ReturnMessageDTO errors ) throws Exception
    {
        LOGGER.debug( "checkPayeeProviderAPIErrorCount : START" );

        Integer count = 0;

        for( ErrorMessageDTO error : errors.getErrors() )
        {

            if( StringUtils.equalsIgnoreCase( error.getErrorMessageId().toString(),
                                              ArrangementConfigServiceErrorMessageConstant.NO_RECORDS_FOUND_PROVIDERS.toString() ) )
            {

                count++;

            }

        }

        LOGGER.debug( "checkPayeeProviderAPIErrorCount : END" );
        return count;
    }

}