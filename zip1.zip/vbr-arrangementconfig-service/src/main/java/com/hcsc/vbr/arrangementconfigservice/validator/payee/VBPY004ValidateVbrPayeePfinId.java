package com.hcsc.vbr.arrangementconfigservice.validator.payee;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.hcsc.vbr.arrangementconfigservice.constant.ArrangementConfigServiceErrorMessageConstant;
import com.hcsc.vbr.arrangementconfigservice.constant.ComponentIdConstant;
import com.hcsc.vbr.arrangementconfigservice.constant.FieldIdConstant;
import com.hcsc.vbr.arrangementconfigservice.domain.VbrPayee;
import com.hcsc.vbr.arrangementconfigservice.validator.base.BaseValidationUnit;
import com.hcsc.vbr.common.dto.ReturnMessageDTO;

@Component
public class VBPY004ValidateVbrPayeePfinId extends BaseValidationUnit
{
    private static final Logger LOGGER = LoggerFactory.getLogger( VBPY004ValidateVbrPayeePfinId.class );

    /**
     * @param vbrPayee
     * @param returnMessage
     * @return
     * @throws Exception
     */
    public boolean validateVbrPayeePfinIdFieldLength( VbrPayee vbrPayee,
            ReturnMessageDTO returnMessage ) throws Exception
    {
        LOGGER.debug( "VBPY004ValidateVbrPayeePfinId : Start" );
        boolean isPayToPfinIdValid = true;

        String payToPfinId = vbrPayee.getPayToPfinId();
        if( ( StringUtils.isNotBlank( payToPfinId ) )
            && ( ( !StringUtils.isAlphanumeric( payToPfinId ) ) || ( payToPfinId.length() > 10 ) ) )
        {
            isPayToPfinIdValid = false;
            addToReturnMessage( ArrangementConfigServiceErrorMessageConstant.PFIN_ID_VALIDATION,
                                FieldIdConstant.VBPY_PFIN_ID,
                                ComponentIdConstant.VBPY,
                                this.getClass().getSimpleName(),
                                returnMessage );
        }

        LOGGER.debug( "VBPY004ValidateVbrPayeePfinId : END" );
        return isPayToPfinIdValid;
    }
}
