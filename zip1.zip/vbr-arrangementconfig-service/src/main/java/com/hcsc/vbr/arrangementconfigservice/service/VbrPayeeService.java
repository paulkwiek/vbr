package com.hcsc.vbr.arrangementconfigservice.service;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.ObjectUtils;

import com.hcsc.vbr.arrangementconfigservice.constant.ArrangementConfigServiceConstant;
import com.hcsc.vbr.arrangementconfigservice.constant.ComponentIdConstant;
import com.hcsc.vbr.arrangementconfigservice.domain.VbrPayee;
import com.hcsc.vbr.arrangementconfigservice.dto.VbrPayeeDTO;
import com.hcsc.vbr.arrangementconfigservice.mapper.VbrPayeeMapper;
import com.hcsc.vbr.arrangementconfigservice.repository.VbrPayeeRepository;
import com.hcsc.vbr.arrangementconfigservice.service.base.BaseService;
import com.hcsc.vbr.arrangementconfigservice.utils.ArrangementConfigServiceUtils;
import com.hcsc.vbr.arrangementconfigservice.utils.VbrPayeeUtils;
import com.hcsc.vbr.arrangementconfigservice.validator.payee.PayeeValidator;
import com.hcsc.vbr.common.apiclient.ProviderServiceApiClient;
import com.hcsc.vbr.common.dto.PayToPFINPayeeAddressDTO;
import com.hcsc.vbr.common.dto.PayeeAddressDTO;
import com.hcsc.vbr.common.dto.ReturnMessageDTO;
import com.hcsc.vbr.common.mapper.ProviderMapper;
import com.hcsc.vbr.common.utils.ProviderUtils;
import com.hcsc.vbr.web.request.PayeeSearchRequest;
import com.hcsc.vbr.web.request.ProviderAPIRequest;
import com.hcsc.vbr.web.request.ProviderApiRetrievePinGrpRequest;
import com.hcsc.vbr.web.response.PayeeRetrieveResponse;
import com.hcsc.vbr.web.response.PayeeSearchResponse;
import com.hcsc.vbr.web.response.ProviderAPIResponse;
import com.hcsc.vbr.web.response.ProviderAPIResponseDTO;
import com.hcsc.vbr.web.response.ProviderAPISearchResponseDTO;
import com.hcsc.vbr.web.response.ProviderApiAddressDTO;
import com.hcsc.vbr.web.response.ProviderApiAddressesResponse;
import com.hcsc.vbr.web.response.ProviderApiDemographicsResponse;
import com.hcsc.vbr.web.response.ProviderApiTaxIdResponse;
import com.hcsc.vbr.web.response.VbrPayeeResponse;

@Service
public class VbrPayeeService extends BaseService
{

    private static final Logger LOGGER = LoggerFactory.getLogger( VbrPayeeService.class );

    private static final String DEFAULT_END_DATE = "2999-12-31";
    private static final String PROVIDER_OPEN_END_DATE = "12/31/9999";

    @Autowired
    private ProviderServiceApiClient providerServiceApiClient;

    @Autowired
    private VbrPayeeRepository vbrPayeeRepo;

    @Autowired
    private VbrPayeeMapper vbrPayeeMapper;

    @Autowired
    private PayeeValidator payeeValidator;

    @Autowired
    private ProviderMapper providerMapper;

    @Autowired
    private VbrPayeeUtils vbrPayeeUtils;

    /**
     * Save or update vbr payee.
     *
     * @param payeeDto the payee dto
     * @return the vbr payee
     * @throws Exception the exception
     */
    @Transactional( propagation = Propagation.REQUIRED )
    public VbrPayeeResponse saveVbrPayee( VbrPayeeDTO payeeDto ) throws Exception
    {

        LOGGER.debug( "saveVbrPayee : START" );

        /**
         * Null check for Provider End dates
         * if End dates are null setting those with open end Dates
         * 
        **/
        payeeDto = checkProviderEndDates( payeeDto );

        //get Payee from PayeeDTO 
        VbrPayee vbrPayee = vbrPayeeMapper.toVbrPayee( payeeDto );
        VbrPayeeResponse vbrPayeeResponse = new VbrPayeeResponse();

        payeeDto.setPinGroupId( StringUtils.upperCase( payeeDto.getPinGroupId() ) );

        ReturnMessageDTO returnMessage = new ReturnMessageDTO( ComponentIdConstant.VBPY );

        payeeValidator.validateSavePayee( vbrPayee,
                                          returnMessage );

        vbrPayee.setPinGroupId( StringUtils.trim( vbrPayee.getPinGroupId() ) );
        vbrPayee = vbrPayeeUtils.getProviderApiAddressAndDemographicsResponse( vbrPayee );

        vbrPayeeRepo.saveVbrPaye( vbrPayee );
        if( StringUtils.equalsIgnoreCase( payeeDto.getRowAction().name(),
                                          "UPDATE" ) )
        {
            payeeValidator.validateStatusOfLinkedArrangementsInUpdatePayee( vbrPayee,
                                                                            returnMessage );
            vbrPayeeResponse.setMessage( StringUtils.join( "Payee: ",
                                                           vbrPayee.getPayToPfinId(),
                                                           " ",
                                                           ArrangementConfigServiceConstant.VBR_PAYEE_UPDATE_MESSAGE ) );
        }
        else
        {
            vbrPayeeResponse.setMessage( StringUtils.join( "Payee: ",
                                                           vbrPayee.getPayToPfinId(),
                                                           " ",
                                                           ArrangementConfigServiceConstant.VBR_PAYEE_SAVE_MESSAGE ) );
        }

        VbrPayeeDTO vbrPayeeDTO = vbrPayeeMapper.toVbrPayeeDTO( vbrPayee );
        vbrPayeeResponse.setPayee( vbrPayeeDTO );
        vbrPayeeResponse.setReturnMessage( returnMessage );

        LOGGER.debug( "saveVbrPayee : END" );
        return vbrPayeeResponse;
    }

    /**
     * Find by corp id and pin group id.
     *
     * @param payeeSearchRequest the payee search request
     * @return the list
     * @throws Exception the exception
     */
    public PayeeSearchResponse searchPayee( PayeeSearchRequest payeeSearchRequest ) throws Exception
    {

        LOGGER.debug( "searchPayee : START" );
        String corporateEntityCode = payeeSearchRequest.getCorpEntityCode();
        String pinGroupId = payeeSearchRequest.getPinGroupId();

        List<VbrPayeeDTO> list = new ArrayList<VbrPayeeDTO>();
        List<VbrPayee> dbList = new ArrayList<VbrPayee>();

        ReturnMessageDTO returnMessage = new ReturnMessageDTO( ComponentIdConstant.VBPY );

        //Checking for pingroupId validations
        payeeValidator.validateSearchPayee( payeeSearchRequest,
                                            returnMessage );

        if( StringUtils.isNotBlank( pinGroupId ) )
        {
            dbList = vbrPayeeRepo.findByCorpIdAndPinGroupId( corporateEntityCode,
                                                             pinGroupId );
        }
        else
        {
            dbList = vbrPayeeRepo.findByCorpId( corporateEntityCode );
        }

        for( VbrPayee payee : dbList )
        {
            payee.setPinGroupId( StringUtils.trim( payee.getPinGroupId() ) );
            VbrPayeeDTO vbrPayeeDTO = vbrPayeeMapper.toVbrPayeeDTO( payee );
            vbrPayeeDTO.setPayToPFINName( vbrPayeeUtils.mapPayToPfinName( payee ) );
            list.add( vbrPayeeDTO );

        }

        //Checking for no records found
        if( CollectionUtils.isEmpty( dbList ) )
        {
            payeeValidator.validateGetPayees( dbList,
                                              returnMessage );
        }

        PayeeSearchResponse searchPayeeResponse = new PayeeSearchResponse();
        searchPayeeResponse.setPayees( list );

        LOGGER.debug( "searchPayee : END" );
        return searchPayeeResponse;
    }

    /**
     * Retrieve payees.
     *
     * @param searchRequest the search request
     * @return the provider API response
     * @throws Exception the exception
     */
    @Transactional( propagation = Propagation.REQUIRED )
    public PayeeRetrieveResponse retrievePayee( PayeeSearchRequest searchRequest ) throws Exception
    {
        LOGGER.debug( "retrievePayee : START" );
        PayeeRetrieveResponse searchPayeeResponse = new PayeeRetrieveResponse();
        List<ProviderAPISearchResponseDTO> capitationPinGroupResponse = null;
        ProviderAPIResponseDTO aResponseDTO = new ProviderAPIResponseDTO();
        ProviderApiRetrievePinGrpRequest providerAPIRequest = new ProviderApiRetrievePinGrpRequest();
        providerAPIRequest.setCorpEntityCode( searchRequest.getCorpEntityCode() );
        providerAPIRequest.setPinGroupID( searchRequest.getPinGroupId() );

        List<PayeeSearchRequest> searchRequestList = new ArrayList<PayeeSearchRequest>();
        searchRequestList.add( searchRequest );
        ReturnMessageDTO returnMessage = new ReturnMessageDTO( ComponentIdConstant.VBPY );
        payeeValidator.validateRetrievePayee( searchRequest,
                                              returnMessage );

        capitationPinGroupResponse = providerServiceApiClient.getPinGroupProviders( providerAPIRequest );

        if( ObjectUtils.isEmpty( capitationPinGroupResponse ) )
        {

            payeeValidator.validateGetPayeesMatchingFromProviderApi( capitationPinGroupResponse,
                                                                     returnMessage );
        }

        VbrPayeeDTO payeeDTO = vbrPayeeMapper.toVbrPayeeDTO( searchRequest );
        List<ProviderAPIResponseDTO> prAPIResponseDTOs = providerMapper.toProviderAPIResponseDTOs( capitationPinGroupResponse );
        aResponseDTO = ArrangementConfigServiceUtils.getMatchingProviderFromAPI( payeeDTO,
                                                                                 prAPIResponseDTOs );

        //call the tax endpoint and retrieve tax details
        List<ProviderApiTaxIdResponse> taxIdByPfinResponse = providerServiceApiClient.getTaxIdsByPfin( aResponseDTO.getPayToPFINId() );

        for( ProviderApiTaxIdResponse aTaxIdResponse : taxIdByPfinResponse )
        {
            aResponseDTO.setTaxId( aTaxIdResponse.getTaxId() );
            aResponseDTO.setTinEffectiveDate( aTaxIdResponse.getTaxIdEffectiveDate() );
            aResponseDTO.setTinEndDate( StringUtils.isBlank( aTaxIdResponse.getTaxIdEndDate() ) ? DEFAULT_END_DATE
                : aTaxIdResponse.getTaxIdEndDate() );
        }

        // Call the addresses endpoint and retrieve billing address to map to response
        ProviderApiAddressesResponse addressessByPfinResponse =
            providerServiceApiClient.getAddressesByPfin( aResponseDTO.getPayToPFINId() );

        ProviderApiAddressDTO aPayeeAddress = addressessByPfinResponse.getBillingAddress().getAddress();
        PayeeAddressDTO aPayeeAddressDTO = providerMapper.toPayeeAddressDTO( aPayeeAddress );
        aResponseDTO.setPayeeAddress( aPayeeAddressDTO );
        PayToPFINPayeeAddressDTO payToPfinPayeeAddressDTO = providerMapper.toPayToPFINPayeeAddressDTO( aPayeeAddress );
        aResponseDTO.setPayToPFINPayeeAddress( payToPfinPayeeAddressDTO );

        // Call the demographics endpoint and assign billing name
        ProviderApiDemographicsResponse demographicsByPfinResponse =
            providerServiceApiClient.getDemographicsByPfin( aResponseDTO.getPayToPFINId() );

        aResponseDTO.setPayToPFINName( ProviderUtils.mapBillingName( demographicsByPfinResponse ) );
        aResponseDTO.setPingroupID( searchRequest.getPinGroupId() );
        aResponseDTO.setCorpEntityCode( searchRequest.getCorpEntityCode() );

        searchPayeeResponse.setVbrPayee( updateDateFormat( vbrPayeeMapper.toVbrPayeeDTO( aResponseDTO ) ) );

        LOGGER.debug( "retrievePayee : END" );
        return searchPayeeResponse;
    }

    /**
     * @param searchRequestList
     * @return
     * @throws Exception
     */
    @Transactional( propagation = Propagation.REQUIRED )
    public List<VbrPayeeDTO> retrievePayees( List<PayeeSearchRequest> searchRequestList ) throws Exception
    {

        LOGGER.debug( "Entering VbrPayeeService::retrievePayees() : START" );
        List<VbrPayeeDTO> listOfPayees = new ArrayList<VbrPayeeDTO>();
        ReturnMessageDTO returnMessage = new ReturnMessageDTO( ComponentIdConstant.VBPY );
        for( PayeeSearchRequest searchRequest : searchRequestList )
        {
            payeeValidator.validateRetrievePayee( searchRequest,
                                                  returnMessage );
        }

        ProviderAPIRequest providerAPIRequest = createProviderAPIRequest( searchRequestList );

        ProviderAPIResponse providerAPIResponse = providerServiceApiClient.getProviders( providerAPIRequest );

        if( ( providerAPIResponse == null ) || ( CollectionUtils.isEmpty( providerAPIResponse.getProviders() ) ) )
        {
            payeeValidator.validateGetPayeesFromProviderApi( providerAPIResponse.getProviders(),
                                                             returnMessage );

        }
        else
        {
            LOGGER.debug( "VbrPayeeService::retrievePayees() : END" );
            providerAPIResponse.getProviders()
                    .forEach( source -> listOfPayees.add( updateDateFormat( vbrPayeeMapper.toVbrPayeeDTO( source ) ) ) );

        }
        return listOfPayees;
    }

    /**
     * validates Unique Payee
     * @param payeeRequest
     * @throws Exception
     */
    public void validateUniquePayee( VbrPayeeDTO payeeRequest ) throws Exception
    {
        LOGGER.debug( "validateUniquePayee : START" );

        VbrPayee vbrPayee = vbrPayeeMapper.toVbrPayee( payeeRequest );
        ReturnMessageDTO returnMessage = new ReturnMessageDTO( ComponentIdConstant.VBPY );
        payeeValidator.validateUniquePayee( vbrPayee,
                                            returnMessage );

        LOGGER.debug( "validateUniquePayee : END" );

    }

    /**
     * null check for provider end dates 
     * if end dates are null then setting them to open end dates
     * 
     * @param payeeDTO
     * @return
     */
    private VbrPayeeDTO checkProviderEndDates( VbrPayeeDTO payeeDTO )
    {

        payeeDTO.setNetworkAssociationEndDate( StringUtils.isBlank( payeeDTO.getNetworkAssociationEndDate() ) ? PROVIDER_OPEN_END_DATE
            : payeeDTO.getNetworkAssociationEndDate() );

        payeeDTO.setPfinEndDate( StringUtils.isBlank( payeeDTO.getPfinEndDate() ) ? PROVIDER_OPEN_END_DATE
            : payeeDTO.getPfinEndDate() );

        payeeDTO.setPinGroupEndDate( StringUtils.isBlank( payeeDTO.getPinGroupEndDate() ) ? PROVIDER_OPEN_END_DATE
            : payeeDTO.getPinGroupEndDate() );

        payeeDTO.setTinEndDate( StringUtils.isBlank( payeeDTO.getTinEndDate() ) ? PROVIDER_OPEN_END_DATE
            : payeeDTO.getTinEndDate() );

        return payeeDTO;
    }

}
