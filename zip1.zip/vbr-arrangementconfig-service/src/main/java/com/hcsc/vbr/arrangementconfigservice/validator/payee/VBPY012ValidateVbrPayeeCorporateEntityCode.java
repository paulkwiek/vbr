package com.hcsc.vbr.arrangementconfigservice.validator.payee;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.hcsc.vbr.arrangementconfigservice.constant.ArrangementConfigServiceErrorMessageConstant;
import com.hcsc.vbr.arrangementconfigservice.constant.ComponentIdConstant;
import com.hcsc.vbr.arrangementconfigservice.constant.FieldIdConstant;
import com.hcsc.vbr.arrangementconfigservice.domain.VbrPayee;
import com.hcsc.vbr.arrangementconfigservice.validator.base.BaseValidationUnit;
import com.hcsc.vbr.common.dto.ReturnMessageDTO;

@Component
public class VBPY012ValidateVbrPayeeCorporateEntityCode extends BaseValidationUnit
{
    private static final Logger LOGGER = LoggerFactory.getLogger( VBPY012ValidateVbrPayeeCorporateEntityCode.class );

    /**
     * @param vbrPayee
     * @param returnMessage
     * @return
     * @throws Exception
     */
    public boolean validateVbrPayeeCorporateEntityCodeFieldLength( VbrPayee vbrPayee,
            ReturnMessageDTO returnMessage ) throws Exception
    {
        LOGGER.debug( "VBPY012ValidateVbrPayeeCorporateEntityCode : Start" );
        boolean isCorporateEntityCodeValid = true;

        String corporateEntityCode = vbrPayee.getCorporateEntityCode();
        if( ( StringUtils.isNotBlank( corporateEntityCode ) )
            && ( ( !StringUtils.isAlphanumeric( corporateEntityCode ) ) || ( corporateEntityCode.length() > 20 ) ) )
        {
            isCorporateEntityCodeValid = false;
            addToReturnMessage( ArrangementConfigServiceErrorMessageConstant.INVALID_CORPORATE_ENTITY,
                                FieldIdConstant.VBPY_CORPORATE_ENTITY_CODE,
                                ComponentIdConstant.VBPY,
                                this.getClass().getSimpleName(),
                                returnMessage );
        }

        LOGGER.debug( "VBPY012ValidateVbrPayeeCorporateEntityCode : END" );
        return isCorporateEntityCodeValid;
    }
}
