package com.hcsc.vbr.arrangementconfigservice.validator.paymentarrangement;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.collections4.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.hcsc.vbr.arrangementconfigservice.constant.ArrangementConfigServiceErrorMessageConstant;
import com.hcsc.vbr.arrangementconfigservice.constant.ComponentIdConstant;
import com.hcsc.vbr.arrangementconfigservice.constant.FieldIdConstant;
import com.hcsc.vbr.arrangementconfigservice.domain.VbrPayee;
import com.hcsc.vbr.arrangementconfigservice.validator.base.BaseValidationUnit;
import com.hcsc.vbr.common.domain.DateRecord;
import com.hcsc.vbr.common.dto.ReturnMessageDTO;
import com.hcsc.vbr.common.utils.VBRDateUtils;

@Component
public class PMAM043CheckArrangementPayeeProviderAPIValidation extends BaseValidationUnit
{

    private static final Logger LOGGER = LoggerFactory.getLogger( PMAM043CheckArrangementPayeeProviderAPIValidation.class );

    /**
     * Method: validationArrangementPayeeProviderAPI
     * @param vbrPayee
     * @param errors
     * @return
     * @throws Exception
     */
    public boolean validationArrangementPayeeProviderAPI( VbrPayee vbrPayee,
            ReturnMessageDTO returnMessage ) throws Exception
    {
        LOGGER.debug( "validationArrangementPayeeProviderAPI : START" );

        boolean isArrangementPayeeDateListInvalid = true;

        // vbrPayeeDateRecord is the Child Record for below validation
        DateRecord vbrPayeeDateRecord = createVbrPayeeDateRecord( vbrPayee.getRecordEffectiveDate(),
                                                                  vbrPayee.getRecordEndDate() );

        // Individual validation will be done below for pinGroupRecord netAssocRecord pfinRecord tinRecord
        List<DateRecord> pinGroupRecord = new ArrayList<DateRecord>();
        List<DateRecord> netAssocRecord = new ArrayList<DateRecord>();
        List<DateRecord> pfinRecord = new ArrayList<DateRecord>();
        List<DateRecord> tinRecord = new ArrayList<DateRecord>();

        pinGroupRecord.add( createDateRecord( vbrPayee.getPinGroupEffectiveDate(),
                                              vbrPayee.getPinGroupEndDate() ) );

        netAssocRecord.add( createDateRecord( vbrPayee.getNetworkAssociationEffectiveDate(),
                                              vbrPayee.getNetworkAssociationEndDate() ) );

        pfinRecord.add( createDateRecord( vbrPayee.getPfinEffectiveDate(),
                                          vbrPayee.getPfinEndDate() ) );

        tinRecord.add( createDateRecord( vbrPayee.getTinEffectiveDate(),
                                         vbrPayee.getTinEndDate() ) );

        addDateRangeValidations( returnMessage,
                                 pinGroupRecord,
                                 vbrPayeeDateRecord,
                                 ArrangementConfigServiceErrorMessageConstant.PIN_GROUP_DATE_RANGE_VALIDATION );

        addDateRangeValidations( returnMessage,
                                 netAssocRecord,
                                 vbrPayeeDateRecord,
                                 ArrangementConfigServiceErrorMessageConstant.NET_ASSOC_DATE_RANGE_VALIDATION );

        addDateRangeValidations( returnMessage,
                                 pfinRecord,
                                 vbrPayeeDateRecord,
                                 ArrangementConfigServiceErrorMessageConstant.PFIN_DATE_RANGE_VALIDATION );

        addDateRangeValidations( returnMessage,
                                 tinRecord,
                                 vbrPayeeDateRecord,
                                 ArrangementConfigServiceErrorMessageConstant.TIN_DATE_RANGE_VALIDATION );

        if( CollectionUtils.isNotEmpty( returnMessage.getErrors() ) )
        {
            isArrangementPayeeDateListInvalid = true;
        }
        LOGGER.debug( "validationArrangementPayeeProviderAPI ArrangementPayee Dates not With in VBRPayee Provider Dates :"
            + isArrangementPayeeDateListInvalid );
        LOGGER.debug( "validationArrangementPayeeProviderAPI : END" );
        return isArrangementPayeeDateListInvalid;

    }

    /**
     * Method: createDateRecord
     * @param recordEffectiveDate
     * @param recordEndDate
     * @return
     */
    private DateRecord createDateRecord( String recordEffectiveDate,
            String recordEndDate )
    {
        LOGGER.debug( "createDateRecord : START" );

        DateRecord dateRecord = new DateRecord();
        dateRecord.setRecordEffectiveDate( VBRDateUtils.convertStringToLocalDateDefaultFormat( recordEffectiveDate ) );
        dateRecord.setRecordEndDate( VBRDateUtils.convertStringToLocalDateDefaultFormat( recordEndDate ) );

        LOGGER.debug( "createDateRecord : END" );

        return dateRecord;
    }

    /**
     * Method: createVbrPayeeDateRecord
     * @param recordEffectiveDate
     * @param recordEndDate
     * @return
     */
    private DateRecord createVbrPayeeDateRecord( LocalDate recordEffectiveDate,
            LocalDate recordEndDate )
    {
        LOGGER.debug( "createVbrPayeeDateRecord : START" );

        DateRecord dateRecord = new DateRecord();
        dateRecord.setRecordEffectiveDate( recordEffectiveDate );
        dateRecord.setRecordEndDate( recordEndDate );

        LOGGER.debug( "createVbrPayeeDateRecord : END" );

        return dateRecord;
    }

    /**
     * Method: addDateRangeValidations
     * @param errors
     * @param parentList
     * @param child
     * @param errorMessageId
     * @throws Exception
     */
    private void addDateRangeValidations( ReturnMessageDTO returnMessage,
            List<DateRecord> parentRecord,
            DateRecord childRecord,
            Long errorMessageId ) throws Exception
    {
        LOGGER.debug( "addDateRangeValidations : START" );

        if( ( CollectionUtils.isNotEmpty( parentRecord ) ) && ( !VBRDateUtils.checkDateCoverage( parentRecord,
                                                                                                 childRecord ) ) )
        {
            addToReturnMessage( errorMessageId,
                                FieldIdConstant.VBPY_EFF_AND_END_DATE,
                                ComponentIdConstant.PMAM,
                                this.getClass().getSimpleName(),
                                returnMessage );

        }

        LOGGER.debug( "addDateRangeValidations : END" );

    }

}
