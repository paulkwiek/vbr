package com.hcsc.vbr.arrangementconfigservice.validator.paymentarrangement;

import java.time.LocalDate;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.hcsc.vbr.arrangementconfigservice.constant.ArrangementConfigServiceErrorMessageConstant;
import com.hcsc.vbr.arrangementconfigservice.constant.ComponentIdConstant;
import com.hcsc.vbr.arrangementconfigservice.constant.FieldIdConstant;
import com.hcsc.vbr.arrangementconfigservice.domain.FlatRate;
import com.hcsc.vbr.arrangementconfigservice.domain.PaymentArrangement;
import com.hcsc.vbr.arrangementconfigservice.domain.PaymentArrangementRate;
import com.hcsc.vbr.arrangementconfigservice.validator.base.BaseValidationUnit;
import com.hcsc.vbr.common.domain.DateRecord;
import com.hcsc.vbr.common.dto.ReturnMessageDTO;
import com.hcsc.vbr.common.utils.VBRDateUtils;

@Component
public class PMAM016CheckArrangementRateDurationWithFlatRates extends BaseValidationUnit
{

    final Logger LOGGER = LoggerFactory.getLogger( PMAM016CheckArrangementRateDurationWithFlatRates.class );

    /**
     * Method: validateArrangementRateDurationWithFlatRates
     * @param flatRatesParent
     * @param arrangementRatechild
     * @param arrangementDate
     * @param processingMonth
     * @param returnMessage
     * @return
     * @throws Exception
     */
    public boolean validateArrangementRateDurationWithFlatRates( List<FlatRate> flatRatesParent,
            PaymentArrangementRate arrangementRatechild,
            PaymentArrangement arrangementDate,
            LocalDate processingMonth,
            ReturnMessageDTO returnMessage ) throws Exception
    {
        LOGGER.debug( "validateArrangementRateDurationWithFlatRates : START" );

        boolean isDateValid = false;
        LocalDate lastDateOfProcessingMonth = VBRDateUtils.getLastDayOfMonth( processingMonth );
        DateRecord parentFlatRateDateRecord = VBRDateUtils.convertDateRecordListToDateRecordRange( flatRatesParent );

        if( !VBRDateUtils.checkDateCoverage( parentFlatRateDateRecord,
                                             arrangementRatechild ) )
        {

            if( arrangementDate.getRecordEffectiveDate().isAfter( lastDateOfProcessingMonth ) )
            {
                addToReturnMessage( ArrangementConfigServiceErrorMessageConstant.GLOBAL_RATE_AND_ARRANGEMENT_RATE_DATES_VALIDATION_FUTURE_ARRANGEMENT,
                                    FieldIdConstant.PMAR_EFF_AND_END_DATE,
                                    ComponentIdConstant.PMAM,
                                    this.getClass().getSimpleName(),
                                    returnMessage );
                isDateValid = true;
            }
            else
            {
                addToReturnMessage( ArrangementConfigServiceErrorMessageConstant.GLOBAL_RATE_AND_ARRANGEMENT_RATE_DATES_VALIDATION,
                                    FieldIdConstant.PMAR_EFF_AND_END_DATE,
                                    ComponentIdConstant.PMAM,
                                    this.getClass().getSimpleName(),
                                    returnMessage );
                isDateValid = true;
            }

        }
        LOGGER.debug( "ArrangementRateDuration Not in WithFlatRates  : " + isDateValid );
        LOGGER.debug( "validateArrangementRateDurationWithFlatRates : START" );
        return isDateValid;
    }

}
