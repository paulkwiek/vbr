package com.hcsc.vbr.arrangementconfigservice.validator.ratename;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnitRunner;

import com.hcsc.vbr.arrangementconfigservice.domain.FlatRate;
import com.hcsc.vbr.arrangementconfigservice.domain.RateName;
import com.hcsc.vbr.arrangementconfigservice.domain.RateNameId;
import com.hcsc.vbr.common.dto.ReturnMessageDTO;

@RunWith( MockitoJUnitRunner.Silent.class )
public class RTNM007CheckRateAmountLessThanOneMillionTest
{

    @InjectMocks
    private RTNM007CheckRateAmountLessThanOneMillion rtnm007CheckRateAmountLessThanOneMillion;

    @Test
    public void isRateAmountLessThanOneMillion() throws Exception
    {

        rtnm007CheckRateAmountLessThanOneMillion.isRateAmountLessThanOneMillion( getRateName(),
                                                                                 getReturnMessageDTO() );

    }

    @Test( expected = NullPointerException.class )
    public void isRateAmountLessThanOneMillion_failure() throws Exception
    {

        rtnm007CheckRateAmountLessThanOneMillion.isRateAmountLessThanOneMillion( getRateName_Failure(),
                                                                                 getReturnMessageDTO() );

    }

    @Test
    public void isRateAmountLessThanOneMillion_Null() throws Exception
    {

        rtnm007CheckRateAmountLessThanOneMillion.isRateAmountLessThanOneMillion( getRateName_Failure1(),
                                                                                 getReturnMessageDTO() );

    }

    private RateName getRateName()
    {

        RateName rtnm = new RateName();
        RateNameId rtnmId = new RateNameId();
        rtnmId.setRateName( "SMOKE25" );
        rtnmId.setCorporateEntityCode( "NM1" );
        rtnm.setRateNameId( rtnmId );
        rtnm.setFlatRates( getflatrateList() );
        return rtnm;
    }

    private List<FlatRate> getflatrateList()
    {
        List<FlatRate> flatRateDTOlist = new ArrayList<FlatRate>();
        FlatRate flatRate = new FlatRate();
        flatRate.setFemaleFlatRateAmount( 456.53 );
        flatRate.setMaleFlatRateAmount( 845.34 );

        flatRateDTOlist.add( flatRate );

        return flatRateDTOlist;
    }

    private RateName getRateName_Failure()
    {

        RateName rtnm = new RateName();
        RateNameId rtnmId = new RateNameId();
        rtnmId.setRateName( "SMOKE25" );
        rtnmId.setCorporateEntityCode( "NM1" );
        rtnm.setRateNameId( rtnmId );
        rtnm.setFlatRates( getflatrateList_Failure() );
        return rtnm;
    }

    private List<FlatRate> getflatrateList_Failure()
    {
        List<FlatRate> flatRateDTOlist = new ArrayList<FlatRate>();
        FlatRate flatRate = new FlatRate();
        flatRate.setFemaleFlatRateAmount( 1000000.0 );
        flatRate.setMaleFlatRateAmount( 1000000.0 );

        flatRateDTOlist.add( flatRate );

        return flatRateDTOlist;
    }

    private RateName getRateName_Failure1()
    {

        RateName rtnm = new RateName();
        RateNameId rtnmId = new RateNameId();
        rtnmId.setRateName( "SMOKE25" );
        rtnmId.setCorporateEntityCode( "NM1" );
        rtnm.setRateNameId( rtnmId );
        rtnm.setFlatRates( getflatrateList_Failure1() );
        return rtnm;
    }

    private List<FlatRate> getflatrateList_Failure1()
    {
        List<FlatRate> flatRateDTOlist = new ArrayList<FlatRate>();
        FlatRate flatRate = new FlatRate();
        flatRate.setFemaleFlatRateAmount( null );
        flatRate.setMaleFlatRateAmount( null );

        FlatRate flatRate1 = new FlatRate();
        flatRate1.setFemaleFlatRateAmount( null );
        flatRate1.setMaleFlatRateAmount( null );
        flatRateDTOlist.add( flatRate );
        flatRateDTOlist.add( flatRate1 );

        return flatRateDTOlist;
    }

    private ReturnMessageDTO getReturnMessageDTO()
    {
        ReturnMessageDTO returnMessage = new ReturnMessageDTO();
        return returnMessage;
    }
}
