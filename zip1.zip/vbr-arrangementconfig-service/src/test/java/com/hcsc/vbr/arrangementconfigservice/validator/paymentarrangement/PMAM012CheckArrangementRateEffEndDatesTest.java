package com.hcsc.vbr.arrangementconfigservice.validator.paymentarrangement;

import static org.junit.Assert.assertEquals;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.json.JacksonTester;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.hcsc.vbr.arrangementconfigservice.domain.PaymentArrangementRate;
import com.hcsc.vbr.arrangementconfigservice.utils.ArrangementConfigServiceUtils;
import com.hcsc.vbr.common.constant.VBRCommonConstant.RowActionTypes;
import com.hcsc.vbr.common.dto.ErrorMessageDTO;
import com.hcsc.vbr.common.dto.ReturnMessageDTO;
import com.hcsc.vbr.common.utils.VBRDateUtils;

public class PMAM012CheckArrangementRateEffEndDatesTest
{
    @InjectMocks
    PMAM012CheckArrangementRateEffEndDates checkArrangementRateEffEndDates;

    @Before
    public void setUp()
    {
        MockitoAnnotations.initMocks( this );
        JacksonTester.initFields( this,
                                  new ObjectMapper() );

    }

    @Test( expected = NullPointerException.class )
    public void validatePaymentArrangementRateEffectiveAndEndDatesList() throws Exception
    {

        assertEquals( !VBRDateUtils.checkEffectiveAndEndDatesList( getPaymentArrangementRates() ),
                      Boolean.FALSE );

        assertEquals( !( 1 == getPaymentArrangementRates().get( 0 ).getRecordEffectiveDate().getDayOfMonth() ),
                      Boolean.TRUE );

        assertEquals( !getPaymentArrangementRates().get( 0 )
                .getRecordEffectiveDate()
                .equals( getPaymentArrangementRates().get( 0 ).getRecordEndDate() )
            && !( ArrangementConfigServiceUtils
                    .getLastDayOfMonth( getPaymentArrangementRates().get( 0 ).getRecordEndDate() ) == getPaymentArrangementRates()
                            .get( 0 ).getRecordEndDate() ),
                      Boolean.FALSE );
        checkArrangementRateEffEndDates.validatePaymentArrangementRateEffectiveAndEndDatesList( getPaymentArrangementRates(),
                                                                                                getReturnMessageDTO() );
    }

    private List<PaymentArrangementRate> getPaymentArrangementRates()
    {
        List<PaymentArrangementRate> paymentArrangementRates = new ArrayList<PaymentArrangementRate>();
        PaymentArrangementRate paymentArrangementRateDTO = new PaymentArrangementRate();
        paymentArrangementRateDTO.setPaymentArrangementRateId( null );
        paymentArrangementRateDTO.setRateName( "RATE07" );
        paymentArrangementRateDTO.setPaymentArrangementId( null );
        paymentArrangementRateDTO.setCorporateEntityCode( "NM1" );
        paymentArrangementRateDTO.setRecordEffectiveDate( LocalDate.now() );
        paymentArrangementRateDTO.setRecordEndDate( LocalDate.now() );
        paymentArrangementRateDTO.setCreateUserId( "U402537" );
        paymentArrangementRateDTO.setUpdateUserId( "U402537" );
        paymentArrangementRateDTO.setRowAction( RowActionTypes.NO_ACTION );
        paymentArrangementRates.add( paymentArrangementRateDTO );

        PaymentArrangementRate paymentArrangementRateDTO1 = new PaymentArrangementRate();
        paymentArrangementRateDTO1.setPaymentArrangementRateId( null );
        paymentArrangementRateDTO1.setRateName( "RATE07" );
        paymentArrangementRateDTO1.setPaymentArrangementId( null );
        paymentArrangementRateDTO1.setCorporateEntityCode( "NM1" );
        paymentArrangementRateDTO1.setRecordEffectiveDate( LocalDate.now() );
        paymentArrangementRateDTO1.setRecordEndDate( LocalDate.now() );
        paymentArrangementRateDTO1.setCreateUserId( "U402537" );
        paymentArrangementRateDTO1.setUpdateUserId( "U402537" );
        paymentArrangementRateDTO1.setRowAction( RowActionTypes.NO_ACTION );
        paymentArrangementRates.add( paymentArrangementRateDTO1 );
        return paymentArrangementRates;
    }

    private List<ErrorMessageDTO> getErrorMessageDTOSuccess() throws Exception
    {
        List<ErrorMessageDTO> errors = new ArrayList<ErrorMessageDTO>();
        ErrorMessageDTO errorMessageDTO = new ErrorMessageDTO();

        errorMessageDTO.setErrorMessageCategoryCode( "PCF-PMAM" );
        errorMessageDTO.setErrorMessageId( new Long( 226 ) );
        errorMessageDTO.setErrorMsgDescriptionText( "Payment Type Is Required" );
        errorMessageDTO.setSeveritylevel( "E" );
        errors.add( errorMessageDTO );
        return errors;

    }

    private ReturnMessageDTO getReturnMessageDTO() throws Exception
    {
        ReturnMessageDTO returnMessage = new ReturnMessageDTO();

        returnMessage.setItemName( "PCF-PMAM" );
        returnMessage.setStatus( "SUCCESS" );
        returnMessage.setErrors( getErrorMessageDTOSuccess() );
        return returnMessage;

    }

}