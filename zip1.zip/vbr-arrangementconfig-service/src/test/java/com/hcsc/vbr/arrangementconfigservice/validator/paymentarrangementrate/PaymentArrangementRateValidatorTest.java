package com.hcsc.vbr.arrangementconfigservice.validator.paymentarrangementrate;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import com.hcsc.vbr.arrangementconfigservice.domain.FlatRate;
import com.hcsc.vbr.arrangementconfigservice.domain.PaymentArrangementRate;
import com.hcsc.vbr.arrangementconfigservice.repository.FlatRateRepository;
import com.hcsc.vbr.common.dto.ReturnMessageDTO;
import com.hcsc.vbr.common.exception.VbrApplicationException;

@RunWith( MockitoJUnitRunner.class )
public class PaymentArrangementRateValidatorTest
{
    @InjectMocks
    private PaymentArrangmentRateValidator PaymentArrangmentRateValidator;

    @Mock
    private FlatRateRepository flatRateRepository;

    @Mock
    private PMRT001CheckArrangementRateEffectiveAndEndDates pmrt001CheckArrangementRateEffectiveAndEndDates;

    @Mock
    private PMRT002CheckCoverageForGlobalRateVsArrangementRate pmrt002CheckCoverageForGlobalRateVsArrangementRate;

    @Mock
    private PMRT003CheckFlatRateListForEmpty pmrt003CheckFlatRateListForEmpty;

    @Test
    public void validatePaymentArrangementRateTest() throws Exception
    {
        when( flatRateRepository.findByRateName( any() ) ).thenReturn( getFlatRates() );
        when( pmrt001CheckArrangementRateEffectiveAndEndDates.validatePaymentArrangementRateEffectiveAndEndDate( any(),
                                                                                                                 any() ) )
                                                                                                                         .thenReturn( Boolean.TRUE );
        when( pmrt002CheckCoverageForGlobalRateVsArrangementRate.CheckCoverageForGlobalRateVsArrangementRate( any(),
                                                                                                              any(),
                                                                                                              any() ) )
                                                                                                                      .thenReturn( Boolean.TRUE );
        when( pmrt003CheckFlatRateListForEmpty.checkFlatRateListForEmpty( any(),
                                                                          any() ) ).thenReturn( Boolean.TRUE );
        PaymentArrangmentRateValidator.validatePaymentArrangementRate( getPaymentArrangementRate(),
                                                                       getReturnMessageDTO() );
    }

    @Test( expected = VbrApplicationException.class )
    public void validatePaymentArrangementRateTest_failure() throws Exception
    {
        when( flatRateRepository.findByRateName( any() ) ).thenReturn( getFlatRates() );
        when( pmrt001CheckArrangementRateEffectiveAndEndDates.validatePaymentArrangementRateEffectiveAndEndDate( any(),
                                                                                                                 any() ) )
                                                                                                                         .thenReturn( Boolean.FALSE );
        when( pmrt002CheckCoverageForGlobalRateVsArrangementRate.CheckCoverageForGlobalRateVsArrangementRate( any(),
                                                                                                              any(),
                                                                                                              any() ) )
                                                                                                                      .thenReturn( Boolean.FALSE );
        when( pmrt003CheckFlatRateListForEmpty.checkFlatRateListForEmpty( any(),
                                                                          any() ) ).thenReturn( Boolean.FALSE );
        PaymentArrangmentRateValidator.validatePaymentArrangementRate( getPaymentArrangementRate(),
                                                                       getReturnMessageDTO() );
    }

    private PaymentArrangementRate getPaymentArrangementRate()
    {
        PaymentArrangementRate paymentArrangementRate = new PaymentArrangementRate();
        paymentArrangementRate.setRateName( "RATE" );
        paymentArrangementRate.setRecordEffectiveDate( LocalDate.now() );
        paymentArrangementRate.setRecordEndDate( LocalDate.now() );
        return paymentArrangementRate;
    }

    private ReturnMessageDTO getReturnMessageDTO()
    {
        ReturnMessageDTO returnMessageDTO = new ReturnMessageDTO();
        return returnMessageDTO;
    }

    private List<FlatRate> getFlatRates()
    {
        List<FlatRate> flatRates = new ArrayList<FlatRate>();
        return flatRates;
    }
}
