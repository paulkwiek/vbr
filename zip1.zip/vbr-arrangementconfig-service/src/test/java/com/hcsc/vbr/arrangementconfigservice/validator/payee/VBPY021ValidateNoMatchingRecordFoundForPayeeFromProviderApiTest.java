package com.hcsc.vbr.arrangementconfigservice.validator.payee;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnitRunner;

import com.hcsc.vbr.common.dto.ReturnMessageDTO;
import com.hcsc.vbr.web.response.ProviderAPISearchResponseDTO;

@RunWith( MockitoJUnitRunner.Silent.class )
public class VBPY021ValidateNoMatchingRecordFoundForPayeeFromProviderApiTest
{
    @InjectMocks
    private VBPY021ValidateNoMatchingRecordFoundForPayeeFromProviderApi vbpy021ValidateNoMatchingRecordFoundForPayeeFromProviderApi;

    @Test
    public void isRecordsFound() throws Exception
    {

        vbpy021ValidateNoMatchingRecordFoundForPayeeFromProviderApi.isRecordsFound( getProviderAPISearchResponseDTO(),
                                                                                    getReturnMessageDTO() );
    }

    @Test( expected = NullPointerException.class )
    public void isRecordsFound_Failure() throws Exception
    {

        vbpy021ValidateNoMatchingRecordFoundForPayeeFromProviderApi.isRecordsFound( getProviderAPISearchResponseDTO_Empty(),
                                                                                    getReturnMessageDTO() );
    }

    List<ProviderAPISearchResponseDTO> getProviderAPISearchResponseDTO()
    {
        List<ProviderAPISearchResponseDTO> providerDTOList = new ArrayList<ProviderAPISearchResponseDTO>();
        ProviderAPISearchResponseDTO providerAPIResponseDTO = new ProviderAPISearchResponseDTO();
        providerAPIResponseDTO.setProcessCode( "CP" );
        providerAPIResponseDTO.setPingroupID( "RE1" );
        providerAPIResponseDTO.setCapitationType( "A1" );
        providerAPIResponseDTO.setPingroupName( "RE1001" );
        providerAPIResponseDTO.setPfinEffectiveDate( "01/01/2019" );
        providerAPIResponseDTO.setPfinEndDate( "12/31/2019" );
        providerDTOList.add( providerAPIResponseDTO );

        return providerDTOList;

    }

    List<ProviderAPISearchResponseDTO> getProviderAPISearchResponseDTO_Empty()
    {

        List<ProviderAPISearchResponseDTO> providerDTOList = new ArrayList<ProviderAPISearchResponseDTO>();

        providerDTOList.removeAll( providerDTOList );
        return providerDTOList;

    }

    private ReturnMessageDTO getReturnMessageDTO()
    {
        ReturnMessageDTO returnMessage = new ReturnMessageDTO();
        return returnMessage;
    }

}
