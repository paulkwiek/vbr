package com.hcsc.vbr.arrangementconfigservice.mapper;

import java.time.LocalDate;
import java.time.Month;
import java.util.ArrayList;
import java.util.List;

import org.assertj.core.api.Assertions;
import org.junit.Test;

import com.hcsc.vbr.arrangementconfigservice.domain.PaymentArrangementPayee;
import com.hcsc.vbr.arrangementconfigservice.domain.VbrPayee;
import com.hcsc.vbr.arrangementconfigservice.dto.PaymentArrangementPayeeDTO;
import com.hcsc.vbr.arrangementconfigservice.dto.VbrPayeeDTO;

public class PaymentArrangementPayeeMapperTest
{

    /*** Domain to DTO mapping test method ***/
    /**
    * Method: testToPaymentArrangementPayeeDTO
    */
    @Test
    public void testToPaymentArrangementPayeeDTO()
    {
        PaymentArrangementPayee paymentArrangementPayee = new PaymentArrangementPayee();
        paymentArrangementPayee.setPaymentArrangementId( 1 );
        VbrPayee vbrPayee = new VbrPayee();
        vbrPayee.setCorporateEntityCode( "NM1" );
        vbrPayee.setVbrPayeeId( 1 );
        paymentArrangementPayee.setVbrPayee( vbrPayee );
        paymentArrangementPayee.setRecordEffectiveDate( LocalDate.of( 2019,
                                                                      Month.OCTOBER,
                                                                      01 ) );
        paymentArrangementPayee.setRecordEndDate( LocalDate.of( 2019,
                                                                Month.OCTOBER,
                                                                01 ) );
        PaymentArrangementPayeeDTO PaymentPayeeDTO =
            PaymentArrangementPayeeMapper.INSTANCE.toPaymentArrangementPayeeDTO( paymentArrangementPayee );

        Assertions.assertThat( PaymentPayeeDTO ).hasFieldOrPropertyWithValue( "paymentArrangementId",
                                                                              1 );
        Assertions.assertThat( PaymentPayeeDTO ).hasFieldOrPropertyWithValue( "vbrPayee.vbrPayeeId",
                                                                              1 );
        Assertions.assertThat( PaymentPayeeDTO ).hasFieldOrPropertyWithValue( "vbrPayee.corporateEntityCode",
                                                                              "NM1" );

    }

    /*** List<Domain> to List<DTO> mapping test method ***/
    /**
    * Method: testToPaymentArrangementPayeeDTOs
    */
    @Test
    public void testToPaymentArrangementPayeeDTOs()
    {
        PaymentArrangementPayee paymentArrangementPayee = new PaymentArrangementPayee();
        paymentArrangementPayee.setPaymentArrangementId( 1 );
        VbrPayee vbrPayee = new VbrPayee();
        vbrPayee.setCorporateEntityCode( "NM1" );
        vbrPayee.setVbrPayeeId( 1 );
        paymentArrangementPayee.setVbrPayee( vbrPayee );
        paymentArrangementPayee.setRecordEffectiveDate( LocalDate.of( 2019,
                                                                      Month.OCTOBER,
                                                                      01 ) );
        paymentArrangementPayee.setRecordEndDate( LocalDate.of( 2019,
                                                                Month.OCTOBER,
                                                                01 ) );
        List<PaymentArrangementPayee> paymentArrangementPayees = new ArrayList<PaymentArrangementPayee>();
        paymentArrangementPayees.add( paymentArrangementPayee );

        List<PaymentArrangementPayeeDTO> paymentArrangementPayeeDTOs =
            PaymentArrangementPayeeMapper.INSTANCE.toPaymentArrangementPayeeDTOs( paymentArrangementPayees );

        for( PaymentArrangementPayeeDTO PaymentPayeeDTO : paymentArrangementPayeeDTOs )
        {
            Assertions.assertThat( PaymentPayeeDTO ).hasFieldOrPropertyWithValue( "paymentArrangementId",
                                                                                  1 );
            Assertions.assertThat( PaymentPayeeDTO ).hasFieldOrPropertyWithValue( "vbrPayee.vbrPayeeId",
                                                                                  1 );
            Assertions.assertThat( PaymentPayeeDTO ).hasFieldOrPropertyWithValue( "vbrPayee.corporateEntityCode",
                                                                                  "NM1" );
        }
    }

    /*** DTO to Domain mapping Test method ***/
    /**
    * Method: testToPaymentArrangementPayee
    */
    @Test
    public void testToPaymentArrangementPayee()
    {
        PaymentArrangementPayeeDTO paymentArrangementPayeeDTO = new PaymentArrangementPayeeDTO();
        paymentArrangementPayeeDTO.setPaymentArrangementId( 1 );
        VbrPayeeDTO vbrPayee = new VbrPayeeDTO();
        vbrPayee.setCorporateEntityCode( "NM1" );
        vbrPayee.setVbrPayeeId( 1 );
        paymentArrangementPayeeDTO.setVbrPayee( vbrPayee );
        paymentArrangementPayeeDTO.setRecordEffectiveDate( "10/01/2019" );
        paymentArrangementPayeeDTO.setRecordEndDate( "10/31/2019" );

        PaymentArrangementPayee paymentArrangementPayee =
            PaymentArrangementPayeeMapper.INSTANCE.toPaymentArrangementPayee( paymentArrangementPayeeDTO );

        Assertions.assertThat( paymentArrangementPayee ).hasFieldOrPropertyWithValue( "paymentArrangementId",
                                                                                      1 );
    }

    /*** List<DTO> to List<Domain> mapping method ***/
    /**
    * Method: testToPaymentArrangementPayees
    */
    @Test
    public void testToPaymentArrangementPayees()
    {
        PaymentArrangementPayeeDTO paymentArrangementPayeeDTO = new PaymentArrangementPayeeDTO();
        paymentArrangementPayeeDTO.setPaymentArrangementId( 1 );
        VbrPayeeDTO vbrPayee = new VbrPayeeDTO();
        vbrPayee.setCorporateEntityCode( "NM1" );
        vbrPayee.setVbrPayeeId( 1 );
        paymentArrangementPayeeDTO.setVbrPayee( vbrPayee );
        paymentArrangementPayeeDTO.setRecordEffectiveDate( "10/01/2019" );
        paymentArrangementPayeeDTO.setRecordEndDate( "10/31/2019" );

        List<PaymentArrangementPayeeDTO> paymentArrangementPayeeDTOs = new ArrayList<PaymentArrangementPayeeDTO>();
        paymentArrangementPayeeDTOs.add( paymentArrangementPayeeDTO );

        List<PaymentArrangementPayee> paymentArrangementPayees =
            PaymentArrangementPayeeMapper.INSTANCE.toPaymentArrangementPayees( paymentArrangementPayeeDTOs );

        for( PaymentArrangementPayee paymentArrangementPayee : paymentArrangementPayees )
        {
            Assertions.assertThat( paymentArrangementPayee ).hasFieldOrPropertyWithValue( "paymentArrangementId",
                                                                                          1 );

            Assertions.assertThat( paymentArrangementPayee ).hasFieldOrPropertyWithValue( "vbrPayee.vbrPayeeId",
                                                                                          1 );
            Assertions.assertThat( paymentArrangementPayee ).hasFieldOrPropertyWithValue( "vbrPayee.corporateEntityCode",
                                                                                          "NM1" );

        }
    }

}
