package com.hcsc.vbr.arrangementconfigservice.service;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import com.hcsc.vbr.arrangementconfigservice.domain.VbrPayee;
import com.hcsc.vbr.arrangementconfigservice.dto.VbrPayeeDTO;
import com.hcsc.vbr.arrangementconfigservice.mapper.VbrPayeeMapper;
import com.hcsc.vbr.arrangementconfigservice.repository.VbrPayeeRepository;
import com.hcsc.vbr.arrangementconfigservice.utils.VbrPayeeUtils;
import com.hcsc.vbr.arrangementconfigservice.validator.payee.PayeeValidator;
import com.hcsc.vbr.common.apiclient.ProviderServiceApiClient;
import com.hcsc.vbr.common.constant.VBRCommonConstant.RowActionTypes;
import com.hcsc.vbr.common.dto.PayeeAddressDTO;
import com.hcsc.vbr.common.mapper.ProviderMapper;
import com.hcsc.vbr.web.request.PayeeSearchRequest;
import com.hcsc.vbr.web.response.ProviderAPIResponse;
import com.hcsc.vbr.web.response.ProviderAPIResponseDTO;
import com.hcsc.vbr.web.response.ProviderAPISearchResponseDTO;
import com.hcsc.vbr.web.response.ProviderApiAddressesResponse;
import com.hcsc.vbr.web.response.ProviderApiDemographicsResponse;
import com.hcsc.vbr.web.response.ProviderApiTaxIdResponse;

@RunWith( MockitoJUnitRunner.Silent.class )
public class VbrPayeeServiceTest
{
    @InjectMocks
    private VbrPayeeService vbrPayeeService;

    @Mock
    private VbrPayeeRepository vbrPayeeRepo;

    @Mock
    private VbrPayeeMapper vbrPayeeMapper;

    @Mock
    private ProviderMapper providerMapper;

    @Mock
    private ProviderServiceApiClient providerServiceApiClient;

    @Mock
    private PayeeValidator payeeValidator;

    @Mock
    private VbrPayeeUtils vbrPayeeUtils;

    @Test
    public void saveVbrPayeeTest() throws Exception
    {
        when( vbrPayeeMapper.toVbrPayee( any() ) ).thenReturn( getVbrPayee() );
        when( vbrPayeeUtils.getProviderApiAddressAndDemographicsResponse( any() ) ).thenReturn( getVbrPayee() );
        vbrPayeeService.saveVbrPayee( getVbrPayeeDTOInsert() );
    }

    @Test
    public void saveVbrPayeeTestForUpdate() throws Exception
    {
        when( vbrPayeeMapper.toVbrPayee( any() ) ).thenReturn( getVbrPayee() );
        when( vbrPayeeUtils.getProviderApiAddressAndDemographicsResponse( any() ) ).thenReturn( getVbrPayee() );
        vbrPayeeService.saveVbrPayee( getVbrPayeeDTOUpdate() );
    }

    @Test
    public void searchPayeeTest() throws Exception
    {
        vbrPayeeService.searchPayee( getPayeeSearchRequest() );
    }

    @Test
    public void searchPayeeTestForNullPinGroupId() throws Exception
    {

        vbrPayeeService.searchPayee( getPayeeSearchRequestForPinGroupId() );
    }

    @Test( expected = NullPointerException.class )
    public void retrievePayeeTest() throws Exception
    {
        when( providerServiceApiClient.getPinGroupProviders( any() ) ).thenReturn( getProviderAPISearchResponseDTOList() );
        when( providerServiceApiClient.getTaxIdsByPfin( any() ) ).thenReturn( getProviderApiTaxIdResponseList() );
        when( providerServiceApiClient.getAddressesByPfin( any() ) ).thenReturn( getProviderApiAddressesResponse() );
        when( providerServiceApiClient.getDemographicsByPfin( any() ) ).thenReturn( getProviderApiDemographicsResponse() );
        when( providerMapper.toPayeeAddressDTO( any() ) ).thenReturn( getPayeeAddressDTO() );
        vbrPayeeService.retrievePayee( getPayeeSearchRequest() );
    }

    @Test( expected = NullPointerException.class )
    public void retrievePayeesTest() throws Exception
    {
        when( providerServiceApiClient.getProviders( any() ) ).thenReturn( getProviderAPIResponse() );
        vbrPayeeService.retrievePayees( getPayeeSearchRequestList() );
    }

    @Test
    public void retrievePayeesNullTest() throws Exception
    {
        when( providerServiceApiClient.getProviders( any() ) ).thenReturn( getProviderAPINullResponse() );
        vbrPayeeService.retrievePayees( getPayeeSearchRequestList() );
    }

    @Test
    public void validateUniquePayeeTest() throws Exception
    {
        when( vbrPayeeMapper.toVbrPayee( any() ) ).thenReturn( getVbrPayee() );
        vbrPayeeService.validateUniquePayee( getVbrPayeeDTOInsert() );
    }

    private VbrPayee getVbrPayee()
    {
        VbrPayee vbrPayee = new VbrPayee();
        vbrPayee.setPinGroupId( "REG" );
        vbrPayee.setCorporateEntityCode( "NM1" );
        vbrPayee.setRecordEffectiveDate( LocalDate.now() );
        vbrPayee.setRecordEndDate( LocalDate.now() );
        vbrPayee.setVbrPayeeId( Integer.valueOf( 1 ) );
        vbrPayee.setCreateRecordTimestamp( LocalDateTime.now() );
        vbrPayee.setUpdateRecordTimestamp( LocalDateTime.now() );
        vbrPayee.setAddressLine1Text( "ADRS1" );
        vbrPayee.setAddressLine2Text( "ADRS2" );
        vbrPayee.setStateCode( "NM" );
        vbrPayee.setCityName( "Mexico" );
        vbrPayee.setZipCode( "AF0012" );
        return vbrPayee;
    }

    private VbrPayeeDTO getVbrPayeeDTOInsert()
    {
        VbrPayeeDTO vbrPayeeDTO = new VbrPayeeDTO();

        vbrPayeeDTO.setVbrPayeeId( Integer.valueOf( "1" ) );
        vbrPayeeDTO.setCapitationCode( "IL1" );
        vbrPayeeDTO.setCapitationProcessCode( "CPC" );
        vbrPayeeDTO.setCorporateEntityCode( "IC1" );
        vbrPayeeDTO.setNetworkCode( "IN1" );
        vbrPayeeDTO.setPayToPfinId( "1" );
        vbrPayeeDTO.setPinGroupId( "1" );
        vbrPayeeDTO.setPinGroupName( "PAY123" );
        vbrPayeeDTO.setTaxIdNumber( "TAX123" );
        vbrPayeeDTO.setRowAction( RowActionTypes.valueOf( "INSERT" ) );

        return vbrPayeeDTO;

    }

    private VbrPayeeDTO getVbrPayeeDTOUpdate()
    {
        VbrPayeeDTO vbrPayeeDTO = new VbrPayeeDTO();

        vbrPayeeDTO.setVbrPayeeId( Integer.valueOf( "1" ) );
        vbrPayeeDTO.setCapitationCode( "IL1" );
        vbrPayeeDTO.setCapitationProcessCode( "CPC" );
        vbrPayeeDTO.setCorporateEntityCode( "IC1" );
        vbrPayeeDTO.setNetworkCode( "IN1" );
        vbrPayeeDTO.setPayToPfinId( "1" );
        vbrPayeeDTO.setPinGroupId( "1" );
        vbrPayeeDTO.setPinGroupName( "PAY123" );
        vbrPayeeDTO.setTaxIdNumber( "TAX123" );
        vbrPayeeDTO.setRowAction( RowActionTypes.valueOf( "UPDATE" ) );
        vbrPayeeDTO.setRecordEffectiveDate( "10/07/2019" );
        vbrPayeeDTO.setRecordEndDate( "10/07/2019" );
        vbrPayeeDTO.setCreateRecordTimestamp( LocalDateTime.now() );
        vbrPayeeDTO.setUpdateRecordTimestamp( LocalDateTime.now() );

        return vbrPayeeDTO;

    }

    private PayeeSearchRequest getPayeeSearchRequest()
    {
        PayeeSearchRequest payeeSearchRequest = new PayeeSearchRequest();
        payeeSearchRequest.setCapitationTypeCode( "IL1" );
        payeeSearchRequest.setCorpEntityCode( "IC1" );
        payeeSearchRequest.setNetworkAssociationID( Integer.valueOf( "1" ) );
        payeeSearchRequest.setNetworkCode( "IN1" );
        payeeSearchRequest.setPayToPFIN( "1" );
        payeeSearchRequest.setPinGroupId( "1" );
        payeeSearchRequest.setPinGroupName( "PAY123" );
        payeeSearchRequest.setProcessCode( "PC123" );
        payeeSearchRequest.setTaxIdNumber( "TAX123" );
        payeeSearchRequest.setVbrPayeeId( Integer.valueOf( "1" ) );
        return payeeSearchRequest;
    }

    private PayeeSearchRequest getPayeeSearchRequestForPinGroupId()
    {
        PayeeSearchRequest payeeSearchRequest = new PayeeSearchRequest();
        payeeSearchRequest.setCapitationTypeCode( "IL1" );
        payeeSearchRequest.setCorpEntityCode( "IC1" );
        payeeSearchRequest.setNetworkAssociationID( Integer.valueOf( "1" ) );
        payeeSearchRequest.setNetworkCode( "IN1" );
        payeeSearchRequest.setPayToPFIN( "1" );
        payeeSearchRequest.setPinGroupId( null );
        payeeSearchRequest.setPinGroupName( "PAY123" );
        payeeSearchRequest.setProcessCode( "PC123" );
        payeeSearchRequest.setTaxIdNumber( "TAX123" );
        payeeSearchRequest.setVbrPayeeId( Integer.valueOf( "1" ) );
        return payeeSearchRequest;
    }

    private List<PayeeSearchRequest> getPayeeSearchRequestList()
    {
        List<PayeeSearchRequest> list = new ArrayList<PayeeSearchRequest>();
        list.add( getPayeeSearchRequest() );
        return list;
    }

    private ProviderAPIResponseDTO getProviderAPIResponseDTO()
    {
        ProviderAPIResponseDTO response = new ProviderAPIResponseDTO();
        response.setCorpEntityCode( "NM1" );
        response.setCapitationTypeCode( "CAP" );
        response.setPingroupID( "REG" );
        response.setPingroupName( "REG001" );
        response.setNetworkAssociationID( "ID1" );
        response.setNetworkCode( "NC" );
        return response;
    }

    private List<ProviderAPIResponseDTO> getProviderAPIResponseDTOList()
    {
        List<ProviderAPIResponseDTO> list = new ArrayList<ProviderAPIResponseDTO>();
        list.add( getProviderAPIResponseDTO() );
        return list;
    }

    private List<ProviderApiTaxIdResponse> getProviderApiTaxIdResponseList()
    {
        ProviderApiTaxIdResponse response = new ProviderApiTaxIdResponse();
        List<ProviderApiTaxIdResponse> list = new ArrayList<ProviderApiTaxIdResponse>();
        response.setTaxId( "12" );
        response.setTaxIdEffectiveDate( "01/01/2019 " );
        response.setTaxIdEndDate( "10/31/2019" );
        list.add( response );
        return list;
    }

    private ProviderApiAddressesResponse getProviderApiAddressesResponse()
    {
        ProviderApiAddressesResponse response = new ProviderApiAddressesResponse();

        return response;
    }

    private ProviderApiDemographicsResponse getProviderApiDemographicsResponse()
    {
        ProviderApiDemographicsResponse response = new ProviderApiDemographicsResponse();
        return response;
    }

    private PayeeAddressDTO getPayeeAddressDTO()
    {
        PayeeAddressDTO dto = new PayeeAddressDTO();
        dto.setAddressLine1( "AD1" );
        dto.setAddressLine2( "AD2" );
        dto.setCity( "city" );
        return dto;

    }

    private ProviderAPIResponse getProviderAPIResponse()
    {
        ProviderAPIResponse response = new ProviderAPIResponse();
        response.setProviders( getProviderAPIResponseDTOList() );
        return response;
    }

    private ProviderAPIResponse getProviderAPINullResponse()
    {
        ProviderAPIResponse response = new ProviderAPIResponse();
        response.setProviders( null );
        return response;
    }

    private List<ProviderAPISearchResponseDTO> getProviderAPISearchResponseDTOList()
    {
        List<ProviderAPISearchResponseDTO> list = new ArrayList<ProviderAPISearchResponseDTO>();
        ProviderAPISearchResponseDTO dto = new ProviderAPISearchResponseDTO();
        dto.setCapitationType( "CT" );
        dto.setCorpEntityCode( "NM1" );
        dto.setPingroupID( "REG" );
        list.add( dto );
        return list;
    }
}
