package com.hcsc.vbr.arrangementconfigservice.validator.paymentarrangement;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.json.JacksonTester;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.hcsc.vbr.arrangementconfigservice.domain.VbrPayee;
import com.hcsc.vbr.common.constant.VBRCommonConstant.RowActionTypes;
import com.hcsc.vbr.common.dto.ErrorMessageDTO;
import com.hcsc.vbr.common.dto.ReturnMessageDTO;

public class PMAM043CheckArrangementPayeeProviderAPIValidationTest
{
    @InjectMocks
    PMAM043CheckArrangementPayeeProviderAPIValidation pmam043CheckArrangementPayeeProviderAPIValidation;

    @Before
    public void setUp()
    {
        MockitoAnnotations.initMocks( this );
        JacksonTester.initFields( this,
                                  new ObjectMapper() );

    }

    @Test
    public void validationArrangementPayeeProviderAPISuccess() throws Exception
    {

        pmam043CheckArrangementPayeeProviderAPIValidation.validationArrangementPayeeProviderAPI( getVbrPayee(),
                                                                                                 getReturnMessageDTO() );
    }

    @Test( expected = NullPointerException.class )
    public void validationArrangementPayeeProviderAPIFail() throws Exception
    {

        pmam043CheckArrangementPayeeProviderAPIValidation.validationArrangementPayeeProviderAPI( getVbrPayee_fail(),
                                                                                                 getReturnMessageDTO() );
    }

    private List<ErrorMessageDTO> getErrorMessageDTOSuccess() throws Exception
    {
        List<ErrorMessageDTO> errors = new ArrayList<ErrorMessageDTO>();
        ErrorMessageDTO errorMessageDTO = new ErrorMessageDTO();

        errorMessageDTO.setErrorMessageCategoryCode( "PCF-PMAM" );
        errorMessageDTO.setErrorMessageId( new Long( 226 ) );
        errorMessageDTO.setErrorMsgDescriptionText( "Payment Type Is Required" );
        errorMessageDTO.setSeveritylevel( "E" );
        errors.add( errorMessageDTO );
        return errors;

    }

    private ReturnMessageDTO getReturnMessageDTO() throws Exception
    {
        ReturnMessageDTO returnMessage = new ReturnMessageDTO();

        returnMessage.setItemName( "PCF-PMAM" );
        returnMessage.setStatus( "SUCCESS" );
        returnMessage.setErrors( getErrorMessageDTOSuccess() );
        return returnMessage;

    }

    private VbrPayee getVbrPayee()
    {
        VbrPayee vbrPayeeDTO = new VbrPayee();
        vbrPayeeDTO.setCorporateEntityCode( "NM1" );
        vbrPayeeDTO.setNetworkAssocProviderId( 772129222 );
        vbrPayeeDTO.setNetworkCode( "MCD" );
        vbrPayeeDTO.setPinGroupId( "RSK" );
        vbrPayeeDTO.setPayToPfinId( "00NMCAB001" );
        vbrPayeeDTO.setCapitationCode( "A1" );
        vbrPayeeDTO.setCapitationProcessCode( "CP" );
        vbrPayeeDTO.setPinGroupName( "RSK001" );
        vbrPayeeDTO.setTaxIdNumber( "999999999" );
        vbrPayeeDTO.setRecordEffectiveDate( LocalDate.now() );
        vbrPayeeDTO.setRecordEndDate( LocalDate.now() );
        vbrPayeeDTO.setCreateUserId( "U402537" );
        vbrPayeeDTO.setUpdateUserId( "U402537" );
        vbrPayeeDTO.setCreateRecordTimestamp( null );
        vbrPayeeDTO.setUpdateRecordTimestamp( null );
        vbrPayeeDTO.setRowAction( RowActionTypes.NO_ACTION );
        vbrPayeeDTO.setVbrPayeeId( 181 );
        vbrPayeeDTO.setNetworkAssociationEffectiveDate( "12/01/2019" );
        vbrPayeeDTO.setNetworkAssociationEndDate( "12/31/2019" );
        vbrPayeeDTO.setPfinEffectiveDate( "12/01/2019" );
        vbrPayeeDTO.setPfinEndDate( "12/31/2019" );
        vbrPayeeDTO.setPinGroupEffectiveDate( "12/01/2019" );
        vbrPayeeDTO.setPinGroupEndDate( "12/31/2019" );
        vbrPayeeDTO.setTinEffectiveDate( "12/01/2019" );
        vbrPayeeDTO.setTinEndDate( "12/31/2019" );
        return vbrPayeeDTO;
    }

    private VbrPayee getVbrPayee_fail()
    {
        VbrPayee vbrPayeeDTO = new VbrPayee();
        vbrPayeeDTO.setCorporateEntityCode( "NM1" );
        vbrPayeeDTO.setNetworkAssocProviderId( 772129222 );
        vbrPayeeDTO.setNetworkCode( "MCD" );
        vbrPayeeDTO.setPinGroupId( "RSK" );
        vbrPayeeDTO.setPayToPfinId( "00NMCAB001" );
        vbrPayeeDTO.setCapitationCode( "A1" );
        vbrPayeeDTO.setCapitationProcessCode( "CP" );
        vbrPayeeDTO.setPinGroupName( "RSK001" );
        vbrPayeeDTO.setTaxIdNumber( "999999999" );
        vbrPayeeDTO.setRecordEffectiveDate( LocalDate.of( 2016,
                                                          12,
                                                          1 ) );
        vbrPayeeDTO.setRecordEndDate( LocalDate.of( 2016,
                                                    12,
                                                    31 ) );
        vbrPayeeDTO.setCreateUserId( "U402537" );
        vbrPayeeDTO.setUpdateUserId( "U402537" );
        vbrPayeeDTO.setCreateRecordTimestamp( null );
        vbrPayeeDTO.setUpdateRecordTimestamp( null );
        vbrPayeeDTO.setRowAction( RowActionTypes.NO_ACTION );
        vbrPayeeDTO.setVbrPayeeId( 181 );
        vbrPayeeDTO.setNetworkAssociationEffectiveDate( "12/01/2019" );
        vbrPayeeDTO.setNetworkAssociationEndDate( "12/31/2019" );
        vbrPayeeDTO.setPfinEffectiveDate( "12/01/2019" );
        vbrPayeeDTO.setPfinEndDate( "12/31/2019" );
        vbrPayeeDTO.setPinGroupEffectiveDate( "12/01/2019" );
        vbrPayeeDTO.setPinGroupEndDate( "12/31/2019" );
        vbrPayeeDTO.setTinEffectiveDate( "12/01/2019" );
        vbrPayeeDTO.setTinEndDate( "12/31/2019" );
        return vbrPayeeDTO;
    }

}
