package com.hcsc.vbr.arrangementconfigservice.mapper;

import java.util.ArrayList;
import java.util.List;

import org.assertj.core.api.Assertions;
import org.junit.Test;

import com.hcsc.vbr.arrangementconfigservice.domain.RateName;
import com.hcsc.vbr.arrangementconfigservice.domain.RateNameId;
import com.hcsc.vbr.arrangementconfigservice.dto.RateNameDTO;

public class RateNameMapperTest
{

    /*** Domain to DTO mapping test method ***/
    /**
    * Method: testToRateNameDTO
    */
    @Test
    public void testToRateNameDTO()
    {

        RateName rateName = new RateName();
        RateNameId rateNameId = new RateNameId();
        rateNameId.setCorporateEntityCode( "IL1" );
        rateNameId.setRateName( "RTN1" );
        rateName.setRateNameId( rateNameId );

        RateNameDTO rateNameDTO = RateNameMapper.INSTANCE.toRateNameDTO( rateName );
        Assertions.assertThat( rateNameDTO ).hasFieldOrPropertyWithValue( "corporateEntityCode",
                                                                          "IL1" );
        Assertions.assertThat( rateNameDTO ).hasFieldOrPropertyWithValue( "rateName",
                                                                          "RTN1" );
    }

    /*** Null Passed for Domain ***/
    /**
     * Method: testNullToRateNameDTO
     */
    @Test
    public void testNullToRateNameDTO()
    {

        RateNameDTO rateNameDTO = RateNameMapper.INSTANCE.toRateNameDTO( null );

        Assertions.assertThat( rateNameDTO == null );

    }

    /*** List<Domain> to List<DTO> mapping test method ***/
    /**
    * Method: testToRateNameDTOs
    */
    @Test
    public void testToRateNameDTOs()
    {
        RateName rateName = new RateName();
        RateNameId rateNameId = new RateNameId();
        rateNameId.setCorporateEntityCode( "IL1" );
        rateNameId.setRateName( "RTN1" );
        rateName.setRateNameId( rateNameId );

        List<RateName> ratenames = new ArrayList<RateName>();
        ratenames.add( rateName );

        List<RateNameDTO> rateNameDTOs = RateNameMapper.INSTANCE.toRateNameDTOs( ratenames );

        for( RateNameDTO rateNameDTO : rateNameDTOs )
        {
            Assertions.assertThat( rateNameDTO ).hasFieldOrPropertyWithValue( "corporateEntityCode",
                                                                              "IL1" );
            Assertions.assertThat( rateNameDTO ).hasFieldOrPropertyWithValue( "rateName",
                                                                              "RTN1" );
        }
    }

    /*** DTO to Domain mapping Test method ***/
    /**
    * Method: testToRateName
    */
    @Test
    public void testToRateName()
    {
        RateNameDTO rateNameDTO = new RateNameDTO();
        rateNameDTO.setCorporateEntityCode( "IL1" );
        rateNameDTO.setRateName( "RTN1" );

        RateName rateName = RateNameMapper.INSTANCE.toRateName( rateNameDTO );

        Assertions.assertThat( rateName ).hasFieldOrPropertyWithValue( "rateNameId.corporateEntityCode",
                                                                       "IL1" );
        Assertions.assertThat( rateName ).hasFieldOrPropertyWithValue( "rateNameId.rateName",
                                                                       "RTN1" );
    }

    /*** List<DTO> to List<Domain> mapping method ***/
    /**
    * Method: testToRateNames
    */
    @Test
    public void testToRateNames()
    {
        RateNameDTO rateNameDTO = new RateNameDTO();
        rateNameDTO.setCorporateEntityCode( "IL1" );
        rateNameDTO.setRateName( "RTN1" );
        List<RateNameDTO> rateNameDTOs = new ArrayList<RateNameDTO>();
        rateNameDTOs.add( rateNameDTO );

        List<RateName> rateNames = RateNameMapper.INSTANCE.toRateNames( rateNameDTOs );

        for( RateName rateName : rateNames )
        {
            Assertions.assertThat( rateName ).hasFieldOrPropertyWithValue( "rateNameId.corporateEntityCode",
                                                                           "IL1" );
            Assertions.assertThat( rateName ).hasFieldOrPropertyWithValue( "rateNameId.rateName",
                                                                           "RTN1" );
        }
    }

    /*** Empty DTO list passed ***/
    /**
    * Method: testNullToRateNames
    */
    @Test
    public void testNullToRateNames()
    {

        List<RateName> rateNames = RateNameMapper.INSTANCE.toRateNames( null );

        Assertions.assertThat( rateNames == null );

    }

}
