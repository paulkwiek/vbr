package com.hcsc.vbr.arrangementconfigservice.validator.ratename;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import com.hcsc.vbr.arrangementconfigservice.domain.FlatRate;
import com.hcsc.vbr.arrangementconfigservice.domain.RateName;
import com.hcsc.vbr.arrangementconfigservice.domain.RateNameId;
import com.hcsc.vbr.arrangementconfigservice.repository.RateNameRepository;
import com.hcsc.vbr.common.dto.ReturnMessageDTO;

@RunWith( MockitoJUnitRunner.class )
public class RTNM005CheckRateNameTest
{

    @InjectMocks
    RTNM005CheckRateName rtnm005CheckRateName;

    @Mock
    public RateNameRepository rateNameRepository;

    @Test( expected = NullPointerException.class )
    public void validateRateAmount_test() throws Exception
    {
        String rateName = "RATENAME";

        when( rateNameRepository.findByRateName( any() ) ).thenReturn( getRateName() );

        rtnm005CheckRateName.validateRateName( rateName,
                                               getReturnMessageDTO() );

    }

    @Test( expected = NullPointerException.class )
    public void validateRateAmount_Failure() throws Exception
    {
        String rateName = " RATE NAME hjfsdfkjbvbhjbfbwrbffbvdfksbvkdfbvkdfjbvksd ";
        rtnm005CheckRateName.validateRateName( rateName,
                                               getReturnMessageDTO() );

    }

    @Test( expected = NullPointerException.class )
    public void validateRateAmount_Null() throws Exception
    {
        String rateName = null;
        rtnm005CheckRateName.validateRateName( rateName,
                                               getReturnMessageDTO() );

    }

    private RateName getRateName()
    {

        RateName rtnm = new RateName();
        RateNameId rtnmId = new RateNameId();
        rtnmId.setRateName( "SMOKE25" );
        rtnmId.setCorporateEntityCode( "NM1" );
        rtnm.setRateNameId( rtnmId );
        rtnm.setFlatRates( getflatrateList() );
        return rtnm;
    }

    private List<FlatRate> getflatrateList()
    {
        List<FlatRate> flatRateDTOlist = new ArrayList<FlatRate>();
        FlatRate flatRate = new FlatRate();
        flatRate.setFemaleFlatRateAmount( 456.53 );
        flatRate.setMaleFlatRateAmount( 845.34 );
        flatRate.setRecordEffectiveDate( LocalDate.of( 2019,
                                                       11,
                                                       01 ) );
        flatRate.setRecordEndDate( LocalDate.of( 2019,
                                                 11,
                                                 30 ) );
        flatRateDTOlist.add( flatRate );

        return flatRateDTOlist;
    }

    private ReturnMessageDTO getReturnMessageDTO()
    {
        ReturnMessageDTO returnMessage = new ReturnMessageDTO();
        return returnMessage;
    }

}
