package com.hcsc.vbr.arrangementconfigservice.validator.payee;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnitRunner;

import com.hcsc.vbr.common.dto.ReturnMessageDTO;
import com.hcsc.vbr.web.response.ProviderAPIResponseDTO;

@RunWith( MockitoJUnitRunner.Silent.class )
public class VBPY018ValidateNoRecordsFoundForPayeeFromProviderApiTest
{
    @InjectMocks
    private VBPY018ValidateNoRecordsFoundForPayeeFromProviderApi vbpy018ValidateNoRecordsFoundForPayeeFromProviderApi;

    @Test
    public void isRecordsFound() throws Exception
    {

        vbpy018ValidateNoRecordsFoundForPayeeFromProviderApi.isRecordsFound( getProviderAPIResponseDTO(),
                                                                             getReturnMessageDTO() );
    }

    @Test( expected = NullPointerException.class )
    public void isRecordsFound_Failure() throws Exception
    {

        vbpy018ValidateNoRecordsFoundForPayeeFromProviderApi.isRecordsFound( getProviderAPIResponseDTO_Empty(),
                                                                             getReturnMessageDTO() );
    }

    List<ProviderAPIResponseDTO> getProviderAPIResponseDTO()
    {
        List<ProviderAPIResponseDTO> providerDTOList = new ArrayList<ProviderAPIResponseDTO>();
        ProviderAPIResponseDTO providerAPIResponseDTO = new ProviderAPIResponseDTO();
        providerAPIResponseDTO.setProcessCode( "CP" );
        providerAPIResponseDTO.setPingroupID( "RE1" );
        providerAPIResponseDTO.setPayToPFINId( "00NMCAP001" );
        providerAPIResponseDTO.setCapitationTypeCode( "A1" );
        providerAPIResponseDTO.setPingroupName( "RE1001" );
        providerAPIResponseDTO.setTaxId( "999999999" );
        providerAPIResponseDTO.setNetworkAssociationEffectiveDate( "01/01/2019" );
        providerAPIResponseDTO.setNetworkAssociationEndDate( "12/31/2019" );
        providerAPIResponseDTO.setPfinEffectiveDate( "01/01/2019" );
        providerAPIResponseDTO.setPfinEndDate( "12/31/2019" );
        providerAPIResponseDTO.setPINGroupEndDate( "01/01/2019" );
        providerAPIResponseDTO.setPINGroupEffectiveDate( "12/31/2019" );
        providerAPIResponseDTO.setTinEffectiveDate( "02/22/2019" );
        providerAPIResponseDTO.setTinEndDate( "02/21/2020" );
        providerDTOList.add( providerAPIResponseDTO );

        return providerDTOList;

    }

    List<ProviderAPIResponseDTO> getProviderAPIResponseDTO_Empty()
    {

        List<ProviderAPIResponseDTO> providerDTOList = new ArrayList<ProviderAPIResponseDTO>();

        providerDTOList.removeAll( providerDTOList );
        return providerDTOList;

    }

    private ReturnMessageDTO getReturnMessageDTO()
    {
        ReturnMessageDTO returnMessage = new ReturnMessageDTO();
        return returnMessage;
    }

}
