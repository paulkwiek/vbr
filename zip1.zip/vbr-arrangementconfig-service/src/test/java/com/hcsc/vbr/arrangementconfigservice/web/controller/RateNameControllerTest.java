package com.hcsc.vbr.arrangementconfigservice.web.controller;

import static org.junit.Assert.assertEquals;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.boot.test.json.JacksonTester;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.hcsc.vbr.arrangementconfigservice.dto.FlatRateDTO;
import com.hcsc.vbr.arrangementconfigservice.dto.RateNameDTO;
import com.hcsc.vbr.arrangementconfigservice.service.RateNameService;
import com.hcsc.vbr.web.controller.RateNameController;
import com.hcsc.vbr.web.request.RateSaveRequest;

@RunWith( MockitoJUnitRunner.class )
public class RateNameControllerTest
{
    @InjectMocks
    private RateNameController rateNameController;

    @Mock
    private RateNameService rateNameService;

    private MockMvc mvc;

    @Before
    public void initTest() throws Exception
    {
        MockitoAnnotations.initMocks( this );
        JacksonTester.initFields( this,
                                  new ObjectMapper() );
        mvc = MockMvcBuilders.standaloneSetup( rateNameController ).setControllerAdvice( new Exception() ).build();
    }

    @Test
    public void testSaveRateSuccess() throws Exception
    {
        ObjectMapper map = new ObjectMapper();
        String jsonReq = map.writeValueAsString( rateSaveRequest() );
        MvcResult result = null;

        result = mvc
                .perform( MockMvcRequestBuilders.post( "/rates/saveRate" )
                        .content( jsonReq )
                        .contentType( MediaType.APPLICATION_JSON )
                        .accept( MediaType.APPLICATION_JSON ) )
                .andExpect( status().isOk() )
                .andReturn();

        assertEquals( 200,
                      result.getResponse().getStatus() );

    }

    @Test
    public void testSaveRateFailure() throws Exception
    {
        String request = "";
        MockHttpServletResponse result = mvc
                .perform( MockMvcRequestBuilders.post( "/rates/saveRate" )
                        .content( request )
                        .contentType( MediaType.APPLICATION_JSON )
                        .accept( MediaType.APPLICATION_JSON ) )
                .andReturn()
                .getResponse();
        assertEquals( 400,
                      result.getStatus() );
    }

    @Test
    public void testRetrieveRateByRatenameSuccess() throws Exception
    {

        MvcResult result =
            mvc.perform( MockMvcRequestBuilders.get( "/rates/retrieveRate/RATE1" ).accept( MediaType.APPLICATION_JSON ) ).andReturn();

        assertEquals( 200,
                      result.getResponse().getStatus() );
    }

    @Test
    public void testRetrieveRateByRatenameFailure() throws Exception
    {

        MvcResult result =
            mvc.perform( MockMvcRequestBuilders.get( "/rates/RATE1" ).accept( MediaType.APPLICATION_JSON ) ).andReturn();

        assertEquals( 404,
                      result.getResponse().getStatus() );
    }

    @Test
    public void testRetrieveRatesSuccess() throws Exception
    {

        MvcResult result =
            mvc.perform( MockMvcRequestBuilders.get( "/rates/retrieveRates/NM1" ).accept( MediaType.APPLICATION_JSON ) ).andReturn();

        assertEquals( 200,
                      result.getResponse().getStatus() );
    }

    @Test
    public void testRetrieveRatesFailure() throws Exception
    {

        MvcResult result =
            mvc.perform( MockMvcRequestBuilders.get( "/rates/retrieveRates" ).accept( MediaType.APPLICATION_JSON ) ).andReturn();

        assertEquals( 404,
                      result.getResponse().getStatus() );
    }

    @Test
    public void testValidateRatenameSuccess() throws Exception
    {

        MvcResult result =
            mvc.perform( MockMvcRequestBuilders.get( "/rates/validateRateName/RATE1" ).accept( MediaType.APPLICATION_JSON ) )
                    .andReturn();

        assertEquals( 200,
                      result.getResponse().getStatus() );
    }

    @Test
    public void testValidateRatenameFailure() throws Exception
    {

        MvcResult result =
            mvc.perform( MockMvcRequestBuilders.get( "/validateRateName/RATE1" ).accept( MediaType.APPLICATION_JSON ) ).andReturn();

        assertEquals( 404,
                      result.getResponse().getStatus() );
    }

    @Test
    public void testGetLinkedArrangementSuccess() throws Exception
    {

        MvcResult result =
            mvc.perform( MockMvcRequestBuilders.get( "/rates/getLinkedArrangements/RATE1" ).accept( MediaType.APPLICATION_JSON ) )
                    .andReturn();

        assertEquals( 200,
                      result.getResponse().getStatus() );
    }

    @Test
    public void testGetLinkedArrangementFailure() throws Exception
    {

        MvcResult result =
            mvc.perform( MockMvcRequestBuilders.get( "/getLinkedArrangements/RATE1" ).accept( MediaType.APPLICATION_JSON ) )
                    .andReturn();

        assertEquals( 404,
                      result.getResponse().getStatus() );
    }

    private RateSaveRequest rateSaveRequest()
    {
        RateSaveRequest rateSaveRequest = new RateSaveRequest();
        rateSaveRequest.setRate( getRateNameDTO() );
        rateSaveRequest.setWarningState( true );
        return rateSaveRequest;

    }

    private RateNameDTO getRateNameDTO()
    {

        RateNameDTO rateNameDTO = new RateNameDTO();
        rateNameDTO.setCorporateEntityCode( "NM" );
        rateNameDTO.setCreateUserId( "CODE124" );
        rateNameDTO.setUpdateUserId( "CODE123" );
        rateNameDTO.setCreateRecordTimestamp( null );
        rateNameDTO.setUpdateRecordTimestamp( null );
        rateNameDTO.setRateName( "RATE1" );
        rateNameDTO.setRateConfigTypeName( "FLATRT" );
        rateNameDTO.setFlatRates( getFlatRates() );
        return rateNameDTO;

    }

    private List<FlatRateDTO> getFlatRates()
    {
        List<FlatRateDTO> flatRateDTOs = new ArrayList<FlatRateDTO>();
        FlatRateDTO flatRateDTO = new FlatRateDTO();
        flatRateDTO.setCorporateEntityCode( "NM" );
        flatRateDTO.setFlatRateId( Integer.valueOf( 1 ) );
        flatRateDTO.setFemaleFlatRateAmount( 123.5 );
        flatRateDTO.setMaleFlatRateAmount( 124.5 );
        flatRateDTO.setRateName( "RATE1" );
        flatRateDTOs.add( flatRateDTO );
        return flatRateDTOs;
    }

}
