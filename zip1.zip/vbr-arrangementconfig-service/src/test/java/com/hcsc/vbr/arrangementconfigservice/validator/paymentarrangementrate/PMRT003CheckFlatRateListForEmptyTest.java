package com.hcsc.vbr.arrangementconfigservice.validator.paymentarrangementrate;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnitRunner;

import com.hcsc.vbr.arrangementconfigservice.domain.FlatRate;
import com.hcsc.vbr.common.dto.ReturnMessageDTO;

@RunWith( MockitoJUnitRunner.class )
public class PMRT003CheckFlatRateListForEmptyTest
{
    @InjectMocks
    private PMRT003CheckFlatRateListForEmpty pmrt003CheckFlatRateListForEmpty;

    @Test
    public void checkFlatRateListForEmptyTest_success() throws Exception
    {
        pmrt003CheckFlatRateListForEmpty.checkFlatRateListForEmpty( getFlatRates_success(),
                                                                    getReturnMessageDTO() );
    }

    @Test( expected = NullPointerException.class )
    public void checkFlatRateListForEmptyTest_failure() throws Exception
    {
        pmrt003CheckFlatRateListForEmpty.checkFlatRateListForEmpty( getFlatRates_failure(),
                                                                    getReturnMessageDTO() );
    }

    private List<FlatRate> getFlatRates_success()
    {
        List<FlatRate> flatRates = new ArrayList<FlatRate>();
        FlatRate flatRate = new FlatRate();
        flatRate.setRecordEffectiveDate( LocalDate.now() );
        flatRate.setRecordEndDate( LocalDate.now() );
        flatRates.add( flatRate );
        return flatRates;
    }

    private List<FlatRate> getFlatRates_failure()
    {
        return null;
    }

    private ReturnMessageDTO getReturnMessageDTO()
    {
        ReturnMessageDTO returnMessageDTO = new ReturnMessageDTO();
        return returnMessageDTO;
    }

}
