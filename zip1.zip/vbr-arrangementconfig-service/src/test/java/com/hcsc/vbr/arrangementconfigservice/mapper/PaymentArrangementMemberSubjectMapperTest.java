package com.hcsc.vbr.arrangementconfigservice.mapper;

import java.util.ArrayList;
import java.util.List;

import org.assertj.core.api.Assertions;
import org.junit.Test;

import com.hcsc.vbr.arrangementconfigservice.domain.PaymentArrangementMemberSubject;
import com.hcsc.vbr.arrangementconfigservice.dto.PaymentArrangementMemberSubjectDTO;

public class PaymentArrangementMemberSubjectMapperTest
{
    private Integer paymentArrangementMemberSubjectId = 1;
    private String productTypeCode = "Product Type Code";
    private String benefitPlanStateCode = "Benefit Plan State Code";
    private String benefitPlanNumber = "Benefit Plan Number";
    private String lineOfBusinessCode = "Line of Business Code";
    private String accountnumber = "Account Number";
    private String groupId = "Group Id";
    private String sectionNumber = "Section Number";
    private String captitationEntityCode = "Capitation Entity Code";
    private Integer benefitArrangementNumber = 12345;
    private String memberLocationId = "Member Location id";
    private String networkRiskLevelCode = "Network Risk Level Code";
    private Integer paymentArrangementId = 78901;
    private String corporateEntityCode = "Corporate Entity Code";
    private String fundingTypeCode = "Funding Type Code";

    @Test
    public void testToPaymentArrangementMemberSubjectDTO()
    {
        PaymentArrangementMemberSubject paymentArrangementMemberSubject = populatePaymentArrangementMemberSubject();

        PaymentArrangementMemberSubjectDTO paymentArrangementMemberSubjectDTO =
            PaymentArrangementMemberSubjectMapper.INSTANCE.toPaymentArrangementMemberSubjectDTO( paymentArrangementMemberSubject );

        Assertions.assertThat( paymentArrangementMemberSubjectDTO )
                .hasFieldOrPropertyWithValue( "memberLocationId",
                                              memberLocationId );
        Assertions.assertThat( paymentArrangementMemberSubjectDTO )
                .hasFieldOrPropertyWithValue( "paymentArrangementId",
                                              paymentArrangementId );
    }

    @Test
    public void testNullToPaymentArrangementMemberSubjectDTO()
    {
        PaymentArrangementMemberSubjectDTO paymentArrangementMemberSubjectDTO =
            PaymentArrangementMemberSubjectMapper.INSTANCE.toPaymentArrangementMemberSubjectDTO( null );

        Assertions.assertThat( paymentArrangementMemberSubjectDTO == null );
    }

    @Test
    public void testToPaymentArrangementMemberSubjectDTOs()
    {
        PaymentArrangementMemberSubject paymentArrangementMemberSubject = populatePaymentArrangementMemberSubject();

        List<PaymentArrangementMemberSubject> paymentArrangementMemberSubjects = new ArrayList<PaymentArrangementMemberSubject>();
        paymentArrangementMemberSubjects.add( paymentArrangementMemberSubject );

        List<PaymentArrangementMemberSubjectDTO> paymentArrangementMemberSubjectDTOs =
            PaymentArrangementMemberSubjectMapper.INSTANCE.toPaymentArrangementMemberSubjectDTOs( paymentArrangementMemberSubjects );

        for( PaymentArrangementMemberSubjectDTO paymentArrangementMemberSubjectDTO : paymentArrangementMemberSubjectDTOs )
        {
            Assertions.assertThat( paymentArrangementMemberSubjectDTO )
                    .hasFieldOrPropertyWithValue( "memberLocationId",
                                                  memberLocationId );
            Assertions.assertThat( paymentArrangementMemberSubjectDTO )
                    .hasFieldOrPropertyWithValue( "paymentArrangementId",
                                                  paymentArrangementId );
        }
    }

    @Test
    public void testNullToPaymentArrangementMemberSubjectDTOs()
    {
        List<PaymentArrangementMemberSubjectDTO> paymentArrangementMemberSubjectDTOs =
            PaymentArrangementMemberSubjectMapper.INSTANCE.toPaymentArrangementMemberSubjectDTOs( null );

        Assertions.assertThat( paymentArrangementMemberSubjectDTOs == null );
    }

    @Test
    public void testToPaymentArrangementMemberSubject()
    {
        PaymentArrangementMemberSubjectDTO paymentArrangementMemberSubjectDTO = populatePaymentArrangementMemberSubjectDTO();

        PaymentArrangementMemberSubject paymentArrangementMemberSubject =
            PaymentArrangementMemberSubjectMapper.INSTANCE.toPaymentArrangementMemberSubject( paymentArrangementMemberSubjectDTO );

        Assertions.assertThat( paymentArrangementMemberSubject )
                .hasFieldOrPropertyWithValue( "benefitPlanStateCode",
                                              benefitPlanStateCode );
        Assertions.assertThat( paymentArrangementMemberSubject )
                .hasFieldOrPropertyWithValue( "benefitArrangementNumber",
                                              benefitArrangementNumber );
    }

    @Test
    public void testNullToPaymentArrangementMemberSubject()
    {
        PaymentArrangementMemberSubject paymentArrangementMemberSubject =
            PaymentArrangementMemberSubjectMapper.INSTANCE.toPaymentArrangementMemberSubject( null );

        Assertions.assertThat( paymentArrangementMemberSubject == null );
    }

    @Test
    public void testToPaymentArrangementMemberSubjects()
    {
        PaymentArrangementMemberSubjectDTO paymentArrangementMemberSubjectDTO = populatePaymentArrangementMemberSubjectDTO();

        List<PaymentArrangementMemberSubjectDTO> paymentArrangementMemberSubjectDTOs =
            new ArrayList<PaymentArrangementMemberSubjectDTO>();
        paymentArrangementMemberSubjectDTOs.add( paymentArrangementMemberSubjectDTO );

        List<PaymentArrangementMemberSubject> paymentArrangementMemberSubjects =
            PaymentArrangementMemberSubjectMapper.INSTANCE.toPaymentArrangementMemberSubjects( paymentArrangementMemberSubjectDTOs );

        for( PaymentArrangementMemberSubject paymentArrangementMemberSubject : paymentArrangementMemberSubjects )
        {
            Assertions.assertThat( paymentArrangementMemberSubject )
                    .hasFieldOrPropertyWithValue( "benefitPlanStateCode",
                                                  benefitPlanStateCode );
            Assertions.assertThat( paymentArrangementMemberSubject )
                    .hasFieldOrPropertyWithValue( "benefitArrangementNumber",
                                                  benefitArrangementNumber );
        }
    }

    @Test
    public void testNullToPaymentArrangementMemberSubjects()
    {
        List<PaymentArrangementMemberSubject> paymentArrangementMemberSubjects =
            PaymentArrangementMemberSubjectMapper.INSTANCE.toPaymentArrangementMemberSubjects( null );

        Assertions.assertThat( paymentArrangementMemberSubjects == null );
    }

    private PaymentArrangementMemberSubject populatePaymentArrangementMemberSubject()
    {
        PaymentArrangementMemberSubject paymentArrangementMemberSubject = new PaymentArrangementMemberSubject();
        paymentArrangementMemberSubject.setAccountnumber( accountnumber );
        paymentArrangementMemberSubject.setBenefitArrangementNumber( benefitArrangementNumber );
        paymentArrangementMemberSubject.setBenefitPlanNumber( benefitPlanNumber );
        paymentArrangementMemberSubject.setBenefitPlanStateCode( benefitPlanStateCode );
        paymentArrangementMemberSubject.setCaptitationEntityCode( captitationEntityCode );
        paymentArrangementMemberSubject.setCorporateEntityCode( corporateEntityCode );
        paymentArrangementMemberSubject.setFundingTypeCode( fundingTypeCode );
        paymentArrangementMemberSubject.setGroupId( groupId );
        paymentArrangementMemberSubject.setLineOfBusinessCode( lineOfBusinessCode );
        paymentArrangementMemberSubject.setMemberLocationId( memberLocationId );
        paymentArrangementMemberSubject.setNetworkRiskLevelCode( networkRiskLevelCode );
        paymentArrangementMemberSubject.setPaymentArrangementMemberSubjectId( paymentArrangementMemberSubjectId );
        paymentArrangementMemberSubject.setProductTypeCode( productTypeCode );
        paymentArrangementMemberSubject.setSectionNumber( sectionNumber );
        paymentArrangementMemberSubject.setPaymentArrangementId( paymentArrangementId );

        return paymentArrangementMemberSubject;
    }

    private PaymentArrangementMemberSubjectDTO populatePaymentArrangementMemberSubjectDTO()
    {
        PaymentArrangementMemberSubjectDTO paymentArrangementMemberSubjectDTO = new PaymentArrangementMemberSubjectDTO();
        paymentArrangementMemberSubjectDTO.setAccountnumber( accountnumber );
        paymentArrangementMemberSubjectDTO.setBenefitArrangementNumber( benefitArrangementNumber );
        paymentArrangementMemberSubjectDTO.setBenefitPlanNumber( benefitPlanNumber );
        paymentArrangementMemberSubjectDTO.setBenefitPlanStateCode( benefitPlanStateCode );
        paymentArrangementMemberSubjectDTO.setCaptitationEntityCode( captitationEntityCode );
        paymentArrangementMemberSubjectDTO.setCorporateEntityCode( corporateEntityCode );
        paymentArrangementMemberSubjectDTO.setFundingTypeCode( fundingTypeCode );
        paymentArrangementMemberSubjectDTO.setGroupId( groupId );
        paymentArrangementMemberSubjectDTO.setLineOfBusinessCode( lineOfBusinessCode );
        paymentArrangementMemberSubjectDTO.setMemberLocationId( memberLocationId );
        paymentArrangementMemberSubjectDTO.setNetworkRiskLevelCode( networkRiskLevelCode );
        paymentArrangementMemberSubjectDTO.setPaymentArrangementMemberSubjectId( paymentArrangementMemberSubjectId );
        paymentArrangementMemberSubjectDTO.setProductTypeCode( productTypeCode );
        paymentArrangementMemberSubjectDTO.setSectionNumber( sectionNumber );
        paymentArrangementMemberSubjectDTO.setPaymentArrangementId( paymentArrangementId );

        return paymentArrangementMemberSubjectDTO;
    }
}
