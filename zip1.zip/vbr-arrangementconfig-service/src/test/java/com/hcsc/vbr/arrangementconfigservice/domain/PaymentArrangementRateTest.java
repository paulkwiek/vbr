package com.hcsc.vbr.arrangementconfigservice.domain;

public class PaymentArrangementRateTest
{
    /* private PaymentArrangementRate paymentArrangementRate;
    
    @Before
    public void setUp()
    {
        paymentArrangementRate = new PaymentArrangementRate();
    }
    
    @Test
    public void PaymentArrangementRate_Test()
    {
        paymentArrangementRate.setPaymentArrangementRateId( Long.valueOf( 1 ) );
        paymentArrangementRate.setCoorporateEntityCode( "NM" );
        paymentArrangementRate.setMemberSubjectId( "U32" );
        paymentArrangementRate.setPaymentArrangementId( Long.valueOf( 1 ) );
        paymentArrangementRate.setPaymentTypeCode( "CAP" );
        paymentArrangementRate.setRateName( "FEMALE LESS THAN 18" );
        paymentArrangementRate.setRateTypeCode( "FLT" );
        paymentArrangementRate.setVbrPayeeId( Long.valueOf( 1 ) );
    
        Assert.assertTrue( paymentArrangementRate != null );
        Assert.assertEquals( Long.valueOf( 1 ),
                             paymentArrangementRate.getPaymentArrangementRateId() );
        Assert.assertEquals( "NM",
                             paymentArrangementRate.getCoorporateEntityCode() );
        Assert.assertEquals( "U32",
                             paymentArrangementRate.getMemberSubjectId() );
        Assert.assertEquals( Long.valueOf( 1 ),
                             paymentArrangementRate.getPaymentArrangementId() );
        Assert.assertEquals( "CAP",
                             paymentArrangementRate.getPaymentTypeCode() );
        Assert.assertEquals( "FEMALE LESS THAN 18",
                             paymentArrangementRate.getRateName() );
        Assert.assertEquals( "FLT",
                             paymentArrangementRate.getRateTypeCode() );
        Assert.assertEquals( Long.valueOf( 1 ),
                             paymentArrangementRate.getVbrPayeeId() );
        Assert.assertTrue( paymentArrangementRate.toString().contains( "paymentArrangementRateId=1" ) );
    }*/
}
