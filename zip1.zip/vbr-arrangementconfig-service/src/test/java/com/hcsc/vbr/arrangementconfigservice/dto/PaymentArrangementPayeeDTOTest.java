package com.hcsc.vbr.arrangementconfigservice.dto;

public class PaymentArrangementPayeeDTOTest
{

    /* private PaymentArrangementPayeeDTO paymentArrangementPayeeDto;
    
    @Before
    public void setUp()
    {
        paymentArrangementPayeeDto = new PaymentArrangementPayeeDTO();
    }
    
    @Test
    public void testArrangementPayee()
    {
        paymentArrangementPayeeDto.setPaymentArrangementRateId( Long.valueOf( "1" ) );
        paymentArrangementPayeeDto.setCorporateEntityCode( "IL1" );
        paymentArrangementPayeeDto.setMemberSubjectId( "MEM123" );
        paymentArrangementPayeeDto.setPaymentArrangementId( Long.valueOf( "1" ) );
        paymentArrangementPayeeDto.setPaymentTypeCode( "PAY123" );
        paymentArrangementPayeeDto.setRateName( "R1" );
        paymentArrangementPayeeDto.setRateTypeCode( "RATE123" );
        paymentArrangementPayeeDto.setVbrPayeeId( Long.valueOf( "1" ) );
    
        Assert.assertTrue( paymentArrangementPayeeDto != null );
        Assert.assertEquals( Long.valueOf( "1" ),
                             paymentArrangementPayeeDto.getPaymentArrangementRateId() );
        Assert.assertEquals( "IL1",
                             paymentArrangementPayeeDto.getCorporateEntityCode() );
        Assert.assertEquals( "MEM123",
                             paymentArrangementPayeeDto.getMemberSubjectId() );
        Assert.assertEquals( "PAY123",
                             paymentArrangementPayeeDto.getPaymentTypeCode() );
        Assert.assertEquals( "R1",
                             paymentArrangementPayeeDto.getRateName() );
        Assert.assertEquals( "RATE123",
                             paymentArrangementPayeeDto.getRateTypeCode() );
    
        Assert.assertEquals( Long.valueOf( "1" ),
                             paymentArrangementPayeeDto.getPaymentArrangementId() );
        Assert.assertEquals( Long.valueOf( "1" ),
                             paymentArrangementPayeeDto.getVbrPayeeId() );
    
        Assert.assertTrue( paymentArrangementPayeeDto.toString().contains( "paymentArrangementRateId=1" ) );
    
    }
    */
}
