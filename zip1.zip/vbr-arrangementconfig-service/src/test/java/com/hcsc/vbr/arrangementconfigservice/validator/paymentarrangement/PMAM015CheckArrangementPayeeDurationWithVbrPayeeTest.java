package com.hcsc.vbr.arrangementconfigservice.validator.paymentarrangement;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.boot.test.json.JacksonTester;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.hcsc.vbr.arrangementconfigservice.domain.PaymentArrangement;
import com.hcsc.vbr.arrangementconfigservice.domain.PaymentArrangementPayee;
import com.hcsc.vbr.arrangementconfigservice.domain.VbrPayee;
import com.hcsc.vbr.common.constant.VBRCommonConstant.RowActionTypes;
import com.hcsc.vbr.common.dto.ErrorMessageDTO;
import com.hcsc.vbr.common.dto.ReturnMessageDTO;

@RunWith( MockitoJUnitRunner.Silent.class )
public class PMAM015CheckArrangementPayeeDurationWithVbrPayeeTest
{
    @InjectMocks
    PMAM015CheckArrangementPayeeDurationWithVbrPayee pMAM015CheckArrangementPayeeDurationWithVbrPayee;

    @Before
    public void setUp()
    {
        MockitoAnnotations.initMocks( this );
        JacksonTester.initFields( this,
                                  new ObjectMapper() );

    }

    @Test
    public void validateArrangementPayeeDurationWithVbrPayeeSuccess() throws Exception
    {

        pMAM015CheckArrangementPayeeDurationWithVbrPayee.validateArrangementPayeeDurationWithVbrPayee( getVbrPayee(),
                                                                                                       getPaymnetArrPayee(),
                                                                                                       getPaymentArrangement(),
                                                                                                       LocalDate.now(),
                                                                                                       getReturnMessageDTO() );

    }

    private List<ErrorMessageDTO> getErrorMessageDTOSuccess() throws Exception
    {
        List<ErrorMessageDTO> errors = new ArrayList<ErrorMessageDTO>();
        ErrorMessageDTO errorMessageDTO = new ErrorMessageDTO();

        errorMessageDTO.setErrorMessageCategoryCode( "PCF-PMAM" );
        errorMessageDTO.setErrorMessageId( new Long( 226 ) );
        errorMessageDTO.setErrorMsgDescriptionText( "Payment Type Is Required" );
        errorMessageDTO.setSeveritylevel( "E" );
        errors.add( errorMessageDTO );
        return errors;

    }

    private ReturnMessageDTO getReturnMessageDTO() throws Exception
    {
        ReturnMessageDTO returnMessage = new ReturnMessageDTO();

        returnMessage.setItemName( "PCF-PMAM" );
        returnMessage.setStatus( "SUCCESS" );
        returnMessage.setErrors( getErrorMessageDTOSuccess() );
        return returnMessage;

    }

    private PaymentArrangement getPaymentArrangement()
    {

        PaymentArrangement paymentArrangementDTO = new PaymentArrangement();
        paymentArrangementDTO.setCorporateEntityCode( "NM1" );
        paymentArrangementDTO.setPaymentArrangementContractId( null );
        paymentArrangementDTO.setPaymentArrangementName( "PaymentArrangementNameTest" );
        paymentArrangementDTO.setArrangementFrequencyCode( "monthly" );
        paymentArrangementDTO.setPaymentArrangementTypeCode( "paymentArrangementTypeCodeTest" );
        paymentArrangementDTO.setPaymentArrangementDescription( "paymentArrangementDescriptionTest" );
        paymentArrangementDTO.setRecordEffectiveDate( LocalDate.now() );
        paymentArrangementDTO.setRecordEndDate( LocalDate.now() );
        paymentArrangementDTO.setCreateUserId( "U402537" );
        paymentArrangementDTO.setUpdateUserId( "U402537" );
        paymentArrangementDTO.setCreateRecordTimestamp( null );
        paymentArrangementDTO.setPaymentArrangementId( null );
        paymentArrangementDTO.setPaymentTypeCode( "paymentTypeCodeTest" );
        paymentArrangementDTO.setValidationStatusCode( null );
        paymentArrangementDTO.setPaymentArrangementId( null );
        paymentArrangementDTO.setRowAction( RowActionTypes.INSERT );
        paymentArrangementDTO.setRetroRuleSetups( null );
        paymentArrangementDTO.setPaymentArrangementHistories( null );
        paymentArrangementDTO.setPaymentArrangementRates( null );
        paymentArrangementDTO.setPaymentArrangementMemberSubjects( null );
        paymentArrangementDTO.setPaymentArrangementPayees( getPaymentArrangementPayees_success() );

        return paymentArrangementDTO;
    }

    private List<PaymentArrangementPayee> getPaymentArrangementPayees_success()
    {
        List<PaymentArrangementPayee> paymentArrangementPayees = new ArrayList<PaymentArrangementPayee>();
        PaymentArrangementPayee paymentArrangementPayeeDTO = new PaymentArrangementPayee();
        paymentArrangementPayeeDTO.setRecordEffectiveDate( LocalDate.now() );
        paymentArrangementPayeeDTO.setRecordEndDate( LocalDate.now() );
        paymentArrangementPayeeDTO.setCreateUserId( "U402537" );
        paymentArrangementPayeeDTO.setUpdateUserId( "U402537" );
        paymentArrangementPayeeDTO.setRowAction( RowActionTypes.NO_ACTION );
        paymentArrangementPayeeDTO.setPaymentArrangementId( null );
        paymentArrangementPayeeDTO.setVbrPayee( getVbrPayee() );
        paymentArrangementPayees.add( paymentArrangementPayeeDTO );

        PaymentArrangementPayee paymentArrangementPayeeDTO1 = new PaymentArrangementPayee();
        paymentArrangementPayeeDTO1.setRecordEffectiveDate( LocalDate.now() );
        paymentArrangementPayeeDTO1.setRecordEndDate( LocalDate.now() );
        paymentArrangementPayeeDTO1.setCreateUserId( "U402537" );
        paymentArrangementPayeeDTO1.setUpdateUserId( "U402537" );
        paymentArrangementPayeeDTO1.setRowAction( RowActionTypes.NO_ACTION );
        paymentArrangementPayeeDTO1.setPaymentArrangementId( null );
        paymentArrangementPayeeDTO1.setVbrPayee( getVbrPayee() );
        paymentArrangementPayees.add( paymentArrangementPayeeDTO1 );
        return paymentArrangementPayees;
    }

    private PaymentArrangementPayee getPaymnetArrPayee()
    {

        PaymentArrangementPayee paymentArrangementPayeeDTO1 = new PaymentArrangementPayee();
        paymentArrangementPayeeDTO1.setRecordEffectiveDate( LocalDate.now() );
        paymentArrangementPayeeDTO1.setRecordEndDate( LocalDate.now() );
        paymentArrangementPayeeDTO1.setCreateUserId( "U402537" );
        paymentArrangementPayeeDTO1.setUpdateUserId( "U402537" );
        paymentArrangementPayeeDTO1.setRowAction( RowActionTypes.NO_ACTION );
        paymentArrangementPayeeDTO1.setPaymentArrangementId( null );
        paymentArrangementPayeeDTO1.setVbrPayee( getVbrPayee() );
        return paymentArrangementPayeeDTO1;

    }

    private VbrPayee getVbrPayee()
    {
        VbrPayee vbrPayeeDTO = new VbrPayee();
        vbrPayeeDTO.setCorporateEntityCode( "NM1" );
        vbrPayeeDTO.setNetworkAssocProviderId( 772129222 );
        vbrPayeeDTO.setNetworkCode( "MCD" );
        vbrPayeeDTO.setPinGroupId( "RSK" );
        vbrPayeeDTO.setPayToPfinId( "00NMCAB001" );
        vbrPayeeDTO.setCapitationCode( "A1" );
        vbrPayeeDTO.setCapitationProcessCode( "CP" );
        vbrPayeeDTO.setPinGroupName( "RSK001" );
        vbrPayeeDTO.setTaxIdNumber( "999999999" );
        vbrPayeeDTO.setRecordEffectiveDate( LocalDate.now() );
        vbrPayeeDTO.setRecordEndDate( LocalDate.now() );
        vbrPayeeDTO.setCreateUserId( "U402537" );
        vbrPayeeDTO.setUpdateUserId( "U402537" );
        vbrPayeeDTO.setCreateRecordTimestamp( null );
        vbrPayeeDTO.setUpdateRecordTimestamp( null );
        vbrPayeeDTO.setRowAction( RowActionTypes.NO_ACTION );
        //        vbrPayeeDTO.setVbrPayeeId( 181 );
        return vbrPayeeDTO;
    }

}
