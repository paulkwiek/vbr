package com.hcsc.vbr.arrangementconfigservice.validator.payee;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnitRunner;

import com.hcsc.vbr.common.dto.ReturnMessageDTO;
import com.hcsc.vbr.web.request.PayeeSearchRequest;

@RunWith( MockitoJUnitRunner.class )
public class VBPY001ValidatePinGroupIdInSearchTest
{

    @InjectMocks
    private VBPY001ValidatePinGroupIdInSearch vbpy001ValidatePinGroupIdInSearch;

    @Test
    public void validatePinGroupId() throws Exception
    {

        vbpy001ValidatePinGroupIdInSearch.validatePinGroupId( getPayeeSearchRequest(),
                                                              getReturnMessageDTO() );
    }

    @Test( expected = NullPointerException.class )
    public void validatePinGroupId_Failure() throws Exception
    {

        vbpy001ValidatePinGroupIdInSearch.validatePinGroupId( getPayeeSearchRequest_Failure(),
                                                              getReturnMessageDTO() );
    }

    private PayeeSearchRequest getPayeeSearchRequest_Failure()
    {
        PayeeSearchRequest payeeSearchRequest = new PayeeSearchRequest();

        payeeSearchRequest.setCorpEntityCode( "NM1" );
        payeeSearchRequest.setPinGroupId( "RE1vgdhdbhcdcdhbcdhcdhjvjhcvdjcsdvhc" );

        return payeeSearchRequest;
    }

    private PayeeSearchRequest getPayeeSearchRequest()
    {
        PayeeSearchRequest payeeSearchRequest = new PayeeSearchRequest();

        payeeSearchRequest.setCorpEntityCode( "NM1" );
        payeeSearchRequest.setPinGroupId( "RE1" );

        return payeeSearchRequest;
    }

    private ReturnMessageDTO getReturnMessageDTO()
    {
        ReturnMessageDTO returnMessage = new ReturnMessageDTO();
        return returnMessage;
    }

}
