package com.hcsc.vbr.arrangementconfigservice.dto;

public class PaymentArrangementDTOTest
{
    /*  @Test
    public void testSetters()
    {
        PaymentArrangementDTO paymentDTO = new PaymentArrangementDTO();
        paymentDTO.setPaymentArrangementId( Long.valueOf( "1" ) );
        paymentDTO.setCorporateEntityCode( "CORPCODE12" );
        paymentDTO.setPaymentArrangementTypeCode( "AR123" );
        paymentDTO.setDescription( "Desc" );
        paymentDTO.setContractId( Long.valueOf( 1 ) );
        assertEquals( Long.valueOf( "1" ),
                      paymentDTO.getPaymentArrangementId() );
        assertEquals( "CORPCODE12",
                      paymentDTO.getCorporateEntityCode() );
        assertEquals( "AR123",
                      paymentDTO.getPaymentArrangementTypeCode() );
        assertEquals( "Desc",
                      paymentDTO.getDescription() );
        assertEquals( Long.valueOf( 1 ),
                      paymentDTO.getContractId() );
        assertTrue( paymentDTO.toString().contains( "paymentArrangementId=1" ) );
    
    }*/

}
