package com.hcsc.vbr.arrangementconfigservice.validator.ratename;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnitRunner;

import com.hcsc.vbr.arrangementconfigservice.domain.FlatRate;
import com.hcsc.vbr.arrangementconfigservice.domain.RateName;
import com.hcsc.vbr.arrangementconfigservice.domain.RateNameId;
import com.hcsc.vbr.common.dto.ReturnMessageDTO;

@RunWith( MockitoJUnitRunner.Silent.class )
public class RTNM010CheckRateEndDateIsLastDayOfMonthTest
{

    @InjectMocks
    private RTNM010CheckRateEndDateIsLastDayOfMonth rtnm010CheckRateEndDateIsLastDayOfMonth;

    @Test
    public void isLastDayOfMonth() throws Exception
    {

        rtnm010CheckRateEndDateIsLastDayOfMonth.isLastDayOfMonth( getRateName(),
                                                                  getReturnMessageDTO() );
    }

    @Test( expected = NullPointerException.class )
    public void isLastDayOfMonth_Failure() throws Exception
    {

        rtnm010CheckRateEndDateIsLastDayOfMonth.isLastDayOfMonth( getRateName_Failure(),
                                                                  getReturnMessageDTO() );
    }

    private RateName getRateName()
    {

        RateName rtnm = new RateName();
        RateNameId rtnmId = new RateNameId();
        rtnmId.setRateName( "SMOKE25" );
        rtnmId.setCorporateEntityCode( "NM1" );
        rtnm.setRateNameId( rtnmId );
        rtnm.setFlatRates( getflatrateList() );
        return rtnm;
    }

    private List<FlatRate> getflatrateList()
    {
        List<FlatRate> flatRateDTOlist = new ArrayList<FlatRate>();
        FlatRate flatRate = new FlatRate();
        flatRate.setRecordEffectiveDate( LocalDate.of( 2019,
                                                       11,
                                                       01 ) );
        flatRate.setRecordEndDate( LocalDate.of( 2019,
                                                 11,
                                                 30 ) );
        flatRateDTOlist.add( flatRate );

        return flatRateDTOlist;
    }

    private RateName getRateName_Failure()
    {

        RateName rtnm = new RateName();
        RateNameId rtnmId = new RateNameId();
        rtnmId.setRateName( "SMOKE25" );
        rtnmId.setCorporateEntityCode( "NM1" );
        rtnm.setRateNameId( rtnmId );
        rtnm.setFlatRates( getflatrateList_Failure() );
        return rtnm;
    }

    private List<FlatRate> getflatrateList_Failure()
    {
        List<FlatRate> flatRateDTOlist = new ArrayList<FlatRate>();
        FlatRate flatRate = new FlatRate();
        flatRate.setRecordEffectiveDate( LocalDate.of( 2019,
                                                       11,
                                                       02 ) );
        flatRate.setRecordEndDate( LocalDate.of( 2019,
                                                 11,
                                                 29 ) );
        flatRateDTOlist.add( flatRate );

        return flatRateDTOlist;
    }

    private ReturnMessageDTO getReturnMessageDTO()
    {
        ReturnMessageDTO returnMessage = new ReturnMessageDTO();
        return returnMessage;
    }
}
