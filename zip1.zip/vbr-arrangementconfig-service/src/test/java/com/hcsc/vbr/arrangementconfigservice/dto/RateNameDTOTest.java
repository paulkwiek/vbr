package com.hcsc.vbr.arrangementconfigservice.dto;

public class RateNameDTOTest
{
    /* @Test
    public void testSetters()
    {
    
        RateNameDTO ratenameDTO = new RateNameDTO();
        ratenameDTO.setRateName( "Vbrrate" );
        ratenameDTO.setCorporateEntityCode( "VBR1209" );
        ratenameDTO.setRateTypeCode( "ab123cd" );
    
        assertEquals( "VBR1209",
                      ratenameDTO.getCorporateEntityCode() );
        assertEquals( "Vbrrate",
                      ratenameDTO.getRateName() );
        assertEquals( "ab123cd",
                      ratenameDTO.getRateTypeCode() );
        assertTrue( ratenameDTO.toString().contains( "rateName=Vbrrate" ) );
    
    }*/
}
