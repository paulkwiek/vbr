package com.hcsc.vbr.arrangementconfigservice.validator.payee;

import java.time.LocalDate;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnitRunner;

import com.hcsc.vbr.arrangementconfigservice.domain.VbrPayee;
import com.hcsc.vbr.common.dto.ReturnMessageDTO;

@RunWith( MockitoJUnitRunner.Silent.class )
public class VBPY005ProviderAPIValidationsTest
{
    @InjectMocks
    private VBPY005ProviderAPIValidations vbpy005ProviderAPIValidations;

    @Test
    public void providerAPIValidations() throws Exception
    {

        vbpy005ProviderAPIValidations.providerAPIValidations( getVbrPayee_Success(),
                                                              getReturnMessageDTO() );
    }

    @Test( expected = NullPointerException.class )
    public void providerAPIValidations_Failure() throws Exception
    {

        vbpy005ProviderAPIValidations.providerAPIValidations( getVbrPayee_Failure(),
                                                              getReturnMessageDTO() );
    }

    private VbrPayee getVbrPayee_Failure()
    {
        VbrPayee vbrPayee = new VbrPayee();

        vbrPayee.setNetworkAssociationEffectiveDate( "01/01/2019" );
        vbrPayee.setNetworkAssociationEndDate( "12/31/2019" );
        vbrPayee.setPfinEffectiveDate( "01/01/2019" );
        vbrPayee.setPfinEndDate( "12/31/2019" );
        vbrPayee.setPinGroupEffectiveDate( "01/01/2019" );
        vbrPayee.setPinGroupEndDate( "12/31/2019" );
        vbrPayee.setTinEffectiveDate( "02/22/2019" );
        vbrPayee.setTinEndDate( "02/21/2020" );
        vbrPayee.setRecordEffectiveDate( LocalDate.of( 2018,
                                                       11,
                                                       01 ) );
        vbrPayee.setRecordEndDate( LocalDate.of( 2019,
                                                 11,
                                                 30 ) );
        return vbrPayee;

    }

    private VbrPayee getVbrPayee_Success()
    {
        VbrPayee vbrPayee = new VbrPayee();

        vbrPayee.setNetworkAssociationEffectiveDate( "01/01/2019" );
        vbrPayee.setNetworkAssociationEndDate( "12/31/2019" );
        vbrPayee.setPfinEffectiveDate( "01/01/2019" );
        vbrPayee.setPfinEndDate( "12/31/2019" );
        vbrPayee.setPinGroupEffectiveDate( "01/01/2019" );
        vbrPayee.setPinGroupEndDate( "12/31/2019" );
        vbrPayee.setTinEffectiveDate( "02/22/2019" );
        vbrPayee.setTinEndDate( "02/21/2020" );
        vbrPayee.setRecordEffectiveDate( LocalDate.of( 2019,
                                                       11,
                                                       01 ) );
        vbrPayee.setRecordEndDate( LocalDate.of( 2019,
                                                 11,
                                                 30 ) );
        return vbrPayee;

    }

    private ReturnMessageDTO getReturnMessageDTO()
    {
        ReturnMessageDTO returnMessage = new ReturnMessageDTO();
        return returnMessage;
    }
}
