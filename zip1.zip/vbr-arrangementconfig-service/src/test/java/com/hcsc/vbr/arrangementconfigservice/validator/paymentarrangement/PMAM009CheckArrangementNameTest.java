package com.hcsc.vbr.arrangementconfigservice.validator.paymentarrangement;

import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import com.hcsc.vbr.arrangementconfigservice.domain.PaymentArrangement;
import com.hcsc.vbr.arrangementconfigservice.service.PaymentArrangementService;
import com.hcsc.vbr.common.dto.ErrorMessageDTO;
import com.hcsc.vbr.common.dto.ReturnMessageDTO;

@RunWith( MockitoJUnitRunner.class )
public class PMAM009CheckArrangementNameTest
{

    @InjectMocks
    private PMAM009CheckArrangementName pmam009CheckArrangementName;

    @Mock
    private PaymentArrangementService paymentArrangementService;

    @Test
    public void validateArrangementName_Pass() throws Exception
    {
        PaymentArrangement paymentArrangementDTO = new PaymentArrangement();
        paymentArrangementDTO.setPaymentArrangementName( "Arrangement1" );

        when( paymentArrangementService.findByArrangementName( any() ) ).thenReturn( true );

        boolean isFailing = pmam009CheckArrangementName.validateArrangementName( paymentArrangementDTO,
                                                                                 getReturnMessageDTO() );
        assertEquals( true,
                      isFailing );
    }

    @Test( expected = NullPointerException.class )
    public void validateArrangementName_Fail() throws Exception
    {
        PaymentArrangement paymentArrangementDTO = new PaymentArrangement();
        paymentArrangementDTO.setPaymentArrangementName( "@ArrangementFAilsin Any of the Aspects" );

        boolean isFailing = pmam009CheckArrangementName.validateArrangementName( paymentArrangementDTO,
                                                                                 getReturnMessageDTO() );
        assertEquals( true,
                      isFailing );
    }

    private List<ErrorMessageDTO> getErrorMessageDTOSuccess() throws Exception
    {
        List<ErrorMessageDTO> errors = new ArrayList<ErrorMessageDTO>();
        ErrorMessageDTO errorMessageDTO = new ErrorMessageDTO();

        errorMessageDTO.setErrorMessageCategoryCode( "PCF-PMAM" );
        errorMessageDTO.setErrorMessageId( new Long( 226 ) );
        errorMessageDTO.setErrorMsgDescriptionText( "Payment Type Is Required" );
        errorMessageDTO.setSeveritylevel( "E" );
        errors.add( errorMessageDTO );
        return errors;

    }

    private ReturnMessageDTO getReturnMessageDTO() throws Exception
    {
        ReturnMessageDTO returnMessage = new ReturnMessageDTO();

        returnMessage.setItemName( "PCF-PMAM" );
        returnMessage.setStatus( "SUCCESS" );
        returnMessage.setErrors( getErrorMessageDTOSuccess() );
        return returnMessage;

    }
}