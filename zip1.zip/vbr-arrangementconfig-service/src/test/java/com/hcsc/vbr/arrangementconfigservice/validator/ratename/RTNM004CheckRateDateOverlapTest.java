package com.hcsc.vbr.arrangementconfigservice.validator.ratename;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import com.hcsc.vbr.arrangementconfigservice.domain.FlatRate;
import com.hcsc.vbr.arrangementconfigservice.domain.RateName;
import com.hcsc.vbr.arrangementconfigservice.domain.RateNameId;
import com.hcsc.vbr.arrangementconfigservice.repository.RateNameRepository;
import com.hcsc.vbr.common.constant.VBRCommonConstant.RowActionTypes;
import com.hcsc.vbr.common.dto.ReturnMessageDTO;

@RunWith( MockitoJUnitRunner.Silent.class )
public class RTNM004CheckRateDateOverlapTest
{
    @InjectMocks
    RTNM004CheckRateDateOverlap rtnm004CheckRateDateOverlap;

    @Mock
    RateNameRepository rateNameRepository;

    @Test
    public void validateRateDateOverlap() throws Exception
    {
        when( rateNameRepository.findByRateName( any() ) ).thenReturn( getRateName() );

        rtnm004CheckRateDateOverlap.validateRateDateOverlap( getRateName(),
                                                             getReturnMessageDTO() );

    }

    @Test
    public void validateRateDateOverlap_Failure() throws Exception
    {
        when( rateNameRepository.findByRateName( any() ) ).thenReturn( getRateName() );

        rtnm004CheckRateDateOverlap.validateRateDateOverlap( getRateName_Failure(),
                                                             getReturnMessageDTO() );

    }

    private RateName getRateName()
    {

        RateName rtnm = new RateName();
        RateNameId rtnmId = new RateNameId();
        rtnmId.setRateName( "SMOKE25" );
        rtnmId.setCorporateEntityCode( "NM1" );
        rtnm.setRateNameId( rtnmId );
        rtnm.setFlatRates( getflatrateList() );
        return rtnm;
    }

    private List<FlatRate> getflatrateList()
    {
        List<FlatRate> flatRateDTOlist = new ArrayList<FlatRate>();
        FlatRate flatRate = new FlatRate();
        flatRate.setFemaleFlatRateAmount( 456.53 );
        flatRate.setMaleFlatRateAmount( 845.34 );
        flatRate.setRecordEffectiveDate( LocalDate.of( 2019,
                                                       11,
                                                       01 ) );
        flatRate.setRecordEndDate( LocalDate.of( 2019,
                                                 11,
                                                 30 ) );
        flatRate.setRowAction( RowActionTypes.INSERT );
        flatRateDTOlist.add( flatRate );

        FlatRate flatRate1 = new FlatRate();
        flatRate1.setFemaleFlatRateAmount( 456.53 );
        flatRate1.setMaleFlatRateAmount( 845.34 );
        flatRate.setRowAction( RowActionTypes.UPDATE );
        flatRate1.setRecordEffectiveDate( LocalDate.of( 2019,
                                                        12,
                                                        01 ) );
        flatRate1.setRecordEndDate( LocalDate.of( 2019,
                                                  12,
                                                  31 ) );
        flatRateDTOlist.add( flatRate1 );
        return flatRateDTOlist;
    }

    private RateName getRateName_Failure()
    {

        RateName rtnm = new RateName();
        RateNameId rtnmId = new RateNameId();
        rtnmId.setRateName( "SMOKE25" );
        rtnmId.setCorporateEntityCode( "NM1" );
        rtnm.setRateNameId( rtnmId );
        rtnm.setFlatRates( getflatrateList_Failure() );
        return rtnm;
    }

    private List<FlatRate> getflatrateList_Failure()
    {
        List<FlatRate> flatRateDTOlist = new ArrayList<FlatRate>();
        FlatRate flatRate = new FlatRate();
        flatRate.setRowAction( RowActionTypes.INSERT );
        flatRate.setRecordEffectiveDate( LocalDate.of( 2019,
                                                       12,
                                                       01 ) );
        flatRate.setRecordEndDate( LocalDate.of( 2019,
                                                 12,
                                                 31 ) );
        FlatRate flatRate1 = new FlatRate();
        flatRate.setRowAction( RowActionTypes.UPDATE );
        flatRate1.setRecordEffectiveDate( LocalDate.of( 2019,
                                                        12,
                                                        01 ) );
        flatRate1.setRecordEndDate( LocalDate.of( 2019,
                                                  12,
                                                  31 ) );
        flatRateDTOlist.add( flatRate );
        flatRateDTOlist.add( flatRate1 );

        return flatRateDTOlist;
    }

    private ReturnMessageDTO getReturnMessageDTO()
    {
        ReturnMessageDTO returnMessage = new ReturnMessageDTO();
        return returnMessage;
    }
}
