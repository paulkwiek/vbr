package com.hcsc.vbr.arrangementconfigservice.validator.paymentarrangement;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnitRunner;

import com.hcsc.vbr.arrangementconfigservice.domain.PaymentArrangement;
import com.hcsc.vbr.common.dto.ReturnMessageDTO;

@RunWith( MockitoJUnitRunner.class )
public class PMAM026CheckPaymentArrangementPaymentTypeCodeTest
{
    @InjectMocks
    private PMAM026CheckPaymentArrangementPaymentTypeCode pmam026CheckPaymentArrangementPaymentTypeCode;

    @Test
    public void checkArrangementPaymentTypeCode_success() throws Exception
    {
        pmam026CheckPaymentArrangementPaymentTypeCode.validateArrangementPaymentTypeCode( getPaymentArrangement(),
                                                                                          getreturnMessageDTO() );
    }

    @Test( expected = NullPointerException.class )
    public void checkArrangementPaymentTypeCode_null() throws Exception
    {

        pmam026CheckPaymentArrangementPaymentTypeCode.validateArrangementPaymentTypeCode( getPaymentArrangement_fail(),
                                                                                          getreturnMessageDTO() );
    }

    private PaymentArrangement getPaymentArrangement()
    {

        PaymentArrangement paymentArrangementDTO = new PaymentArrangement();

        paymentArrangementDTO.setPaymentTypeCode( "paymentTypeCodeTest" );

        return paymentArrangementDTO;
    }

    private PaymentArrangement getPaymentArrangement_fail()
    {

        PaymentArrangement paymentArrangementDTO = new PaymentArrangement();

        paymentArrangementDTO.setPaymentTypeCode( null );

        return paymentArrangementDTO;
    }

    private ReturnMessageDTO getreturnMessageDTO()
    {
        ReturnMessageDTO returnMessage = new ReturnMessageDTO();

        return returnMessage;
    }

}
