package com.hcsc.vbr.arrangementconfigservice.validator.paymentarrangement;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.boot.test.json.JacksonTester;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.hcsc.vbr.arrangementconfigservice.apiclient.CalculationServiceApiClient;
import com.hcsc.vbr.arrangementconfigservice.domain.PaymentArrangement;
import com.hcsc.vbr.arrangementconfigservice.domain.PaymentArrangementMemberSubject;
import com.hcsc.vbr.arrangementconfigservice.domain.PaymentArrangementPayee;
import com.hcsc.vbr.arrangementconfigservice.domain.PaymentArrangementRate;
import com.hcsc.vbr.arrangementconfigservice.domain.VbrPayee;
import com.hcsc.vbr.arrangementconfigservice.dto.PaymentArrangementPayeeDTO;
import com.hcsc.vbr.arrangementconfigservice.dto.VbrPayeeDTO;
import com.hcsc.vbr.arrangementconfigservice.mapper.PaymentArrangementMapper;
import com.hcsc.vbr.arrangementconfigservice.repository.FlatRateRepository;
import com.hcsc.vbr.arrangementconfigservice.validator.base.BaseValidator;
import com.hcsc.vbr.common.constant.VBRCommonConstant.RowActionTypes;
import com.hcsc.vbr.common.dto.ReturnMessageDTO;
import com.hcsc.vbr.common.exception.VbrApplicationException;
import com.hcsc.vbr.web.request.ValidateArrangementPayeeRequest;
import com.hcsc.vbr.web.response.PayeeRetrieveResponse;

@RunWith( MockitoJUnitRunner.Silent.class )
public class PaymentArrangementValidatorTest extends BaseValidator
{
    @InjectMocks
    PaymentArrangementValidator paymentArrangementValidator;

    @Mock
    private CalculationServiceApiClient calculationServiceApiClient;

    @Mock
    private PMAM002CheckFrequencyCode pmam002CheckFrequencyCode;

    @Mock
    private PMAM003CheckGapInArrangmentPayeeEffEndDates pmam003CheckGapInArrangmentPayeeEffEndDates;

    @Mock
    private PMAM004CheckOverlapInArrangmentPayeeEffEndDates pmam004CheckOverlapInArrangmentPayeeEffEndDates;

    @Mock
    private PMAM005CheckArrangementDurationWithArrangementPayee pmam005CheckArrangementDurationWithArrangementPayee;

    @Mock
    private PMAM006CheckArrangementPayeeVBRPayeeProviderDates pmam006CheckArrangementPayeeVBRPayeeProviderDates;

    @Mock
    private PMAM007CheckPaymentArrangementPayeeEffectiveAndEndDates pmam007CheckPaymentArrangementPayeeEffectiveAndEndDates;

    @Mock
    private PMAM009CheckArrangementName pmam009CheckArrangementName;

    @Mock
    private PMAM010CheckArrangementDescription pmam010CheckArrangementDescription;

    @Mock
    private PMAM011CheckArrangementDurationWithArrangementRate pmam011CheckArrangementDurationWithArrangementRate;

    @Mock
    private PMAM013CheckArrangementPayeeValidForProcessingMonth pmam013CheckArrangementPayeeValidForProcessingMonth;

    @Mock
    private PMAM014CheckArrangementRateValidForProcessingMonth pmam014CheckArrangementRateValidForProcessingMonth;

    @Mock
    private PMAM015CheckArrangementPayeeDurationWithVbrPayee pmam015CheckArrangementPayeeDurationWithVbrPayee;

    @Mock
    private PMAM016CheckArrangementRateDurationWithFlatRates pmam016CheckArrangementRateDurationWithFlatRates;

    @Mock
    private FlatRateRepository flatRateRepository;

    @Mock
    private PMAM017CheckGapInArrangementRateEffEndDates pmam017CheckGapInArrangementRateEffEndDates;

    @Mock
    private PMAM018CheckOverlapInArrangementRateEffEndDates pmam018CheckOverlapInArrangementRateEffEndDates;

    @Mock
    private PMAM019CheckValidationStatusCode pmam019CheckValidationStatusCode;

    @Mock
    private PMAM020CheckPaymentArrangementSubject pmam020CheckPaymentArrangementSubject;

    @Mock
    private PMAM021CheckPaymentArrangementRate pmam021CheckPaymentArrangementRate;

    @Mock
    private PMAM022CheckPaymentArrangementPayee pmam022CheckPaymentArrangementPayee;

    @Mock
    private PMAM023CheckDuplicateVbrPayee pmam023CheckDuplicateVbrPayee;

    @Mock
    private PMAM025CheckArrangementRateEffEndDates pmam025CheckArrangementRateEffEndDates;

    @Mock
    private PMAM026CheckPaymentArrangementPaymentTypeCode pmam026CheckPaymentArrangementPaymentTypeCode;

    @Mock
    private PMAM027CheckArrangementMemberSubject pmam027CheckArrangementMemberSubject;

    @Mock
    private PMAM030CheckPaymentArrangementExpiredStatus pmam030CheckPaymentArrangementExpiredStatus;

    @Mock
    private PMAM029CheckForNullPaymentArrangementPayeeDuration pmam029CheckForNullPaymentArrangementPayeeDuration;

    @Mock
    private PMAM031ValidatePaymentArrangementStatus pmam031ValidatePaymentArrangementStatus;

    @Mock
    private PMAM032CheckMemberSubjectFieldLOB pmam032CheckMemberSubjectFieldLOB;

    @Mock
    private PMAM033CheckMemberSubjectFieldContractId pmam033CheckMemberSubjectFieldContractId;

    @Mock
    private PMAM036CheckArrangementDuration pmam036CheckArrangementDuration;

    @Mock
    private PMAM040CheckArrangementPayeeDurationWithVbrPayee pmam040CheckArrangementPayeeDurationWithVbrPayee;

    @Mock
    private PMAM041CheckPaymentArrangementPayeeEffectiveAndEndDates pmam041CheckPaymentArrangementPayeeEffectiveAndEndDates;

    @Mock
    private PMAM042CheckCompareArrangementPayeeEffectiveAndEndDate pmam042CheckCompareArrangementPayeeEffectiveAndEndDate;

    @Mock
    private PMAM044CheckRetrieveArrangement pmam044CheckRetrieveArrangement;

    @Mock
    private PMAM045CheckRetrievePayee pmam045CheckRetrievePayee;

    @Mock
    private PMAM046CheckPremierProviderResponse pmam046CheckPremierProviderResponse;

    @Mock
    private PMAM047CheckFetchArrangements pmam047CheckFetchArrangements;

    @Mock
    private PaymentArrangementMapper paymentArrangementMapper;

    @Before
    public void setUp()
    {
        MockitoAnnotations.initMocks( this );
        JacksonTester.initFields( this,
                                  new ObjectMapper() );

    }

    private ReturnMessageDTO getReturnMessageDTO() throws Exception
    {
        ReturnMessageDTO returnMessage = new ReturnMessageDTO();

        returnMessage.setItemName( "PCF-PMAM" );
        returnMessage.setStatus( "SUCCESS" );
        return returnMessage;

    }

    @Test
    public void validateSave_test1() throws Exception
    {

        when( pmam009CheckArrangementName.validateArrangementName( any(),
                                                                   any() ) ).thenReturn( Boolean.TRUE );
        when( pmam002CheckFrequencyCode.validateFrequencyCode( any(),
                                                               any() ) ).thenReturn( Boolean.TRUE );

        when( pmam010CheckArrangementDescription.validateArrangementDescription( any(),
                                                                                 any() ) ).thenReturn( Boolean.TRUE );

        when( pmam026CheckPaymentArrangementPaymentTypeCode.validateArrangementPaymentTypeCode( any(),
                                                                                                any() ) ).thenReturn( Boolean.TRUE );
        when( pmam036CheckArrangementDuration.validateArrangementDuration( any(),
                                                                           any() ) ).thenReturn( Boolean.TRUE );

        //        List<PaymentArrangementPayee> paymentArrangementPayees = getPaymentArrangement().getPaymentArrangementPayees();
        //        List<PaymentArrangementRate> paymentArrangementRates = getPaymentArrangement().getPaymentArrangementRates();
        //        when( paymentArrangementValidator.validateArrangementForMandatoryFields( getPaymentArrangement(),
        //                                                                                 getReturnMessageDTO() ) ).thenReturn( Boolean.TRUE );

        when( calculationServiceApiClient.getCurrentProcessingMonth( any() ) ).thenReturn( LocalDate.now() );

        when( pmam020CheckPaymentArrangementSubject.validatePaymentArrangementSubject( any(),
                                                                                       any() ) ).thenReturn( Boolean.TRUE );
        when( pmam021CheckPaymentArrangementRate.validatePaymentArrangementRate( any(),
                                                                                 any() ) ).thenReturn( Boolean.TRUE );

        when( pmam022CheckPaymentArrangementPayee.validatePaymentArrangementPayees( any(),
                                                                                    any() ) ).thenReturn( Boolean.TRUE );

        when( pmam029CheckForNullPaymentArrangementPayeeDuration.isPaymentArrangementPayeeDatesEmpty( any(),
                                                                                                      any() ) )
                                                                                                              .thenReturn( Boolean.TRUE );

        when( pmam023CheckDuplicateVbrPayee.validateVbrPaye( any(),
                                                             any() ) ).thenReturn( Boolean.TRUE );

        when( pmam005CheckArrangementDurationWithArrangementPayee.validateArrangementDurationWithArrangementPayee( any(),
                                                                                                                   any(),
                                                                                                                   any(),
                                                                                                                   any() ) )
                                                                                                                           .thenReturn( Boolean.TRUE );

        when( pmam006CheckArrangementPayeeVBRPayeeProviderDates.validateArrangementPayeeVBRPayeeDates( any(),
                                                                                                       any(),
                                                                                                       any() ) )
                                                                                                               .thenReturn( Boolean.TRUE );

        when( pmam013CheckArrangementPayeeValidForProcessingMonth.validateArrangementPayeeForProcessingMonth( any(),
                                                                                                              any(),
                                                                                                              any(),
                                                                                                              any() ) )
                                                                                                                      .thenReturn( Boolean.TRUE );

        when( pmam007CheckPaymentArrangementPayeeEffectiveAndEndDates.validatePaymentArrangementPayeeEffectiveAndEndDates( any(),
                                                                                                                           any() ) )
                                                                                                                                   .thenReturn( Boolean.TRUE );

        when( pmam025CheckArrangementRateEffEndDates.validateArrangementRateEffEndDates( any(),
                                                                                         any(),
                                                                                         any(),
                                                                                         any() ) ).thenReturn( Boolean.TRUE );

        when( pmam011CheckArrangementDurationWithArrangementRate.validateArrangementDurationWithArrangementRate( any(),
                                                                                                                 any(),
                                                                                                                 any(),
                                                                                                                 any() ) )
                                                                                                                         .thenReturn( Boolean.TRUE );

        when( pmam014CheckArrangementRateValidForProcessingMonth.validateArrangementRateForProcessingMonth( any(),
                                                                                                            any(),
                                                                                                            any(),
                                                                                                            any(),
                                                                                                            any() ) )
                                                                                                                    .thenReturn( Boolean.TRUE );

        when( pmam027CheckArrangementMemberSubject.checkArrangementMemberSubject( any(),
                                                                                  any() ) ).thenReturn( Boolean.TRUE );

        when( pmam032CheckMemberSubjectFieldLOB.checkArrangementMemberSubjectLOB( any(),
                                                                                  any() ) ).thenReturn( Boolean.TRUE );

        when( pmam033CheckMemberSubjectFieldContractId.checkArrangementMemberSubjectContractId( any(),
                                                                                                any() ) ).thenReturn( Boolean.TRUE );

        //        when( pmam019CheckValidationStatusCode.getValidationStatusCode( any(),
        //                                                                        any(),
        //                                                                        any(),
        //                                                                        any(),
        //                                                                        any() ) ).thenReturn( "EX" );

        when( pmam030CheckPaymentArrangementExpiredStatus.setWarningForExpiredArrangement( any(),
                                                                                           any() ) ).thenReturn( Boolean.TRUE );

        paymentArrangementValidator.validateSave( getPaymentArrangement(),
                                                  getReturnMessageDTO() );
    }

    @Test( expected = VbrApplicationException.class )
    public void validateSave_test2() throws Exception
    {

        when( calculationServiceApiClient.getCurrentProcessingMonth( any() ) ).thenReturn( LocalDate.now() );

        when( pmam020CheckPaymentArrangementSubject.validatePaymentArrangementSubject( any(),
                                                                                       any() ) ).thenReturn( Boolean.FALSE );
        when( pmam021CheckPaymentArrangementRate.validatePaymentArrangementRate( any(),
                                                                                 any() ) ).thenReturn( Boolean.FALSE );

        when( pmam022CheckPaymentArrangementPayee.validatePaymentArrangementPayees( any(),
                                                                                    any() ) ).thenReturn( Boolean.FALSE );

        when( pmam029CheckForNullPaymentArrangementPayeeDuration.isPaymentArrangementPayeeDatesEmpty( any(),
                                                                                                      any() ) )
                                                                                                              .thenReturn( Boolean.FALSE );

        when( pmam023CheckDuplicateVbrPayee.validateVbrPaye( any(),
                                                             any() ) ).thenReturn( Boolean.FALSE );

        when( pmam005CheckArrangementDurationWithArrangementPayee.validateArrangementDurationWithArrangementPayee( any(),
                                                                                                                   any(),
                                                                                                                   any(),
                                                                                                                   any() ) )
                                                                                                                           .thenReturn( Boolean.FALSE );

        when( pmam006CheckArrangementPayeeVBRPayeeProviderDates.validateArrangementPayeeVBRPayeeDates( any(),
                                                                                                       any(),
                                                                                                       any() ) )
                                                                                                               .thenReturn( Boolean.FALSE );

        when( pmam013CheckArrangementPayeeValidForProcessingMonth.validateArrangementPayeeForProcessingMonth( any(),
                                                                                                              any(),
                                                                                                              any(),
                                                                                                              any() ) )
                                                                                                                      .thenReturn( Boolean.FALSE );

        when( pmam007CheckPaymentArrangementPayeeEffectiveAndEndDates.validatePaymentArrangementPayeeEffectiveAndEndDates( any(),
                                                                                                                           any() ) )
                                                                                                                                   .thenReturn( Boolean.FALSE );

        when( pmam025CheckArrangementRateEffEndDates.validateArrangementRateEffEndDates( any(),
                                                                                         any(),
                                                                                         any(),
                                                                                         any() ) ).thenReturn( Boolean.FALSE );

        when( pmam011CheckArrangementDurationWithArrangementRate.validateArrangementDurationWithArrangementRate( any(),
                                                                                                                 any(),
                                                                                                                 any(),
                                                                                                                 any() ) )
                                                                                                                         .thenReturn( Boolean.FALSE );

        when( pmam014CheckArrangementRateValidForProcessingMonth.validateArrangementRateForProcessingMonth( any(),
                                                                                                            any(),
                                                                                                            any(),
                                                                                                            any(),
                                                                                                            any() ) )
                                                                                                                    .thenReturn( Boolean.FALSE );

        when( pmam027CheckArrangementMemberSubject.checkArrangementMemberSubject( any(),
                                                                                  any() ) ).thenReturn( Boolean.FALSE );

        when( pmam032CheckMemberSubjectFieldLOB.checkArrangementMemberSubjectLOB( any(),
                                                                                  any() ) ).thenReturn( Boolean.FALSE );

        when( pmam033CheckMemberSubjectFieldContractId.checkArrangementMemberSubjectContractId( any(),
                                                                                                any() ) ).thenReturn( Boolean.FALSE );

        //        when( pmam019CheckValidationStatusCode.getValidationStatusCode( any(),
        //                                                                        any(),
        //                                                                        any(),
        //                                                                        any(),
        //                                                                        any() ) ).thenReturn( "EX" );

        when( pmam030CheckPaymentArrangementExpiredStatus.setWarningForExpiredArrangement( any(),
                                                                                           any() ) ).thenReturn( Boolean.FALSE );

        paymentArrangementValidator.validateSave( getPaymentArrangement(),
                                                  getReturnMessageDTO() );
    }

    @Test
    public void validateArrangementForMandatoryFields_test() throws Exception
    {

        when( pmam009CheckArrangementName.validateArrangementName( any(),
                                                                   any() ) ).thenReturn( Boolean.TRUE );
        when( pmam002CheckFrequencyCode.validateFrequencyCode( any(),
                                                               any() ) ).thenReturn( Boolean.TRUE );

        when( pmam010CheckArrangementDescription.validateArrangementDescription( any(),
                                                                                 any() ) ).thenReturn( Boolean.TRUE );

        when( pmam026CheckPaymentArrangementPaymentTypeCode.validateArrangementPaymentTypeCode( any(),
                                                                                                any() ) ).thenReturn( Boolean.TRUE );
        when( pmam036CheckArrangementDuration.validateArrangementDuration( any(),
                                                                           any() ) ).thenReturn( Boolean.TRUE );

        paymentArrangementValidator.validateArrangementForMandatoryFields( any(),
                                                                           any() );
    }

    @Test( expected = VbrApplicationException.class )
    public void validateArrangementPayeeDatestest_success() throws Exception
    {

        when( paymentArrangementMapper.toPaymentArrangementPayee( any() ) ).thenReturn( getPaymentArrangementPayee() );
        when( pmam041CheckPaymentArrangementPayeeEffectiveAndEndDates.validateArrangementPayeeEffectiveAndEndDate( any(),
                                                                                                                   any() ) )
                                                                                                                           .thenReturn( Boolean.TRUE );
        when( pmam042CheckCompareArrangementPayeeEffectiveAndEndDate.compareArrangementPayeeEffectiveAndEndDate( any(),
                                                                                                                 any() ) )
                                                                                                                         .thenReturn( Boolean.TRUE );

        when( pmam040CheckArrangementPayeeDurationWithVbrPayee.validateArrangementPayeeDatesWithVbrPayee( any(),
                                                                                                          any(),
                                                                                                          any() ) )
                                                                                                                  .thenReturn( Boolean.TRUE );

        paymentArrangementValidator.validateArrangementPayeeDates( getValidateArrangementPayeeReq(),
                                                                   getReturnMessageDTO() );
    }

    @Test
    public void validateArrangementPayeeDatestest_failure() throws Exception
    {
        when( paymentArrangementMapper.toPaymentArrangementPayee( any() ) ).thenReturn( getPaymentArrangementPayee() );
        when( pmam041CheckPaymentArrangementPayeeEffectiveAndEndDates.validateArrangementPayeeEffectiveAndEndDate( any(),
                                                                                                                   any() ) )
                                                                                                                           .thenReturn( Boolean.FALSE );
        when( pmam042CheckCompareArrangementPayeeEffectiveAndEndDate.compareArrangementPayeeEffectiveAndEndDate( any(),
                                                                                                                 any() ) )
                                                                                                                         .thenReturn( Boolean.FALSE );

        when( pmam040CheckArrangementPayeeDurationWithVbrPayee.validateArrangementPayeeDatesWithVbrPayee( any(),
                                                                                                          any(),
                                                                                                          any() ) )
                                                                                                                  .thenReturn( Boolean.FALSE );

        paymentArrangementValidator.validateArrangementPayeeDates( getValidateArrangementPayeeReq(),
                                                                   getReturnMessageDTO() );
    }

    @Test
    public void validateRetrieveArrangementTest_success() throws Exception
    {

        when( pmam044CheckRetrieveArrangement.validateRetrieveArrangement( any(),
                                                                           any() ) ).thenReturn( Boolean.TRUE );

        paymentArrangementValidator.validateRetrieveArrangement( getPaymentArrangement(),
                                                                 getReturnMessageDTO() );
    }

    @Test( expected = VbrApplicationException.class )
    public void validateRetrieveArrangementTest_failure() throws Exception
    {

        when( pmam044CheckRetrieveArrangement.validateRetrieveArrangement( any(),
                                                                           any() ) ).thenReturn( Boolean.FALSE );

        paymentArrangementValidator.validateRetrieveArrangement( getPaymentArrangement(),
                                                                 getReturnMessageDTO() );
    }

    @Test
    public void validateRetrievePayeeTest_success() throws Exception
    {

        when( pmam045CheckRetrievePayee.validateRetrievePayee( any(),
                                                               any() ) ).thenReturn( Boolean.TRUE );

        paymentArrangementValidator.validateRetrievePayee( getVbrPayees(),
                                                           getReturnMessageDTO() );
    }

    @Test( expected = VbrApplicationException.class )
    public void validateRetrievePayeeTest_failure() throws Exception
    {

        when( pmam045CheckRetrievePayee.validateRetrievePayee( any(),
                                                               any() ) ).thenReturn( Boolean.FALSE );

        paymentArrangementValidator.validateRetrievePayee( getVbrPayees(),
                                                           getReturnMessageDTO() );
    }

    @Test
    public void validateMatchingPremierProviderResponseTest_success() throws Exception
    {

        when( pmam046CheckPremierProviderResponse.validatePremierProviderResponse( any(),
                                                                                   any() ) ).thenReturn( Boolean.TRUE );

        paymentArrangementValidator.validateMatchingPremierProviderResponse( getPayeeRetrieveResponse(),
                                                                             getReturnMessageDTO() );
    }

    @Test( expected = VbrApplicationException.class )
    public void validateMatchingPremierProviderResponseTest_failure() throws Exception
    {

        when( pmam046CheckPremierProviderResponse.validatePremierProviderResponse( any(),
                                                                                   any() ) ).thenReturn( Boolean.FALSE );

        paymentArrangementValidator.validateMatchingPremierProviderResponse( getPayeeRetrieveResponse(),
                                                                             getReturnMessageDTO() );
    }

    @Test( expected = VbrApplicationException.class )
    public void validateArrangementStatus_test1() throws Exception
    {

        paymentArrangementValidator.validateArrangementStatus( getPaymentArrangement(),
                                                               getReturnMessageDTO() );
    }

    @Test( expected = VbrApplicationException.class )
    public void validateRetrieveArrangements_test1() throws Exception
    {

        when( pmam047CheckFetchArrangements.validateFetchArrangements( getPaymenetArrangements(),
                                                                       getReturnMessageDTO() ) ).thenReturn( Boolean.TRUE );

        paymentArrangementValidator.validateRetrieveArrangements( getPaymenetArrangements(),
                                                                  getReturnMessageDTO() );
    }

    @Test
    public void validateRetrieveArrangementsTest() throws Exception
    {

        when( pmam047CheckFetchArrangements.validateFetchArrangements( any(),
                                                                       any() ) ).thenReturn( Boolean.TRUE );

        paymentArrangementValidator.validateRetrieveArrangements( getPaymenetArrangements(),
                                                                  getReturnMessageDTO() );
    }

    private PaymentArrangement getPaymentArrangement()
    {

        PaymentArrangement paymentArrangementDTO = new PaymentArrangement();
        paymentArrangementDTO.setCorporateEntityCode( "NM1" );
        paymentArrangementDTO.setPaymentArrangementContractId( null );
        paymentArrangementDTO.setPaymentArrangementName( "PaymentArrangementNameTest" );
        paymentArrangementDTO.setArrangementFrequencyCode( "monthly" );
        paymentArrangementDTO.setPaymentArrangementTypeCode( "paymentArrangementTypeCodeTest" );
        paymentArrangementDTO.setPaymentArrangementDescription( "paymentArrangementDescriptionTest" );
        paymentArrangementDTO.setRecordEffectiveDate( LocalDate.now() );
        paymentArrangementDTO.setRecordEndDate( LocalDate.now() );
        paymentArrangementDTO.setCreateUserId( "U402537" );
        paymentArrangementDTO.setUpdateUserId( "U402537" );
        paymentArrangementDTO.setCreateRecordTimestamp( null );
        paymentArrangementDTO.setPaymentArrangementId( null );
        paymentArrangementDTO.setPaymentTypeCode( "paymentTypeCodeTest" );
        paymentArrangementDTO.setValidationStatusCode( null );
        paymentArrangementDTO.setPaymentArrangementId( null );
        paymentArrangementDTO.setRowAction( RowActionTypes.INSERT );
        paymentArrangementDTO.setRetroRuleSetups( null );
        paymentArrangementDTO.setPaymentArrangementHistories( null );
        paymentArrangementDTO.setPaymentArrangementRates( getPaymentArrangementRates() );
        paymentArrangementDTO.setPaymentArrangementMemberSubjects( getPaymentArrangementMemberSubjects() );
        paymentArrangementDTO.setPaymentArrangementPayees( getPaymentArrangementPayees() );
        paymentArrangementDTO.setOverwriteSaveArrangement( "true" );

        return paymentArrangementDTO;
    }

    private List<PaymentArrangement> getPaymenetArrangements()
    {
        List<PaymentArrangement> paymentArrangements = new ArrayList<>();
        paymentArrangements.add( getPaymentArrangement() );
        return paymentArrangements;
    }

    private List<PaymentArrangementRate> getPaymentArrangementRates()
    {
        List<PaymentArrangementRate> paymentArrangementRates = new ArrayList<PaymentArrangementRate>();
        PaymentArrangementRate paymentArrangementRateDTO = new PaymentArrangementRate();
        paymentArrangementRateDTO.setPaymentArrangementRateId( null );
        paymentArrangementRateDTO.setRateName( "RATE07" );
        paymentArrangementRateDTO.setPaymentArrangementId( null );
        paymentArrangementRateDTO.setCorporateEntityCode( "NM1" );
        paymentArrangementRateDTO.setRecordEffectiveDate( LocalDate.now() );
        paymentArrangementRateDTO.setRecordEndDate( LocalDate.now() );
        paymentArrangementRateDTO.setCreateUserId( "U402537" );
        paymentArrangementRateDTO.setUpdateUserId( "U402537" );
        paymentArrangementRateDTO.setRowAction( RowActionTypes.NO_ACTION );
        paymentArrangementRates.add( paymentArrangementRateDTO );

        PaymentArrangementRate paymentArrangementRateDTO1 = new PaymentArrangementRate();
        paymentArrangementRateDTO1.setPaymentArrangementRateId( null );
        paymentArrangementRateDTO1.setRateName( "RATE07" );
        paymentArrangementRateDTO1.setPaymentArrangementId( null );
        paymentArrangementRateDTO1.setCorporateEntityCode( "NM1" );
        paymentArrangementRateDTO1.setRecordEffectiveDate( LocalDate.now() );
        paymentArrangementRateDTO1.setRecordEndDate( LocalDate.now() );
        paymentArrangementRateDTO1.setCreateUserId( "U402537" );
        paymentArrangementRateDTO1.setUpdateUserId( "U402537" );
        paymentArrangementRateDTO1.setRowAction( RowActionTypes.NO_ACTION );
        paymentArrangementRates.add( paymentArrangementRateDTO1 );
        return paymentArrangementRates;
    }

    private List<PaymentArrangementMemberSubject> getPaymentArrangementMemberSubjects()
    {
        List<PaymentArrangementMemberSubject> paymentArrangementMemberSubjects = new ArrayList<PaymentArrangementMemberSubject>();
        PaymentArrangementMemberSubject paymentArrangementMemberSubjectDTO = new PaymentArrangementMemberSubject();
        paymentArrangementMemberSubjectDTO.setContractId( "H8634" );
        paymentArrangementMemberSubjectDTO.setLineOfBusinessCode( "Medicare" );
        paymentArrangementMemberSubjectDTO.setPaymentArrangementMemberSubjectId( null );
        paymentArrangementMemberSubjectDTO.setPaymentArrangementId( null );
        paymentArrangementMemberSubjectDTO.setCorporateEntityCode( "NM1" );
        paymentArrangementMemberSubjectDTO.setRowAction( RowActionTypes.INSERT );
        paymentArrangementMemberSubjectDTO.setCreateUserId( "U402537" );
        paymentArrangementMemberSubjectDTO.setUpdateUserId( "U402537" );
        return paymentArrangementMemberSubjects;
    }

    private List<PaymentArrangementPayee> getPaymentArrangementPayees()
    {
        List<PaymentArrangementPayee> paymentArrangementPayees = new ArrayList<PaymentArrangementPayee>();
        PaymentArrangementPayee paymentArrangementPayeeDTO = new PaymentArrangementPayee();
        paymentArrangementPayeeDTO.setRecordEffectiveDate( LocalDate.now() );
        paymentArrangementPayeeDTO.setRecordEndDate( LocalDate.now() );
        paymentArrangementPayeeDTO.setCreateUserId( "U402537" );
        paymentArrangementPayeeDTO.setUpdateUserId( "U402537" );
        paymentArrangementPayeeDTO.setRowAction( RowActionTypes.NO_ACTION );
        paymentArrangementPayeeDTO.setPaymentArrangementId( null );
        paymentArrangementPayeeDTO.setVbrPayee( getVbrPayee() );
        paymentArrangementPayees.add( paymentArrangementPayeeDTO );

        PaymentArrangementPayee paymentArrangementPayeeDTO1 = new PaymentArrangementPayee();
        paymentArrangementPayeeDTO1.setRecordEffectiveDate( LocalDate.now() );
        paymentArrangementPayeeDTO1.setRecordEndDate( LocalDate.now() );
        paymentArrangementPayeeDTO1.setCreateUserId( "U402537" );
        paymentArrangementPayeeDTO1.setUpdateUserId( "U402537" );
        paymentArrangementPayeeDTO1.setRowAction( RowActionTypes.NO_ACTION );
        paymentArrangementPayeeDTO1.setPaymentArrangementId( null );
        paymentArrangementPayeeDTO1.setVbrPayee( getVbrPayee() );
        paymentArrangementPayees.add( paymentArrangementPayeeDTO1 );

        return paymentArrangementPayees;
    }

    private PaymentArrangementPayee getPaymentArrangementPayee()
    {

        PaymentArrangementPayee paymentArrangementPayeeDTO = new PaymentArrangementPayee();
        paymentArrangementPayeeDTO.setRecordEffectiveDate( LocalDate.now() );
        paymentArrangementPayeeDTO.setRecordEndDate( LocalDate.now() );
        paymentArrangementPayeeDTO.setCreateUserId( "U402537" );
        paymentArrangementPayeeDTO.setUpdateUserId( "U402537" );
        paymentArrangementPayeeDTO.setRowAction( RowActionTypes.NO_ACTION );
        paymentArrangementPayeeDTO.setPaymentArrangementId( null );
        paymentArrangementPayeeDTO.setVbrPayee( getVbrPayee() );

        return paymentArrangementPayeeDTO;
    }

    private ValidateArrangementPayeeRequest getValidateArrangementPayeeReq()
    {
        ValidateArrangementPayeeRequest validateArrangementPayeeRequest = new ValidateArrangementPayeeRequest();
        PaymentArrangementPayeeDTO paymentArrangementPayeeDTO = new PaymentArrangementPayeeDTO();
        paymentArrangementPayeeDTO.setRecordEffectiveDate( "12/31/2019" );
        paymentArrangementPayeeDTO.setRecordEndDate( "12/12/2019" );
        paymentArrangementPayeeDTO.setCreateUserId( "U402537" );
        paymentArrangementPayeeDTO.setUpdateUserId( "U402537" );
        paymentArrangementPayeeDTO.setRowAction( RowActionTypes.NO_ACTION );
        paymentArrangementPayeeDTO.setPaymentArrangementId( null );
        validateArrangementPayeeRequest.setValidateArrangementPayee( paymentArrangementPayeeDTO );
        return validateArrangementPayeeRequest;
    }

    private VbrPayeeDTO getVbrPayeeDTO()
    {
        VbrPayeeDTO vbrPayeeDTO = new VbrPayeeDTO();
        vbrPayeeDTO.setCorporateEntityCode( "NM1" );
        vbrPayeeDTO.setNetworkAssociationID( 772129222 );
        vbrPayeeDTO.setNetworkCode( "MCD" );
        vbrPayeeDTO.setPinGroupId( "RSK" );
        vbrPayeeDTO.setPayToPfinId( "00NMCAB001" );
        vbrPayeeDTO.setCapitationCode( "A1" );
        vbrPayeeDTO.setCapitationProcessCode( "CP" );
        vbrPayeeDTO.setPinGroupName( "RSK001" );
        vbrPayeeDTO.setTaxIdNumber( "999999999" );
        vbrPayeeDTO.setRecordEffectiveDate( "11/30/2019" );
        vbrPayeeDTO.setRecordEndDate( "11/30/2019" );
        vbrPayeeDTO.setCreateUserId( "U402537" );
        vbrPayeeDTO.setUpdateUserId( "U402537" );
        vbrPayeeDTO.setCreateRecordTimestamp( null );
        vbrPayeeDTO.setUpdateRecordTimestamp( null );
        vbrPayeeDTO.setRowAction( RowActionTypes.NO_ACTION );
        //        vbrPayeeDTO.setVbrPayeeId( 181 );
        return vbrPayeeDTO;
    }

    private List<PayeeRetrieveResponse> getPayeeRetrieveResponse()
    {
        List<PayeeRetrieveResponse> payeeRetrieveResponses = new ArrayList<>();
        PayeeRetrieveResponse payeeRetrieveResponse = new PayeeRetrieveResponse();
        payeeRetrieveResponse.setVbrPayee( getVbrPayeeDTO() );
        payeeRetrieveResponses.add( payeeRetrieveResponse );
        return payeeRetrieveResponses;
    }

    private VbrPayee getVbrPayee()
    {
        VbrPayee vbrPayeeDTO = new VbrPayee();
        vbrPayeeDTO.setCorporateEntityCode( "NM1" );
        vbrPayeeDTO.setNetworkAssocProviderId( 772129222 );
        vbrPayeeDTO.setNetworkCode( "MCD" );
        vbrPayeeDTO.setPinGroupId( "RSK" );
        vbrPayeeDTO.setPayToPfinId( "00NMCAB001" );
        vbrPayeeDTO.setCapitationCode( "A1" );
        vbrPayeeDTO.setCapitationProcessCode( "CP" );
        vbrPayeeDTO.setPinGroupName( "RSK001" );
        vbrPayeeDTO.setTaxIdNumber( "999999999" );
        vbrPayeeDTO.setRecordEffectiveDate( LocalDate.now() );
        vbrPayeeDTO.setRecordEndDate( LocalDate.now() );
        vbrPayeeDTO.setCreateUserId( "U402537" );
        vbrPayeeDTO.setUpdateUserId( "U402537" );
        vbrPayeeDTO.setCreateRecordTimestamp( null );
        vbrPayeeDTO.setUpdateRecordTimestamp( null );
        vbrPayeeDTO.setRowAction( RowActionTypes.NO_ACTION );
        //        vbrPayeeDTO.setVbrPayeeId( 181 );
        return vbrPayeeDTO;
    }

    private List<VbrPayee> getVbrPayees()
    {
        List<VbrPayee> vbrPayees = new ArrayList<>();
        vbrPayees.add( getVbrPayee() );
        return vbrPayees;
    }

}