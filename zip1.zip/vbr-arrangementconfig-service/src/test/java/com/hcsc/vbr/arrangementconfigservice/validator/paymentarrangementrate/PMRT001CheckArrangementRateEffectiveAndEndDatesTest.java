package com.hcsc.vbr.arrangementconfigservice.validator.paymentarrangementrate;

import java.time.LocalDate;
import java.time.Month;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnitRunner;

import com.hcsc.vbr.arrangementconfigservice.domain.PaymentArrangementRate;
import com.hcsc.vbr.common.dto.ReturnMessageDTO;

@RunWith( MockitoJUnitRunner.class )
public class PMRT001CheckArrangementRateEffectiveAndEndDatesTest
{
    @InjectMocks
    private PMRT001CheckArrangementRateEffectiveAndEndDates pmrt001CheckArrangementRateEffectiveAndEndDates;

    @Test( expected = NullPointerException.class )
    public void validatePaymentArrangementRateEffectiveAndEndDateTest() throws Exception
    {
        pmrt001CheckArrangementRateEffectiveAndEndDates.validatePaymentArrangementRateEffectiveAndEndDate( getPaymentArrangementRate(),
                                                                                                           getReturnMessageDTO() );
    }

    @Test( expected = NullPointerException.class )
    public void validatePaymentArrangementRateEffectiveAndEndDateTest_failure() throws Exception
    {
        pmrt001CheckArrangementRateEffectiveAndEndDates
                .validatePaymentArrangementRateEffectiveAndEndDate( getPaymentArrangementRate_failure(),
                                                                    getReturnMessageDTO() );
    }

    @Test( expected = NullPointerException.class )
    public void validatePaymentArrangementRateEffectiveAndEndDateTest_null() throws Exception
    {
        pmrt001CheckArrangementRateEffectiveAndEndDates
                .validatePaymentArrangementRateEffectiveAndEndDate( getPaymentArrangementRate_null(),
                                                                    getReturnMessageDTO() );
    }

    @Test
    public void validatePaymentArrangementRateEffectiveAndEndDateTest_success() throws Exception
    {
        pmrt001CheckArrangementRateEffectiveAndEndDates
                .validatePaymentArrangementRateEffectiveAndEndDate( getPaymentArrangementRate_success(),
                                                                    getReturnMessageDTO() );
    }

    private PaymentArrangementRate getPaymentArrangementRate()
    {
        PaymentArrangementRate paymentArrangementRate = new PaymentArrangementRate();
        paymentArrangementRate.setRateName( "RATE" );
        paymentArrangementRate.setRecordEffectiveDate( LocalDate.MIN );
        paymentArrangementRate.setRecordEndDate( LocalDate.now() );
        return paymentArrangementRate;
    }

    private PaymentArrangementRate getPaymentArrangementRate_success()
    {
        PaymentArrangementRate paymentArrangementRate = new PaymentArrangementRate();
        paymentArrangementRate.setRateName( "RATE" );
        paymentArrangementRate.setRecordEffectiveDate( LocalDate.of( 2019,
                                                                     Month.DECEMBER,
                                                                     01 ) );
        paymentArrangementRate.setRecordEndDate( LocalDate.of( 2019,
                                                               Month.DECEMBER,
                                                               31 ) );
        return paymentArrangementRate;
    }

    private PaymentArrangementRate getPaymentArrangementRate_null()
    {
        PaymentArrangementRate paymentArrangementRate = new PaymentArrangementRate();
        paymentArrangementRate.setRateName( "RATE" );
        paymentArrangementRate.setRecordEffectiveDate( null );
        paymentArrangementRate.setRecordEndDate( null );
        return paymentArrangementRate;
    }

    private PaymentArrangementRate getPaymentArrangementRate_failure()
    {
        PaymentArrangementRate paymentArrangementRate = new PaymentArrangementRate();
        paymentArrangementRate.setRateName( "RATE" );
        paymentArrangementRate.setRecordEffectiveDate( LocalDate.now() );
        paymentArrangementRate.setRecordEndDate( LocalDate.now().plusDays( 1 ) );
        return paymentArrangementRate;
    }

    private ReturnMessageDTO getReturnMessageDTO()
    {
        ReturnMessageDTO returnMessageDTO = new ReturnMessageDTO();
        return returnMessageDTO;
    }

}
