package com.hcsc.vbr.arrangementconfigservice.dto;

public class VbrPayeeDTOTest
{
    /* private VbrPayeeDTO vbrPayeeDTO;
    
    @Before
    public void setUp()
    {
        vbrPayeeDTO = new VbrPayeeDTO();
    }
    
    @Test
    public void testArrangementPayee()
    {
        vbrPayeeDTO.setVbrPayeeId( Long.valueOf( "1" ) );
        vbrPayeeDTO.setCapitationCode( "IL1" );
        vbrPayeeDTO.setCapitationProcessCode( "CPC" );
        vbrPayeeDTO.setCorporateEntityCode( "IC1" );
        vbrPayeeDTO.setNetworkAssocProviderId( Long.valueOf( "1" ) );
        vbrPayeeDTO.setNetworkCode( "IN1" );
        vbrPayeeDTO.setPayToPfinKeyId( Long.valueOf( "1" ) );
        vbrPayeeDTO.setPinGroupId( Long.valueOf( "1" ) );
        vbrPayeeDTO.setPinGroupName( "PAY123" );
        vbrPayeeDTO.setTaxIdNumber( "TAX123" );
    
        Assert.assertTrue( vbrPayeeDTO != null );
        Assert.assertEquals( Long.valueOf( "1" ),
                             vbrPayeeDTO.getVbrPayeeId() );
        Assert.assertEquals( "IL1",
                             vbrPayeeDTO.getCapitationCode() );
        Assert.assertEquals( "CPC",
                             vbrPayeeDTO.getCapitationProcessCode() );
        Assert.assertEquals( "IC1",
                             vbrPayeeDTO.getCorporateEntityCode() );
        Assert.assertEquals( Long.valueOf( "1" ),
                             vbrPayeeDTO.getNetworkAssocProviderId() );
        Assert.assertEquals( "IN1",
                             vbrPayeeDTO.getNetworkCode() );
        Assert.assertEquals( Long.valueOf( "1" ),
                             vbrPayeeDTO.getPayToPfinKeyId() );
        Assert.assertEquals( Long.valueOf( "1" ),
                             vbrPayeeDTO.getPinGroupId() );
        Assert.assertEquals( "PAY123",
                             vbrPayeeDTO.getPinGroupName() );
        Assert.assertEquals( "TAX123",
                             vbrPayeeDTO.getTaxIdNumber() );
    
        Assert.assertTrue( vbrPayeeDTO.toString().contains( "vbrPayeeId=1" ) );
    
    }*/
}
