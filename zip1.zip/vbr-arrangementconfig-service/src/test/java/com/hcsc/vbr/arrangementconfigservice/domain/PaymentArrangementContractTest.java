package com.hcsc.vbr.arrangementconfigservice.domain;

public class PaymentArrangementContractTest
{
    /*  @Test
    public void testSetters()
    {
        Contract contract = new Contract();
        contract.setContractId( Long.valueOf( "1" ) );
        contract.setCorporateEntityCode( "IL1" );
        contract.setProgramName( "VBR" );
        contract.setDescription( "desc" );
    
        assertEquals( Long.valueOf( "1" ),
                      contract.getContractId() );
        assertEquals( "IL1",
                      contract.getCorporateEntityCode() );
        assertEquals( "VBR",
                      contract.getProgramName() );
        assertEquals( "desc",
                      contract.getDescription() );
        
        assertTrue( contract.toString().contains( "contractId=1" ) );
    
    }*/
}
