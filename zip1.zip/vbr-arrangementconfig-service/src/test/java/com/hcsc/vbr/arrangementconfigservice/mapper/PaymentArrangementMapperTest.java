package com.hcsc.vbr.arrangementconfigservice.mapper;

import java.util.ArrayList;
import java.util.List;

import org.assertj.core.api.Assertions;
import org.junit.Test;

import com.hcsc.vbr.arrangementconfigservice.domain.PaymentArrangement;
import com.hcsc.vbr.arrangementconfigservice.dto.PaymentArrangementDTO;

public class PaymentArrangementMapperTest
{
    private int paymentArrangementId = 1;
    private int contractId = 2;
    private String arrangementFrequencyCode = "AFC";
    private String corporateEntityCode = "NM1";
    private String paymentArrangementDescription = "Payment Description";
    private String paymentArrangementTypeCode = "Payment Arrangement Type Code";
    private String paymentTypeCode = "Payment Type Code";
    private String validationStatusCode = "Validation Status Code";

    @Test
    public void testToPaymentArrangementDTO()
    {
        PaymentArrangement paymentArrangement = populatePaymentArrangement();

        PaymentArrangementDTO paymentArrangementDTO = PaymentArrangementMapper.INSTANCE.toPaymentArrangmentDTO( paymentArrangement );

        Assertions.assertThat( paymentArrangementDTO ).hasFieldOrPropertyWithValue( "paymentArrangementId",
                                                                                    paymentArrangementId );
        Assertions.assertThat( paymentArrangementDTO ).hasFieldOrPropertyWithValue( "paymentArrangementContractId",
                                                                                    contractId );
        Assertions.assertThat( paymentArrangementDTO ).hasFieldOrPropertyWithValue( "arrangementFrequencyCode",
                                                                                    arrangementFrequencyCode );
        Assertions.assertThat( paymentArrangementDTO ).hasFieldOrPropertyWithValue( "corporateEntityCode",
                                                                                    corporateEntityCode );
        Assertions.assertThat( paymentArrangementDTO ).hasFieldOrPropertyWithValue( "paymentArrangementDescription",
                                                                                    paymentArrangementDescription );
        Assertions.assertThat( paymentArrangementDTO ).hasFieldOrPropertyWithValue( "paymentArrangementTypeCode",
                                                                                    paymentArrangementTypeCode );
        Assertions.assertThat( paymentArrangementDTO ).hasFieldOrPropertyWithValue( "paymentTypeCode",
                                                                                    paymentTypeCode );
        Assertions.assertThat( paymentArrangementDTO ).hasFieldOrPropertyWithValue( "validationStatusCode",
                                                                                    validationStatusCode );
    }

    @Test
    public void testNullToPaymentArrangementDTO()
    {
        PaymentArrangementDTO paymentArrangementDTO = PaymentArrangementMapper.INSTANCE.toPaymentArrangmentDTO( null );

        Assertions.assertThat( paymentArrangementDTO == null );
    }

    @Test
    public void testToPaymentArrangementDTOs()
    {

        PaymentArrangement paymentArrangement = populatePaymentArrangement();

        List<PaymentArrangement> paymentArrangements = new ArrayList<PaymentArrangement>();
        paymentArrangements.add( paymentArrangement );

        List<PaymentArrangementDTO> paymentArrangementDTOs =
            PaymentArrangementMapper.INSTANCE.toPaymentArrangmentDTOs( paymentArrangements );

        for( PaymentArrangementDTO paymentArrangementDTO : paymentArrangementDTOs )
        {
            Assertions.assertThat( paymentArrangementDTO ).hasFieldOrPropertyWithValue( "paymentArrangementId",
                                                                                        paymentArrangementId );
            Assertions.assertThat( paymentArrangementDTO ).hasFieldOrPropertyWithValue( "paymentArrangementContractId",
                                                                                        contractId );
            Assertions.assertThat( paymentArrangementDTO ).hasFieldOrPropertyWithValue( "arrangementFrequencyCode",
                                                                                        arrangementFrequencyCode );
            Assertions.assertThat( paymentArrangementDTO ).hasFieldOrPropertyWithValue( "corporateEntityCode",
                                                                                        corporateEntityCode );
            Assertions.assertThat( paymentArrangementDTO ).hasFieldOrPropertyWithValue( "paymentArrangementDescription",
                                                                                        paymentArrangementDescription );
            Assertions.assertThat( paymentArrangementDTO ).hasFieldOrPropertyWithValue( "paymentArrangementTypeCode",
                                                                                        paymentArrangementTypeCode );
            Assertions.assertThat( paymentArrangementDTO ).hasFieldOrPropertyWithValue( "paymentTypeCode",
                                                                                        paymentTypeCode );
            Assertions.assertThat( paymentArrangementDTO ).hasFieldOrPropertyWithValue( "validationStatusCode",
                                                                                        validationStatusCode );
        }
    }

    @Test
    public void testNullToPaymentArrangementDTOs()
    {
        List<PaymentArrangementDTO> paymentArrangementDTOs = PaymentArrangementMapper.INSTANCE.toPaymentArrangmentDTOs( null );

        Assertions.assertThat( paymentArrangementDTOs == null );
    }

    @Test
    public void testToPaymentArrangement()
    {
        PaymentArrangementDTO paymentArrangementDTO = populatePaymentArrangementDTO();

        PaymentArrangement paymentArrangement = PaymentArrangementMapper.INSTANCE.toPaymentArrangement( paymentArrangementDTO );

        Assertions.assertThat( paymentArrangement ).hasFieldOrPropertyWithValue( "paymentArrangementId",
                                                                                 paymentArrangementId );
        Assertions.assertThat( paymentArrangement ).hasFieldOrPropertyWithValue( "paymentArrangementContractId",
                                                                                 contractId );
        Assertions.assertThat( paymentArrangement ).hasFieldOrPropertyWithValue( "arrangementFrequencyCode",
                                                                                 arrangementFrequencyCode );
        Assertions.assertThat( paymentArrangement ).hasFieldOrPropertyWithValue( "corporateEntityCode",
                                                                                 corporateEntityCode );
        Assertions.assertThat( paymentArrangement ).hasFieldOrPropertyWithValue( "paymentArrangementDescription",
                                                                                 paymentArrangementDescription );
        Assertions.assertThat( paymentArrangement ).hasFieldOrPropertyWithValue( "paymentArrangementTypeCode",
                                                                                 paymentArrangementTypeCode );
        Assertions.assertThat( paymentArrangement ).hasFieldOrPropertyWithValue( "paymentTypeCode",
                                                                                 paymentTypeCode );
        Assertions.assertThat( paymentArrangement ).hasFieldOrPropertyWithValue( "validationStatusCode",
                                                                                 validationStatusCode );
    }

    @Test
    public void testNullToPaymentArrangement()
    {
        PaymentArrangement paymentArrangement = PaymentArrangementMapper.INSTANCE.toPaymentArrangement( null );

        Assertions.assertThat( paymentArrangement == null );
    }

    @Test
    public void testToPaymentArrangements()
    {
        PaymentArrangementDTO paymentArrangementDTO = populatePaymentArrangementDTO();

        List<PaymentArrangementDTO> paymentArrangementDTOs = new ArrayList<PaymentArrangementDTO>();
        paymentArrangementDTOs.add( paymentArrangementDTO );

        List<PaymentArrangement> paymentArrangements =
            PaymentArrangementMapper.INSTANCE.toPaymentArrangements( paymentArrangementDTOs );

        for( PaymentArrangement paymentArrangement : paymentArrangements )
        {
            Assertions.assertThat( paymentArrangement ).hasFieldOrPropertyWithValue( "paymentArrangementId",
                                                                                     paymentArrangementId );
            Assertions.assertThat( paymentArrangement ).hasFieldOrPropertyWithValue( "paymentArrangementContractId",
                                                                                     contractId );
            Assertions.assertThat( paymentArrangement ).hasFieldOrPropertyWithValue( "arrangementFrequencyCode",
                                                                                     arrangementFrequencyCode );
            Assertions.assertThat( paymentArrangement ).hasFieldOrPropertyWithValue( "corporateEntityCode",
                                                                                     corporateEntityCode );
            Assertions.assertThat( paymentArrangement ).hasFieldOrPropertyWithValue( "paymentArrangementDescription",
                                                                                     paymentArrangementDescription );
            Assertions.assertThat( paymentArrangement ).hasFieldOrPropertyWithValue( "paymentArrangementTypeCode",
                                                                                     paymentArrangementTypeCode );
            Assertions.assertThat( paymentArrangement ).hasFieldOrPropertyWithValue( "paymentTypeCode",
                                                                                     paymentTypeCode );
            Assertions.assertThat( paymentArrangement ).hasFieldOrPropertyWithValue( "validationStatusCode",
                                                                                     validationStatusCode );
        }
    }

    @Test
    public void testNullToPaymentArrangements()
    {
        List<PaymentArrangement> payArrangements = PaymentArrangementMapper.INSTANCE.toPaymentArrangements( null );

        Assertions.assertThat( payArrangements == null );
    }

    private PaymentArrangement populatePaymentArrangement()
    {
        PaymentArrangement paymentArrangement = new PaymentArrangement();
        paymentArrangement.setPaymentArrangementId( paymentArrangementId );
        paymentArrangement.setPaymentArrangementContractId( contractId );
        paymentArrangement.setArrangementFrequencyCode( arrangementFrequencyCode );
        paymentArrangement.setCorporateEntityCode( corporateEntityCode );
        paymentArrangement.setPaymentArrangementDescription( paymentArrangementDescription );
        paymentArrangement.setPaymentArrangementTypeCode( paymentArrangementTypeCode );
        paymentArrangement.setPaymentTypeCode( paymentTypeCode );
        paymentArrangement.setValidationStatusCode( validationStatusCode );
        return paymentArrangement;
    }

    private PaymentArrangementDTO populatePaymentArrangementDTO()
    {
        PaymentArrangementDTO paymentArrangementDTO = new PaymentArrangementDTO();
        paymentArrangementDTO.setPaymentArrangementId( paymentArrangementId );
        paymentArrangementDTO.setPaymentArrangementContractId( contractId );
        paymentArrangementDTO.setArrangementFrequencyCode( arrangementFrequencyCode );
        paymentArrangementDTO.setCorporateEntityCode( corporateEntityCode );
        paymentArrangementDTO.setPaymentArrangementDescription( paymentArrangementDescription );
        paymentArrangementDTO.setPaymentArrangementTypeCode( paymentArrangementTypeCode );
        paymentArrangementDTO.setPaymentTypeCode( paymentTypeCode );
        paymentArrangementDTO.setValidationStatusCode( validationStatusCode );
        return paymentArrangementDTO;
    }

}
