package com.hcsc.vbr.arrangementconfigservice.validator.paymentarrangement;

import static org.junit.Assert.assertEquals;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnitRunner;

import com.hcsc.vbr.arrangementconfigservice.domain.PaymentArrangement;
import com.hcsc.vbr.arrangementconfigservice.domain.PaymentArrangementPayee;
import com.hcsc.vbr.arrangementconfigservice.domain.VbrPayee;
import com.hcsc.vbr.common.constant.VBRCommonConstant.RowActionTypes;
import com.hcsc.vbr.common.dto.ErrorMessageDTO;
import com.hcsc.vbr.common.dto.ReturnMessageDTO;

@RunWith( MockitoJUnitRunner.class )
public class PMAM005CheckArrangementDurationWithArrangementPayeeTest
{
    @InjectMocks
    private PMAM005CheckArrangementDurationWithArrangementPayee pMAM005CheckArrangementDurationWithArrangementPayee;

    @Test
    public void validateArrangementDurationWithArrangementPayee_Fail() throws Exception
    {

        boolean isFailing = pMAM005CheckArrangementDurationWithArrangementPayee
                .validateArrangementDurationWithArrangementPayee( getPaymentArrangementPayees_fail(),
                                                                  getPaymentArrangement_fail(),
                                                                  LocalDate.now(),
                                                                  getReturnMessageDTO() );
        assertEquals( false,
                      isFailing );
    }

    @Test
    public void validateArrangementDurationWithArrangementPayee_Pass() throws Exception
    {

        boolean isFailing = pMAM005CheckArrangementDurationWithArrangementPayee
                .validateArrangementDurationWithArrangementPayee( getPaymentArrangementPayees_success(),
                                                                  getPaymentArrangement_success(),
                                                                  LocalDate.now(),
                                                                  getReturnMessageDTO() );
        assertEquals( false,
                      isFailing );
    }

    private List<ErrorMessageDTO> getErrorMessageDTOSuccess() throws Exception
    {
        List<ErrorMessageDTO> errors = new ArrayList<ErrorMessageDTO>();
        ErrorMessageDTO errorMessageDTO = new ErrorMessageDTO();

        errorMessageDTO.setErrorMessageCategoryCode( "PCF-PMAM" );
        errorMessageDTO.setErrorMessageId( new Long( 226 ) );
        errorMessageDTO.setErrorMsgDescriptionText( "Payment Type Is Required" );
        errorMessageDTO.setSeveritylevel( "E" );
        errors.add( errorMessageDTO );
        return errors;

    }

    private ReturnMessageDTO getReturnMessageDTO() throws Exception
    {
        ReturnMessageDTO returnMessage = new ReturnMessageDTO();

        returnMessage.setItemName( "PCF-PMAM" );
        returnMessage.setStatus( "SUCCESS" );
        returnMessage.setErrors( getErrorMessageDTOSuccess() );
        return returnMessage;

    }

    private PaymentArrangement getPaymentArrangement_success()
    {

        PaymentArrangement paymentArrangementDTO = new PaymentArrangement();
        paymentArrangementDTO.setCorporateEntityCode( "NM1" );
        paymentArrangementDTO.setPaymentArrangementContractId( null );
        paymentArrangementDTO.setPaymentArrangementName( "PaymentArrangementNameTest" );
        paymentArrangementDTO.setArrangementFrequencyCode( "monthly" );
        paymentArrangementDTO.setPaymentArrangementTypeCode( "paymentArrangementTypeCodeTest" );
        paymentArrangementDTO.setPaymentArrangementDescription( "paymentArrangementDescriptionTest" );
        paymentArrangementDTO.setRecordEffectiveDate( LocalDate.now() );
        paymentArrangementDTO.setRecordEndDate( LocalDate.now() );
        paymentArrangementDTO.setCreateUserId( "U402537" );
        paymentArrangementDTO.setUpdateUserId( "U402537" );
        paymentArrangementDTO.setCreateRecordTimestamp( null );
        paymentArrangementDTO.setPaymentArrangementId( null );
        paymentArrangementDTO.setPaymentTypeCode( "paymentTypeCodeTest" );
        paymentArrangementDTO.setValidationStatusCode( null );
        paymentArrangementDTO.setPaymentArrangementId( null );
        paymentArrangementDTO.setRowAction( RowActionTypes.INSERT );
        paymentArrangementDTO.setRetroRuleSetups( null );
        paymentArrangementDTO.setPaymentArrangementHistories( null );
        paymentArrangementDTO.setPaymentArrangementRates( null );
        paymentArrangementDTO.setPaymentArrangementMemberSubjects( null );
        paymentArrangementDTO.setPaymentArrangementPayees( getPaymentArrangementPayees_success() );

        return paymentArrangementDTO;
    }

    private PaymentArrangement getPaymentArrangement_fail()
    {

        PaymentArrangement paymentArrangementDTO = new PaymentArrangement();
        paymentArrangementDTO.setCorporateEntityCode( "NM1" );
        paymentArrangementDTO.setPaymentArrangementContractId( null );
        paymentArrangementDTO.setPaymentArrangementName( "PaymentArrangementNameTest" );
        paymentArrangementDTO.setArrangementFrequencyCode( "monthly" );
        paymentArrangementDTO.setPaymentArrangementTypeCode( "paymentArrangementTypeCodeTest" );
        paymentArrangementDTO.setPaymentArrangementDescription( "paymentArrangementDescriptionTest" );
        paymentArrangementDTO.setRecordEffectiveDate( LocalDate.now() );
        paymentArrangementDTO.setRecordEndDate( LocalDate.now() );
        paymentArrangementDTO.setCreateUserId( "U402537" );
        paymentArrangementDTO.setUpdateUserId( "U402537" );
        paymentArrangementDTO.setCreateRecordTimestamp( null );
        paymentArrangementDTO.setPaymentArrangementId( null );
        paymentArrangementDTO.setPaymentTypeCode( "paymentTypeCodeTest" );
        paymentArrangementDTO.setValidationStatusCode( null );
        paymentArrangementDTO.setPaymentArrangementId( null );
        paymentArrangementDTO.setRowAction( RowActionTypes.INSERT );
        paymentArrangementDTO.setRetroRuleSetups( null );
        paymentArrangementDTO.setPaymentArrangementHistories( null );
        paymentArrangementDTO.setPaymentArrangementRates( null );
        paymentArrangementDTO.setPaymentArrangementMemberSubjects( null );
        paymentArrangementDTO.setPaymentArrangementPayees( getPaymentArrangementPayees_fail() );

        return paymentArrangementDTO;
    }

    private List<PaymentArrangementPayee> getPaymentArrangementPayees_fail()
    {
        List<PaymentArrangementPayee> paymentArrangementPayees = new ArrayList<PaymentArrangementPayee>();
        PaymentArrangementPayee paymentArrangementPayeeDTO = new PaymentArrangementPayee();
        paymentArrangementPayeeDTO.setRecordEffectiveDate( LocalDate.now() );
        paymentArrangementPayeeDTO.setRecordEndDate( LocalDate.now() );
        paymentArrangementPayeeDTO.setCreateUserId( "U402537" );
        paymentArrangementPayeeDTO.setUpdateUserId( "U402537" );
        paymentArrangementPayeeDTO.setRowAction( RowActionTypes.NO_ACTION );
        paymentArrangementPayeeDTO.setPaymentArrangementId( null );
        paymentArrangementPayeeDTO.setVbrPayee( getVbrPayee() );
        paymentArrangementPayees.add( paymentArrangementPayeeDTO );

        PaymentArrangementPayee paymentArrangementPayeeDTO1 = new PaymentArrangementPayee();
        paymentArrangementPayeeDTO1.setRecordEffectiveDate( LocalDate.of( 2020,
                                                                          12,
                                                                          1 ) );
        paymentArrangementPayeeDTO1.setRecordEndDate( LocalDate.of( 2020,
                                                                    12,
                                                                    31 ) );
        paymentArrangementPayeeDTO1.setCreateUserId( "U402537" );
        paymentArrangementPayeeDTO1.setUpdateUserId( "U402537" );
        paymentArrangementPayeeDTO1.setRowAction( RowActionTypes.NO_ACTION );
        paymentArrangementPayeeDTO1.setPaymentArrangementId( null );
        paymentArrangementPayeeDTO1.setVbrPayee( getVbrPayee() );
        paymentArrangementPayees.add( paymentArrangementPayeeDTO1 );
        return paymentArrangementPayees;
    }

    private List<PaymentArrangementPayee> getPaymentArrangementPayees_success()
    {
        List<PaymentArrangementPayee> paymentArrangementPayees = new ArrayList<PaymentArrangementPayee>();
        PaymentArrangementPayee paymentArrangementPayeeDTO = new PaymentArrangementPayee();
        paymentArrangementPayeeDTO.setRecordEffectiveDate( LocalDate.now() );
        paymentArrangementPayeeDTO.setRecordEndDate( LocalDate.now() );
        paymentArrangementPayeeDTO.setCreateUserId( "U402537" );
        paymentArrangementPayeeDTO.setUpdateUserId( "U402537" );
        paymentArrangementPayeeDTO.setRowAction( RowActionTypes.NO_ACTION );
        paymentArrangementPayeeDTO.setPaymentArrangementId( null );
        paymentArrangementPayeeDTO.setVbrPayee( getVbrPayee() );
        paymentArrangementPayees.add( paymentArrangementPayeeDTO );

        PaymentArrangementPayee paymentArrangementPayeeDTO1 = new PaymentArrangementPayee();
        paymentArrangementPayeeDTO1.setRecordEffectiveDate( LocalDate.now() );
        paymentArrangementPayeeDTO1.setRecordEndDate( LocalDate.now() );
        paymentArrangementPayeeDTO1.setCreateUserId( "U402537" );
        paymentArrangementPayeeDTO1.setUpdateUserId( "U402537" );
        paymentArrangementPayeeDTO1.setRowAction( RowActionTypes.NO_ACTION );
        paymentArrangementPayeeDTO1.setPaymentArrangementId( null );
        paymentArrangementPayeeDTO1.setVbrPayee( getVbrPayee() );
        paymentArrangementPayees.add( paymentArrangementPayeeDTO1 );
        return paymentArrangementPayees;
    }

    private VbrPayee getVbrPayee()
    {
        VbrPayee vbrPayeeDTO = new VbrPayee();
        vbrPayeeDTO.setCorporateEntityCode( "NM1" );
        vbrPayeeDTO.setNetworkAssocProviderId( 772129222 );
        vbrPayeeDTO.setNetworkCode( "MCD" );
        vbrPayeeDTO.setPinGroupId( "RSK" );
        vbrPayeeDTO.setPayToPfinId( "00NMCAB001" );
        vbrPayeeDTO.setCapitationCode( "A1" );
        vbrPayeeDTO.setCapitationProcessCode( "CP" );
        vbrPayeeDTO.setPinGroupName( "RSK001" );
        vbrPayeeDTO.setTaxIdNumber( "999999999" );
        vbrPayeeDTO.setRecordEffectiveDate( LocalDate.now() );
        vbrPayeeDTO.setRecordEndDate( LocalDate.now() );
        vbrPayeeDTO.setCreateUserId( "U402537" );
        vbrPayeeDTO.setUpdateUserId( "U402537" );
        vbrPayeeDTO.setCreateRecordTimestamp( null );
        vbrPayeeDTO.setUpdateRecordTimestamp( null );
        vbrPayeeDTO.setRowAction( RowActionTypes.NO_ACTION );
        //        vbrPayeeDTO.setVbrPayeeId( 181 );
        return vbrPayeeDTO;
    }

}
