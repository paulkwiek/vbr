package com.hcsc.vbr.arrangementconfigservice.validator.paymentarrangement;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.json.JacksonTester;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.hcsc.vbr.arrangementconfigservice.domain.PaymentArrangement;
import com.hcsc.vbr.arrangementconfigservice.domain.PaymentArrangementMemberSubject;
import com.hcsc.vbr.arrangementconfigservice.domain.PaymentArrangementPayee;
import com.hcsc.vbr.arrangementconfigservice.domain.PaymentArrangementRate;
import com.hcsc.vbr.arrangementconfigservice.domain.VbrPayee;
import com.hcsc.vbr.common.constant.VBRCommonConstant.RowActionTypes;
import com.hcsc.vbr.common.dto.ErrorMessageDTO;
import com.hcsc.vbr.common.dto.ReturnMessageDTO;

@Component
public class PMAM001CheckPaymentArrangementEffectiveDateEqualorBeforeEndDateTest
{
    @InjectMocks
    PMAM001CheckPaymentArrangementEffectiveDateEqualorBeforeEndDate checkPaymentArrangementEffectiveAndEndDates;

    @Before
    public void setUp()
    {
        MockitoAnnotations.initMocks( this );
        JacksonTester.initFields( this,
                                  new ObjectMapper() );

    }

    @Test
    public void validatePaymentArrangementEffectiveAndEndDatesTest() throws Exception
    {

        boolean isValid = checkPaymentArrangementEffectiveAndEndDates
                .validatePaymentArrangementEffectiveDateEqualBeforeEndDate( getPaymentArrangement(),
                                                                            getReturnMessageDTO() );
        assertTrue( isValid );
    }

    @Test( expected = NullPointerException.class )
    public void validatePaymentArrangementEffectiveAndEndDatesTest_fail() throws Exception
    {

        boolean isValid = checkPaymentArrangementEffectiveAndEndDates
                .validatePaymentArrangementEffectiveDateEqualBeforeEndDate( getPaymentArrangement_fail(),
                                                                            getReturnMessageDTO() );
        assertFalse( isValid );
    }

    private ReturnMessageDTO getReturnMessageDTO() throws Exception
    {
        ReturnMessageDTO returnMessage = new ReturnMessageDTO();

        returnMessage.setItemName( "PCF-PMAM" );
        returnMessage.setStatus( "SUCCESS" );
        returnMessage.setErrors( getErrorMessageDTORecord() );
        return returnMessage;

    }

    private List<ErrorMessageDTO> getErrorMessageDTORecord() throws Exception
    {
        List<ErrorMessageDTO> errors = new ArrayList<ErrorMessageDTO>();
        ErrorMessageDTO errorMessageDTO = new ErrorMessageDTO();

        errorMessageDTO.setErrorMessageCategoryCode( "PCF-PMAM" );
        errorMessageDTO.setErrorMessageId( new Long( 4 ) );
        errorMessageDTO
                .setErrorMsgDescriptionText( "Payment Arrangement Effective date should be less than or equal to Payment Arrangement End date" );
        errorMessageDTO.setSeveritylevel( "E" );
        errors.add( errorMessageDTO );
        return errors;

    }

    private PaymentArrangement getPaymentArrangement()
    {

        PaymentArrangement paymentArrangementDTO = new PaymentArrangement();
        paymentArrangementDTO.setCorporateEntityCode( "NM1" );
        paymentArrangementDTO.setPaymentArrangementContractId( null );
        paymentArrangementDTO.setPaymentArrangementName( "PaymentArrangementNameTest" );
        paymentArrangementDTO.setArrangementFrequencyCode( "monthly" );
        paymentArrangementDTO.setPaymentArrangementTypeCode( "paymentArrangementTypeCodeTest" );
        paymentArrangementDTO.setPaymentArrangementDescription( "paymentArrangementDescriptionTest" );
        paymentArrangementDTO.setRecordEffectiveDate( LocalDate.now() );
        paymentArrangementDTO.setRecordEndDate( LocalDate.now() );
        paymentArrangementDTO.setCreateUserId( "U402537" );
        paymentArrangementDTO.setUpdateUserId( "U402537" );
        paymentArrangementDTO.setCreateRecordTimestamp( null );
        paymentArrangementDTO.setPaymentArrangementId( null );
        paymentArrangementDTO.setPaymentTypeCode( "paymentTypeCodeTest" );
        paymentArrangementDTO.setValidationStatusCode( null );
        paymentArrangementDTO.setPaymentArrangementId( null );
        paymentArrangementDTO.setRowAction( RowActionTypes.INSERT );
        paymentArrangementDTO.setRetroRuleSetups( null );
        paymentArrangementDTO.setPaymentArrangementHistories( null );
        paymentArrangementDTO.setPaymentArrangementRates( getPaymentArrangementRates() );
        paymentArrangementDTO.setPaymentArrangementMemberSubjects( getPaymentArrangementMemberSubjects() );
        paymentArrangementDTO.setPaymentArrangementPayees( getPaymentArrangementPayees() );

        return paymentArrangementDTO;
    }

    private PaymentArrangement getPaymentArrangement_fail()
    {

        PaymentArrangement paymentArrangementDTO = new PaymentArrangement();
        paymentArrangementDTO.setCorporateEntityCode( "NM1" );
        paymentArrangementDTO.setPaymentArrangementContractId( null );
        paymentArrangementDTO.setPaymentArrangementName( "PaymentArrangementNameTest" );
        paymentArrangementDTO.setArrangementFrequencyCode( "monthly" );
        paymentArrangementDTO.setPaymentArrangementTypeCode( "paymentArrangementTypeCodeTest" );
        paymentArrangementDTO.setPaymentArrangementDescription( "paymentArrangementDescriptionTest" );
        paymentArrangementDTO.setRecordEffectiveDate( LocalDate.ofYearDay( 2020,
                                                                           1 ) );
        paymentArrangementDTO.setRecordEndDate( LocalDate.now() );
        paymentArrangementDTO.setCreateUserId( "U402537" );
        paymentArrangementDTO.setUpdateUserId( "U402537" );
        paymentArrangementDTO.setCreateRecordTimestamp( null );
        paymentArrangementDTO.setPaymentArrangementId( null );
        paymentArrangementDTO.setPaymentTypeCode( "paymentTypeCodeTest" );
        paymentArrangementDTO.setValidationStatusCode( null );
        paymentArrangementDTO.setPaymentArrangementId( null );
        paymentArrangementDTO.setRowAction( RowActionTypes.INSERT );
        paymentArrangementDTO.setRetroRuleSetups( null );
        paymentArrangementDTO.setPaymentArrangementHistories( null );
        paymentArrangementDTO.setPaymentArrangementRates( getPaymentArrangementRates() );
        paymentArrangementDTO.setPaymentArrangementMemberSubjects( getPaymentArrangementMemberSubjects() );
        paymentArrangementDTO.setPaymentArrangementPayees( getPaymentArrangementPayees() );

        return paymentArrangementDTO;
    }

    private List<PaymentArrangementRate> getPaymentArrangementRates()
    {
        List<PaymentArrangementRate> paymentArrangementRates = new ArrayList<PaymentArrangementRate>();
        PaymentArrangementRate paymentArrangementRateDTO = new PaymentArrangementRate();
        paymentArrangementRateDTO.setPaymentArrangementRateId( null );
        paymentArrangementRateDTO.setRateName( "RATE07" );
        paymentArrangementRateDTO.setPaymentArrangementId( null );
        paymentArrangementRateDTO.setCorporateEntityCode( "NM1" );
        paymentArrangementRateDTO.setRecordEffectiveDate( LocalDate.now() );
        paymentArrangementRateDTO.setRecordEndDate( LocalDate.now() );
        paymentArrangementRateDTO.setCreateUserId( "U402537" );
        paymentArrangementRateDTO.setUpdateUserId( "U402537" );
        paymentArrangementRateDTO.setRowAction( RowActionTypes.NO_ACTION );
        paymentArrangementRates.add( paymentArrangementRateDTO );

        PaymentArrangementRate paymentArrangementRateDTO1 = new PaymentArrangementRate();
        paymentArrangementRateDTO1.setPaymentArrangementRateId( null );
        paymentArrangementRateDTO1.setRateName( "RATE07" );
        paymentArrangementRateDTO1.setPaymentArrangementId( null );
        paymentArrangementRateDTO1.setCorporateEntityCode( "NM1" );
        paymentArrangementRateDTO1.setRecordEffectiveDate( LocalDate.now() );
        paymentArrangementRateDTO1.setRecordEndDate( LocalDate.now() );
        paymentArrangementRateDTO1.setCreateUserId( "U402537" );
        paymentArrangementRateDTO1.setUpdateUserId( "U402537" );
        paymentArrangementRateDTO1.setRowAction( RowActionTypes.NO_ACTION );
        paymentArrangementRates.add( paymentArrangementRateDTO1 );
        return paymentArrangementRates;
    }

    private List<PaymentArrangementMemberSubject> getPaymentArrangementMemberSubjects()
    {
        List<PaymentArrangementMemberSubject> paymentArrangementMemberSubjects = new ArrayList<PaymentArrangementMemberSubject>();
        PaymentArrangementMemberSubject paymentArrangementMemberSubjectDTO = new PaymentArrangementMemberSubject();
        paymentArrangementMemberSubjectDTO.setContractId( "H8634" );
        paymentArrangementMemberSubjectDTO.setLineOfBusinessCode( "Medicare" );
        paymentArrangementMemberSubjectDTO.setPaymentArrangementMemberSubjectId( null );
        paymentArrangementMemberSubjectDTO.setPaymentArrangementId( null );
        paymentArrangementMemberSubjectDTO.setCorporateEntityCode( "NM1" );
        paymentArrangementMemberSubjectDTO.setRowAction( RowActionTypes.INSERT );
        paymentArrangementMemberSubjectDTO.setCreateUserId( "U402537" );
        paymentArrangementMemberSubjectDTO.setUpdateUserId( "U402537" );
        return paymentArrangementMemberSubjects;
    }

    private List<PaymentArrangementPayee> getPaymentArrangementPayees()
    {
        List<PaymentArrangementPayee> paymentArrangementPayees = new ArrayList<PaymentArrangementPayee>();
        PaymentArrangementPayee paymentArrangementPayeeDTO = new PaymentArrangementPayee();
        paymentArrangementPayeeDTO.setRecordEffectiveDate( LocalDate.now() );
        paymentArrangementPayeeDTO.setRecordEndDate( LocalDate.now() );
        paymentArrangementPayeeDTO.setCreateUserId( "U402537" );
        paymentArrangementPayeeDTO.setUpdateUserId( "U402537" );
        paymentArrangementPayeeDTO.setRowAction( RowActionTypes.NO_ACTION );
        paymentArrangementPayeeDTO.setPaymentArrangementId( null );
        paymentArrangementPayeeDTO.setVbrPayee( getVbrPayee() );
        paymentArrangementPayees.add( paymentArrangementPayeeDTO );

        PaymentArrangementPayee paymentArrangementPayeeDTO1 = new PaymentArrangementPayee();
        paymentArrangementPayeeDTO1.setRecordEffectiveDate( LocalDate.now() );
        paymentArrangementPayeeDTO1.setRecordEndDate( LocalDate.now() );
        paymentArrangementPayeeDTO1.setCreateUserId( "U402537" );
        paymentArrangementPayeeDTO1.setUpdateUserId( "U402537" );
        paymentArrangementPayeeDTO1.setRowAction( RowActionTypes.NO_ACTION );
        paymentArrangementPayeeDTO1.setPaymentArrangementId( null );
        paymentArrangementPayeeDTO1.setVbrPayee( getVbrPayee() );
        paymentArrangementPayees.add( paymentArrangementPayeeDTO1 );
        return paymentArrangementPayees;
    }

    private VbrPayee getVbrPayee()
    {
        VbrPayee vbrPayeeDTO = new VbrPayee();
        vbrPayeeDTO.setCorporateEntityCode( "NM1" );
        vbrPayeeDTO.setNetworkAssocProviderId( 772129222 );
        vbrPayeeDTO.setNetworkCode( "MCD" );
        vbrPayeeDTO.setPinGroupId( "RSK" );
        vbrPayeeDTO.setPayToPfinId( "00NMCAB001" );
        vbrPayeeDTO.setCapitationCode( "A1" );
        vbrPayeeDTO.setCapitationProcessCode( "CP" );
        vbrPayeeDTO.setPinGroupName( "RSK001" );
        vbrPayeeDTO.setTaxIdNumber( "999999999" );
        vbrPayeeDTO.setRecordEffectiveDate( LocalDate.now() );
        vbrPayeeDTO.setRecordEndDate( LocalDate.now() );
        vbrPayeeDTO.setCreateUserId( "U402537" );
        vbrPayeeDTO.setUpdateUserId( "U402537" );
        vbrPayeeDTO.setCreateRecordTimestamp( null );
        vbrPayeeDTO.setUpdateRecordTimestamp( null );
        vbrPayeeDTO.setRowAction( RowActionTypes.NO_ACTION );
        //        vbrPayeeDTO.setVbrPayeeId( 181 );
        return vbrPayeeDTO;
    }

}