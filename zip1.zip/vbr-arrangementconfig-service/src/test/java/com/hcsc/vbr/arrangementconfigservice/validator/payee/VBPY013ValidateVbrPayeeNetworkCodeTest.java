package com.hcsc.vbr.arrangementconfigservice.validator.payee;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnitRunner;

import com.hcsc.vbr.arrangementconfigservice.domain.VbrPayee;
import com.hcsc.vbr.common.dto.ReturnMessageDTO;

@RunWith( MockitoJUnitRunner.Silent.class )
public class VBPY013ValidateVbrPayeeNetworkCodeTest
{
    @InjectMocks
    private VBPY013ValidateVbrPayeeNetworkCode vbpy013ValidateVbrPayeeNetworkCode;

    @Test
    public void validateVbrPayeeNetworkCodeFieldLength() throws Exception
    {

        vbpy013ValidateVbrPayeeNetworkCode.validateVbrPayeeNetworkCodeFieldLength( getVbrPayee_Success(),
                                                                                   getReturnMessageDTO() );
    }

    @Test( expected = NullPointerException.class )
    public void validateVbrPayeeNetworkCodeFieldLength_Failure() throws Exception
    {

        vbpy013ValidateVbrPayeeNetworkCode.validateVbrPayeeNetworkCodeFieldLength( getVbrPayee_Failure(),
                                                                                   getReturnMessageDTO() );
    }

    private VbrPayee getVbrPayee_Failure()
    {
        VbrPayee vbrPayee = new VbrPayee();

        vbrPayee.setNetworkCode( "MCDjnfdjfkjbkjcdckjdkjckjdchdcbwe" );
        return vbrPayee;

    }

    private VbrPayee getVbrPayee_Success()
    {
        VbrPayee vbrPayee = new VbrPayee();

        vbrPayee.setNetworkCode( "MCD" );
        return vbrPayee;

    }

    private ReturnMessageDTO getReturnMessageDTO()
    {
        ReturnMessageDTO returnMessage = new ReturnMessageDTO();
        return returnMessage;
    }

}
