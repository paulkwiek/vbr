package com.hcsc.vbr.arrangementconfigservice.validator.payee;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnitRunner;

import com.hcsc.vbr.arrangementconfigservice.domain.VbrPayee;
import com.hcsc.vbr.common.constant.VBRCommonConstant.RowActionTypes;
import com.hcsc.vbr.common.dto.ReturnMessageDTO;

@RunWith( MockitoJUnitRunner.Silent.class )
public class VBPY017ValidateNoRecordsFoundForPayeeTest
{

    @InjectMocks
    private VBPY017ValidateNoRecordsFoundForPayee vbpy017ValidateNoRecordsFoundForPayee;

    @Test
    public void isRecordsFound() throws Exception
    {

        vbpy017ValidateNoRecordsFoundForPayee.isRecordsFound( getPayees(),
                                                              getReturnMessageDTO() );
    }

    @Test( expected = NullPointerException.class )
    public void isRecordsFound_Failure() throws Exception
    {

        vbpy017ValidateNoRecordsFoundForPayee.isRecordsFound( getPayees_Empty(),
                                                              getReturnMessageDTO() );
    }

    private List<VbrPayee> getPayees()
    {

        List<VbrPayee> payees = new ArrayList<VbrPayee>();
        VbrPayee vbrPayee = new VbrPayee();
        vbrPayee.setCorporateEntityCode( "NM" );
        vbrPayee.setNetworkAssocProviderId( 772129111 );
        vbrPayee.setNetworkCode( "MCD" );
        vbrPayee.setCapitationProcessCode( "CP" );
        vbrPayee.setPinGroupId( "RE1" );
        vbrPayee.setPayToPfinId( "00NMCAP001" );
        vbrPayee.setCapitationCode( "A1" );
        vbrPayee.setPinGroupName( "RE1001" );
        vbrPayee.setTaxIdNumber( "999999999" );
        vbrPayee.setNetworkAssociationEffectiveDate( "01/01/2019" );
        vbrPayee.setNetworkAssociationEndDate( "12/31/2019" );
        vbrPayee.setPfinEffectiveDate( "01/01/2019" );
        vbrPayee.setPfinEndDate( "12/31/2019" );
        vbrPayee.setPinGroupEffectiveDate( "01/01/2019" );
        vbrPayee.setPinGroupEndDate( "12/31/2019" );
        vbrPayee.setTinEffectiveDate( "02/22/2019" );
        vbrPayee.setTinEndDate( "02/21/2020" );
        vbrPayee.setRecordEffectiveDate( LocalDate.of( 2019,
                                                       11,
                                                       01 ) );
        vbrPayee.setRecordEndDate( LocalDate.of( 2019,
                                                 11,
                                                 30 ) );
        vbrPayee.setCreateUserId( "u399768" );
        vbrPayee.setUpdateUserId( "u399768" );
        vbrPayee.setRowAction( RowActionTypes.INSERT );
        payees.add( vbrPayee );
        return payees;

    }

    private List<VbrPayee> getPayees_Empty()
    {

        List<VbrPayee> payees = new ArrayList<VbrPayee>();

        payees.removeAll( payees );
        return payees;

    }

    private ReturnMessageDTO getReturnMessageDTO()
    {
        ReturnMessageDTO returnMessage = new ReturnMessageDTO();
        return returnMessage;
    }

}
