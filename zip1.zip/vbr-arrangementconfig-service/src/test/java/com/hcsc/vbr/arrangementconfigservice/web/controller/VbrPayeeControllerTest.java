package com.hcsc.vbr.arrangementconfigservice.web.controller;

import static org.junit.Assert.assertEquals;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.boot.test.json.JacksonTester;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.hcsc.vbr.arrangementconfigservice.dto.VbrPayeeDTO;
import com.hcsc.vbr.arrangementconfigservice.service.VbrPayeeService;
import com.hcsc.vbr.web.controller.VbrPayeeController;
import com.hcsc.vbr.web.request.PayeeSaveRequest;
import com.hcsc.vbr.web.request.PayeeSearchRequest;

@RunWith( MockitoJUnitRunner.class )
public class VbrPayeeControllerTest
{
    @InjectMocks
    private VbrPayeeController vbrPayeeController;

    @Mock
    private VbrPayeeService vbrPayeeService;

    private MockMvc mvc;

    @Before
    public void initTest() throws Exception
    {
        MockitoAnnotations.initMocks( this );
        JacksonTester.initFields( this,
                                  new ObjectMapper() );
        mvc = MockMvcBuilders.standaloneSetup( vbrPayeeController ).setControllerAdvice( new Exception() ).build();
    }

    @Test
    public void testsaveVbrPayee() throws Exception
    {
        ObjectMapper map = new ObjectMapper();
        String jsonReq = map.writeValueAsString( payeeSaveRequest() );
        MvcResult result = null;

        result = mvc
                .perform( MockMvcRequestBuilders.post( "/payee/savePayee" )
                        .content( jsonReq )
                        .contentType( MediaType.APPLICATION_JSON )
                        .accept( MediaType.APPLICATION_JSON ) )
                .andExpect( status().isOk() )
                .andReturn();

        assertEquals( 200,
                      result.getResponse().getStatus() );

    }

    @Test
    public void testSearchVbrPayee() throws Exception
    {
        ObjectMapper objectMapper = new ObjectMapper();
        String request = objectMapper.writeValueAsString( getPayeeSearchRequest() );
        MvcResult result = mvc
                .perform( MockMvcRequestBuilders.post( "/payee/searchPayee" )
                        .content( request )
                        .contentType( MediaType.APPLICATION_JSON )
                        .accept( MediaType.APPLICATION_JSON ) )
                .andExpect( status().isOk() )
                .andReturn();

        assertEquals( 200,
                      result.getResponse().getStatus() );
    }

    @Test
    public void testRetrieveVbrPayee() throws Exception
    {
        ObjectMapper objectMapper = new ObjectMapper();
        String request = objectMapper.writeValueAsString( getPayeeSearchRequest() );
        MvcResult result = mvc
                .perform( MockMvcRequestBuilders.post( "/payee/retrievePayee" )
                        .content( request )
                        .contentType( MediaType.APPLICATION_JSON )
                        .accept( MediaType.APPLICATION_JSON ) )
                .andExpect( status().isOk() )
                .andReturn();

        assertEquals( 200,
                      result.getResponse().getStatus() );
    }

    @Test
    public void testRetrieveVbrPayees() throws Exception
    {
        ObjectMapper objectMapper = new ObjectMapper();
        String request = objectMapper.writeValueAsString( getMultiplePayee() );
        MvcResult result = mvc
                .perform( MockMvcRequestBuilders.post( "/payee/retrievePayees" )
                        .content( request )
                        .contentType( MediaType.APPLICATION_JSON )
                        .accept( MediaType.APPLICATION_JSON ) )
                .andExpect( status().isOk() )
                .andReturn();

        assertEquals( 200,
                      result.getResponse().getStatus() );
    }

    @Test
    public void testValidateUniquePayee() throws Exception
    {
        ObjectMapper objectMapper = new ObjectMapper();
        String request = objectMapper.writeValueAsString( payeeSaveRequest() );
        MvcResult result = mvc
                .perform( MockMvcRequestBuilders.post( "/payee/validateUniquePayee" )
                        .content( request )
                        .contentType( MediaType.APPLICATION_JSON )
                        .accept( MediaType.APPLICATION_JSON ) )
                .andExpect( status().isOk() )
                .andReturn();

        assertEquals( 200,
                      result.getResponse().getStatus() );
    }

    private PayeeSaveRequest payeeSaveRequest()
    {
        PayeeSaveRequest payeeSaveRequest = new PayeeSaveRequest();
        VbrPayeeDTO vbrPayee = new VbrPayeeDTO();
        vbrPayee.setCapitationCode( "CP" );
        vbrPayee.setCorporateEntityCode( "NM1" );
        vbrPayee.setCreateUserId( "USR1" );
        vbrPayee.setUpdateUserId( "USR2" );
        payeeSaveRequest.setPayee( vbrPayee );
        return payeeSaveRequest;

    }

    private PayeeSearchRequest getPayeeSearchRequest()
    {
        PayeeSearchRequest payeeSearchRequest = new PayeeSearchRequest();

        payeeSearchRequest.setCapitationTypeCode( "IL1" );
        payeeSearchRequest.setProcessCode( "CPC" );
        payeeSearchRequest.setCorpEntityCode( "IC1" );
        payeeSearchRequest.setNetworkAssociationID( 1 );
        payeeSearchRequest.setNetworkCode( "IN1" );
        payeeSearchRequest.setPayToPFIN( "1" );
        payeeSearchRequest.setPinGroupId( "1" );

        return payeeSearchRequest;

    }

    private List<PayeeSearchRequest> getMultiplePayee()
    {
        PayeeSearchRequest payeeSearchRequest = new PayeeSearchRequest();
        List<PayeeSearchRequest> request = new ArrayList<PayeeSearchRequest>();
        payeeSearchRequest.setCapitationTypeCode( "IL1" );
        payeeSearchRequest.setProcessCode( "CPC" );
        payeeSearchRequest.setCorpEntityCode( "IC1" );
        payeeSearchRequest.setNetworkAssociationID( 1 );
        payeeSearchRequest.setNetworkCode( "IN1" );
        payeeSearchRequest.setPayToPFIN( "1" );
        payeeSearchRequest.setPinGroupId( "1" );
        request.add( payeeSearchRequest );
        return request;

    }

}
