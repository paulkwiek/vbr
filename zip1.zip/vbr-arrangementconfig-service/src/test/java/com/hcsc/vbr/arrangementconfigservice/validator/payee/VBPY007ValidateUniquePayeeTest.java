package com.hcsc.vbr.arrangementconfigservice.validator.payee;

import java.time.LocalDate;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import com.hcsc.vbr.arrangementconfigservice.domain.VbrPayee;
import com.hcsc.vbr.arrangementconfigservice.repository.VbrPayeeRepository;
import com.hcsc.vbr.common.constant.VBRCommonConstant.RowActionTypes;
import com.hcsc.vbr.common.dto.ReturnMessageDTO;

@RunWith( MockitoJUnitRunner.Silent.class )
public class VBPY007ValidateUniquePayeeTest
{

    @InjectMocks
    private VBPY007ValidateUniquePayee vbpy007ValidateUniquePayee;

    @Mock
    private VbrPayeeRepository vbrPayeeRepository;

    @Test
    public void validateUniquePayee() throws Exception
    {

        vbpy007ValidateUniquePayee.validateUniquePayee( getVbrPayee_Success(),
                                                        getReturnMessageDTO() );
    }

    @Test
    public void validateUniquePayee_Failure() throws Exception
    {

        vbpy007ValidateUniquePayee.validateUniquePayee( getVbrPayee_Failure(),
                                                        getReturnMessageDTO() );
    }

    private VbrPayee getVbrPayee_Failure()
    {
        VbrPayee vbrPayee = new VbrPayee();
        vbrPayee.setCorporateEntityCode( "NM" );
        vbrPayee.setNetworkAssocProviderId( 772129111 );
        vbrPayee.setNetworkCode( "MCD" );
        vbrPayee.setCapitationProcessCode( "CP" );
        vbrPayee.setPinGroupId( "RE1" );
        vbrPayee.setPayToPfinId( "00NMCAP001" );
        vbrPayee.setCapitationCode( "A1" );
        vbrPayee.setPinGroupName( "RE1001" );
        vbrPayee.setTaxIdNumber( "999999999" );
        vbrPayee.setNetworkAssociationEffectiveDate( "01/01/2019" );
        vbrPayee.setNetworkAssociationEndDate( "12/31/2019" );
        vbrPayee.setPfinEffectiveDate( "01/01/2019" );
        vbrPayee.setPfinEndDate( "12/31/2019" );
        vbrPayee.setPinGroupEffectiveDate( "01/01/2019" );
        vbrPayee.setPinGroupEndDate( "12/31/2019" );
        vbrPayee.setTinEffectiveDate( "02/22/2019" );
        vbrPayee.setTinEndDate( "02/21/2020" );
        vbrPayee.setRecordEffectiveDate( LocalDate.of( 2019,
                                                       11,
                                                       01 ) );
        vbrPayee.setRecordEndDate( LocalDate.of( 2019,
                                                 11,
                                                 30 ) );
        vbrPayee.setCreateUserId( "u399768" );
        vbrPayee.setUpdateUserId( "u399768" );
        vbrPayee.setRowAction( RowActionTypes.INSERT );
        return vbrPayee;

    }

    private VbrPayee getVbrPayee_Success()
    {
        VbrPayee vbrPayee = new VbrPayee();
        vbrPayee.setCorporateEntityCode( "NM" );
        vbrPayee.setNetworkAssocProviderId( 772129111 );
        vbrPayee.setNetworkCode( "MCD" );
        vbrPayee.setCapitationProcessCode( "CP" );
        vbrPayee.setPinGroupId( "RE1" );
        vbrPayee.setPayToPfinId( "00NMCAP001" );
        vbrPayee.setCapitationCode( "A1" );
        vbrPayee.setPinGroupName( "RE1001" );
        vbrPayee.setTaxIdNumber( "999999999" );
        vbrPayee.setNetworkAssociationEffectiveDate( "01/01/2019" );
        vbrPayee.setNetworkAssociationEndDate( "12/31/2019" );
        vbrPayee.setPfinEffectiveDate( "01/01/2019" );
        vbrPayee.setPfinEndDate( "12/31/2019" );
        vbrPayee.setPinGroupEffectiveDate( "01/01/2019" );
        vbrPayee.setPinGroupEndDate( "12/31/2019" );
        vbrPayee.setTinEffectiveDate( "02/22/2019" );
        vbrPayee.setTinEndDate( "02/21/2020" );
        vbrPayee.setRecordEffectiveDate( LocalDate.of( 2019,
                                                       11,
                                                       01 ) );
        vbrPayee.setRecordEndDate( LocalDate.of( 2019,
                                                 11,
                                                 30 ) );
        vbrPayee.setCreateUserId( "u399768" );
        vbrPayee.setUpdateUserId( "u399768" );
        vbrPayee.setRowAction( RowActionTypes.INSERT );
        return vbrPayee;

    }

    private ReturnMessageDTO getReturnMessageDTO()
    {
        ReturnMessageDTO returnMessage = new ReturnMessageDTO();
        return returnMessage;
    }

}
