package com.hcsc.vbr.arrangementconfigservice.service;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import com.hcsc.vbr.arrangementconfigservice.domain.PaymentArrangementRate;
import com.hcsc.vbr.arrangementconfigservice.mapper.PaymentArrangementMapper;
import com.hcsc.vbr.arrangementconfigservice.validator.paymentarrangementrate.PaymentArrangmentRateValidator;
import com.hcsc.vbr.web.request.ValidateArrangementRateRequest;

@RunWith( MockitoJUnitRunner.class )
public class PaymentArrangementRateServiceTest
{
    @InjectMocks
    PaymentArrangementRateService paymentArrangementRateService;

    @Mock
    private PaymentArrangmentRateValidator paymentArrangmentRateValidator;

    @Mock
    private PaymentArrangementMapper paymentArrangementMapper;

    @Test
    public void validatePaymentArrangementRateTest() throws Exception
    {
        when( paymentArrangementMapper.toPaymentArrangementRate( any() ) ).thenReturn( getPaymentArrangementRate() );
        paymentArrangementRateService.validatePaymentArrangementRate( getValidateArrangementRateRequest() );

    }

    private ValidateArrangementRateRequest getValidateArrangementRateRequest()
    {
        ValidateArrangementRateRequest validateArrangementRateRequest = new ValidateArrangementRateRequest();

        return validateArrangementRateRequest;
    }

    private PaymentArrangementRate getPaymentArrangementRate()
    {
        PaymentArrangementRate paymentArrangementRate = new PaymentArrangementRate();
        return paymentArrangementRate;
    }

}
