package com.hcsc.vbr.arrangementconfigservice.validator.paymentarrangementrate;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnitRunner;

import com.hcsc.vbr.arrangementconfigservice.domain.FlatRate;
import com.hcsc.vbr.arrangementconfigservice.domain.PaymentArrangementRate;
import com.hcsc.vbr.common.dto.ReturnMessageDTO;

@RunWith( MockitoJUnitRunner.class )
public class PMRT002CheckCoverageForGlobalRateVsArrangementRateTest
{

    @InjectMocks
    private PMRT002CheckCoverageForGlobalRateVsArrangementRate pmrt002CheckCoverageForGlobalRateVsArrangementRate;

    @Test
    public void CheckCoverageForGlobalRateVsArrangementRateTest_success() throws Exception
    {
        pmrt002CheckCoverageForGlobalRateVsArrangementRate
                .CheckCoverageForGlobalRateVsArrangementRate( getPaymentArrangementRates_success(),
                                                              getFlatRates_success(),
                                                              getReturnMessageDTO() );
    }

    @Test( expected = NullPointerException.class )
    public void CheckCoverageForGlobalRateVsArrangementRateTest_failure() throws Exception
    {
        pmrt002CheckCoverageForGlobalRateVsArrangementRate
                .CheckCoverageForGlobalRateVsArrangementRate( getPaymentArrangementRates_failure(),
                                                              getFlatRates_faliure(),
                                                              getReturnMessageDTO() );
    }

    @Test
    public void CheckCoverageForGlobalRateVsArrangementRateTest_failure1() throws Exception
    {
        pmrt002CheckCoverageForGlobalRateVsArrangementRate
                .CheckCoverageForGlobalRateVsArrangementRate( getPaymentArrangementRates_failure1(),
                                                              getFlatRates_faliure1(),
                                                              getReturnMessageDTO() );
    }

    private List<PaymentArrangementRate> getPaymentArrangementRates_success()
    {
        List<PaymentArrangementRate> paymentArrangementRates = new ArrayList<PaymentArrangementRate>();
        PaymentArrangementRate paymentArrangementRate = new PaymentArrangementRate();
        paymentArrangementRate.setRecordEffectiveDate( LocalDate.MIN );
        paymentArrangementRate.setRecordEndDate( LocalDate.MAX );
        paymentArrangementRates.add( paymentArrangementRate );
        return paymentArrangementRates;
    }

    private List<PaymentArrangementRate> getPaymentArrangementRates_failure()
    {
        List<PaymentArrangementRate> paymentArrangementRates = new ArrayList<PaymentArrangementRate>();
        PaymentArrangementRate paymentArrangementRate = new PaymentArrangementRate();
        paymentArrangementRate.setRecordEffectiveDate( LocalDate.now() );
        paymentArrangementRate.setRecordEndDate( LocalDate.now() );
        paymentArrangementRates.add( paymentArrangementRate );
        return paymentArrangementRates;
    }

    private List<PaymentArrangementRate> getPaymentArrangementRates_failure1()
    {
        List<PaymentArrangementRate> paymentArrangementRates = new ArrayList<PaymentArrangementRate>();
        PaymentArrangementRate paymentArrangementRate = new PaymentArrangementRate();
        paymentArrangementRate.setRecordEffectiveDate( LocalDate.now() );
        paymentArrangementRate.setRecordEndDate( LocalDate.now() );
        paymentArrangementRates.add( paymentArrangementRate );
        return paymentArrangementRates;
    }

    private List<FlatRate> getFlatRates_success()
    {
        List<FlatRate> flatRates = new ArrayList<FlatRate>();
        FlatRate flatRate = new FlatRate();
        flatRate.setRecordEffectiveDate( LocalDate.MIN );
        flatRate.setRecordEndDate( LocalDate.MAX );
        flatRates.add( flatRate );
        return flatRates;
    }

    private List<FlatRate> getFlatRates_faliure()
    {
        List<FlatRate> flatRates = new ArrayList<FlatRate>();
        FlatRate flatRate = new FlatRate();
        flatRate.setRecordEffectiveDate( LocalDate.now() );
        flatRate.setRecordEndDate( LocalDate.now() );
        flatRates.add( flatRate );
        return flatRates;
    }

    private List<FlatRate> getFlatRates_faliure1()
    {
        List<FlatRate> flatRates = new ArrayList<FlatRate>();
        FlatRate flatRate = new FlatRate();
        flatRate.setRecordEffectiveDate( LocalDate.now().minusDays( 1 ) );
        flatRate.setRecordEndDate( LocalDate.now().plusDays( 1 ) );
        flatRates.add( flatRate );
        return flatRates;
    }

    private ReturnMessageDTO getReturnMessageDTO()
    {
        ReturnMessageDTO returnMessageDTO = new ReturnMessageDTO();
        return returnMessageDTO;
    }
}
