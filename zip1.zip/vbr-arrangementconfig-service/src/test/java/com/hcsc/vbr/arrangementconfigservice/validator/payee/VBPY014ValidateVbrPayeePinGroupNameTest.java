package com.hcsc.vbr.arrangementconfigservice.validator.payee;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnitRunner;

import com.hcsc.vbr.arrangementconfigservice.domain.VbrPayee;
import com.hcsc.vbr.common.dto.ReturnMessageDTO;

@RunWith( MockitoJUnitRunner.Silent.class )
public class VBPY014ValidateVbrPayeePinGroupNameTest
{
    @InjectMocks
    private VBPY014ValidateVbrPayeePinGroupName vbpy014ValidateVbrPayeePinGroupName;

    @Test
    public void validateVbrPayeeCorporateEntityCodeFieldLength() throws Exception
    {

        vbpy014ValidateVbrPayeePinGroupName.validateVbrPayeePinGroupNameFieldLength( getVbrPayee_Success(),
                                                                                     getReturnMessageDTO() );
    }

    @Test
    public void validateVbrPayeeCorporateEntityCodeFieldLength_Failure() throws Exception
    {

        vbpy014ValidateVbrPayeePinGroupName.validateVbrPayeePinGroupNameFieldLength( getVbrPayee_Failure(),
                                                                                     getReturnMessageDTO() );
    }

    private VbrPayee getVbrPayee_Failure()
    {
        VbrPayee vbrPayee = new VbrPayee();

        vbrPayee.setPinGroupName( "RE1001n HJwgsd " );
        return vbrPayee;

    }

    private VbrPayee getVbrPayee_Success()
    {
        VbrPayee vbrPayee = new VbrPayee();

        vbrPayee.setPinGroupName( "RE1001" );
        return vbrPayee;

    }

    private ReturnMessageDTO getReturnMessageDTO()
    {
        ReturnMessageDTO returnMessage = new ReturnMessageDTO();
        return returnMessage;
    }
}
