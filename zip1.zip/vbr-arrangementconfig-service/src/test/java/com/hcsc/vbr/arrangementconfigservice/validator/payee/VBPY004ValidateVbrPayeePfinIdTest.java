package com.hcsc.vbr.arrangementconfigservice.validator.payee;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnitRunner;

import com.hcsc.vbr.arrangementconfigservice.domain.VbrPayee;
import com.hcsc.vbr.common.dto.ReturnMessageDTO;

@RunWith( MockitoJUnitRunner.Silent.class )
public class VBPY004ValidateVbrPayeePfinIdTest
{

    @InjectMocks
    private VBPY004ValidateVbrPayeePfinId vbpy004ValidateVbrPayeePfinId;

    @Test
    public void validateVbrPayeePfinIdFieldLength() throws Exception
    {

        vbpy004ValidateVbrPayeePfinId.validateVbrPayeePfinIdFieldLength( getVbrPayee_Success(),
                                                                         getReturnMessageDTO() );
    }

    @Test( expected = NullPointerException.class )
    public void validateVbrPayeePfinIdFieldLength_Failure() throws Exception
    {

        vbpy004ValidateVbrPayeePfinId.validateVbrPayeePfinIdFieldLength( getVbrPayee_Failure(),
                                                                         getReturnMessageDTO() );
    }

    private VbrPayee getVbrPayee_Failure()
    {
        VbrPayee vbrPayee = new VbrPayee();

        vbrPayee.setPayToPfinId( "00NMCAP001DbJKHbfjhsdbgfbfjhdfh" );
        return vbrPayee;

    }

    private VbrPayee getVbrPayee_Success()
    {
        VbrPayee vbrPayee = new VbrPayee();

        vbrPayee.setPayToPfinId( "00NMCAP001" );
        return vbrPayee;

    }

    private ReturnMessageDTO getReturnMessageDTO()
    {
        ReturnMessageDTO returnMessage = new ReturnMessageDTO();
        return returnMessage;
    }

}
