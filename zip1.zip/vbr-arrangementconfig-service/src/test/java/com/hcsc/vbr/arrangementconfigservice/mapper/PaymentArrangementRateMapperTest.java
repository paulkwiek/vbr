package com.hcsc.vbr.arrangementconfigservice.mapper;

import java.util.ArrayList;
import java.util.List;

import org.assertj.core.api.Assertions;
import org.junit.Test;

import com.hcsc.vbr.arrangementconfigservice.domain.PaymentArrangementRate;
import com.hcsc.vbr.arrangementconfigservice.dto.PaymentArrangementRateDTO;

public class PaymentArrangementRateMapperTest
{

    /***********************PaymentArrangementRate to PaymentArrangementRateDTO mapping test method*********************************************/
    /**
    * Method: testtoPaymentArrangementRateDTO
    */
    @Test
    public void testtoPaymentArrangementRateDTO()
    {

        PaymentArrangementRateDTO paymentArrangementRateDTO = new PaymentArrangementRateDTO();
        paymentArrangementRateDTO.setPaymentArrangementRateId( 1 );
        paymentArrangementRateDTO.setCorporateEntityCode( "NM" );
        paymentArrangementRateDTO.setPaymentArrangementId( 11 );
        paymentArrangementRateDTO.setRateName( "RTYPE" );

        PaymentArrangementRate paymentArrangementRate =
            PaymentArrangementRateMapper.INSTANCE.toPaymentArrangementRate( paymentArrangementRateDTO );
        Assertions.assertThat( paymentArrangementRate ).hasFieldOrPropertyWithValue( "paymentArrangementRateId",
                                                                                     1 );
        Assertions.assertThat( paymentArrangementRate ).hasFieldOrPropertyWithValue( "corporateEntityCode",
                                                                                     "NM" );

        Assertions.assertThat( paymentArrangementRate ).hasFieldOrPropertyWithValue( "paymentArrangementId",
                                                                                     11 );

        Assertions.assertThat( paymentArrangementRate ).hasFieldOrPropertyWithValue( "rateName",
                                                                                     "RTYPE" );

    }

    /**
    * Method: testNulltoPaymentArrangementRateDTO
    */
    @Test
    public void testNulltoPaymentArrangementRateDTO()
    {
        PaymentArrangementRateDTO paymentArrangementRateDTO =
            PaymentArrangementRateMapper.INSTANCE.toPaymentArrangementRateDTO( null );
        Assertions.assertThat( paymentArrangementRateDTO == null );
    }

    /***********************PaymentArrangementRateDTO to PaymentArrangementRate mapping test method*********************************************/

    /**
     * Method: testtoPaymentArrangementRate
     */
    @Test
    public void testtoPaymentArrangementRate()
    {

        PaymentArrangementRate paymentArrangementRate =
            PaymentArrangementRateMapper.INSTANCE.toPaymentArrangementRate( getPaymentArrangementRateDTO() );

        Assertions.assertThat( paymentArrangementRate ).hasFieldOrPropertyWithValue( "paymentArrangementRateId",
                                                                                     1 );
        Assertions.assertThat( paymentArrangementRate ).hasFieldOrPropertyWithValue( "corporateEntityCode",
                                                                                     "NM" );
        Assertions.assertThat( paymentArrangementRate ).hasFieldOrPropertyWithValue( "paymentArrangementId",
                                                                                     11 );
        Assertions.assertThat( paymentArrangementRate ).hasFieldOrPropertyWithValue( "rateName",
                                                                                     "RTYPE" );

    }

    /**
    * Method: testNulltoPaymentArrangementRate
    */
    @Test
    public void testNulltoPaymentArrangementRate()
    {

        PaymentArrangementRate paymentArrangementRate = PaymentArrangementRateMapper.INSTANCE.toPaymentArrangementRate( null );
        Assertions.assertThat( paymentArrangementRate == null );
    }

    /**********Utility methods for testcase******************************/
    /**
     * Method: getPaymentArrangementRate
     * @return
     */
    private PaymentArrangementRate getPaymentArrangementRate()
    {
        PaymentArrangementRate paymentArrangementRate = new PaymentArrangementRate();
        paymentArrangementRate.setPaymentArrangementRateId( 1 );
        paymentArrangementRate.setCorporateEntityCode( "NM" );
        paymentArrangementRate.setRateName( "RTYPE" );

        return paymentArrangementRate;
    }

    /**
     * Method: getPaymentArrangementRateDTO
     * @return
     */
    private PaymentArrangementRateDTO getPaymentArrangementRateDTO()
    {
        PaymentArrangementRateDTO paymentArrangementRateDTO = new PaymentArrangementRateDTO();
        paymentArrangementRateDTO.setPaymentArrangementRateId( 1 );
        paymentArrangementRateDTO.setCorporateEntityCode( "NM" );
        paymentArrangementRateDTO.setPaymentArrangementId( 11 );
        paymentArrangementRateDTO.setRateName( "RTYPE" );

        return paymentArrangementRateDTO;
    }

    /***********************List<PaymentArrangementRateDTO>  to List<PaymentArrangementRate> mapping test method*********************************************/

    /**
     * Method: testtopaymentArrangementRates
     */
    @Test
    public void testtopaymentArrangementRates()
    {
        PaymentArrangementRateDTO paymentArrangementRateDTO = new PaymentArrangementRateDTO();
        paymentArrangementRateDTO.setPaymentArrangementRateId( 1 );
        paymentArrangementRateDTO.setCorporateEntityCode( "NM" );
        paymentArrangementRateDTO.setPaymentArrangementId( 11 );
        paymentArrangementRateDTO.setRateName( "RTYPE" );

        List<PaymentArrangementRateDTO> paymentArrangementRateDTOs = new ArrayList<PaymentArrangementRateDTO>();
        paymentArrangementRateDTOs.add( paymentArrangementRateDTO );

        List<PaymentArrangementRate> paymentArrangementRates =
            PaymentArrangementRateMapper.INSTANCE.toPaymentArrangementRates( paymentArrangementRateDTOs );

        for( PaymentArrangementRate paymentArrangementRate : paymentArrangementRates )
        {
            Assertions.assertThat( paymentArrangementRate ).hasFieldOrPropertyWithValue( "paymentArrangementRateId",
                                                                                         1 );
            Assertions.assertThat( paymentArrangementRate ).hasFieldOrPropertyWithValue( "corporateEntityCode",
                                                                                         "NM" );
            Assertions.assertThat( paymentArrangementRate ).hasFieldOrPropertyWithValue( "paymentArrangementId",
                                                                                         11 );
            Assertions.assertThat( paymentArrangementRate ).hasFieldOrPropertyWithValue( "rateName",
                                                                                         "RTYPE" );

        }
    }

    /***********************List<PaymentArrangementRateDTO>  to List<PaymentArrangementRate> mapping test method*********************************************/

    /**
     * Method: testtopaymentArrangementRates_Neg
     */
    @Test
    public void testtopaymentArrangementRates_Neg()
    {

        List<PaymentArrangementRate> paymentArrangementRateList =
            PaymentArrangementRateMapper.INSTANCE.toPaymentArrangementRates( null );
        Assertions.assertThat( paymentArrangementRateList == null );
    }

    /***********************List<PaymentArrangementRate>  to List<PaymentArrangementRateDTO> mapping test method*********************************************/

    /**
     * Method: testtopaymentArrangementRatesDTO
     */
    //    @Test
    //    public void testtopaymentArrangementRatesDTO()
    //    {
    //        PaymentArrangementRate paymentArrangementRate = new PaymentArrangementRate();
    //        paymentArrangementRate.setPaymentArrangementRateId( 1 );
    //        paymentArrangementRate.setCorporateEntityCode( "NM" );
    //        paymentArrangementRate.setPaymentArrangementId( 11 );
    //        paymentArrangementRate.setRateName( "RTYPE" );
    //
    //        List<PaymentArrangementRate> paymentArrangementRateList = new ArrayList<PaymentArrangementRate>();
    //        paymentArrangementRateList.add( getPaymentArrangementRate() );
    //
    //        List<PaymentArrangementRateDTO> paymentArrangementRateDTOList =
    //            PaymentArrangementRateMapper.INSTANCE.toPaymentArrangementRateDTOs( paymentArrangementRateList );
    //
    //        for( PaymentArrangementRateDTO paymentArrangementRateDTO : paymentArrangementRateDTOList )
    //        {
    //            Assertions.assertThat( paymentArrangementRateDTO ).hasFieldOrPropertyWithValue( "paymentArrangementRateId",
    //                                                                                            1 );
    //            Assertions.assertThat( paymentArrangementRateDTO ).hasFieldOrPropertyWithValue( "corporateEntityCode",
    //                                                                                            "NM" );
    //            Assertions.assertThat( paymentArrangementRateDTO ).hasFieldOrPropertyWithValue( "paymentArrangementId",
    //                                                                                            11 );
    //            Assertions.assertThat( paymentArrangementRateDTO ).hasFieldOrPropertyWithValue( "rateName",
    //                                                                                            "RTYPE" );
    //
    //        }
    //    }

    /***********************List<PaymentArrangementRate>  to List<PaymentArrangementRateDTO> mapping test method*********************************************/
    /**
     * Method: topaymentArrangementRatesDTO_Neg
     */
    @Test
    public void testtopaymentArrangementRatesDTO_Neg()
    {

        List<PaymentArrangementRateDTO> paymentArrangementRateDTOList =
            PaymentArrangementRateMapper.INSTANCE.toPaymentArrangementRateDTOs( null );
        Assertions.assertThat( paymentArrangementRateDTOList == null );
    }

}
