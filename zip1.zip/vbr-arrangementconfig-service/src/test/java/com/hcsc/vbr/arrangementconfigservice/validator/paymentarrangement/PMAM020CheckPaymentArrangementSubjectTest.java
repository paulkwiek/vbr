package com.hcsc.vbr.arrangementconfigservice.validator.paymentarrangement;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.json.JacksonTester;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.hcsc.vbr.arrangementconfigservice.domain.PaymentArrangement;
import com.hcsc.vbr.arrangementconfigservice.domain.PaymentArrangementMemberSubject;
import com.hcsc.vbr.common.constant.VBRCommonConstant.RowActionTypes;
import com.hcsc.vbr.common.dto.ErrorMessageDTO;
import com.hcsc.vbr.common.dto.ReturnMessageDTO;

public class PMAM020CheckPaymentArrangementSubjectTest
{
    @InjectMocks
    PMAM020CheckPaymentArrangementSubject pmam020CheckPaymentArrangementSubject;

    @Before
    public void setUp()
    {
        MockitoAnnotations.initMocks( this );
        JacksonTester.initFields( this,
                                  new ObjectMapper() );

    }

    @Test
    public void validatePaymentArrangementSubject_valid() throws Exception
    {

        pmam020CheckPaymentArrangementSubject.validatePaymentArrangementSubject( getPaymentArrangement_success(),
                                                                                 getReturnMessageDTO() );
    }

    @Test( expected = NullPointerException.class )
    public void validatePaymentArrangementSubject_invalid() throws Exception
    {

        pmam020CheckPaymentArrangementSubject.validatePaymentArrangementSubject( getPaymentArrangement_fail(),
                                                                                 getReturnMessageDTO() );
    }

    private List<ErrorMessageDTO> getErrorMessageDTOSuccess() throws Exception
    {
        List<ErrorMessageDTO> errors = new ArrayList<ErrorMessageDTO>();
        ErrorMessageDTO errorMessageDTO = new ErrorMessageDTO();

        errorMessageDTO.setErrorMessageCategoryCode( "PCF-PMAM" );
        errorMessageDTO.setErrorMessageId( new Long( 226 ) );
        errorMessageDTO.setErrorMsgDescriptionText( "Payment Type Is Required" );
        errorMessageDTO.setSeveritylevel( "E" );
        errors.add( errorMessageDTO );
        return errors;

    }

    private ReturnMessageDTO getReturnMessageDTO() throws Exception
    {
        ReturnMessageDTO returnMessage = new ReturnMessageDTO();

        returnMessage.setItemName( "PCF-PMAM" );
        returnMessage.setStatus( "SUCCESS" );
        returnMessage.setErrors( getErrorMessageDTOSuccess() );
        return returnMessage;

    }

    private PaymentArrangement getPaymentArrangement_success()
    {

        PaymentArrangement paymentArrangementDTO = new PaymentArrangement();
        paymentArrangementDTO.setCorporateEntityCode( "NM1" );
        paymentArrangementDTO.setPaymentArrangementContractId( null );
        paymentArrangementDTO.setPaymentArrangementName( "PaymentArrangementNameTest" );
        paymentArrangementDTO.setArrangementFrequencyCode( "monthly" );
        paymentArrangementDTO.setPaymentArrangementTypeCode( "paymentArrangementTypeCodeTest" );
        paymentArrangementDTO.setPaymentArrangementDescription( "paymentArrangementDescriptionTest" );
        paymentArrangementDTO.setRecordEffectiveDate( LocalDate.now() );
        paymentArrangementDTO.setRecordEndDate( LocalDate.now() );
        paymentArrangementDTO.setCreateUserId( "U402537" );
        paymentArrangementDTO.setUpdateUserId( "U402537" );
        paymentArrangementDTO.setCreateRecordTimestamp( null );
        paymentArrangementDTO.setPaymentArrangementId( null );
        paymentArrangementDTO.setPaymentTypeCode( "paymentTypeCodeTest" );
        paymentArrangementDTO.setValidationStatusCode( null );
        paymentArrangementDTO.setPaymentArrangementId( null );
        paymentArrangementDTO.setRowAction( RowActionTypes.INSERT );
        paymentArrangementDTO.setRetroRuleSetups( null );
        paymentArrangementDTO.setPaymentArrangementHistories( null );
        paymentArrangementDTO.setPaymentArrangementRates( null );
        paymentArrangementDTO.setPaymentArrangementMemberSubjects( getPaymentArrangementMemberSubjects() );
        paymentArrangementDTO.setPaymentArrangementPayees( null );

        return paymentArrangementDTO;
    }

    private PaymentArrangement getPaymentArrangement_fail()
    {

        PaymentArrangement paymentArrangementDTO = new PaymentArrangement();
        paymentArrangementDTO.setCorporateEntityCode( "NM1" );
        paymentArrangementDTO.setPaymentArrangementContractId( null );
        paymentArrangementDTO.setPaymentArrangementName( "PaymentArrangementNameTest" );
        paymentArrangementDTO.setArrangementFrequencyCode( "monthly" );
        paymentArrangementDTO.setPaymentArrangementTypeCode( "paymentArrangementTypeCodeTest" );
        paymentArrangementDTO.setPaymentArrangementDescription( "paymentArrangementDescriptionTest" );
        paymentArrangementDTO.setRecordEffectiveDate( LocalDate.now() );
        paymentArrangementDTO.setRecordEndDate( LocalDate.now() );
        paymentArrangementDTO.setCreateUserId( "U402537" );
        paymentArrangementDTO.setUpdateUserId( "U402537" );
        paymentArrangementDTO.setCreateRecordTimestamp( null );
        paymentArrangementDTO.setPaymentArrangementId( null );
        paymentArrangementDTO.setPaymentTypeCode( "paymentTypeCodeTest" );
        paymentArrangementDTO.setValidationStatusCode( null );
        paymentArrangementDTO.setPaymentArrangementId( null );
        paymentArrangementDTO.setRowAction( RowActionTypes.INSERT );
        paymentArrangementDTO.setRetroRuleSetups( null );
        paymentArrangementDTO.setPaymentArrangementHistories( null );
        paymentArrangementDTO.setPaymentArrangementRates( null );
        paymentArrangementDTO.setPaymentArrangementMemberSubjects( null );
        paymentArrangementDTO.setPaymentArrangementPayees( null );

        return paymentArrangementDTO;
    }

    private List<PaymentArrangementMemberSubject> getPaymentArrangementMemberSubjects()
    {
        List<PaymentArrangementMemberSubject> paymentArrangementMemberSubjects = new ArrayList<PaymentArrangementMemberSubject>();
        PaymentArrangementMemberSubject paymentArrangementMemberSubjectDTO = new PaymentArrangementMemberSubject();
        paymentArrangementMemberSubjectDTO.setContractId( "H8634" );
        paymentArrangementMemberSubjectDTO.setLineOfBusinessCode( "Medicare" );
        paymentArrangementMemberSubjectDTO.setPaymentArrangementMemberSubjectId( null );
        paymentArrangementMemberSubjectDTO.setPaymentArrangementId( null );
        paymentArrangementMemberSubjectDTO.setCorporateEntityCode( "NM1" );
        paymentArrangementMemberSubjectDTO.setRowAction( RowActionTypes.INSERT );
        paymentArrangementMemberSubjectDTO.setCreateUserId( "U402537" );
        paymentArrangementMemberSubjectDTO.setUpdateUserId( "U402537" );
        paymentArrangementMemberSubjects.add( paymentArrangementMemberSubjectDTO );
        return paymentArrangementMemberSubjects;
    }

}
