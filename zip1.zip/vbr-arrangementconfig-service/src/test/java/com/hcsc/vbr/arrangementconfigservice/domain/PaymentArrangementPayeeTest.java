package com.hcsc.vbr.arrangementconfigservice.domain;

public class PaymentArrangementPayeeTest
{
    /* private PaymentArrangementPayee paymentArrangementPayee;
    
    @Before
    public void setUp()
    {
        paymentArrangementPayee = new PaymentArrangementPayee();
    }
    
    @Test
    public void testArrangementPayee()
    {
        paymentArrangementPayee.setPaymentArrangementRateId( Long.valueOf( "1" ) );
        paymentArrangementPayee.setCorporateEntityCode( "IL1" );
        paymentArrangementPayee.setMemberSubjectId( "MEM123" );
        paymentArrangementPayee.setPaymentArrangementId( Long.valueOf( "1" ) );
        paymentArrangementPayee.setPaymentTypeCode( "PAY123" );
        paymentArrangementPayee.setRateName( "R1" );
        paymentArrangementPayee.setRateTypeCode( "RATE123" );
        paymentArrangementPayee.setVbrPayeeId( Long.valueOf( "1" ) );
    
        Assert.assertTrue( paymentArrangementPayee != null );
        Assert.assertEquals( Long.valueOf( "1" ),
                             paymentArrangementPayee.getPaymentArrangementRateId() );
        Assert.assertEquals( "IL1",
                             paymentArrangementPayee.getCorporateEntityCode() );
        Assert.assertEquals( "MEM123",
                             paymentArrangementPayee.getMemberSubjectId() );
        Assert.assertEquals( "PAY123",
                             paymentArrangementPayee.getPaymentTypeCode() );
        Assert.assertEquals( "R1",
                             paymentArrangementPayee.getRateName() );
        Assert.assertEquals( "RATE123",
                             paymentArrangementPayee.getRateTypeCode() );
    
        Assert.assertEquals( Long.valueOf( "1" ),
                             paymentArrangementPayee.getPaymentArrangementId() );
        Assert.assertEquals( Long.valueOf( "1" ),
                             paymentArrangementPayee.getVbrPayeeId() );
    
        Assert.assertTrue( paymentArrangementPayee.toString().contains( "paymentArrangementRateId=1" ) );
    
    }*/

}
