package com.hcsc.vbr.arrangementconfigservice.validator.ratename;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnitRunner;

import com.hcsc.vbr.arrangementconfigservice.domain.FlatRate;
import com.hcsc.vbr.arrangementconfigservice.domain.RateName;
import com.hcsc.vbr.arrangementconfigservice.domain.RateNameId;
import com.hcsc.vbr.common.dto.ReturnMessageDTO;

@RunWith( MockitoJUnitRunner.Silent.class )
public class RTNM001CheckRateAmountTest
{

    @InjectMocks
    RTNM001CheckRateAmount rtnm001CheckRateAmount;

    @Test
    public void validateRateAmount_test() throws Exception
    {

        rtnm001CheckRateAmount.validateRateAmount( getRateName(),
                                                   getReturnMessageDTO() );

    }

    @Test( expected = NullPointerException.class )
    public void validateRateAmount_failure() throws Exception
    {

        rtnm001CheckRateAmount.validateRateAmount( getRateName_Failure(),
                                                   getReturnMessageDTO() );

    }

    @Test( expected = NullPointerException.class )
    public void validateRateAmount_Null() throws Exception
    {

        rtnm001CheckRateAmount.validateRateAmount( getRateName_Failure1(),
                                                   getReturnMessageDTO() );

    }

    private RateName getRateName()
    {

        RateName rtnm = new RateName();
        RateNameId rtnmId = new RateNameId();
        rtnmId.setRateName( "SMOKE25" );
        rtnmId.setCorporateEntityCode( "NM1" );
        rtnm.setRateNameId( rtnmId );
        rtnm.setFlatRates( getflatrateList() );
        return rtnm;
    }

    private List<FlatRate> getflatrateList()
    {
        List<FlatRate> flatRateDTOlist = new ArrayList<FlatRate>();
        FlatRate flatRate = new FlatRate();
        flatRate.setFemaleFlatRateAmount( 456.53 );
        flatRate.setMaleFlatRateAmount( 845.34 );
        flatRate.setRecordEffectiveDate( LocalDate.of( 2019,
                                                       11,
                                                       01 ) );
        flatRate.setRecordEndDate( LocalDate.of( 2019,
                                                 11,
                                                 30 ) );
        flatRateDTOlist.add( flatRate );

        return flatRateDTOlist;
    }

    private RateName getRateName_Failure()
    {

        RateName rtnm = new RateName();
        RateNameId rtnmId = new RateNameId();
        rtnmId.setRateName( "SMOKE25" );
        rtnmId.setCorporateEntityCode( "NM1" );
        rtnm.setRateNameId( rtnmId );
        rtnm.setFlatRates( getflatrateList_Failure() );
        return rtnm;
    }

    private List<FlatRate> getflatrateList_Failure()
    {
        List<FlatRate> flatRateDTOlist = new ArrayList<FlatRate>();
        FlatRate flatRate = new FlatRate();
        flatRate.setFemaleFlatRateAmount( -10.0 );
        flatRate.setMaleFlatRateAmount( -12.0 );

        FlatRate flatRate1 = new FlatRate();
        flatRate1.setFemaleFlatRateAmount( -10.0 );
        flatRate1.setMaleFlatRateAmount( -12.0 );
        flatRateDTOlist.add( flatRate );
        flatRateDTOlist.add( flatRate1 );

        return flatRateDTOlist;
    }

    private RateName getRateName_Failure1()
    {

        RateName rtnm = new RateName();
        RateNameId rtnmId = new RateNameId();
        rtnmId.setRateName( "SMOKE25" );
        rtnmId.setCorporateEntityCode( "NM1" );
        rtnm.setRateNameId( rtnmId );
        rtnm.setFlatRates( getflatrateList_Failure1() );
        return rtnm;
    }

    private List<FlatRate> getflatrateList_Failure1()
    {
        List<FlatRate> flatRateDTOlist = new ArrayList<FlatRate>();
        FlatRate flatRate = new FlatRate();
        flatRate.setFemaleFlatRateAmount( null );
        flatRate.setMaleFlatRateAmount( null );

        FlatRate flatRate1 = new FlatRate();
        flatRate1.setFemaleFlatRateAmount( null );
        flatRate1.setMaleFlatRateAmount( null );
        flatRateDTOlist.add( flatRate );
        flatRateDTOlist.add( flatRate1 );

        return flatRateDTOlist;
    }

    private ReturnMessageDTO getReturnMessageDTO()
    {
        ReturnMessageDTO returnMessage = new ReturnMessageDTO();
        return returnMessage;
    }
}
