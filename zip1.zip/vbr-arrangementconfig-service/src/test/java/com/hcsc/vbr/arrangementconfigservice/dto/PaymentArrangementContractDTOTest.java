package com.hcsc.vbr.arrangementconfigservice.dto;

public class PaymentArrangementContractDTOTest
{
    /*
    @Test
    public void testSetters()
    {
        ContractDTO contract = new ContractDTO();
        contract.setContractId( Long.valueOf( "1" ) );
        contract.setCorporateEntityCode( "IL1" );
        contract.setProgramName( "VBR" );
        contract.setDescription( "desc" );
    
        assertEquals( Long.valueOf( "1" ),
                      contract.getContractId() );
        assertEquals( "IL1",
                      contract.getCorporateEntityCode() );
        assertEquals( "VBR",
                      contract.getProgramName() );
        assertEquals( "desc",
                      contract.getDescription() );
    
        assertTrue( contract.toString().contains( "contractId=1" ) );
    
    }*/

}
