package com.hcsc.vbr.arrangementconfigservice.validator.paymentarrangement;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.json.JacksonTester;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.hcsc.vbr.common.domain.DateRecord;
import com.hcsc.vbr.common.utils.VBRDateUtils;

public class PMAM028CheckGapInArrangementDatesTest
{
    @InjectMocks
    private PMAM028CheckGapInArrangementDates pmam028CheckGapInArrangementDates;

    @Before
    public void setUp()
    {
        MockitoAnnotations.initMocks( this );
        JacksonTester.initFields( this,
                                  new ObjectMapper() );

    }

    @Test
    public void validateGapInArrangmentPayeeEffEndDatesFail() throws Exception
    {

        pmam028CheckGapInArrangementDates.checkForNoArrangementGaps( getdateRecordList_fail(),
                                                                     getdateRecord() );
    }

    @Test
    public void validateGapInArrangmentPayeeEffEndDatesSuccess() throws Exception
    {

        pmam028CheckGapInArrangementDates.checkForNoArrangementGaps( getdateRecordList_success(),
                                                                     getdateRecord() );
    }

    private DateRecord getdateRecord()
    {

        DateRecord dateRecord1 = new DateRecord();
        dateRecord1.setRecordEffectiveDate( VBRDateUtils.convertStringToLocalDateDefaultFormat( "01/01/2019" ) );
        dateRecord1.setRecordEndDate( VBRDateUtils.convertStringToLocalDateDefaultFormat( "12/31/2019" ) );
        return dateRecord1;
    }

    private List<DateRecord> getdateRecordList_fail()
    {
        List<DateRecord> dateRecordList = new ArrayList<DateRecord>();
        DateRecord dateRecord1 = new DateRecord();
        dateRecord1.setRecordEffectiveDate( VBRDateUtils.convertStringToLocalDateDefaultFormat( "01/01/2019" ) );
        dateRecord1.setRecordEndDate( VBRDateUtils.convertStringToLocalDateDefaultFormat( "05/31/2019" ) );
        dateRecordList.add( dateRecord1 );
        DateRecord dateRecord2 = new DateRecord();
        dateRecord2.setRecordEffectiveDate( VBRDateUtils.convertStringToLocalDateDefaultFormat( "07/01/2019" ) );
        dateRecord2.setRecordEndDate( VBRDateUtils.convertStringToLocalDateDefaultFormat( "12/31/2019" ) );
        dateRecordList.add( dateRecord2 );
        return dateRecordList;
    }

    private List<DateRecord> getdateRecordList_success()
    {
        List<DateRecord> dateRecordList = new ArrayList<DateRecord>();
        DateRecord dateRecord1 = new DateRecord();
        dateRecord1.setRecordEffectiveDate( VBRDateUtils.convertStringToLocalDateDefaultFormat( "01/01/2020" ) );
        dateRecord1.setRecordEndDate( VBRDateUtils.convertStringToLocalDateDefaultFormat( "05/31/2020" ) );
        dateRecordList.add( dateRecord1 );
        DateRecord dateRecord2 = new DateRecord();
        dateRecord2.setRecordEffectiveDate( VBRDateUtils.convertStringToLocalDateDefaultFormat( "07/01/2021" ) );
        dateRecord2.setRecordEndDate( VBRDateUtils.convertStringToLocalDateDefaultFormat( "12/31/2021" ) );
        dateRecordList.add( dateRecord2 );
        return dateRecordList;
    }

}
