package com.hcsc.vbr.arrangementconfigservice.domain;

public class VbrPayeeTest
{
    /* private VbrPayee vbrPayee;
    
    @Before
    public void setUp()
    {
        vbrPayee = new VbrPayee();
    }
    
    @Test
    public void testVbrPayee()
    {
        vbrPayee.setVbrPayeeId( Long.valueOf( "1" ) );
        vbrPayee.setCorporateEntityCode( "IL1" );
        vbrPayee.setCapitationCode( "MEM123" );
        vbrPayee.setPayToPfinKeyId( Long.valueOf( "1" ) );
        vbrPayee.setCapitationProcessCode( "PAY123" );
        vbrPayee.setNetworkAssocProviderId( Long.valueOf( "1" ) );
        vbrPayee.setNetworkCode( "RATE123" );
        vbrPayee.setPinGroupId( Long.valueOf( "1" ) );
        vbrPayee.setPinGroupName( "PIN123" );
        vbrPayee.setTaxIdNumber( "TAX123" );
    
        Assert.assertTrue( vbrPayee != null );
        Assert.assertEquals( Long.valueOf( "1" ),
                             vbrPayee.getVbrPayeeId() );
        Assert.assertEquals( "IL1",
                             vbrPayee.getCorporateEntityCode() );
        Assert.assertEquals( "MEM123",
                             vbrPayee.getCapitationCode() );
        Assert.assertEquals( Long.valueOf( "1" ),
                             vbrPayee.getPayToPfinKeyId() );
        Assert.assertEquals( "PAY123",
                             vbrPayee.getCapitationProcessCode() );
        Assert.assertEquals( Long.valueOf( "1" ),
                             vbrPayee.getNetworkAssocProviderId() );
        Assert.assertEquals( "RATE123",
                             vbrPayee.getNetworkCode() );
        Assert.assertEquals( Long.valueOf( "1" ),
                             vbrPayee.getPinGroupId() );
        Assert.assertEquals( "PIN123",
                             vbrPayee.getPinGroupName() );
        Assert.assertEquals( "TAX123",
                             vbrPayee.getTaxIdNumber() );
        
        Assert.assertTrue( vbrPayee.toString().contains( "vbrPayeeId=1" ) );
    
    }*/
}
