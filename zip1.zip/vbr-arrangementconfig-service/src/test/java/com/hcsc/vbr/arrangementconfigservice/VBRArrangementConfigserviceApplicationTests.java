package com.hcsc.vbr.arrangementconfigservice;

import org.junit.Test;

//@RunWith( SpringRunner.class )
//@SpringBootTest( classes = VBRArrangementConfigserviceApplication.class, webEnvironment = WebEnvironment.RANDOM_PORT )
public class VBRArrangementConfigserviceApplicationTests
{
    /*
    @Test
    public void contextLoads()
    {
    }
    */
}
