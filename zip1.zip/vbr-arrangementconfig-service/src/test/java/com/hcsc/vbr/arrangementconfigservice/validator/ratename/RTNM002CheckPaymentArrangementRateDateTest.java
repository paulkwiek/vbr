package com.hcsc.vbr.arrangementconfigservice.validator.ratename;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import com.hcsc.vbr.arrangementconfigservice.domain.PaymentArrangementRate;
import com.hcsc.vbr.arrangementconfigservice.dto.ErrorMessageDTO;
import com.hcsc.vbr.arrangementconfigservice.dto.FlatRateDTO;
import com.hcsc.vbr.arrangementconfigservice.repository.PaymentArrangementRateRepository;
import com.hcsc.vbr.common.constant.VBRCommonConstant.RowActionTypes;

@RunWith( MockitoJUnitRunner.class )
public class RTNM002CheckPaymentArrangementRateDateTest
{
    @InjectMocks
    RTNM002CheckPaymentArrangementRateDate rTNM002CheckPaymentArrangementRateDate;

    @Mock
    public RateNameValidator rateNameValidator;

    @Mock
    PaymentArrangementRateRepository paymentArrangementRateRepository;

    @Test
    public void validateRateDatewithPaymentArrangementRateTest() throws Exception
    {

        when( paymentArrangementRateRepository.getPaymenArrangementRate( any(),
                                                                         any() ) ).thenReturn( getpaymentArrangementRate() );

        rTNM002CheckPaymentArrangementRateDate.validateRateDatewithPaymentArrangementRate( getFlatRateDTO(),
                                                                                           getErrorMessageDTORecord() );

    }

    private FlatRateDTO getFlatRateDTO()
    {
        FlatRateDTO flatRateDTO = new FlatRateDTO();
        flatRateDTO.setRecordEffectiveDate( "01/01/2019" );

        flatRateDTO.setRecordEndDate( "05/31/2019" );
        flatRateDTO.setRowAction( RowActionTypes.valueOf( "UPDATE" ) );

        return flatRateDTO;

    }

    private List<PaymentArrangementRate> getpaymentArrangementRate()
    {
        List<PaymentArrangementRate> paymentArrangementRate = new ArrayList<PaymentArrangementRate>();
        paymentArrangementRate.add( getpaymentArrangementRate1() );
        return paymentArrangementRate;
    }

    private PaymentArrangementRate getpaymentArrangementRate1()
    {
        PaymentArrangementRate paymentArrangementRate = new PaymentArrangementRate();
        paymentArrangementRate.setCorporateEntityCode( "dwedw" );
        paymentArrangementRate.setPaymentArrangementId( 12 );
        paymentArrangementRate.setPaymentArrangementRateId( 34 );
        paymentArrangementRate.setRateName( "rate" );
        return paymentArrangementRate;

    }

    private List<ErrorMessageDTO> getErrorMessageDTORecord() throws Exception
    {
        List<ErrorMessageDTO> errors = new ArrayList<ErrorMessageDTO>();
        ErrorMessageDTO errorMessageDTO = new ErrorMessageDTO();

        errorMessageDTO.setErrorMessageCategoryCode( "PCF-PMAM" );
        errorMessageDTO.setErrorMessageId( new Long( 86 ) );
        errorMessageDTO.setErrorMsgDescriptionText( "Payment Type Is Required" );
        errorMessageDTO.setSeveritylevel( "E" );
        errors.add( errorMessageDTO );
        return errors;

    }
}
