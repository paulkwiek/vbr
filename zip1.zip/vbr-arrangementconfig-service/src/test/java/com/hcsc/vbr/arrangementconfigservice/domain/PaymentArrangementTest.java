package com.hcsc.vbr.arrangementconfigservice.domain;

public class PaymentArrangementTest
{
    /* @Test
    public void testSetters()
    {
        PaymentArrangement paymentArrangemnt = new PaymentArrangement();
        paymentArrangemnt.setPaymentArrangementId( Long.valueOf( "1" ) );
        paymentArrangemnt.setCorporateEntityCode( "CORPCODE12" );
        paymentArrangemnt.setPaymentArrangementTypeCode( "AR123" );
        paymentArrangemnt.setDescription( "Desc" );
        paymentArrangemnt.setContractId( Long.valueOf( 1 ) );
        assertEquals( Long.valueOf( "1" ),
                      paymentArrangemnt.getPaymentArrangementId() );
        assertEquals( "CORPCODE12",
                      paymentArrangemnt.getCorporateEntityCode() );
        assertEquals( "AR123",
                      paymentArrangemnt.getPaymentArrangementTypeCode() );
        assertEquals( "Desc",
                      paymentArrangemnt.getDescription() );
        assertEquals( Long.valueOf( 1 ),
                      paymentArrangemnt.getContractId() );
        assertTrue( paymentArrangemnt.toString().contains( "paymentArrangementId=1" ) );
    
    }*/

}
