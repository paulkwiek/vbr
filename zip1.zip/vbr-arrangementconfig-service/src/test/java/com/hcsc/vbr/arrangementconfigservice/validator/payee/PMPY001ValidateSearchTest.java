/*package com.hcsc.vbr.arrangementconfigservice.validator.payee;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnitRunner;

import com.hcsc.vbr.arrangementconfigservice.dto.ErrorMessageDTO;
import com.hcsc.vbr.web.request.PayeeSearchRequest;

@RunWith( MockitoJUnitRunner.class )
public class PMPY001ValidateSearchTest
{
    @InjectMocks
    private PMPY001ValidateSearch validateSearch;

    @Test
    public void validateSearchAlphaNumeric() throws Exception
    {

        List<ErrorMessageDTO> errorMessageDTOList = getErrorMessageDTOList();
        assertFalse( validateSearch.validateSearch( getPayeeSearchRequest( "1234ABCD" ),
                                                    errorMessageDTOList ) );

        assertTrue( errorMessageDTOList.isEmpty() );

    }

    @Test
    public void validateSearchNumeric() throws Exception
    {

        List<ErrorMessageDTO> errorMessageDTOList = getErrorMessageDTOList();
        assertFalse( validateSearch.validateSearch( getPayeeSearchRequest( "123456789" ),
                                                    errorMessageDTOList ) );

        assertTrue( errorMessageDTOList.isEmpty() );

    }

    @Test
    public void validateSearchLengthAndAlpha() throws Exception
    {

        List<ErrorMessageDTO> errorMessageDTOList = getErrorMessageDTOList();
        assertTrue( validateSearch.validateSearch( getPayeeSearchRequest( "AAAAAAAAAAAAAAAA" ),
                                                   errorMessageDTOList ) );

        assertFalse( errorMessageDTOList.isEmpty() );

    }

    @Test
    public void validateSearchSpecialChar() throws Exception
    {

        List<ErrorMessageDTO> errorMessageDTOList = getErrorMessageDTOList();
        assertTrue( validateSearch.validateSearch( getPayeeSearchRequest( "AAAAAAA@#" ),
                                                   errorMessageDTOList ) );

        assertFalse( errorMessageDTOList.isEmpty() );

    }

    @Test
    public void validateSearchEmpty() throws Exception
    {

        List<ErrorMessageDTO> errorMessageDTOList = getErrorMessageDTOList();
        assertFalse( validateSearch.validateSearch( getPayeeSearchRequest( "" ),
                                                    errorMessageDTOList ) );

        assertTrue( errorMessageDTOList.isEmpty() );

    }

    private PayeeSearchRequest getPayeeSearchRequest( String pinGroupId )
    {
        PayeeSearchRequest payeeSearchRequest = new PayeeSearchRequest();
        payeeSearchRequest.setPinGroupId( pinGroupId );
        return payeeSearchRequest;
    }

    private List<ErrorMessageDTO> getErrorMessageDTOList()
    {
        List<ErrorMessageDTO> errorMessageDTOList = new ArrayList<ErrorMessageDTO>();
        return errorMessageDTOList;
    }

}
*/