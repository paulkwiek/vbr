package com.hcsc.vbr.arrangementconfigservice.validator.payee;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import com.hcsc.vbr.arrangementconfigservice.apiclient.CalculationServiceApiClient;
import com.hcsc.vbr.arrangementconfigservice.domain.PaymentArrangement;
import com.hcsc.vbr.arrangementconfigservice.domain.PaymentArrangementPayee;
import com.hcsc.vbr.arrangementconfigservice.domain.VbrPayee;
import com.hcsc.vbr.arrangementconfigservice.repository.PaymentArrangementPayeeRepository;
import com.hcsc.vbr.arrangementconfigservice.repository.PaymentArrangementRepository;
import com.hcsc.vbr.arrangementconfigservice.validator.paymentarrangement.PMAM019CheckValidationStatusCode;
import com.hcsc.vbr.common.constant.VBRCommonConstant.RowActionTypes;
import com.hcsc.vbr.common.dto.ReturnMessageDTO;

@RunWith( MockitoJUnitRunner.Silent.class )
public class VBPY019ValidateStatusOfLinkedArrangementsInUpdatePayeeTest
{

    @InjectMocks
    private VBPY019ValidateStatusOfLinkedArrangementsInUpdatePayee vbpy019ValidateStatusOfLinkedArrangementsInUpdatePayee;

    @Mock
    private CalculationServiceApiClient calculationServiceApiClient;

    @Mock
    private PaymentArrangementPayeeRepository paymentArrangementPayeeRepository;

    @Mock
    private PaymentArrangementRepository paymentArrangementRepository;

    @Mock
    private PMAM019CheckValidationStatusCode checkValidationStatus;

    @Test( expected = NullPointerException.class )
    public void validateStatusOFLinkedArrangements() throws Exception
    {
        when( calculationServiceApiClient.getCurrentProcessingMonth( any() ) ).thenReturn( LocalDate.of( 2019,
                                                                                                         11,
                                                                                                         30 ) );
        when( paymentArrangementPayeeRepository.findByPayeeId( any() ) ).thenReturn( getpaymentArrangementPayee() );

        when( paymentArrangementRepository.findByArrangementId( any() ) ).thenReturn( getpaymentArrangement() );

        vbpy019ValidateStatusOfLinkedArrangementsInUpdatePayee.validateStatusOFLinkedArrangements( getVbrPayee_Success(),
                                                                                                   getReturnMessageDTO() );
    }

    @Test
    public void validateStatusOFLinkedArrangements_Failure() throws Exception
    {

        vbpy019ValidateStatusOfLinkedArrangementsInUpdatePayee.validateStatusOFLinkedArrangements( getVbrPayee_Success(),
                                                                                                   getReturnMessageDTO() );
    }

    private VbrPayee getVbrPayee_Success()
    {
        VbrPayee vbrPayee = new VbrPayee();
        vbrPayee.setCorporateEntityCode( "NM" );
        vbrPayee.setNetworkAssocProviderId( 772129111 );
        vbrPayee.setNetworkCode( "MCD" );
        vbrPayee.setCapitationProcessCode( "CP" );
        vbrPayee.setPinGroupId( "RE1" );
        vbrPayee.setPayToPfinId( "00NMCAP001" );
        vbrPayee.setCapitationCode( "A1" );
        vbrPayee.setPinGroupName( "RE1001" );
        vbrPayee.setTaxIdNumber( "999999999" );
        vbrPayee.setNetworkAssociationEffectiveDate( "01/01/2019" );
        vbrPayee.setNetworkAssociationEndDate( "12/31/2019" );
        vbrPayee.setPfinEffectiveDate( "01/01/2019" );
        vbrPayee.setPfinEndDate( "12/31/2019" );
        vbrPayee.setPinGroupEffectiveDate( "01/01/2019" );
        vbrPayee.setPinGroupEndDate( "12/31/2019" );
        vbrPayee.setTinEffectiveDate( "02/22/2019" );
        vbrPayee.setTinEndDate( "02/21/2020" );
        vbrPayee.setRecordEffectiveDate( LocalDate.of( 2019,
                                                       11,
                                                       01 ) );
        vbrPayee.setRecordEndDate( LocalDate.of( 2019,
                                                 11,
                                                 30 ) );
        vbrPayee.setCreateUserId( "u399768" );
        vbrPayee.setUpdateUserId( "u399768" );
        vbrPayee.setVbrPayeeId( 425 );
        vbrPayee.setCreateRecordTimestamp( LocalDateTime.of( 2019,
                                                             11,
                                                             25,
                                                             07,
                                                             47,
                                                             8,
                                                             709 ) );
        vbrPayee.setUpdateRecordTimestamp( LocalDateTime.of( 2019,
                                                             12,
                                                             03,
                                                             15,
                                                             42,
                                                             20,
                                                             877 ) );
        vbrPayee.setRowAction( RowActionTypes.UPDATE );
        return vbrPayee;

    }

    private List<VbrPayee> getVbrPayee_Success_empty()
    {
        List<VbrPayee> vbrPayeelist = new ArrayList<>();
        vbrPayeelist.add( getVbrPayee_Success() );
        return vbrPayeelist;

    }

    private PaymentArrangement getpaymentArrangement()
    {
        PaymentArrangement paymentArrangement = new PaymentArrangement();
        paymentArrangement.setPaymentArrangementId( 234 );
        paymentArrangement.setCorporateEntityCode( "" );
        paymentArrangement.setValidationStatusCode( "IV" );
        return paymentArrangement;

    }

    private List<PaymentArrangementPayee> getpaymentArrangementPayee()
    {
        List<PaymentArrangementPayee> paymentArrangementPayeelist = new ArrayList<>();

        PaymentArrangementPayee paymentArrangementPayee = new PaymentArrangementPayee();
        paymentArrangementPayee.setVbrPayeeId( 123 );
        paymentArrangementPayeelist.add( paymentArrangementPayee );
        return paymentArrangementPayeelist;

    }

    private ReturnMessageDTO getReturnMessageDTO()
    {
        ReturnMessageDTO returnMessage = new ReturnMessageDTO();
        return returnMessage;
    }
}
