package com.hcsc.vbr.arrangementconfigservice.mapper;

import java.util.ArrayList;
import java.util.List;

import org.assertj.core.api.Assertions;
import org.junit.Test;

import com.hcsc.vbr.arrangementconfigservice.domain.PaymentArrangementContract;
import com.hcsc.vbr.arrangementconfigservice.dto.PaymentArrangementContractDTO;

public class PaymentArrangementContractMapperTest
{

    @Test
    public void testToContractDTO()
    {
        PaymentArrangementContractDTO dto = PaymentArrangementContractMapper.INSTANCE.toContractDTO( getContract() );
        Assertions.assertThat( dto ).hasFieldOrPropertyWithValue( "paymentArrangementContractId",
                                                                  1 );
        Assertions.assertThat( dto ).hasFieldOrPropertyWithValue( "programCode",
                                                                  "78678" );
        Assertions.assertThat( dto ).hasFieldOrPropertyWithValue( "contractDescription",
                                                                  "description" );
    }

    @Test
    public void testNullToContractDTO()
    {
        PaymentArrangementContractDTO dto = PaymentArrangementContractMapper.INSTANCE.toContractDTO( null );
        Assertions.assertThat( dto == null );
    }

    @Test
    public void testToContractDTOs()
    {
        List<PaymentArrangementContractDTO> dto = PaymentArrangementContractMapper.INSTANCE.toContractDTOs( getContractList() );
        Assertions.assertThat( dto.get( 0 ) ).hasFieldOrPropertyWithValue( "paymentArrangementContractId",
                                                                           1 );
        Assertions.assertThat( dto.get( 0 ) ).hasFieldOrPropertyWithValue( "programCode",
                                                                           "78678" );
        Assertions.assertThat( dto.get( 0 ) ).hasFieldOrPropertyWithValue( "contractDescription",
                                                                           "description" );
    }

    @Test
    public void testNullToContractDTOs()
    {
        List<PaymentArrangementContractDTO> dto = PaymentArrangementContractMapper.INSTANCE.toContractDTOs( null );
        Assertions.assertThat( dto == null );
    }

    @Test
    public void testToContract()
    {
        PaymentArrangementContract dto = PaymentArrangementContractMapper.INSTANCE.toContract( getContractDTO() );
        Assertions.assertThat( dto ).hasFieldOrPropertyWithValue( "paymentArrangementContractId",
                                                                  1 );
        Assertions.assertThat( dto ).hasFieldOrPropertyWithValue( "programCode",
                                                                  "78678" );
        Assertions.assertThat( dto ).hasFieldOrPropertyWithValue( "contractDescription",
                                                                  "description" );
    }

    @Test
    public void testNullToContract()
    {
        PaymentArrangementContract dto = PaymentArrangementContractMapper.INSTANCE.toContract( null );
        Assertions.assertThat( dto == null );
    }

    @Test
    public void testToContracts()
    {
        List<PaymentArrangementContract> dto = PaymentArrangementContractMapper.INSTANCE.toContracts( getContractDTOList() );
        Assertions.assertThat( dto.get( 0 ) ).hasFieldOrPropertyWithValue( "paymentArrangementContractId",
                                                                           1 );
        Assertions.assertThat( dto.get( 0 ) ).hasFieldOrPropertyWithValue( "programCode",
                                                                           "78678" );
        Assertions.assertThat( dto.get( 0 ) ).hasFieldOrPropertyWithValue( "contractDescription",
                                                                           "description" );
    }

    @Test
    public void testNullToContracts()
    {
        List<PaymentArrangementContract> dto = PaymentArrangementContractMapper.INSTANCE.toContracts( null );
        Assertions.assertThat( dto == null );
    }

    private PaymentArrangementContract getContract()
    {
        PaymentArrangementContract contract = new PaymentArrangementContract();
        contract.setPaymentArrangementContractId( 1 );
        contract.setProgramCode( "78678" );
        contract.setContractDescription( "description" );
        return contract;

    }

    private PaymentArrangementContractDTO getContractDTO()
    {
        PaymentArrangementContractDTO contract = new PaymentArrangementContractDTO();
        contract.setPaymentArrangementContractId( 1 );
        contract.setProgramCode( "78678" );
        contract.setContractDescription( "description" );
        return contract;

    }

    private List<PaymentArrangementContract> getContractList()
    {
        List<PaymentArrangementContract> list = new ArrayList<PaymentArrangementContract>();
        list.add( getContract() );
        return list;

    }

    private List<PaymentArrangementContractDTO> getContractDTOList()
    {
        List<PaymentArrangementContractDTO> list = new ArrayList<PaymentArrangementContractDTO>();
        list.add( getContractDTO() );
        return list;

    }
}
