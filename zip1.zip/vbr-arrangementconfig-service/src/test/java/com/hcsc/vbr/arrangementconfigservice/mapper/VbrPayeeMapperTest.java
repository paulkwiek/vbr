package com.hcsc.vbr.arrangementconfigservice.mapper;

import org.assertj.core.api.Assertions;
import org.junit.Test;

import com.hcsc.vbr.arrangementconfigservice.domain.VbrPayee;
import com.hcsc.vbr.arrangementconfigservice.dto.VbrPayeeDTO;

public class VbrPayeeMapperTest
{

    /*
     * *****************************VRPayee and VBRPayeeDTO*******************************************
     * */

    /**
    * Method: testToVbrPayeeDTO
    */
    @Test
    public void testToVbrPayeeDTO()
    {
        VbrPayee vbrPayee = new VbrPayee();
        vbrPayee.setVbrPayeeId( 1 );
        vbrPayee.setNetworkAssocProviderId( 2 );

        VbrPayeeDTO vbrPayeeDTO = VbrPayeeMapper.INSTANCE.toVbrPayeeDTO( vbrPayee );

        Assertions.assertThat( vbrPayeeDTO ).hasFieldOrPropertyWithValue( "vbrPayeeId",
                                                                          1 );
    }

    /**
    * Method: testNullToVbrPayeeDTO
    */
    @Test
    public void testNullToVbrPayeeDTO()
    {
        VbrPayee vbrPayee = new VbrPayee();
        vbrPayee.setNetworkAssocProviderId( 2 );

        VbrPayeeDTO vbrPayeeDTO = VbrPayeeMapper.INSTANCE.toVbrPayeeDTO( vbrPayee );

        Assertions.assertThat( vbrPayeeDTO.getCapitationCode() == null );

    }

    /**
    * Method: testTovbrPayee
    */
    @Test
    public void testTovbrPayee()
    {
        VbrPayeeDTO vbrPayeeDTO = new VbrPayeeDTO();
        vbrPayeeDTO.setVbrPayeeId( 1 );

        VbrPayee vbrPayee = VbrPayeeMapper.INSTANCE.toVbrPayee( vbrPayeeDTO );

        Assertions.assertThat( vbrPayee ).hasFieldOrPropertyWithValue( "vbrPayeeId",
                                                                       1 );
    }

    /**
    * Method: testToNullTovbrPayee
    */
    @Test
    public void testToNullTovbrPayee()
    {

        VbrPayee vbrPayee = VbrPayeeMapper.INSTANCE.toVbrPayee( null );

        Assertions.assertThat( vbrPayee == null );

    }

}
