package com.hcsc.vbr.arrangementconfigservice.validator.paymentarrangement;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.json.JacksonTester;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.hcsc.vbr.arrangementconfigservice.domain.FlatRate;
import com.hcsc.vbr.arrangementconfigservice.domain.PaymentArrangement;
import com.hcsc.vbr.arrangementconfigservice.domain.PaymentArrangementRate;
import com.hcsc.vbr.common.constant.VBRCommonConstant.RowActionTypes;
import com.hcsc.vbr.common.dto.ErrorMessageDTO;
import com.hcsc.vbr.common.dto.ReturnMessageDTO;

public class PMAM014CheckArrangementRateValidForProcessingMonthTest
{
    @InjectMocks
    PMAM014CheckArrangementRateValidForProcessingMonth checkArrangementRateValidForProcessingMonth;

    @Before
    public void setUp()
    {
        MockitoAnnotations.initMocks( this );
        JacksonTester.initFields( this,
                                  new ObjectMapper() );

    }

    @Test
    public void validateArrangementPayeeValidForProcessingMonthTest() throws Exception
    {

        checkArrangementRateValidForProcessingMonth.validateArrangementRateForProcessingMonth( getFlatRates(),
                                                                                               getPaymentArrangementRates(),
                                                                                               getPaymentArrangement(),
                                                                                               LocalDate.now(),
                                                                                               getReturnMessageDTO() );
    }

    private List<ErrorMessageDTO> getErrorMessageDTOSuccess() throws Exception
    {
        List<ErrorMessageDTO> errors = new ArrayList<ErrorMessageDTO>();
        ErrorMessageDTO errorMessageDTO = new ErrorMessageDTO();

        errorMessageDTO.setErrorMessageCategoryCode( "PCF-PMAM" );
        errorMessageDTO.setErrorMessageId( new Long( 226 ) );
        errorMessageDTO.setErrorMsgDescriptionText( "Payment Type Is Required" );
        errorMessageDTO.setSeveritylevel( "E" );
        errors.add( errorMessageDTO );
        return errors;

    }

    private ReturnMessageDTO getReturnMessageDTO() throws Exception
    {
        ReturnMessageDTO returnMessage = new ReturnMessageDTO();

        returnMessage.setItemName( "PCF-PMAM" );
        returnMessage.setStatus( "SUCCESS" );
        returnMessage.setErrors( getErrorMessageDTOSuccess() );
        return returnMessage;

    }

    private PaymentArrangement getPaymentArrangement()
    {

        PaymentArrangement paymentArrangementDTO = new PaymentArrangement();
        paymentArrangementDTO.setCorporateEntityCode( "NM1" );
        paymentArrangementDTO.setPaymentArrangementContractId( null );
        paymentArrangementDTO.setPaymentArrangementName( "PaymentArrangementNameTest" );
        paymentArrangementDTO.setArrangementFrequencyCode( "monthly" );
        paymentArrangementDTO.setPaymentArrangementTypeCode( "paymentArrangementTypeCodeTest" );
        paymentArrangementDTO.setPaymentArrangementDescription( "paymentArrangementDescriptionTest" );
        paymentArrangementDTO.setRecordEffectiveDate( LocalDate.now() );
        paymentArrangementDTO.setRecordEndDate( LocalDate.now() );
        paymentArrangementDTO.setCreateUserId( "U402537" );
        paymentArrangementDTO.setUpdateUserId( "U402537" );
        paymentArrangementDTO.setCreateRecordTimestamp( null );
        paymentArrangementDTO.setPaymentArrangementId( null );
        paymentArrangementDTO.setPaymentTypeCode( "paymentTypeCodeTest" );
        paymentArrangementDTO.setValidationStatusCode( null );
        paymentArrangementDTO.setPaymentArrangementId( null );
        paymentArrangementDTO.setRowAction( RowActionTypes.INSERT );
        paymentArrangementDTO.setRetroRuleSetups( null );
        paymentArrangementDTO.setPaymentArrangementHistories( null );
        paymentArrangementDTO.setPaymentArrangementRates( getPaymentArrangementRates() );
        paymentArrangementDTO.setPaymentArrangementMemberSubjects( null );
        paymentArrangementDTO.setPaymentArrangementPayees( null );

        return paymentArrangementDTO;
    }

    private List<PaymentArrangementRate> getPaymentArrangementRates()
    {
        List<PaymentArrangementRate> paymentArrangementRates = new ArrayList<PaymentArrangementRate>();
        PaymentArrangementRate paymentArrangementRateDTO = new PaymentArrangementRate();
        paymentArrangementRateDTO.setPaymentArrangementRateId( null );
        paymentArrangementRateDTO.setRateName( "RATE07" );
        paymentArrangementRateDTO.setPaymentArrangementId( null );
        paymentArrangementRateDTO.setCorporateEntityCode( "NM1" );
        paymentArrangementRateDTO.setRecordEffectiveDate( LocalDate.now() );
        paymentArrangementRateDTO.setRecordEndDate( LocalDate.now() );
        paymentArrangementRateDTO.setCreateUserId( "U402537" );
        paymentArrangementRateDTO.setUpdateUserId( "U402537" );
        paymentArrangementRateDTO.setRowAction( RowActionTypes.NO_ACTION );
        paymentArrangementRates.add( paymentArrangementRateDTO );

        PaymentArrangementRate paymentArrangementRateDTO1 = new PaymentArrangementRate();
        paymentArrangementRateDTO1.setPaymentArrangementRateId( null );
        paymentArrangementRateDTO1.setRateName( "RATE07" );
        paymentArrangementRateDTO1.setPaymentArrangementId( null );
        paymentArrangementRateDTO1.setCorporateEntityCode( "NM1" );
        paymentArrangementRateDTO1.setRecordEffectiveDate( LocalDate.now() );
        paymentArrangementRateDTO1.setRecordEndDate( LocalDate.now() );
        paymentArrangementRateDTO1.setCreateUserId( "U402537" );
        paymentArrangementRateDTO1.setUpdateUserId( "U402537" );
        paymentArrangementRateDTO1.setRowAction( RowActionTypes.NO_ACTION );
        paymentArrangementRates.add( paymentArrangementRateDTO1 );
        return paymentArrangementRates;
    }

    private List<FlatRate> getFlatRates()
    {
        List<FlatRate> flatRates = new ArrayList<>();
        FlatRate flatRate = new FlatRate();
        flatRate.setRecordEffectiveDate( LocalDate.now() );
        flatRate.setRecordEndDate( LocalDate.now() );
        flatRates.add( flatRate );
        return flatRates;
    }

}