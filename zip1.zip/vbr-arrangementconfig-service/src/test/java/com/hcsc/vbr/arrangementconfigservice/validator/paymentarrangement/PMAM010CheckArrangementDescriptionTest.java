package com.hcsc.vbr.arrangementconfigservice.validator.paymentarrangement;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.json.JacksonTester;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.hcsc.vbr.arrangementconfigservice.constant.ArrangementConfigServiceConstant;
import com.hcsc.vbr.arrangementconfigservice.domain.PaymentArrangement;
import com.hcsc.vbr.common.dto.ErrorMessageDTO;
import com.hcsc.vbr.common.dto.ReturnMessageDTO;

public class PMAM010CheckArrangementDescriptionTest
{
    @InjectMocks
    PMAM010CheckArrangementDescription checkArrangementDescription;

    @Mock
    ArrangementConfigServiceConstant arrangementConfigServiceConstant;

    @Before
    public void setUp()
    {
        MockitoAnnotations.initMocks( this );
        JacksonTester.initFields( this,
                                  new ObjectMapper() );

    }

    @Test( expected = NullPointerException.class )
    public void validateArrangementDescriptionSuccess() throws Exception
    {

        assertEquals( !StringUtils.isBlank( getPaymentArrangementDTO().getPaymentArrangementDescription() ),
                      Boolean.TRUE );

        assertEquals( getPaymentArrangementDTO().getPaymentArrangementDescription().length() > 500,
                      Boolean.TRUE );

        checkArrangementDescription.validateArrangementDescription( getPaymentArrangementDTO(),
                                                                    getReturnMessageDTO() );
    }

    @Test( expected = NullPointerException.class )
    public void validateArrangementDescriptionFail() throws Exception
    {

        assertEquals( !StringUtils.isBlank( getPaymentArrangementDTOFail().getPaymentArrangementDescription() ),
                      Boolean.FALSE );

        checkArrangementDescription.validateArrangementDescription( getPaymentArrangementDTOFail(),
                                                                    getReturnMessageDTO() );
    }

    private PaymentArrangement getPaymentArrangementDTO()
    {

        PaymentArrangement paymentArrangementDTO = new PaymentArrangement();
        paymentArrangementDTO
                .setPaymentArrangementDescription( "PaymentArrangementDescriptionPaymentArrangementDescriptionPaymentArrangementDescriptionPaymentArrangementDescriptionPaymentArrangementDescriptionPaymentArrangementDescriptionPaymentArrangementDescriptionPaymentArrangementDescriptionPaymentArrangementDescriptionPaymentArrangementDescriptionPaymentArrangementDescriptionPaymentArrangementDescriptionPaymentArrangementDescriptionPaymentArrangementDescriptionPaymentArrangementDescriptionPaymentArrangementDescriptionPaymentArrangementDescriptionPaymentArrangementDescriptionPaymentArrangementDescriptionPaymentArrangementDescriptionPaymentArrangementDescriptionPaymentArrangementDescriptionPaymentArrangementDescriptionPaymentArrangementDescriptionPaymentArrangementDescriptionPaymentArrangementDescriptionPaymentArrangementDescriptionPaymentArrangementDescriptionPaymentArrangementDescriptionPaymentArrangementDescriptionPaymentArrangementDescriptionPaymentArrangementDescriptionPaymentArrangementDescriptionPaymentArrangementDescriptionPaymentArrangementDescriptionPaymentArrangementDescriptionPaymentArrangementDescriptionPaymentArrangementDescriptionPaymentArrangementDescriptionPaymentArrangementDescriptionPaymentArrangementDescriptionPaymentArrangementDescriptionPaymentArrangementDescriptionPaymentArrangementDescriptionPaymentArrangementDescriptionPaymentArrangementDescriptionPaymentArrangementDescription" );
        return paymentArrangementDTO;
    }

    private PaymentArrangement getPaymentArrangementDTOFail()
    {

        PaymentArrangement paymentArrangementDTO = new PaymentArrangement();
        paymentArrangementDTO.setPaymentArrangementDescription( null );
        return paymentArrangementDTO;
    }

    private List<ErrorMessageDTO> getErrorMessageDTOSuccess() throws Exception
    {
        List<ErrorMessageDTO> errors = new ArrayList<ErrorMessageDTO>();
        ErrorMessageDTO errorMessageDTO = new ErrorMessageDTO();

        errorMessageDTO.setErrorMessageCategoryCode( "PCF-PMAM" );
        errorMessageDTO.setErrorMessageId( new Long( 226 ) );
        errorMessageDTO.setErrorMsgDescriptionText( "Payment Type Is Required" );
        errorMessageDTO.setSeveritylevel( "E" );
        errors.add( errorMessageDTO );
        return errors;

    }

    private ReturnMessageDTO getReturnMessageDTO() throws Exception
    {
        ReturnMessageDTO returnMessage = new ReturnMessageDTO();

        returnMessage.setItemName( "PCF-PMAM" );
        returnMessage.setStatus( "SUCCESS" );
        returnMessage.setErrors( getErrorMessageDTOSuccess() );
        return returnMessage;

    }

}