package com.hcsc.vbr.arrangementconfigservice.dto;

public class PaymentArrangementRateDTOTest
{
    /*private PaymentArrangementRateDTO paymentArrangementRateDTO;
    
    @Before
    public void setUp()
    {
        paymentArrangementRateDTO = new PaymentArrangementRateDTO();
    }
    
    @Test
    public void PaymentArrangementRateDTO_Test()
    {
        paymentArrangementRateDTO.setPaymentArrangementRateId( Long.valueOf( 1 ) );
        paymentArrangementRateDTO.setCoorporateEntityCode( "NM" );
        paymentArrangementRateDTO.setMemberSubjectId( "U32" );
        paymentArrangementRateDTO.setPaymentArrangementId( Long.valueOf( 1 ) );
        paymentArrangementRateDTO.setPaymentTypeCode( "CAP" );
        paymentArrangementRateDTO.setRateName( "FEMALE LESS THAN 18" );
        paymentArrangementRateDTO.setRateTypeCode( "FLT" );
        paymentArrangementRateDTO.setVbrPayeeId( Long.valueOf( 1 ) );
    
        Assert.assertTrue( paymentArrangementRateDTO != null );
        Assert.assertEquals( Long.valueOf( 1 ),
                             paymentArrangementRateDTO.getPaymentArrangementRateId() );
        Assert.assertEquals( "NM",
                             paymentArrangementRateDTO.getCoorporateEntityCode() );
        Assert.assertEquals( "U32",
                             paymentArrangementRateDTO.getMemberSubjectId() );
        Assert.assertEquals( Long.valueOf( 1 ),
                             paymentArrangementRateDTO.getPaymentArrangementId() );
        Assert.assertEquals( "CAP",
                             paymentArrangementRateDTO.getPaymentTypeCode() );
        Assert.assertEquals( "FEMALE LESS THAN 18",
                             paymentArrangementRateDTO.getRateName() );
        Assert.assertEquals( "FLT",
                             paymentArrangementRateDTO.getRateTypeCode() );
        Assert.assertEquals( Long.valueOf( 1 ),
                             paymentArrangementRateDTO.getVbrPayeeId() );
        Assert.assertTrue( paymentArrangementRateDTO.toString().contains( "paymentArrangementRateId=1" ) );
    }
    
    private LocalDate convertStringToLocalDate( String str )
    {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern( "MM/dd/yyyy" );
        LocalDate localDate = LocalDate.parse( str,
                                               formatter );
        return localDate;
    }*/
}
