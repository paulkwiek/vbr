package com.hcsc.vbr.arrangementconfigservice.validator.paymentarrangement;

import static org.junit.Assert.assertFalse;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.json.JacksonTester;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.hcsc.vbr.arrangementconfigservice.constant.ArrangementConfigServiceConstant;
import com.hcsc.vbr.arrangementconfigservice.domain.PaymentArrangement;
import com.hcsc.vbr.common.dto.ErrorMessageDTO;
import com.hcsc.vbr.common.dto.ReturnMessageDTO;

@Component
public class PMAM002CheckFrequencyCodeTest
{
    @InjectMocks
    PMAM002CheckFrequencyCode checkFrequencyCode;

    @Mock
    ArrangementConfigServiceConstant arrangementConfigServiceConstant;

    @Before
    public void setUp()
    {
        MockitoAnnotations.initMocks( this );
        JacksonTester.initFields( this,
                                  new ObjectMapper() );

    }

    @Test( expected = NullPointerException.class )
    public void validateFrequencyCodeTestSuccess() throws Exception
    {

        boolean isValid = checkFrequencyCode.validateFrequencyCode( getPaymentArrangement(),
                                                                    getReturnMessageDTO() );
        assertFalse( isValid );
    }

    @Test( expected = NullPointerException.class )
    public void validateFrequencyCodeTestFail() throws Exception
    {

        boolean isValid = checkFrequencyCode.validateFrequencyCode( getPaymentArrangementFail(),
                                                                    getReturnMessageDTO() );
        assertFalse( isValid );
    }

    private List<ErrorMessageDTO> getErrorMessageDTOSuccess() throws Exception
    {
        List<ErrorMessageDTO> errors = new ArrayList<ErrorMessageDTO>();
        ErrorMessageDTO errorMessageDTO = new ErrorMessageDTO();

        errorMessageDTO.setErrorMessageCategoryCode( "PCF-PMAM" );
        errorMessageDTO.setErrorMessageId( new Long( 23 ) );
        errorMessageDTO.setErrorMsgDescriptionText( "Payment Type Is Required" );
        errorMessageDTO.setSeveritylevel( "E" );
        errors.add( errorMessageDTO );
        return errors;

    }

    private ReturnMessageDTO getReturnMessageDTO() throws Exception
    {
        ReturnMessageDTO returnMessage = new ReturnMessageDTO();

        returnMessage.setItemName( "PCF-PMAM" );
        returnMessage.setStatus( "SUCCESS" );
        returnMessage.setErrors( getErrorMessageDTOSuccess() );
        return returnMessage;

    }

    private PaymentArrangement getPaymentArrangement()
    {

        PaymentArrangement paymentArrangementDTO = new PaymentArrangement();
        paymentArrangementDTO.setArrangementFrequencyCode( "MONThly" );
        return paymentArrangementDTO;
    }

    private PaymentArrangement getPaymentArrangementFail()
    {

        PaymentArrangement paymentArrangementDTO = new PaymentArrangement();
        paymentArrangementDTO.setArrangementFrequencyCode( null );
        return paymentArrangementDTO;
    }

}