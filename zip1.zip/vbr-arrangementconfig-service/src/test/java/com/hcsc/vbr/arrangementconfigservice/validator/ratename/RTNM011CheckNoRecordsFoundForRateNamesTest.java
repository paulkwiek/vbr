package com.hcsc.vbr.arrangementconfigservice.validator.ratename;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnitRunner;

import com.hcsc.vbr.arrangementconfigservice.domain.FlatRate;
import com.hcsc.vbr.arrangementconfigservice.domain.RateName;
import com.hcsc.vbr.arrangementconfigservice.domain.RateNameId;
import com.hcsc.vbr.common.dto.ReturnMessageDTO;

@RunWith( MockitoJUnitRunner.Silent.class )
public class RTNM011CheckNoRecordsFoundForRateNamesTest
{

    @InjectMocks
    private RTNM011CheckNoRecordsFoundForRateNames rtnm011CheckNoRecordsFoundForRateNames;

    @Test
    public void isRecordsFound() throws Exception
    {

        rtnm011CheckNoRecordsFoundForRateNames.isRecordsFound( getRateNames(),
                                                               getReturnMessageDTO() );
    }

    @Test( expected = NullPointerException.class )
    public void isRecordsFound_Failure() throws Exception
    {

        rtnm011CheckNoRecordsFoundForRateNames.isRecordsFound( getRateNames_Empty(),
                                                               getReturnMessageDTO() );
    }

    private List<FlatRate> getflatrateList()
    {
        List<FlatRate> flatRateDTOlist = new ArrayList<FlatRate>();
        FlatRate flatRate = new FlatRate();
        flatRate.setFemaleFlatRateAmount( 456.53 );
        flatRate.setMaleFlatRateAmount( 845.34 );
        flatRate.setRecordEffectiveDate( LocalDate.of( 2019,
                                                       11,
                                                       01 ) );
        flatRate.setRecordEndDate( LocalDate.of( 2019,
                                                 11,
                                                 30 ) );
        flatRateDTOlist.add( flatRate );

        FlatRate flatRate1 = new FlatRate();
        flatRate1.setFemaleFlatRateAmount( 456.53 );
        flatRate1.setMaleFlatRateAmount( 845.34 );
        flatRate1.setRecordEffectiveDate( LocalDate.of( 2019,
                                                        12,
                                                        01 ) );
        flatRate1.setRecordEndDate( LocalDate.of( 2019,
                                                  12,
                                                  31 ) );
        flatRateDTOlist.add( flatRate1 );
        return flatRateDTOlist;
    }

    private List<RateName> getRateNames()
    {
        List<RateName> list = new ArrayList<RateName>();
        RateName rtnm = new RateName();
        RateNameId rtnmId = new RateNameId();
        rtnmId.setRateName( "SMOKE25" );
        rtnmId.setCorporateEntityCode( "NM1" );
        rtnm.setRateNameId( rtnmId );
        rtnm.setFlatRates( getflatrateList() );
        list.add( rtnm );
        return list;
    }

    private List<RateName> getRateNames_Empty()
    {

        List<RateName> rates = new ArrayList<RateName>();

        rates.removeAll( rates );
        return rates;

    }

    private ReturnMessageDTO getReturnMessageDTO()
    {
        ReturnMessageDTO returnMessage = new ReturnMessageDTO();
        return returnMessage;
    }
}
