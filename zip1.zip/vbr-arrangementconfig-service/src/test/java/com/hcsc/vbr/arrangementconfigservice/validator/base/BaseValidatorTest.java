package com.hcsc.vbr.arrangementconfigservice.validator.base;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnitRunner;

import com.hcsc.vbr.arrangementconfigservice.dto.ErrorMessageDTO;
import com.hcsc.vbr.arrangementconfigservice.dto.FlatRateDTO;
import com.hcsc.vbr.arrangementconfigservice.validator.base.BaseValidator;

@RunWith( MockitoJUnitRunner.class )
public class BaseValidatorTest
{

    @InjectMocks
    private BaseValidator baseValidator;

    @Test
    public void addToErrorList_Test()
    {
        List<ErrorMessageDTO> errors = new ArrayList<>();
        Long errorId = Long.valueOf( 21 );
        BaseValidator.addToErrorList( errors,
                                      errorId );
        Long resultId = errors.get( 0 ).getErrorMessageId();
        assertEquals( resultId,
                      errorId );
    }

    @Test
    public void checkAmountDecimal_Test_Pass()
    {
        Double amount = Double.valueOf( "12347" );
        boolean check = baseValidator.checkAmountDecimal( amount );
        assertEquals( true,
                      check );
    }

    @Test
    public void checkAmountDecimal_Test_Fail()
    {
        Double amount = Double.valueOf( "12345677" );
        boolean check = baseValidator.checkAmountDecimal( amount );
        assertEquals( false,
                      check );
    }

    @Test
    public void checkDateFormat_Test_Pass()
    {
        List<ErrorMessageDTO> errors = new ArrayList<>();
        FlatRateDTO flatRateDTO = new FlatRateDTO();
        flatRateDTO.setRecordEffectiveDate( "01/01/2019" );
        flatRateDTO.setRecordEndDate( "01/31/2019" );
        boolean check = BaseValidator.checkDateFormat( flatRateDTO,
                                                       errors );
        assertEquals( true,
                      check );
    }

    @Test
    public void checkDateFormat_Test_Fail()
    {
        List<ErrorMessageDTO> errors = new ArrayList<>();
        FlatRateDTO flatRateDTO = new FlatRateDTO();
        flatRateDTO.setRecordEffectiveDate( "0123/01/2019" );
        flatRateDTO.setRecordEndDate( "0122/31/2019" );
        boolean check = BaseValidator.checkDateFormat( flatRateDTO,
                                                       errors );
        assertEquals( false,
                      check );
    }
}
