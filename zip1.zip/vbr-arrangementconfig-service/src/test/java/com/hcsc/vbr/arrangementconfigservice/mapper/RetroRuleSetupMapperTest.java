package com.hcsc.vbr.arrangementconfigservice.mapper;

import java.util.ArrayList;
import java.util.List;

import org.assertj.core.api.Assertions;
import org.junit.Test;

import com.hcsc.vbr.arrangementconfigservice.domain.RetroActivityRuleSetup;
import com.hcsc.vbr.arrangementconfigservice.dto.RetroActivityRuleSetupDTO;

public class RetroRuleSetupMapperTest
{
    /*** Domain to DTO mapping test method ***/
    /**
     * Method: testToRetroRuleDTO
     */
    @Test
    public void testToRetroRuleDTO()
    {

        RetroActivityRuleSetup retroRule = new RetroActivityRuleSetup();
        retroRule.setRetroActivityRuleSetupId( 44 );
        retroRule.setCorporateEntityCode( "NM1" );
        retroRule.setPaymentTypeCode( "VC1" );
        retroRule.setRetroActivityCategoryCode( "RC1" );

        new RetroActivityRuleSetup();
        RetroActivityRuleSetupDTO retroActivityRuleSetupDTO = RetroRuleSetupMapper.INSTANCE.toRetroRuleDTO( retroRule );
        Assertions.assertThat( retroActivityRuleSetupDTO ).hasFieldOrPropertyWithValue( "retroActivityRuleSetupId",
                                                                                        44 );
        Assertions.assertThat( retroActivityRuleSetupDTO ).hasFieldOrPropertyWithValue( "corporateEntityCode",
                                                                                        "NM1" );
        Assertions.assertThat( retroActivityRuleSetupDTO ).hasFieldOrPropertyWithValue( "paymentTypeCode",
                                                                                        "VC1" );
        Assertions.assertThat( retroActivityRuleSetupDTO ).hasFieldOrPropertyWithValue( "retroActivityCategoryCode",
                                                                                        "RC1" );

    }

    /*** Null Passed for Domain ***/

    /**
     * Method: testNullToRetroNameDTO
     */
    @Test
    public void testNullToRetroNameDTO()
    {

        RetroActivityRuleSetupDTO retroRuleDTO = RetroRuleSetupMapper.INSTANCE.toRetroRuleDTO( null );

        Assertions.assertThat( retroRuleDTO == null );
    }

    /**
    * Method: testToRetroRuleDTOs
    */
    @Test
    public void testToRetroRuleDTOs()
    {
        RetroActivityRuleSetup retroRule = new RetroActivityRuleSetup();
        retroRule.setRetroActivityRuleSetupId( 44 );
        retroRule.setCorporateEntityCode( "NM1" );
        retroRule.setPaymentTypeCode( "VC1" );
        retroRule.setRetroActivityCategoryCode( "RC1" );

        List<RetroActivityRuleSetup> retroRules = new ArrayList<>();
        retroRules.add( retroRule );

        List<RetroActivityRuleSetupDTO> retroActivityRuleSetupDTOs = RetroRuleSetupMapper.INSTANCE.toRetroRuleDTOs( retroRules );

        for( RetroActivityRuleSetupDTO retroActivityRuleSetupDTO : retroActivityRuleSetupDTOs )
        {
            Assertions.assertThat( retroActivityRuleSetupDTO ).hasFieldOrPropertyWithValue( "retroActivityRuleSetupId",
                                                                                            44 );
            Assertions.assertThat( retroActivityRuleSetupDTO ).hasFieldOrPropertyWithValue( "corporateEntityCode",
                                                                                            "NM1" );
            Assertions.assertThat( retroActivityRuleSetupDTO ).hasFieldOrPropertyWithValue( "paymentTypeCode",
                                                                                            "VC1" );
            Assertions.assertThat( retroActivityRuleSetupDTO ).hasFieldOrPropertyWithValue( "retroActivityCategoryCode",
                                                                                            "RC1" );
        }
    }

    /**
    * Method: testToRetroRule
    */
    @Test
    public void testToRetroRule()
    {
        RetroActivityRuleSetupDTO retroActivityRuleSetupDTO = new RetroActivityRuleSetupDTO();
        retroActivityRuleSetupDTO.setRetroActivityRuleSetupId( 1 );
        retroActivityRuleSetupDTO.setPaymentArrangementId( 2 );
        retroActivityRuleSetupDTO.setCorporateEntityCode( "NM1" );
        retroActivityRuleSetupDTO.setPaymentTypeCode( "RTYPE" );

        RetroRuleSetupMapper.INSTANCE.toRetroRule( retroActivityRuleSetupDTO );

        Assertions.assertThat( retroActivityRuleSetupDTO ).hasFieldOrPropertyWithValue( "retroActivityRuleSetupId",
                                                                                        1 );
        Assertions.assertThat( retroActivityRuleSetupDTO ).hasFieldOrPropertyWithValue( "paymentArrangementId",
                                                                                        2 );
        Assertions.assertThat( retroActivityRuleSetupDTO ).hasFieldOrPropertyWithValue( "corporateEntityCode",
                                                                                        "NM1" );
        Assertions.assertThat( retroActivityRuleSetupDTO ).hasFieldOrPropertyWithValue( "paymentTypeCode",
                                                                                        "RTYPE" );
    }

    /*** Empty DTO list passed ***/
    /**
    * Method: testNullToRetroRule
    */
    @Test
    public void testNullToRetroRule()
    {

        RetroActivityRuleSetup retroRule = RetroRuleSetupMapper.INSTANCE.toRetroRule( null );

        Assertions.assertThat( retroRule == null );

    }

}
