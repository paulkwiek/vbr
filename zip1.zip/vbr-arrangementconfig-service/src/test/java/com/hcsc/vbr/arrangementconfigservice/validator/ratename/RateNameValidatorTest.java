package com.hcsc.vbr.arrangementconfigservice.validator.ratename;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import com.hcsc.vbr.arrangementconfigservice.domain.FlatRate;
import com.hcsc.vbr.arrangementconfigservice.domain.RateName;
import com.hcsc.vbr.arrangementconfigservice.domain.RateNameId;
import com.hcsc.vbr.common.dto.ReturnMessageDTO;
import com.hcsc.vbr.common.exception.VbrApplicationException;
import com.hcsc.vbr.web.request.RateSaveRequest;
import com.hcsc.vbr.web.response.PaymentArrangementListResponse;

@RunWith( MockitoJUnitRunner.Silent.class )
public class RateNameValidatorTest
{

    @InjectMocks
    RateNameValidator rateNameValidator;

    @Mock
    private RTNM001CheckRateAmount rtnm001CheckRateAmount;

    @Mock
    private RTNM003CheckRateDate rtnm003CheckRateDate;

    @Mock
    private RTNM004CheckRateDateOverlap rtnm004CheckRateDateOverlap;

    @Mock
    private RTNM007CheckRateAmountLessThanOneMillion rtnm007CheckRateAmountLessThanOneMillion;

    @Mock
    private RTNM008CheckRateAmountGreaterThanThousand rtnm008CheckRateAmountGreaterThanThousand;

    @Mock
    private RTNM009CheckRateEffDateIsFirstDayOfMonth rtnm009CheckRateEffDateIsFirstDayOfMonth;

    @Mock
    private RTNM010CheckRateEndDateIsLastDayOfMonth rtnm010CheckRateEndDateIsLastDayOfMonth;

    @Mock
    private RTNM011CheckNoRecordsFoundForRateNames rtnm011CheckNoRecordsFoundForRateNames;

    @Mock
    private RTNM012CheckNoRecordsFoundForFlatRates rtnm012CheckNoRecordsFoundForFlatRates;

    @Mock
    private RTNM013CheckNoRecordsFoundForlinkedArrangements rtnm013CheckNoRecordsFoundForlinkedArrangements;

    @Test
    public void validateSaveRateName() throws Exception
    {

        when( rtnm001CheckRateAmount.validateRateAmount( any(),
                                                         any() ) ).thenReturn( true );
        when( rtnm003CheckRateDate.IsValidRateDate( any(),
                                                    any() ) ).thenReturn( true );
        when( rtnm004CheckRateDateOverlap.validateRateDateOverlap( any(),
                                                                   any() ) ).thenReturn( true );

        when( rtnm007CheckRateAmountLessThanOneMillion.isRateAmountLessThanOneMillion( any(),
                                                                                       any() ) ).thenReturn( true );
        when( rtnm008CheckRateAmountGreaterThanThousand.isRateAmountGreaterThanThousand( any(),
                                                                                         any(),
                                                                                         any() ) ).thenReturn( true );
        when( rtnm009CheckRateEffDateIsFirstDayOfMonth.isFirstDayOfMonth( any(),
                                                                          any() ) ).thenReturn( true );
        when( rtnm010CheckRateEndDateIsLastDayOfMonth.isLastDayOfMonth( any(),
                                                                        any() ) ).thenReturn( true );
        when( rtnm011CheckNoRecordsFoundForRateNames.isRecordsFound( any(),
                                                                     any() ) ).thenReturn( true );
        when( rtnm012CheckNoRecordsFoundForFlatRates.isRecordsFound( any(),
                                                                     any() ) ).thenReturn( true );
        when( rtnm013CheckNoRecordsFoundForlinkedArrangements.isRecordsFound( any(),
                                                                              any() ) ).thenReturn( true );

        rateNameValidator.validateSaveRateName( rateSaveRequest(),
                                                getRateName(),
                                                getReturnMessageDTO() );
    }

    @Test( expected = VbrApplicationException.class )
    public void validateSaveRateName_Failure() throws Exception
    {

        when( rtnm001CheckRateAmount.validateRateAmount( any(),
                                                         any() ) ).thenReturn( false );
        when( rtnm003CheckRateDate.IsValidRateDate( any(),
                                                    any() ) ).thenReturn( false );
        when( rtnm004CheckRateDateOverlap.validateRateDateOverlap( any(),
                                                                   any() ) ).thenReturn( false );

        when( rtnm007CheckRateAmountLessThanOneMillion.isRateAmountLessThanOneMillion( any(),
                                                                                       any() ) ).thenReturn( false );
        when( rtnm008CheckRateAmountGreaterThanThousand.isRateAmountGreaterThanThousand( any(),
                                                                                         any(),
                                                                                         any() ) ).thenReturn( false );
        when( rtnm009CheckRateEffDateIsFirstDayOfMonth.isFirstDayOfMonth( any(),
                                                                          any() ) ).thenReturn( false );
        when( rtnm010CheckRateEndDateIsLastDayOfMonth.isLastDayOfMonth( any(),
                                                                        any() ) ).thenReturn( false );
        when( rtnm011CheckNoRecordsFoundForRateNames.isRecordsFound( any(),
                                                                     any() ) ).thenReturn( false );
        when( rtnm012CheckNoRecordsFoundForFlatRates.isRecordsFound( any(),
                                                                     any() ) ).thenReturn( false );
        when( rtnm013CheckNoRecordsFoundForlinkedArrangements.isRecordsFound( any(),
                                                                              any() ) ).thenReturn( false );

        rateNameValidator.validateSaveRateName( rateSaveRequest(),
                                                getRateName(),
                                                getReturnMessageDTO() );
    }

    @Test
    public void validateLinkedArrangements() throws Exception
    {
        when( rtnm013CheckNoRecordsFoundForlinkedArrangements.isRecordsFound( any(),
                                                                              any() ) ).thenReturn( true );
        rateNameValidator.validateLinkedArrangements( linkedArrangementResponseList(),
                                                      getReturnMessageDTO() );
    }

    @Test( expected = VbrApplicationException.class )
    public void validateLinkedArrangements_Failure() throws Exception
    {
        when( rtnm013CheckNoRecordsFoundForlinkedArrangements.isRecordsFound( any(),
                                                                              any() ) ).thenReturn( false );
        rateNameValidator.validateLinkedArrangements( linkedArrangementResponseList(),
                                                      getReturnMessageDTO() );
    }

    @Test
    public void validateGetFlatRates() throws Exception
    {
        when( rtnm012CheckNoRecordsFoundForFlatRates.isRecordsFound( any(),
                                                                     any() ) ).thenReturn( true );
        rateNameValidator.validateGetFlatRates( getflatrateList(),
                                                getReturnMessageDTO() );
    }

    @Test( expected = VbrApplicationException.class )
    public void validateGetFlatRates_Failure() throws Exception
    {
        when( rtnm012CheckNoRecordsFoundForFlatRates.isRecordsFound( any(),
                                                                     any() ) ).thenReturn( false );
        rateNameValidator.validateGetFlatRates( getflatrateList(),
                                                getReturnMessageDTO() );
    }

    @Test
    public void validateGetRates() throws Exception
    {
        when( rtnm011CheckNoRecordsFoundForRateNames.isRecordsFound( any(),
                                                                     any() ) ).thenReturn( true );
        rateNameValidator.validateGetRateNames( getRateNames(),
                                                getReturnMessageDTO() );
    }

    @Test( expected = VbrApplicationException.class )
    public void validateGetRates_Failure() throws Exception
    {
        when( rtnm011CheckNoRecordsFoundForRateNames.isRecordsFound( any(),
                                                                     any() ) ).thenReturn( false );
        rateNameValidator.validateGetRateNames( getRateNames(),
                                                getReturnMessageDTO() );
    }

    private List<PaymentArrangementListResponse> linkedArrangementResponseList()
    {
        List<PaymentArrangementListResponse> list = new ArrayList<PaymentArrangementListResponse>();
        PaymentArrangementListResponse response = new PaymentArrangementListResponse();
        response.setPaymentArrangementId( 123 );
        return list;
    }

    private RateName getRateName()
    {

        RateName rtnm = new RateName();
        RateNameId rtnmId = new RateNameId();
        rtnmId.setRateName( "SMOKE25" );
        rtnmId.setCorporateEntityCode( "NM1" );
        rtnm.setRateNameId( rtnmId );
        rtnm.setFlatRates( getflatrateList() );
        return rtnm;
    }

    private List<FlatRate> getflatrateList()
    {
        List<FlatRate> flatRateDTOlist = new ArrayList<FlatRate>();
        FlatRate flatRate = new FlatRate();
        flatRate.setFemaleFlatRateAmount( 456.53 );
        flatRate.setMaleFlatRateAmount( 845.34 );
        flatRate.setRecordEffectiveDate( LocalDate.of( 2019,
                                                       11,
                                                       01 ) );
        flatRate.setRecordEndDate( LocalDate.of( 2019,
                                                 11,
                                                 30 ) );
        flatRateDTOlist.add( flatRate );

        FlatRate flatRate1 = new FlatRate();
        flatRate1.setFemaleFlatRateAmount( 456.53 );
        flatRate1.setMaleFlatRateAmount( 845.34 );
        flatRate1.setRecordEffectiveDate( LocalDate.of( 2019,
                                                        12,
                                                        01 ) );
        flatRate1.setRecordEndDate( LocalDate.of( 2019,
                                                  12,
                                                  31 ) );
        flatRateDTOlist.add( flatRate1 );
        return flatRateDTOlist;
    }

    private List<RateName> getRateNames()
    {
        List<RateName> list = new ArrayList<RateName>();
        RateName rtnm = new RateName();
        RateNameId rtnmId = new RateNameId();
        rtnmId.setRateName( "SMOKE25" );
        rtnmId.setCorporateEntityCode( "NM1" );
        rtnm.setRateNameId( rtnmId );
        rtnm.setFlatRates( getflatrateList() );
        list.add( rtnm );
        return list;
    }

    private RateSaveRequest rateSaveRequest()
    {

        RateSaveRequest rateSaveRequest = new RateSaveRequest();

        rateSaveRequest.setWarningState( false );

        return rateSaveRequest;
    }

    private ReturnMessageDTO getReturnMessageDTO()
    {
        ReturnMessageDTO returnMessage = new ReturnMessageDTO();
        return returnMessage;
    }

}
