package com.hcsc.vbr.arrangementconfigservice.validator.ratename;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnitRunner;

import com.hcsc.vbr.arrangementconfigservice.domain.FlatRate;
import com.hcsc.vbr.arrangementconfigservice.domain.RateName;
import com.hcsc.vbr.arrangementconfigservice.domain.RateNameId;
import com.hcsc.vbr.common.dto.ReturnMessageDTO;

@RunWith( MockitoJUnitRunner.class )
public class RTNM003CheckRateDateTest
{

    @InjectMocks
    RTNM003CheckRateDate rtnm003CheckRateDate;

    @Test
    public void validateRateDate() throws Exception
    {
        rtnm003CheckRateDate.IsValidRateDate( getRateName(),
                                              getReturnMessageDTO() );
    }

    @Test( expected = NullPointerException.class )
    public void validateRateDate_Failure() throws Exception
    {
        rtnm003CheckRateDate.IsValidRateDate( getRateName_Failure(),
                                              getReturnMessageDTO() );
    }

    private RateName getRateName()
    {

        RateName rtnm = new RateName();
        RateNameId rtnmId = new RateNameId();
        rtnmId.setRateName( "SMOKE25" );
        rtnmId.setCorporateEntityCode( "NM1" );
        rtnm.setRateNameId( rtnmId );
        rtnm.setFlatRates( getflatrateList() );
        return rtnm;
    }

    private List<FlatRate> getflatrateList()
    {
        List<FlatRate> flatRateDTOlist = new ArrayList<FlatRate>();
        FlatRate flatRate = new FlatRate();
        flatRate.setFemaleFlatRateAmount( 456.53 );
        flatRate.setMaleFlatRateAmount( 845.34 );
        flatRate.setRecordEffectiveDate( LocalDate.of( 2019,
                                                       11,
                                                       01 ) );
        flatRate.setRecordEndDate( LocalDate.of( 2019,
                                                 11,
                                                 30 ) );
        flatRateDTOlist.add( flatRate );

        FlatRate flatRate1 = new FlatRate();
        flatRate1.setFemaleFlatRateAmount( 456.53 );
        flatRate1.setMaleFlatRateAmount( 845.34 );
        flatRate1.setRecordEffectiveDate( LocalDate.of( 2019,
                                                        12,
                                                        01 ) );
        flatRate1.setRecordEndDate( LocalDate.of( 2019,
                                                  12,
                                                  31 ) );
        flatRateDTOlist.add( flatRate1 );
        return flatRateDTOlist;
    }

    private RateName getRateName_Failure()
    {

        RateName rtnm = new RateName();
        RateNameId rtnmId = new RateNameId();
        rtnmId.setRateName( "SMOKE25" );
        rtnmId.setCorporateEntityCode( "NM1" );
        rtnm.setRateNameId( rtnmId );
        rtnm.setFlatRates( getflatrateList_Failure() );
        return rtnm;
    }

    private List<FlatRate> getflatrateList_Failure()
    {
        List<FlatRate> flatRateDTOlist = new ArrayList<FlatRate>();
        FlatRate flatRate = new FlatRate();
        flatRate.setRecordEffectiveDate( LocalDate.of( 2019,
                                                       12,
                                                       01 ) );
        flatRate.setRecordEndDate( LocalDate.of( 2019,
                                                 12,
                                                 31 ) );
        FlatRate flatRate1 = new FlatRate();
        flatRate1.setRecordEffectiveDate( LocalDate.of( 2019,
                                                        12,
                                                        01 ) );
        flatRate1.setRecordEndDate( LocalDate.of( 2019,
                                                  11,
                                                  30 ) );
        flatRateDTOlist.add( flatRate );
        flatRateDTOlist.add( flatRate1 );

        return flatRateDTOlist;
    }

    private ReturnMessageDTO getReturnMessageDTO()
    {
        ReturnMessageDTO returnMessage = new ReturnMessageDTO();
        return returnMessage;
    }

}
