package com.hcsc.vbr.arrangementconfigservice.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.boot.test.json.JacksonTester;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.hcsc.vbr.arrangementconfigservice.apiclient.CodeServiceApiClient;
import com.hcsc.vbr.arrangementconfigservice.domain.FlatRate;
import com.hcsc.vbr.arrangementconfigservice.domain.FlatRateHistory;
import com.hcsc.vbr.arrangementconfigservice.domain.PaymentArrangement;
import com.hcsc.vbr.arrangementconfigservice.domain.PaymentArrangementPayee;
import com.hcsc.vbr.arrangementconfigservice.domain.PaymentArrangementRate;
import com.hcsc.vbr.arrangementconfigservice.domain.RateName;
import com.hcsc.vbr.arrangementconfigservice.domain.RateNameId;
import com.hcsc.vbr.arrangementconfigservice.domain.VbrPayee;
import com.hcsc.vbr.arrangementconfigservice.dto.ErrorMessageDTO;
import com.hcsc.vbr.arrangementconfigservice.dto.FlatRateDTO;
import com.hcsc.vbr.arrangementconfigservice.dto.FlatRateHistoryDTO;
import com.hcsc.vbr.arrangementconfigservice.dto.RateNameDTO;
import com.hcsc.vbr.arrangementconfigservice.mapper.RateNameListMapper;
import com.hcsc.vbr.arrangementconfigservice.mapper.RateNameMapper;
import com.hcsc.vbr.arrangementconfigservice.repository.FlatRateHistoryRepository;
import com.hcsc.vbr.arrangementconfigservice.repository.FlatRateRepository;
import com.hcsc.vbr.arrangementconfigservice.repository.PaymentArrangementRateRepository;
import com.hcsc.vbr.arrangementconfigservice.repository.PaymentArrangementRepository;
import com.hcsc.vbr.arrangementconfigservice.repository.RateNameRepository;
import com.hcsc.vbr.arrangementconfigservice.validator.ratename.RTNM005CheckRateName;
import com.hcsc.vbr.arrangementconfigservice.validator.ratename.RTNM006CheckPaymentArrangementStatus;
import com.hcsc.vbr.arrangementconfigservice.validator.ratename.RateNameValidator;
import com.hcsc.vbr.common.constant.VBRCommonConstant.RowActionTypes;
import com.hcsc.vbr.web.request.RateSaveRequest;
import com.hcsc.vbr.web.response.RateSaveResponse;

@RunWith( MockitoJUnitRunner.Silent.class )
public class RateNameServiceTest
{

    @InjectMocks
    private RateNameService rateNameService;

    @Mock
    private RateNameRepository rateNameRepo;

    @Mock
    private FlatRateRepository flatRateRepository;

    @Mock
    private RateNameListMapper rateNameListMapper;

    @Mock
    private RateNameMapper rateNameMapper;

    @Mock
    private RateNameValidator rateNameValidator;

    @Mock
    private PaymentArrangementRateRepository paymentArrangementRateRepo;

    @Mock
    private PaymentArrangementRepository paymentArrangementRepo;

    @Mock
    private FlatRateHistoryRepository flatRateHistoryRepository;

    @Mock
    RTNM005CheckRateName rtnm005CheckRateName;

    @Mock
    private CodeServiceApiClient codeServiceApiClient;

    @Mock
    RTNM006CheckPaymentArrangementStatus rtnm006CheckPaymentArrangementstatus;

    @Before
    public void setUp()
    {

        MockitoAnnotations.initMocks( this );
        JacksonTester.initFields( this,
                                  new ObjectMapper() );

    }

    @Test
    public void saveRateTest() throws Exception
    {

        when( rateNameValidator.validateSaveRateName( any(),
                                                      any(),
                                                      any() ) ).thenReturn( Boolean.TRUE );
        when( rateNameMapper.toRateName( any() ) ).thenReturn( getRateName1() );
        when( rateNameMapper.toFlatRateHistory( any() ) ).thenReturn( getFlatRateHistory() );
        flatRateHistoryRepository.saveFlatRateHistory( getFlatRateHistory() );

        rateNameService.saveRate( getRateSaveRequest() );

    }

    @Test
    public void saveRate_RateName_test_Pass() throws Exception
    {
        String rateName = "RateDevTest";
        RateNameDTO rateNameDTO = getRateNameDTO();
        rateNameDTO.setRateName( StringUtils.upperCase( rateName ) );

        when( rateNameValidator.validateSaveRateName( any(),
                                                      any(),
                                                      any() ) ).thenReturn( Boolean.TRUE );
        when( rateNameMapper.toRateName( any() ) ).thenReturn( getRateName1() );
        when( rateNameMapper.toFlatRateHistory( any() ) ).thenReturn( getFlatRateHistory() );

        when( rateNameMapper.toRateNameDTO( any() ) ).thenReturn( rateNameDTO );

        flatRateHistoryRepository.saveFlatRateHistory( getFlatRateHistory() );

        RateSaveRequest rateSaveRequest = getRateSaveRequest();

        rateSaveRequest.getRate().setRateName( rateName );

        RateSaveResponse rateSaveResponse = rateNameService.saveRate( rateSaveRequest );

        assertEquals( rateName.toUpperCase(),
                      rateSaveResponse.getRateName().getRateName() );

    }

    @Test
    public void saveRateTest_1() throws Exception
    {

        when( rateNameValidator.validateSaveRateName( any(),
                                                      any(),
                                                      any() ) ).thenReturn( Boolean.FALSE );
        when( rateNameMapper.toRateName( any() ) ).thenReturn( getRateName() );
        rateNameService.saveRate( getRateSaveRequest() );

    }

    @Test
    public void saveRateTest_2() throws Exception
    {

        when( rateNameValidator.validateSaveRateName( any(),
                                                      any(),
                                                      any() ) ).thenReturn( Boolean.FALSE );
        when( rateNameMapper.toRateName( any() ) ).thenReturn( getRateName2() );
        rateNameService.saveRate( getRateSaveRequest() );

    }

    @Test
    public void getRateNamestest_1() throws Exception
    {
        when( rateNameMapper.toRateNameDTO( any() ) ).thenReturn( getRateNameDTO() );
        when( rateNameListMapper.toRateNameDTOs( any() ) ).thenReturn( getRateNameDTOs() );

        rateNameService.getRateNames( "NM1" );
    }

    @Test
    public void getRateNamestest() throws Exception
    {
        when( rateNameRepo.findAll() ).thenReturn( getRateNamesList() );
        when( rateNameMapper.toRateNameDTO( any() ) ).thenReturn( getRateNameDTO() );
        when( rateNameListMapper.toRateNameDTOs( any() ) ).thenReturn( getRateNameDTOs() );
        rateNameService.getRateNames( "NM1" );
    }

    @Test
    public void testgetRateDetailsByRateId_success() throws Exception
    {

        when( rateNameRepo.findByRateName( any() ) ).thenReturn( getRateName() );
        when( flatRateRepository.findByRateName( any() ) ).thenReturn( getFlatRates() );
        when( rateNameMapper.toRateNameDTO( any() ) ).thenReturn( getRateNameDTO() );
        RateSaveResponse rateSaveResponse = rateNameService.getRateByRateId( "RATE1" );
    }

    @Test( expected = NullPointerException.class )
    public void testgetRateDetailsByRateId_failure() throws Exception
    {
        RateSaveResponse rateNameDTO = rateNameService.getRateByRateId( "" );
        assertNotNull( rateNameDTO );
    }

    @Test
    public void testvalidateRateName() throws Exception
    {

        rateNameService.validateRateName( "RATE07" );

    }

    @Test
    public void getLinkedArrangementstest() throws Exception
    {

        when( paymentArrangementRepo.findByArrangementId( any() ) ).thenReturn( getPaymentArrangement() );
        rateNameService.getLinkedArrangements( "RATE07" );

    }

    @Test
    public void getLinkedArrangementstest_1() throws Exception
    {

        when( paymentArrangementRateRepo.findByRateName( any() ) ).thenReturn( getpaymentArrangementRates() );
        when( paymentArrangementRepo.findByArrangementId( any() ) ).thenReturn( getPaymentArrangement() );
        rateNameService.getLinkedArrangements( "RATE07" );

    }

    private RateName getRateName()

    {
        RateName rateName = new RateName();
        rateName.setCreateUserId( "CODE124" );
        rateName.setUpdateUserId( "CODE123" );
        rateName.setCreateRecordTimestamp( LocalDateTime.now() );
        rateName.setUpdateRecordTimestamp( LocalDateTime.now() );
        rateName.setRateConfigTypeName( "FLATRT" );
        rateName.setFlatRates( getFlatRates() );
        rateName.setRateNameId( getRateDetails() );
        rateName.setRowAction( RowActionTypes.valueOf( "NO_ACTION" ) );
        return rateName;
    }

    private RateName getRateName2()

    {
        RateName rateName = new RateName();
        rateName.setCreateUserId( "CODE124" );
        rateName.setUpdateUserId( "CODE123" );
        rateName.setCreateRecordTimestamp( LocalDateTime.now() );
        rateName.setUpdateRecordTimestamp( LocalDateTime.now() );
        rateName.setRateConfigTypeName( "FLATRT" );
        rateName.setFlatRates( getFlatRates1() );
        rateName.setRateNameId( getRateDetails() );
        rateName.setRowAction( RowActionTypes.valueOf( "NO_ACTION" ) );
        return rateName;
    }

    private RateName getRateName1()

    {
        RateName rateName = new RateName();
        rateName.setCreateUserId( "CODE124" );
        rateName.setUpdateUserId( "CODE123" );
        rateName.setCreateRecordTimestamp( LocalDateTime.now() );
        rateName.setUpdateRecordTimestamp( LocalDateTime.now() );
        rateName.setRateConfigTypeName( "FLATRT" );
        rateName.setFlatRates( getFlatRates() );
        rateName.setRateNameId( getRateDetails() );
        rateName.setRowAction( RowActionTypes.valueOf( "INSERT" ) );
        return rateName;
    }

    private List<RateName> getRateNamesList()

    {
        List<RateName> rateNameList = new ArrayList<RateName>();
        RateName rateName = new RateName();
        rateName.setCreateUserId( "CODE124" );
        rateName.setUpdateUserId( "CODE123" );
        rateName.setCreateRecordTimestamp( LocalDateTime.now() );
        rateName.setUpdateRecordTimestamp( LocalDateTime.now() );
        rateName.setRateConfigTypeName( "FLATRT" );
        //rateName.setRates( getFlatRates() );
        rateName.setRateNameId( getRateDetails() );
        rateNameList.add( rateName );

        RateName rateName1 = new RateName();
        rateName1.setCreateUserId( "CODE124" );
        rateName1.setUpdateUserId( "CODE123" );
        rateName1.setCreateRecordTimestamp( LocalDateTime.now() );
        rateName1.setUpdateRecordTimestamp( LocalDateTime.now() );
        rateName1.setRateConfigTypeName( "FLATRT" );
        //rateName.setRates( getFlatRates() );
        rateName1.setRateNameId( getRateDetails() );
        rateNameList.add( rateName1 );

        return rateNameList;
    }

    private List<RateNameDTO> getRateNameDTOs()
    {
        List<RateNameDTO> rateNameDTOsList = new ArrayList<RateNameDTO>();
        RateNameDTO rateNameDTO = new RateNameDTO();
        rateNameDTO.setCorporateEntityCode( "NM1" );
        rateNameDTO.setRateName( "RATE1" );
        rateNameDTO.setRateConfigTypeName( "FL_RT" );
        rateNameDTO.setCreateRecordTimestamp( LocalDateTime.now() );
        rateNameDTO.setUpdateRecordTimestamp( LocalDateTime.now() );
        rateNameDTO.setCreateUserId( "U1" );
        rateNameDTO.setUpdateUserId( "U2" );
        rateNameDTOsList.add( rateNameDTO );

        return rateNameDTOsList;

    }

    private RateNameId getRateDetails()
    {
        RateNameId rateNameId = new RateNameId();
        rateNameId.setCorporateEntityCode( "NM" );
        rateNameId.setRateName( "RATE1" );
        return rateNameId;
    }

    private RateSaveRequest getRateSaveRequest()
    {

        RateSaveRequest rateSaveRequest = new RateSaveRequest();
        RateNameDTO rateNameDTO = new RateNameDTO();
        rateNameDTO.setCorporateEntityCode( "NM" );
        rateNameDTO.setCreateUserId( "CODE124" );
        rateNameDTO.setUpdateUserId( "CODE123" );
        rateNameDTO.setCreateRecordTimestamp( LocalDateTime.now() );
        rateNameDTO.setUpdateRecordTimestamp( LocalDateTime.now() );
        rateNameDTO.setRateName( "RATE1" );
        rateNameDTO.setRateConfigTypeName( "FLATRT" );
        rateSaveRequest.setRate( rateNameDTO );
        return rateSaveRequest;
    }

    private RateNameDTO getRateNameDTO()
    {

        RateNameDTO rateNameDTO = new RateNameDTO();
        rateNameDTO.setCorporateEntityCode( "NM" );
        rateNameDTO.setCreateUserId( "CODE124" );
        rateNameDTO.setUpdateUserId( "CODE123" );
        rateNameDTO.setCreateRecordTimestamp( LocalDateTime.now() );
        rateNameDTO.setUpdateRecordTimestamp( LocalDateTime.now() );
        rateNameDTO.setRateName( "RATE1" );
        rateNameDTO.setRateConfigTypeName( "FLATRT" );
        return rateNameDTO;

    }

    private List<FlatRateDTO> getFlatRateDTOs()
    {
        List<FlatRateDTO> flatRateDTOs = new ArrayList<FlatRateDTO>();
        FlatRateDTO flatRateDTO = new FlatRateDTO();
        flatRateDTO.setCorporateEntityCode( "NM" );
        flatRateDTO.setFlatRateId( Integer.valueOf( 1 ) );
        flatRateDTO.setFemaleFlatRateAmount( 123.5 );
        flatRateDTO.setMaleFlatRateAmount( 124.5 );
        flatRateDTO.setRateName( "RATE1" );
        flatRateDTOs.add( flatRateDTO );

        return flatRateDTOs;
    }

    private FlatRateDTO getFlatRateDTO()
    {
        FlatRateDTO flatRateDTO = new FlatRateDTO();
        flatRateDTO.setCorporateEntityCode( "NM" );
        flatRateDTO.setFlatRateId( Integer.valueOf( 1 ) );
        flatRateDTO.setFemaleFlatRateAmount( 123.5 );
        flatRateDTO.setMaleFlatRateAmount( 124.5 );
        flatRateDTO.setRateName( "RATE1" );
        return flatRateDTO;
    }

    private List<FlatRateHistoryDTO> getFlatRateHistoryListDTO()
    {
        List<FlatRateHistoryDTO> flatRateHistoryDTOs = new ArrayList<FlatRateHistoryDTO>();
        FlatRateHistoryDTO flatRateHistoryDTO = new FlatRateHistoryDTO();
        flatRateHistoryDTO.setCommentText( "nm" );
        flatRateHistoryDTO.setFlatRateId( 1 );
        flatRateHistoryDTO.setFlatRateHistoryId( 1 );
        flatRateHistoryDTO.setCorporateEntityCode( "text" );
        flatRateHistoryDTO.setRateName( "we" );

        flatRateHistoryDTO.setFemaleFlatRateAmount( 56.1 );
        flatRateHistoryDTO.setMaleFlatRateAmount( 345.6 );
        flatRateHistoryDTOs.add( flatRateHistoryDTO );
        return flatRateHistoryDTOs;
    }

    private FlatRateHistory getFlatRateHistory()
    {
        FlatRateHistory flatRateHistory = new FlatRateHistory();
        flatRateHistory.setCommentText( "nm" );
        flatRateHistory.setFlatRateId( 1 );
        flatRateHistory.setFlatRateHistoryId( 1 );
        flatRateHistory.setCorporateEntityCode( "text" );
        flatRateHistory.setRateName( "we" );
        ;
        flatRateHistory.setFemaleFlatRateAmount( 56.1 );
        flatRateHistory.setMaleFlatRateAmount( 345.6 );
        return flatRateHistory;
    }

    private List<FlatRate> getFlatRates()
    {
        List<FlatRate> flatRates = new ArrayList<FlatRate>();
        FlatRate flatRate = new FlatRate();
        flatRate.setFlatRateId( Integer.valueOf( 1 ) );
        flatRate.setFemaleFlatRateAmount( 123.5 );
        flatRate.setMaleFlatRateAmount( 124.5 );
        flatRate.setRowAction( RowActionTypes.valueOf( "INSERT" ) );
        flatRates.add( flatRate );
        return flatRates;
    }

    private List<FlatRate> getFlatRates1()
    {
        List<FlatRate> flatRates = new ArrayList<FlatRate>();
        FlatRate flatRate = new FlatRate();
        flatRate.setFlatRateId( Integer.valueOf( 1 ) );
        flatRate.setFemaleFlatRateAmount( 123.5 );
        flatRate.setMaleFlatRateAmount( 124.5 );
        flatRate.setRowAction( RowActionTypes.valueOf( "UPDATE" ) );
        flatRates.add( flatRate );
        return flatRates;
    }

    private List<ErrorMessageDTO> getErrorMessageDTO()
    {
        List<ErrorMessageDTO> errorMessageDTOs = new ArrayList<ErrorMessageDTO>();
        ErrorMessageDTO errorMessageDTO = new ErrorMessageDTO();
        errorMessageDTO.setErrorMessageId( 131L );
        errorMessageDTO.setErrorMessageCategoryCode( "test0" );
        errorMessageDTO.setSeveritylevel( "E" );
        errorMessageDTO.setErrorMsgDescriptionText( "yer" );
        errorMessageDTOs.add( errorMessageDTO );
        return errorMessageDTOs;
    }

    private List<PaymentArrangementRate> getpaymentArrangementRates()
    {

        List<PaymentArrangementRate> paymentArrangementRateList = new ArrayList<PaymentArrangementRate>();

        PaymentArrangementRate paymentArrangementRate = new PaymentArrangementRate();
        paymentArrangementRate.setCorporateEntityCode( "NM" );
        paymentArrangementRate.setPaymentArrangementId( 1 );
        paymentArrangementRateList.add( paymentArrangementRate );

        return paymentArrangementRateList;

    }

    private List<PaymentArrangement> getPaymentArrangements()
    {

        List<PaymentArrangement> PaymentArrangementsList = new ArrayList<PaymentArrangement>();
        PaymentArrangement paymentArrangement = new PaymentArrangement();
        paymentArrangement.setPaymentArrangementPayees( getpaymentArrangementPayees() );
        paymentArrangement.setRecordEffectiveDate( LocalDate.now() );
        paymentArrangement.setRecordEndDate( LocalDate.now() );
        PaymentArrangementsList.add( paymentArrangement );
        return PaymentArrangementsList;

    }

    private List<PaymentArrangementPayee> getpaymentArrangementPayees()
    {

        List<PaymentArrangementPayee> paymentArrangementPayeeList = new ArrayList<PaymentArrangementPayee>();
        PaymentArrangementPayee paymentArrangementPayee = new PaymentArrangementPayee();
        paymentArrangementPayee.setVbrPayee( getVbrPayees() );
        paymentArrangementPayeeList.add( paymentArrangementPayee );
        return paymentArrangementPayeeList;

    }

    private VbrPayee getVbrPayees()
    {

        VbrPayee vbrPayee = new VbrPayee();
        vbrPayee.setCorporateEntityCode( "NM1" );
        vbrPayee.setPinGroupId( "BSR" );
        vbrPayee.setPinGroupName( "Some" );
        vbrPayee.setRecordEffectiveDate( LocalDate.of( 2019,
                                                       01,
                                                       01 ) );
        vbrPayee.setRecordEndDate( LocalDate.of( 2019,
                                                 12,
                                                 31 ) );
        return vbrPayee;

    }

    private PaymentArrangement getPaymentArrangement()
    {
        PaymentArrangement paymentArrangement = new PaymentArrangement();
        paymentArrangement.setCreateUserId( "CODE124" );
        paymentArrangement.setUpdateUserId( "fgf" );
        paymentArrangement.setCreateRecordTimestamp( LocalDateTime.now() );
        paymentArrangement.setUpdateRecordTimestamp( LocalDateTime.now() );
        paymentArrangement.setRecordEffectiveDate( LocalDate.now() );
        paymentArrangement.setRecordEndDate( LocalDate.now() );
        paymentArrangement.setPaymentArrangementId( Integer.valueOf( 1 ) );
        paymentArrangement.setCorporateEntityCode( "CCODE" );
        paymentArrangement.setPaymentArrangementName( "ARR" );
        paymentArrangement.setArrangementFrequencyCode( "freq" );
        paymentArrangement.setPaymentArrangementTypeCode( "PCODE" );
        paymentArrangement.setPaymentArrangementDescription( "Payment" );
        paymentArrangement.setPaymentArrangementPayees( getpaymentArrangementPayees() );
        return paymentArrangement;
    }

    private PaymentArrangement getPaymentArrangement1()
    {
        PaymentArrangement paymentArrangement = new PaymentArrangement();
        paymentArrangement.setCreateUserId( "CODE124" );
        paymentArrangement.setUpdateUserId( "fgf" );
        paymentArrangement.setCreateRecordTimestamp( LocalDateTime.now() );
        paymentArrangement.setUpdateRecordTimestamp( LocalDateTime.now() );
        paymentArrangement.setRecordEffectiveDate( LocalDate.of( 2018,
                                                                 01,
                                                                 01 ) );
        paymentArrangement.setRecordEndDate( LocalDate.of( 2019,
                                                           12,
                                                           31 ) );
        paymentArrangement.setPaymentArrangementId( Integer.valueOf( 1 ) );
        paymentArrangement.setCorporateEntityCode( "CCODE" );
        paymentArrangement.setPaymentArrangementName( "ARR" );
        paymentArrangement.setArrangementFrequencyCode( "freq" );
        paymentArrangement.setPaymentArrangementTypeCode( "PCODE" );
        paymentArrangement.setPaymentArrangementDescription( "Payment" );
        paymentArrangement.setPaymentArrangementPayees( getpaymentArrangementPayees() );
        return paymentArrangement;
    }

}
