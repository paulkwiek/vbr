/*package com.hcsc.vbr.arrangementconfigservice.validator.payee;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import com.hcsc.vbr.arrangementconfigservice.apiclient.ProviderServiceApiClient;
import com.hcsc.vbr.arrangementconfigservice.dto.ErrorMessageDTO;
import com.hcsc.vbr.arrangementconfigservice.dto.VbrPayeeDTO;
import com.hcsc.vbr.web.response.ProviderAPIResponse;
import com.hcsc.vbr.web.response.ProviderAPIResponseDTO;

@RunWith( MockitoJUnitRunner.class )
public class PMPY005ProviderAPIValidationsTest
{

    @InjectMocks
    private PMPY005ProviderAPIValidations providerAPIValidations;

    @Mock
    private ProviderServiceApiClient providerServiceApiClient;

    @Test
    public void testProviderAPIValidations() throws Exception
    {
        VbrPayeeDTO vbrPayeeSaveRequest = getVbrPayeeDTO();
        List<ErrorMessageDTO> errors = getErrorMessageDTOList();
        ProviderAPIResponse response = new ProviderAPIResponse();
        response.setProviders( getProviders() );

        when( providerServiceApiClient.getProviders( any() ) ).thenReturn( response );

        providerAPIValidations.providerAPIValidations( vbrPayeeSaveRequest,
                                                       errors );

        assertTrue( errors.isEmpty() );

    }

    @Test
    public void testProviderAPIValidationsINVALIDCASE() throws Exception
    {
        VbrPayeeDTO vbrPayeeSaveRequest = getVbrPayeeDTOINVALID();
        List<ErrorMessageDTO> errors = getErrorMessageDTOList();
        ProviderAPIResponse response = new ProviderAPIResponse();
        response.setProviders( getProvidersINVALID() );

        when( providerServiceApiClient.getProviders( any() ) ).thenReturn( response );

        providerAPIValidations.providerAPIValidations( vbrPayeeSaveRequest,
                                                       errors );

        assertFalse( errors.isEmpty() );

    }

    private List<ErrorMessageDTO> getErrorMessageDTOList()
    {
        List<ErrorMessageDTO> errorMessageDTOList = new ArrayList<ErrorMessageDTO>();
        return errorMessageDTOList;
    }

    private VbrPayeeDTO getVbrPayeeDTO()
    {
        VbrPayeeDTO vbrPayeeDTO = new VbrPayeeDTO();
        vbrPayeeDTO.setVbrPayeeId( 11 );
        vbrPayeeDTO.setRecordEffectiveDate( "01/01/2019" );
        vbrPayeeDTO.setRecordEndDate( "12/31/2019" );
        vbrPayeeDTO.setPinGroupId( "abcd2345" );
        vbrPayeeDTO.setCorporateEntityCode( "IL" );
        vbrPayeeDTO.setNetworkAssocProviderId( 11 );
        vbrPayeeDTO.setNetworkCode( "TX" );
        vbrPayeeDTO.setPayToPfinId( "pfin" );
        vbrPayeeDTO.setCapitationCode( "test" );
        vbrPayeeDTO.setCapitationProcessCode( "Test" );

        return vbrPayeeDTO;

    }

    private VbrPayeeDTO getVbrPayeeDTOINVALID()
    {
        VbrPayeeDTO vbrPayeeDTO = new VbrPayeeDTO();
        vbrPayeeDTO.setVbrPayeeId( 11 );
        vbrPayeeDTO.setRecordEffectiveDate( "01/01/2019" );
        vbrPayeeDTO.setRecordEndDate( "12/31/2019" );
        vbrPayeeDTO.setPinGroupId( "abcd2345" );
        vbrPayeeDTO.setCorporateEntityCode( "IL" );
        vbrPayeeDTO.setNetworkAssocProviderId( 11 );
        vbrPayeeDTO.setNetworkCode( "TX" );
        vbrPayeeDTO.setPayToPfinId( "pfin" );
        vbrPayeeDTO.setCapitationCode( "test" );
        vbrPayeeDTO.setCapitationProcessCode( "Test" );

        return vbrPayeeDTO;

    }

    private List<ProviderAPIResponseDTO> getProviders()
    {
        List<ProviderAPIResponseDTO> providers = new ArrayList<ProviderAPIResponseDTO>();
        ProviderAPIResponseDTO response = new ProviderAPIResponseDTO();
        response.setPINGroupEffectiveDate( "2019-01-01" );
        response.setPINGroupEndDate( "2019-12-31" );

        response.setNetworkAssociationEffectiveDate( "2019-01-01" );
        response.setNetworkAssociationEndDate( "2019-12-31" );

        response.setPfinEffectiveDate( "2019-01-01" );
        response.setPfinEndDate( "2019-12-31" );

        response.setTinEffectiveDate( "2019-01-01" );
        response.setTinEndDate( "2019-12-31" );

        response.setPINGroupCapitationEffectiveDate( "2019-01-01" );
        response.setPINGroupCapitationEndDate( "2019-12-31" );

        providers.add( response );
        return providers;
    }

    private List<ProviderAPIResponseDTO> getProvidersINVALID()
    {
        List<ProviderAPIResponseDTO> providers = new ArrayList<ProviderAPIResponseDTO>();
        ProviderAPIResponseDTO response = new ProviderAPIResponseDTO();
        response.setPINGroupEffectiveDate( "2019-01-01" );
        response.setPINGroupEndDate( "2019-12-31" );

        response.setNetworkAssociationEffectiveDate( "2019-01-01" );
        response.setNetworkAssociationEndDate( "2019-12-31" );

        response.setPfinEffectiveDate( "2019-01-01" );
        response.setPfinEndDate( "2019-12-31" );

        response.setTinEffectiveDate( "2019-01-01" );
        response.setTinEndDate( "2019-12-31" );

        response.setPINGroupCapitationEffectiveDate( "2020-01-01" );
        response.setPINGroupCapitationEndDate( "2019-12-31" );

        providers.add( response );
        return providers;
    }

}
*/