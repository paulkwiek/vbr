package com.hcsc.vbr.arrangementconfigservice.service;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.boot.test.json.JacksonTester;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.hcsc.vbr.arrangementconfigservice.apiclient.CodeServiceApiClient;
import com.hcsc.vbr.arrangementconfigservice.constant.ArrangementConfigServiceConstant;
import com.hcsc.vbr.arrangementconfigservice.constant.ComponentIdConstant;
import com.hcsc.vbr.arrangementconfigservice.constant.FieldIdConstant;
import com.hcsc.vbr.arrangementconfigservice.domain.PaymentArrangement;
import com.hcsc.vbr.arrangementconfigservice.domain.PaymentArrangementMemberSubject;
import com.hcsc.vbr.arrangementconfigservice.domain.PaymentArrangementPayee;
import com.hcsc.vbr.arrangementconfigservice.domain.PaymentArrangementRate;
import com.hcsc.vbr.arrangementconfigservice.domain.VbrPayee;
import com.hcsc.vbr.arrangementconfigservice.dto.CalculationArrangementsDTO;
import com.hcsc.vbr.arrangementconfigservice.dto.CalculationRequestDTO;
import com.hcsc.vbr.arrangementconfigservice.dto.CalculationRequestGroupingDTO;
import com.hcsc.vbr.arrangementconfigservice.dto.PaymentArrangementDTO;
import com.hcsc.vbr.arrangementconfigservice.dto.PaymentArrangementPayeeDTO;
import com.hcsc.vbr.arrangementconfigservice.dto.VbrPayeeDTO;
import com.hcsc.vbr.arrangementconfigservice.mapper.PaymentArrangementMapper;
import com.hcsc.vbr.arrangementconfigservice.repository.PaymentArrangementHistoryRepository;
import com.hcsc.vbr.arrangementconfigservice.repository.PaymentArrangementMemberSubjectRepository;
import com.hcsc.vbr.arrangementconfigservice.repository.PaymentArrangementPayeeRepository;
import com.hcsc.vbr.arrangementconfigservice.repository.PaymentArrangementRateRepository;
import com.hcsc.vbr.arrangementconfigservice.repository.PaymentArrangementRepository;
import com.hcsc.vbr.arrangementconfigservice.repository.VbrPayeeRepository;
import com.hcsc.vbr.arrangementconfigservice.utils.ArrangementConfigServiceUtils;
import com.hcsc.vbr.arrangementconfigservice.utils.VbrPayeeUtils;
import com.hcsc.vbr.arrangementconfigservice.validator.paymentarrangement.PaymentArrangementValidator;
import com.hcsc.vbr.common.constant.VBRCommonConstant.RowActionTypes;
import com.hcsc.vbr.common.dto.ErrorMessageDTO;
import com.hcsc.vbr.common.dto.ReturnMessageDTO;
import com.hcsc.vbr.web.request.CalculationRequestSaveRequest;
import com.hcsc.vbr.web.request.PaymentArrangementSaveRequest;
import com.hcsc.vbr.web.request.ValidateArrangementPayeeRequest;
import com.hcsc.vbr.web.response.PaymentArrangementSaveResponse;

@RunWith( MockitoJUnitRunner.Silent.class )
public class PaymentArrangementServiceTest
{

    @Mock
    private ArrangementConfigServiceUtils arrangementConfigServiceUtils;

    @Mock
    private CodeServiceApiClient codeServiceApiClient;

    @Mock
    private PaymentArrangementHistoryRepository paymentArrangementHistoryRepository;

    @Mock
    private PaymentArrangementMapper paymentArrangementMapper;

    @Mock
    private PaymentArrangementMemberSubjectRepository paymentArrangementMemberSubjectRepository;

    @Mock
    private PaymentArrangementPayeeRepository paymentArrangementPayeeRepository;

    @Mock
    private PaymentArrangementRateRepository paymentArrangementRateRepository;

    @Mock
    PaymentArrangementRepository paymentArrangementRepo;

    @InjectMocks
    PaymentArrangementService paymentArrangementService;

    @Mock
    private PaymentArrangementValidator paymentArrangementValidator;

    @Mock
    private VbrPayeeRepository vbrPayeeRepo;

    @Mock
    private VbrPayeeUtils vbrPayeeUtils;

    @Before
    public void setUp()
    {
        MockitoAnnotations.initMocks( this );
        JacksonTester.initFields( this,
                                  new ObjectMapper() );

    }

    @Test
    public void savePaymentArrangementValid() throws Exception
    {
        when( paymentArrangementMapper.toPaymentArrangement( any() ) ).thenReturn( getPmtArrangement() );
        when( paymentArrangementValidator.validateArrangementStatus( any(),
                                                                     any() ) )
                                                                             .thenReturn( ArrangementConfigServiceConstant.ARRANGEMENT_STATUS_VALID );
        when( paymentArrangementMapper.toPaymentArrangmentDTO( any() ) ).thenReturn( getPmtArrangementDTO() );
        paymentArrangementHistoryRepository.savePaymentArrangementHistory( any() );
        paymentArrangementMemberSubjectRepository.savePaymentMemberSubject( any() );
        paymentArrangementPayeeRepository.savePaymentArgmtPayee( any() );
        paymentArrangementRateRepository.savePaymentArrangementRate( any() );
        paymentArrangementService.savePaymentArrangement( getPaymentSaveRequest() );
    }

    @Test
    public void savePaymentArrangementFutureValid() throws Exception
    {
        when( paymentArrangementMapper.toPaymentArrangement( any() ) ).thenReturn( getPmtArrangement() );
        when( paymentArrangementValidator.validateArrangementStatus( any(),
                                                                     any() ) )
                                                                             .thenReturn( ArrangementConfigServiceConstant.ARRANGEMENT_STATUS_FUTURE_VALID );
        when( paymentArrangementMapper.toPaymentArrangmentDTO( any() ) ).thenReturn( getPmtArrangementDTOFutureValid() );
        paymentArrangementHistoryRepository.savePaymentArrangementHistory( any() );
        paymentArrangementMemberSubjectRepository.savePaymentMemberSubject( any() );
        paymentArrangementPayeeRepository.savePaymentArgmtPayee( any() );
        paymentArrangementRateRepository.savePaymentArrangementRate( any() );
        paymentArrangementService.savePaymentArrangement( getPaymentSaveRequest() );
    }

    @Test
    public void savePaymentArrangementSuccess() throws Exception
    {
        when( paymentArrangementMapper.toPaymentArrangement( any() ) ).thenReturn( getPmtArrangement() );
        when( paymentArrangementValidator.validateArrangementStatus( any(),
                                                                     any() ) )
                                                                             .thenReturn( ArrangementConfigServiceConstant.ARRANGEMENT_STATUS_EXPIRED );
        when( paymentArrangementMapper.toPaymentArrangmentDTO( any() ) ).thenReturn( getPmtArrangementDTOExpired() );
        paymentArrangementHistoryRepository.savePaymentArrangementHistory( any() );
        paymentArrangementMemberSubjectRepository.savePaymentMemberSubject( any() );
        paymentArrangementPayeeRepository.savePaymentArgmtPayee( any() );
        paymentArrangementRateRepository.savePaymentArrangementRate( any() );
        paymentArrangementService.savePaymentArrangement( getPaymentSaveRequest() );
    }

    @Test
    public void savePaymentArrangementDraft() throws Exception
    {
        when( paymentArrangementMapper.toPaymentArrangement( any() ) ).thenReturn( getPmtArrangement() );
        when( paymentArrangementValidator.validateArrangementStatus( any(),
                                                                     any() ) )
                                                                             .thenReturn( ArrangementConfigServiceConstant.ARRANGEMENT_STATUS_DRAFT );
        when( paymentArrangementMapper.toPaymentArrangmentDTO( any() ) ).thenReturn( getPmtArrangementDTODraft() );
        paymentArrangementHistoryRepository.savePaymentArrangementHistory( any() );
        paymentArrangementMemberSubjectRepository.savePaymentMemberSubject( any() );
        paymentArrangementPayeeRepository.savePaymentArgmtPayee( any() );
        paymentArrangementRateRepository.savePaymentArrangementRate( any() );
        ReturnMessageDTO returnMessage = getReturnMessage();

        paymentArrangementService.setArrangementSuccessMessage( returnMessage,
                                                                new PaymentArrangementSaveResponse(),
                                                                ArrangementConfigServiceConstant.ARRANGEMENT_STATUS_DRAFT );
        paymentArrangementService.savePaymentArrangement( getPaymentSaveRequest() );
    }

    @Test
    public void savePaymentArrangementExpired() throws Exception
    {
        when( paymentArrangementMapper.toPaymentArrangement( any() ) ).thenReturn( getPmtArrangement() );
        when( paymentArrangementValidator.validateArrangementStatus( any(),
                                                                     any() ) )
                                                                             .thenReturn( ArrangementConfigServiceConstant.ARRANGEMENT_STATUS_EXPIRED );
        when( paymentArrangementMapper.toPaymentArrangmentDTO( any() ) ).thenReturn( getPmtArrangementDTOExpired() );
        paymentArrangementHistoryRepository.savePaymentArrangementHistory( any() );
        paymentArrangementMemberSubjectRepository.savePaymentMemberSubject( any() );
        paymentArrangementPayeeRepository.savePaymentArgmtPayee( any() );
        paymentArrangementRateRepository.savePaymentArrangementRate( any() );
        ReturnMessageDTO returnMessage = getReturnMessage();

        paymentArrangementService.setArrangementSuccessMessage( returnMessage,
                                                                new PaymentArrangementSaveResponse(),
                                                                ArrangementConfigServiceConstant.ARRANGEMENT_STATUS_EXPIRED );
        paymentArrangementService.savePaymentArrangement( getPaymentSaveRequest() );
    }

    @Test
    public void savePaymentArrangementInvalid() throws Exception
    {
        when( paymentArrangementMapper.toPaymentArrangement( any() ) ).thenReturn( getPmtArrangement() );
        when( paymentArrangementValidator.validateArrangementStatus( any(),
                                                                     any() ) )
                                                                             .thenReturn( ArrangementConfigServiceConstant.ARRANGEMENT_STATUS_INVALID );
        when( paymentArrangementMapper.toPaymentArrangmentDTO( any() ) ).thenReturn( getPmtArrangementDTOInvalid() );
        paymentArrangementHistoryRepository.savePaymentArrangementHistory( any() );
        paymentArrangementMemberSubjectRepository.savePaymentMemberSubject( any() );
        paymentArrangementPayeeRepository.savePaymentArgmtPayee( any() );
        paymentArrangementRateRepository.savePaymentArrangementRate( any() );
        ReturnMessageDTO returnMessage = getReturnMessage();

        paymentArrangementService.setArrangementSuccessMessage( returnMessage,
                                                                new PaymentArrangementSaveResponse(),
                                                                ArrangementConfigServiceConstant.ARRANGEMENT_STATUS_INVALID );
        paymentArrangementService.savePaymentArrangement( getPaymentSaveRequest() );
    }

    @Test
    public void savePaymentArrangementFutureInvalid() throws Exception
    {
        when( paymentArrangementMapper.toPaymentArrangement( any() ) ).thenReturn( getPmtArrangement() );
        when( paymentArrangementValidator.validateArrangementStatus( any(),
                                                                     any() ) )
                                                                             .thenReturn( ArrangementConfigServiceConstant.ARRANGEMENT_STATUS_FUTURE_INVALID );
        when( paymentArrangementMapper.toPaymentArrangmentDTO( any() ) ).thenReturn( getPmtArrangementDTOFutureInvalid() );
        paymentArrangementHistoryRepository.savePaymentArrangementHistory( any() );
        paymentArrangementMemberSubjectRepository.savePaymentMemberSubject( any() );
        paymentArrangementPayeeRepository.savePaymentArgmtPayee( any() );
        paymentArrangementRateRepository.savePaymentArrangementRate( any() );
        ReturnMessageDTO returnMessage = getReturnMessage();

        paymentArrangementService.setArrangementSuccessMessage( returnMessage,
                                                                new PaymentArrangementSaveResponse(),
                                                                ArrangementConfigServiceConstant.ARRANGEMENT_STATUS_FUTURE_INVALID );
        paymentArrangementService.savePaymentArrangement( getPaymentSaveRequest() );
    }

    @Test
    public void savePaymentArrangementWarning() throws Exception
    {
        when( paymentArrangementMapper.toPaymentArrangement( any() ) ).thenReturn( getPmtArrangement() );
        when( paymentArrangementValidator.validateArrangementStatus( any(),
                                                                     any() ) )
                                                                             .thenReturn( ArrangementConfigServiceConstant.ARRANGEMENT_STATUS_WARNING );
        when( paymentArrangementMapper.toPaymentArrangmentDTO( any() ) ).thenReturn( getPmtArrangementDTOWarning() );
        paymentArrangementHistoryRepository.savePaymentArrangementHistory( any() );
        paymentArrangementMemberSubjectRepository.savePaymentMemberSubject( any() );
        paymentArrangementPayeeRepository.savePaymentArgmtPayee( any() );
        paymentArrangementRateRepository.savePaymentArrangementRate( any() );
        ReturnMessageDTO returnMessage = getReturnMessage();

        paymentArrangementService.setArrangementSuccessMessage( returnMessage,
                                                                new PaymentArrangementSaveResponse(),
                                                                ArrangementConfigServiceConstant.ARRANGEMENT_STATUS_WARNING );
        paymentArrangementService.savePaymentArrangement( getPaymentSaveRequest() );
    }

    @Test
    public void savePaymentArrangementWithoutPayee() throws Exception
    {
        when( paymentArrangementMapper.toPaymentArrangement( any() ) ).thenReturn( getPmtArrangementWrtPayee() );
        when( paymentArrangementValidator.validateArrangementStatus( any(),
                                                                     any() ) )
                                                                             .thenReturn( ArrangementConfigServiceConstant.ARRANGEMENT_STATUS_EXPIRED );
        when( paymentArrangementMapper.toPaymentArrangmentDTO( any() ) ).thenReturn( getPmtArrangementDTO() );
        paymentArrangementHistoryRepository.savePaymentArrangementHistory( any() );
        paymentArrangementMemberSubjectRepository.savePaymentMemberSubject( any() );
        when( vbrPayeeUtils.getProviderApiAddressAndDemographicsResponse( any() ) ).thenReturn( getVbrPayeeWrtPayee() );
        paymentArrangementPayeeRepository.savePaymentArgmtPayee( any() );
        paymentArrangementService.savePaymentArrangement( getPaymentSaveRequest() );
    }

    @Test
    public void getPaymentArrangementIdTest() throws Exception
    {
        Map<String, String> codeDescriptionMap = new HashMap<String, String>();
        when( codeServiceApiClient.getAllPaymentArrangementStatusDescription( any(),
                                                                              any() ) ).thenReturn( codeDescriptionMap );
        when( paymentArrangementRepo.findByArrangementId( any() ) ).thenReturn( getPmtArrangementByID() );

        when( paymentArrangementValidator.validateRetrieveArrangement( any(),
                                                                       any() ) ).thenReturn( Boolean.TRUE );
        when( paymentArrangementMapper.toPaymentArrangmentDTO( any() ) ).thenReturn( getPmtArrangementDTOByID() );
        when( paymentArrangementValidator.validateSave( any(),
                                                        any() ) )
                                                                .thenReturn( ArrangementConfigServiceConstant.ARRANGEMENT_STATUS_VALID );
        paymentArrangementService.getPaymentArrangementId( 1 );
    }

    @Test
    public void getArrangementsByCorporateEntityCodeTest() throws Exception
    {
        when( paymentArrangementRepo.findArrangementsByCorporateEntityCode( any() ) ).thenReturn( getPmtArrangements() );
        when( paymentArrangementValidator.validateRetrieveArrangements( any(),
                                                                        any() ) ).thenReturn( Boolean.TRUE );
        paymentArrangementService.getArrangementsByCorporateEntityCode( "NM1" );
    }

    @Test
    public void getArrangementsByCorporateEntityCodeActiveTest() throws Exception
    {
        when( paymentArrangementRepo.findArrangementsByCorporateEntityCode( any() ) ).thenReturn( getPmtArrangementsActive() );
        when( paymentArrangementValidator.validateRetrieveArrangements( any(),
                                                                        any() ) ).thenReturn( Boolean.TRUE );
        paymentArrangementService.getArrangementsByCorporateEntityCode( "NM1" );
    }

    @Test
    public void findByArrangementName() throws Exception
    {
        when( paymentArrangementRepo.findByArrangementName( any() ) ).thenReturn( getPmtArrangementName() );
        paymentArrangementService.findByArrangementName( "PANM" );
    }

    @Test
    public void validateArrangementPayeeTest() throws Exception
    {
        paymentArrangementValidator.validateArrangementPayeeDates( any(),
                                                                   any() );
        paymentArrangementService.validateArrangementPayee( getValidateArrangementPayeeRequest() );
    }

    @Test
    public void getCalculationRequestPaymentArrangementsTest() throws Exception
    {
        when( paymentArrangementRepo.findByCorporateEntityCodeAndLineOfBusinessCode( any(),
                                                                                     any() ) ).thenReturn( getPmtArrangements() );
        when( paymentArrangementMapper.toRunPaymentArrangmentDTOs( any() ) ).thenReturn( getCalculationArrangementsDTO() );
        paymentArrangementService.getCalculationRequestPaymentArrangements( getCalculationRequestSaveRequest() );
    }

    private ReturnMessageDTO getReturnMessage()
    {
        ReturnMessageDTO returnMessage = new ReturnMessageDTO( ComponentIdConstant.PMAM );
        List<ErrorMessageDTO> warnings = new ArrayList<ErrorMessageDTO>();
        ErrorMessageDTO warning = new ErrorMessageDTO();
        warning.setComponentName( ComponentIdConstant.PMAM );
        warning.setErrorMessageCategoryCode( "PMAM" );
        warning.setErrorMessageId( Long.valueOf( 1 ) );
        warning.setErrorMsgDescriptionText( "Warning" );
        warning.setFieldId( FieldIdConstant.PMAM_STATUS );
        warning.setSeveritylevel( "W" );
        warnings.add( warning );
        returnMessage.setWarnings( warnings );
        return returnMessage;
    }

    private List<CalculationArrangementsDTO> getCalculationArrangementsDTO()
    {
        List<CalculationArrangementsDTO> calculationArrangementsDTOs = new ArrayList<CalculationArrangementsDTO>();
        CalculationArrangementsDTO calculationArrangementsDTO = new CalculationArrangementsDTO();
        calculationArrangementsDTOs.add( calculationArrangementsDTO );
        return calculationArrangementsDTOs;
    }

    private CalculationRequestSaveRequest getCalculationRequestSaveRequest()
    {
        CalculationRequestSaveRequest calculationRequestSaveRequest = new CalculationRequestSaveRequest();
        CalculationRequestDTO calculationRequestDTO = new CalculationRequestDTO();
        List<CalculationRequestGroupingDTO> calculationRequestGroupingDTOs = new ArrayList<CalculationRequestGroupingDTO>();
        CalculationRequestGroupingDTO calculationRequestGroupingDTO = new CalculationRequestGroupingDTO();
        calculationRequestGroupingDTO.setCorporateEntityCode( "CEC" );
        calculationRequestGroupingDTO.setCalculationGroupingLevelValueText( "MDAP" );
        calculationRequestGroupingDTOs.add( calculationRequestGroupingDTO );
        calculationRequestDTO.setCreateUserId( "USER1" );
        calculationRequestDTO.setRowAction( RowActionTypes.INSERT );
        calculationRequestDTO.setUpdateUserId( "USER1" );
        calculationRequestDTO.setCalculationRequestGroupingDTOs( calculationRequestGroupingDTOs );
        calculationRequestSaveRequest.setCalculationRequestDTO( calculationRequestDTO );
        return calculationRequestSaveRequest;
    }

    private ValidateArrangementPayeeRequest getValidateArrangementPayeeRequest()
    {
        ValidateArrangementPayeeRequest validateArrangementPayeeRequest = new ValidateArrangementPayeeRequest();
        validateArrangementPayeeRequest.setValidateArrangementPayee( getPayeeDTO() );
        return validateArrangementPayeeRequest;
    }

    private PaymentArrangementPayeeDTO getPayeeDTO()
    {
        PaymentArrangementPayeeDTO payee = new PaymentArrangementPayeeDTO();
        payee.setPaymentArrangementPayeeId( Integer.valueOf( 1 ) );
        payee.setCreateUserId( "USER1" );
        payee.setUpdateUserId( "USER1" );
        payee.setCreateRecordTimestamp( LocalDateTime.now() );
        payee.setUpdateRecordTimestamp( LocalDateTime.now() );
        payee.setRecordEffectiveDate( "" );
        payee.setRecordEndDate( "" );
        VbrPayeeDTO vbrPayee = getVbrPayeeDTO();
        payee.setVbrPayee( vbrPayee );
        return payee;
    }

    private List<PaymentArrangement> getPmtArrangements()
    {
        List<PaymentArrangement> pmtArrangements = new ArrayList<PaymentArrangement>();
        pmtArrangements.add( getPmtArrangement() );
        return pmtArrangements;
    }

    private List<PaymentArrangement> getPmtArrangementsActive()
    {
        List<PaymentArrangement> pmtArrangements = new ArrayList<PaymentArrangement>();
        pmtArrangements.add( getPmtArrangementActive() );
        return pmtArrangements;
    }

    private List<PaymentArrangementPayeeDTO> getPayeesDTO()
    {
        List<PaymentArrangementPayeeDTO> payees = new ArrayList<PaymentArrangementPayeeDTO>();
        PaymentArrangementPayeeDTO payee = new PaymentArrangementPayeeDTO();
        payee.setPaymentArrangementPayeeId( Integer.valueOf( 1 ) );
        payee.setCreateUserId( "USER1" );
        payee.setUpdateUserId( "USER1" );
        payee.setCreateRecordTimestamp( LocalDateTime.now() );
        payee.setUpdateRecordTimestamp( LocalDateTime.now() );
        payee.setRecordEffectiveDate( "" );
        payee.setRecordEndDate( "" );
        VbrPayeeDTO vbrPayee = getVbrPayeeDTO();
        payee.setVbrPayee( vbrPayee );
        payees.add( payee );
        return payees;
    }

    private PaymentArrangementSaveRequest getPaymentSaveRequest()
    {
        PaymentArrangementSaveRequest paymentArrangementSaveRequest = new PaymentArrangementSaveRequest();
        paymentArrangementSaveRequest.setArrangement( getPmtArrangementDTO() );
        return paymentArrangementSaveRequest;
    }

    private PaymentArrangement getPmtArrangementActive()
    {
        PaymentArrangement paymentArrangement = new PaymentArrangement();
        paymentArrangement.setCreateUserId( "USER1" );
        paymentArrangement.setUpdateUserId( "USER1" );
        paymentArrangement.setCreateRecordTimestamp( LocalDateTime.now() );
        paymentArrangement.setUpdateRecordTimestamp( LocalDateTime.now() );
        paymentArrangement.setRecordEffectiveDate( LocalDate.now() );
        paymentArrangement.setRecordEndDate( LocalDate.now() );
        paymentArrangement.setPaymentArrangementId( Integer.valueOf( 1 ) );
        paymentArrangement.setCorporateEntityCode( "CEC" );
        paymentArrangement.setPaymentArrangementName( "PANM" );
        paymentArrangement.setArrangementFrequencyCode( "MONT" );
        paymentArrangement.setPaymentArrangementTypeCode( "PATC" );
        paymentArrangement.setPaymentArrangementDescription( "PADSC" );
        paymentArrangement.setPaymentArrangementPayees( getPmtArrangementPayeesActive() );
        paymentArrangement.setPaymentArrangementRates( getPmtArrangementRates() );
        paymentArrangement.setPaymentArrangementMemberSubjects( getPmtArrangementMemberSubjects() );
        paymentArrangement.setValidationStatusCode( ArrangementConfigServiceConstant.ARRANGEMENT_STATUS_EXPIRED );
        return paymentArrangement;

    }

    private PaymentArrangement getPmtArrangement()
    {
        PaymentArrangement paymentArrangement = new PaymentArrangement();
        paymentArrangement.setCreateUserId( "USER1" );
        paymentArrangement.setUpdateUserId( "USER1" );
        paymentArrangement.setCreateRecordTimestamp( LocalDateTime.now() );
        paymentArrangement.setUpdateRecordTimestamp( LocalDateTime.now() );
        paymentArrangement.setRecordEffectiveDate( LocalDate.now() );
        paymentArrangement.setRecordEndDate( LocalDate.now() );
        paymentArrangement.setPaymentArrangementId( Integer.valueOf( 1 ) );
        paymentArrangement.setCorporateEntityCode( "CEC" );
        paymentArrangement.setPaymentArrangementName( "PANM" );
        paymentArrangement.setArrangementFrequencyCode( "MONT" );
        paymentArrangement.setPaymentArrangementTypeCode( "PATC" );
        paymentArrangement.setPaymentArrangementDescription( "PADSC" );
        paymentArrangement.setPaymentArrangementPayees( getPmtArrangementPayees() );
        paymentArrangement.setPaymentArrangementRates( getPmtArrangementRates() );
        paymentArrangement.setPaymentArrangementMemberSubjects( getPmtArrangementMemberSubjects() );
        return paymentArrangement;

    }

    private PaymentArrangement getPmtArrangementByID()
    {
        PaymentArrangement paymentArrangement = new PaymentArrangement();
        paymentArrangement.setCreateUserId( "USER1" );
        paymentArrangement.setUpdateUserId( "USER1" );
        paymentArrangement.setCreateRecordTimestamp( LocalDateTime.now() );
        paymentArrangement.setUpdateRecordTimestamp( LocalDateTime.now() );
        paymentArrangement.setRecordEffectiveDate( LocalDate.now() );
        paymentArrangement.setRecordEndDate( LocalDate.now() );
        paymentArrangement.setPaymentArrangementId( Integer.valueOf( 1 ) );
        paymentArrangement.setCorporateEntityCode( "CEC" );
        paymentArrangement.setPaymentArrangementName( "PANM" );
        paymentArrangement.setArrangementFrequencyCode( "MONT" );
        paymentArrangement.setPaymentArrangementTypeCode( "PATC" );
        paymentArrangement.setPaymentArrangementDescription( "PADSC" );
        paymentArrangement.setPaymentArrangementPayees( getPmtArrangementPayees() );
        paymentArrangement.setPaymentArrangementRates( getPmtArrangementRates() );
        paymentArrangement.setPaymentArrangementMemberSubjects( getPmtArrangementMemberSubjects() );
        paymentArrangement.setValidationStatusCode( ArrangementConfigServiceConstant.ARRANGEMENT_STATUS_EXPIRED );
        return paymentArrangement;

    }

    private PaymentArrangement getPmtArrangementName()
    {
        PaymentArrangement paymentArrangement = null;
        return paymentArrangement;

    }

    private PaymentArrangementDTO getPmtArrangementDTO()
    {
        PaymentArrangementDTO paymentArrangement = new PaymentArrangementDTO();
        paymentArrangement.setCreateUserId( "USER1" );
        paymentArrangement.setUpdateUserId( "USER1" );
        paymentArrangement.setCreateRecordTimestamp( LocalDateTime.now() );
        paymentArrangement.setUpdateRecordTimestamp( LocalDateTime.now() );
        paymentArrangement.setRecordEffectiveDate( null );
        paymentArrangement.setRecordEndDate( null );
        paymentArrangement.setPaymentArrangementId( Integer.valueOf( 1 ) );
        paymentArrangement.setCorporateEntityCode( "CEC" );
        paymentArrangement.setPaymentArrangementName( "PANM" );
        paymentArrangement.setArrangementFrequencyCode( "MONT" );
        paymentArrangement.setPaymentArrangementTypeCode( "PATC" );
        paymentArrangement.setPaymentArrangementDescription( "PADSC" );
        paymentArrangement.setValidationStatusCode( ArrangementConfigServiceConstant.ARRANGEMENT_STATUS_VALID );
        paymentArrangement.setPaymentArrangementPayees( getPayeesDTO() );
        paymentArrangement.setRowAction( RowActionTypes.INSERT );
        return paymentArrangement;

    }

    private PaymentArrangementDTO getPmtArrangementDTOExpired()
    {
        PaymentArrangementDTO paymentArrangement = new PaymentArrangementDTO();
        paymentArrangement.setCreateUserId( "USER1" );
        paymentArrangement.setUpdateUserId( "USER1" );
        paymentArrangement.setCreateRecordTimestamp( LocalDateTime.now() );
        paymentArrangement.setUpdateRecordTimestamp( LocalDateTime.now() );
        paymentArrangement.setRecordEffectiveDate( null );
        paymentArrangement.setRecordEndDate( null );
        paymentArrangement.setPaymentArrangementId( Integer.valueOf( 1 ) );
        paymentArrangement.setCorporateEntityCode( "CEC" );
        paymentArrangement.setPaymentArrangementName( "PANM" );
        paymentArrangement.setArrangementFrequencyCode( "MONT" );
        paymentArrangement.setPaymentArrangementTypeCode( "PATC" );
        paymentArrangement.setPaymentArrangementDescription( "PADSC" );
        paymentArrangement.setValidationStatusCode( ArrangementConfigServiceConstant.ARRANGEMENT_STATUS_EXPIRED );
        paymentArrangement.setPaymentArrangementPayees( getPayeesDTO() );
        paymentArrangement.setRowAction( RowActionTypes.INSERT );
        return paymentArrangement;

    }

    private PaymentArrangementDTO getPmtArrangementDTOFutureInvalid()
    {
        PaymentArrangementDTO paymentArrangement = new PaymentArrangementDTO();
        paymentArrangement.setCreateUserId( "USER1" );
        paymentArrangement.setUpdateUserId( "USER1" );
        paymentArrangement.setCreateRecordTimestamp( LocalDateTime.now() );
        paymentArrangement.setUpdateRecordTimestamp( LocalDateTime.now() );
        paymentArrangement.setRecordEffectiveDate( null );
        paymentArrangement.setRecordEndDate( null );
        paymentArrangement.setPaymentArrangementId( Integer.valueOf( 1 ) );
        paymentArrangement.setCorporateEntityCode( "CEC" );
        paymentArrangement.setPaymentArrangementName( "PANM" );
        paymentArrangement.setArrangementFrequencyCode( "MONT" );
        paymentArrangement.setPaymentArrangementTypeCode( "PATC" );
        paymentArrangement.setPaymentArrangementDescription( "PADSC" );
        paymentArrangement.setValidationStatusCode( ArrangementConfigServiceConstant.ARRANGEMENT_STATUS_FUTURE_INVALID );
        paymentArrangement.setPaymentArrangementPayees( getPayeesDTO() );
        paymentArrangement.setRowAction( RowActionTypes.INSERT );
        return paymentArrangement;

    }

    private PaymentArrangementDTO getPmtArrangementDTOInvalid()
    {
        PaymentArrangementDTO paymentArrangement = new PaymentArrangementDTO();
        paymentArrangement.setCreateUserId( "USER1" );
        paymentArrangement.setUpdateUserId( "USER1" );
        paymentArrangement.setCreateRecordTimestamp( LocalDateTime.now() );
        paymentArrangement.setUpdateRecordTimestamp( LocalDateTime.now() );
        paymentArrangement.setRecordEffectiveDate( null );
        paymentArrangement.setRecordEndDate( null );
        paymentArrangement.setPaymentArrangementId( Integer.valueOf( 1 ) );
        paymentArrangement.setCorporateEntityCode( "CEC" );
        paymentArrangement.setPaymentArrangementName( "PANM" );
        paymentArrangement.setArrangementFrequencyCode( "MONT" );
        paymentArrangement.setPaymentArrangementTypeCode( "PATC" );
        paymentArrangement.setPaymentArrangementDescription( "PADSC" );
        paymentArrangement.setValidationStatusCode( ArrangementConfigServiceConstant.ARRANGEMENT_STATUS_INVALID );
        paymentArrangement.setPaymentArrangementPayees( getPayeesDTO() );
        paymentArrangement.setRowAction( RowActionTypes.INSERT );
        return paymentArrangement;

    }

    private PaymentArrangementDTO getPmtArrangementDTOWarning()
    {
        PaymentArrangementDTO paymentArrangement = new PaymentArrangementDTO();
        paymentArrangement.setCreateUserId( "USER1" );
        paymentArrangement.setUpdateUserId( "USER1" );
        paymentArrangement.setCreateRecordTimestamp( LocalDateTime.now() );
        paymentArrangement.setUpdateRecordTimestamp( LocalDateTime.now() );
        paymentArrangement.setRecordEffectiveDate( null );
        paymentArrangement.setRecordEndDate( null );
        paymentArrangement.setPaymentArrangementId( Integer.valueOf( 1 ) );
        paymentArrangement.setCorporateEntityCode( "CEC" );
        paymentArrangement.setPaymentArrangementName( "PANM" );
        paymentArrangement.setArrangementFrequencyCode( "MONT" );
        paymentArrangement.setPaymentArrangementTypeCode( "PATC" );
        paymentArrangement.setPaymentArrangementDescription( "PADSC" );
        paymentArrangement.setValidationStatusCode( ArrangementConfigServiceConstant.ARRANGEMENT_STATUS_WARNING );
        paymentArrangement.setPaymentArrangementPayees( getPayeesDTO() );
        paymentArrangement.setRowAction( RowActionTypes.INSERT );
        return paymentArrangement;

    }

    private PaymentArrangementDTO getPmtArrangementDTODraft()
    {
        PaymentArrangementDTO paymentArrangement = new PaymentArrangementDTO();
        paymentArrangement.setCreateUserId( "USER1" );
        paymentArrangement.setUpdateUserId( "USER1" );
        paymentArrangement.setCreateRecordTimestamp( LocalDateTime.now() );
        paymentArrangement.setUpdateRecordTimestamp( LocalDateTime.now() );
        paymentArrangement.setRecordEffectiveDate( null );
        paymentArrangement.setRecordEndDate( null );
        paymentArrangement.setPaymentArrangementId( Integer.valueOf( 1 ) );
        paymentArrangement.setCorporateEntityCode( "CEC" );
        paymentArrangement.setPaymentArrangementName( "PANM" );
        paymentArrangement.setArrangementFrequencyCode( "MONT" );
        paymentArrangement.setPaymentArrangementTypeCode( "PATC" );
        paymentArrangement.setPaymentArrangementDescription( "PADSC" );
        paymentArrangement.setValidationStatusCode( ArrangementConfigServiceConstant.ARRANGEMENT_STATUS_DRAFT );
        paymentArrangement.setPaymentArrangementPayees( getPayeesDTO() );
        paymentArrangement.setRowAction( RowActionTypes.INSERT );
        return paymentArrangement;

    }

    private PaymentArrangementDTO getPmtArrangementDTOFutureValid()
    {
        PaymentArrangementDTO paymentArrangement = new PaymentArrangementDTO();
        paymentArrangement.setCreateUserId( "USER1" );
        paymentArrangement.setUpdateUserId( "USER1" );
        paymentArrangement.setCreateRecordTimestamp( LocalDateTime.now() );
        paymentArrangement.setUpdateRecordTimestamp( LocalDateTime.now() );
        paymentArrangement.setRecordEffectiveDate( null );
        paymentArrangement.setRecordEndDate( null );
        paymentArrangement.setPaymentArrangementId( Integer.valueOf( 1 ) );
        paymentArrangement.setCorporateEntityCode( "CEC" );
        paymentArrangement.setPaymentArrangementName( "PANM" );
        paymentArrangement.setArrangementFrequencyCode( "MONT" );
        paymentArrangement.setPaymentArrangementTypeCode( "PATC" );
        paymentArrangement.setPaymentArrangementDescription( "PADSC" );
        paymentArrangement.setValidationStatusCode( ArrangementConfigServiceConstant.ARRANGEMENT_STATUS_FUTURE_VALID );
        paymentArrangement.setPaymentArrangementPayees( getPayeesDTO() );
        paymentArrangement.setRowAction( RowActionTypes.INSERT );
        return paymentArrangement;

    }

    private PaymentArrangementDTO getPmtArrangementDTOByID()
    {
        PaymentArrangementDTO paymentArrangement = new PaymentArrangementDTO();
        paymentArrangement.setCreateUserId( "USER1" );
        paymentArrangement.setUpdateUserId( "USER1" );
        paymentArrangement.setCreateRecordTimestamp( LocalDateTime.now() );
        paymentArrangement.setUpdateRecordTimestamp( LocalDateTime.now() );
        paymentArrangement.setRecordEffectiveDate( null );
        paymentArrangement.setRecordEndDate( null );
        paymentArrangement.setPaymentArrangementId( Integer.valueOf( 1 ) );
        paymentArrangement.setCorporateEntityCode( "CEC" );
        paymentArrangement.setPaymentArrangementName( "PANM" );
        paymentArrangement.setArrangementFrequencyCode( "MONT" );
        paymentArrangement.setPaymentArrangementTypeCode( "PATC" );
        paymentArrangement.setPaymentArrangementDescription( "PADSC" );
        paymentArrangement.setValidationStatusCode( ArrangementConfigServiceConstant.ARRANGEMENT_STATUS_EXPIRED );
        paymentArrangement.setPaymentArrangementPayees( getPayeesDTO() );
        paymentArrangement.setRowAction( RowActionTypes.INSERT );
        return paymentArrangement;

    }

    private List<PaymentArrangementMemberSubject> getPmtArrangementMemberSubjects()
    {
        List<PaymentArrangementMemberSubject> pmtArrangementMemberSubjects = new ArrayList<PaymentArrangementMemberSubject>();
        PaymentArrangementMemberSubject pmtArrangementMemberSubject = new PaymentArrangementMemberSubject();
        pmtArrangementMemberSubject.setContractId( "CTID" );
        pmtArrangementMemberSubject.setLineOfBusinessCode( "LOB" );
        pmtArrangementMemberSubject.setCorporateEntityCode( "CEC" );
        pmtArrangementMemberSubjects.add( pmtArrangementMemberSubject );
        return pmtArrangementMemberSubjects;
    }

    private List<PaymentArrangementPayee> getPmtArrangementPayeesActive()
    {
        List<PaymentArrangementPayee> pmtArrangementPayees = new ArrayList<PaymentArrangementPayee>();
        PaymentArrangementPayee pmtArrangementPayee = new PaymentArrangementPayee();
        pmtArrangementPayee.setPaymentArrangementPayeeId( Integer.valueOf( 1 ) );
        pmtArrangementPayee.setCreateUserId( "USER1" );
        pmtArrangementPayee.setUpdateUserId( "USER1" );
        pmtArrangementPayee.setCreateRecordTimestamp( LocalDateTime.now() );
        pmtArrangementPayee.setUpdateRecordTimestamp( LocalDateTime.now() );
        pmtArrangementPayee.setRecordEffectiveDate( LocalDate.now() );
        pmtArrangementPayee.setRecordEndDate( LocalDate.now() );
        VbrPayee vbrPayee = getVbrPayeeActive();
        pmtArrangementPayee.setVbrPayee( vbrPayee );
        pmtArrangementPayees.add( pmtArrangementPayee );
        return pmtArrangementPayees;
    }

    private List<PaymentArrangementPayee> getPmtArrangementPayees()
    {
        List<PaymentArrangementPayee> pmtArrangementPayees = new ArrayList<PaymentArrangementPayee>();
        PaymentArrangementPayee pmtArrangementPayee = new PaymentArrangementPayee();
        pmtArrangementPayee.setPaymentArrangementPayeeId( Integer.valueOf( 1 ) );
        pmtArrangementPayee.setCreateUserId( "USER1" );
        pmtArrangementPayee.setUpdateUserId( "USER1" );
        pmtArrangementPayee.setCreateRecordTimestamp( LocalDateTime.now() );
        pmtArrangementPayee.setUpdateRecordTimestamp( LocalDateTime.now() );
        pmtArrangementPayee.setRecordEffectiveDate( LocalDate.now() );
        pmtArrangementPayee.setRecordEndDate( LocalDate.now() );
        VbrPayee vbrPayee = getVbrPayee();
        pmtArrangementPayee.setVbrPayee( vbrPayee );
        pmtArrangementPayees.add( pmtArrangementPayee );
        return pmtArrangementPayees;
    }

    private List<PaymentArrangementPayee> getPmtArrangementPayeesWrtPayee()
    {
        List<PaymentArrangementPayee> pmtArrangementPayees = new ArrayList<PaymentArrangementPayee>();
        PaymentArrangementPayee pmtArrangementPayee = new PaymentArrangementPayee();
        pmtArrangementPayee.setPaymentArrangementPayeeId( Integer.valueOf( 1 ) );
        pmtArrangementPayee.setCreateUserId( "USER1" );
        pmtArrangementPayee.setUpdateUserId( "USER1" );
        pmtArrangementPayee.setCreateRecordTimestamp( LocalDateTime.now() );
        pmtArrangementPayee.setUpdateRecordTimestamp( LocalDateTime.now() );
        pmtArrangementPayee.setRecordEffectiveDate( LocalDate.now() );
        pmtArrangementPayee.setRecordEndDate( LocalDate.now() );
        VbrPayee vbrPayee = getVbrPayeeWrtPayee();
        pmtArrangementPayee.setVbrPayee( vbrPayee );
        pmtArrangementPayees.add( pmtArrangementPayee );
        return pmtArrangementPayees;
    }

    private List<PaymentArrangementRate> getPmtArrangementRates()
    {
        List<PaymentArrangementRate> pmtArrangementRates = new ArrayList<PaymentArrangementRate>();
        PaymentArrangementRate pmtArrangementRate = new PaymentArrangementRate();
        pmtArrangementRate.setRateName( "DEMO" );
        pmtArrangementRates.add( pmtArrangementRate );
        return pmtArrangementRates;
    }

    private PaymentArrangement getPmtArrangementWrtPayee()
    {
        PaymentArrangement paymentArrangement = new PaymentArrangement();
        paymentArrangement.setCreateUserId( "USER1" );
        paymentArrangement.setUpdateUserId( "USER1" );
        paymentArrangement.setCreateRecordTimestamp( LocalDateTime.now() );
        paymentArrangement.setUpdateRecordTimestamp( LocalDateTime.now() );
        paymentArrangement.setRecordEffectiveDate( LocalDate.now() );
        paymentArrangement.setRecordEndDate( LocalDate.now() );
        paymentArrangement.setPaymentArrangementId( Integer.valueOf( 1 ) );
        paymentArrangement.setCorporateEntityCode( "CEC" );
        paymentArrangement.setPaymentArrangementName( "PANM" );
        paymentArrangement.setArrangementFrequencyCode( "MONT" );
        paymentArrangement.setPaymentArrangementTypeCode( "PATC" );
        paymentArrangement.setPaymentArrangementDescription( "PADSC" );
        paymentArrangement.setPaymentArrangementPayees( getPmtArrangementPayeesWrtPayee() );
        paymentArrangement.setPaymentArrangementRates( getPmtArrangementRates() );
        paymentArrangement.setPaymentArrangementMemberSubjects( getPmtArrangementMemberSubjects() );
        return paymentArrangement;

    }

    private VbrPayee getVbrPayeeActive()
    {
        VbrPayee vbrPayee = new VbrPayee();
        vbrPayee.setPinGroupId( "PGID" );
        vbrPayee.setRecordEffectiveDate( LocalDate.now().minusDays( 30 ) );
        vbrPayee.setRecordEndDate( LocalDate.now().plusDays( 30 ) );
        vbrPayee.setVbrPayeeId( Integer.valueOf( 1 ) );
        vbrPayee.setCreateRecordTimestamp( LocalDateTime.now() );
        vbrPayee.setUpdateRecordTimestamp( LocalDateTime.now() );
        return vbrPayee;
    }

    private VbrPayee getVbrPayee()
    {
        VbrPayee vbrPayee = new VbrPayee();
        vbrPayee.setPinGroupId( "PGID" );
        vbrPayee.setRecordEffectiveDate( LocalDate.now() );
        vbrPayee.setRecordEndDate( LocalDate.now() );
        vbrPayee.setVbrPayeeId( Integer.valueOf( 1 ) );
        vbrPayee.setCreateRecordTimestamp( LocalDateTime.now() );
        vbrPayee.setUpdateRecordTimestamp( LocalDateTime.now() );
        return vbrPayee;
    }

    private VbrPayeeDTO getVbrPayeeDTO()
    {
        VbrPayeeDTO vbrPayee = new VbrPayeeDTO();
        vbrPayee.setPinGroupId( "PGID" );
        vbrPayee.setRecordEffectiveDate( "" );
        vbrPayee.setRecordEndDate( "" );
        vbrPayee.setVbrPayeeId( Integer.valueOf( 1 ) );
        return vbrPayee;
    }

    private VbrPayee getVbrPayeeWrtPayee()
    {
        VbrPayee vbrPayee = new VbrPayee();
        vbrPayee.setPinGroupId( "PGID" );
        vbrPayee.setRecordEffectiveDate( LocalDate.now() );
        vbrPayee.setRecordEndDate( LocalDate.now() );
        vbrPayee.setCreateRecordTimestamp( LocalDateTime.now() );
        vbrPayee.setUpdateRecordTimestamp( LocalDateTime.now() );
        return vbrPayee;
    }
}