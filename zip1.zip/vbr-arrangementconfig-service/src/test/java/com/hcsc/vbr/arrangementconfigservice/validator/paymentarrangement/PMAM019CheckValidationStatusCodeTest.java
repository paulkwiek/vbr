package com.hcsc.vbr.arrangementconfigservice.validator.paymentarrangement;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import com.hcsc.vbr.arrangementconfigservice.domain.PaymentArrangement;
import com.hcsc.vbr.arrangementconfigservice.domain.PaymentArrangementMemberSubject;
import com.hcsc.vbr.arrangementconfigservice.domain.PaymentArrangementPayee;
import com.hcsc.vbr.arrangementconfigservice.domain.PaymentArrangementRate;
import com.hcsc.vbr.arrangementconfigservice.utils.ArrangementConfigServiceUtils;
import com.hcsc.vbr.common.utils.VBRDateUtils;

@RunWith( MockitoJUnitRunner.Silent.class )
public class PMAM019CheckValidationStatusCodeTest
{
    @InjectMocks
    private PMAM019CheckValidationStatusCode pMAM019CheckValidationStatusCode;

    @Mock
    private VBRDateUtils vBRDateUtils;

    @Mock
    private ArrangementConfigServiceUtils arrangementConfigServiceUtils;

    @Test
    public void getValidationStatusCodeTest_failure_checkAllArrangementConfigured() throws Exception
    {
        pMAM019CheckValidationStatusCode.getValidationStatusCode( getPaymentArrangementDTO_failure_checkAllArrangementConfigured(),
                                                                  Boolean.TRUE,
                                                                  Boolean.TRUE,
                                                                  LocalDate.now(),
                                                                  Boolean.TRUE );
    }

    @Test
    public void getValidationStatusCodeTest_Future_Invalid() throws Exception
    {
        pMAM019CheckValidationStatusCode.getValidationStatusCode( getPaymentArrangementDTO_Future_Invalid(),
                                                                  Boolean.TRUE,
                                                                  Boolean.TRUE,
                                                                  LocalDate.now(),
                                                                  Boolean.TRUE );
    }

    @Test
    public void getValidationStatusCodeTest_Valid() throws Exception
    {
        pMAM019CheckValidationStatusCode.getValidationStatusCode( getPaymentArrangementDTO_Valid(),
                                                                  Boolean.TRUE,
                                                                  Boolean.TRUE,
                                                                  LocalDate.now(),
                                                                  Boolean.FALSE );
    }

    @Test
    public void getValidationStatusCodeTest_Future_Valid() throws Exception
    {
        pMAM019CheckValidationStatusCode.getValidationStatusCode( getPaymentArrangementDTO_Success_checkAllArrangementConfigured(),
                                                                  Boolean.FALSE,
                                                                  Boolean.FALSE,
                                                                  LocalDate.now(),
                                                                  Boolean.TRUE );
    }

    @Test
    public void getValidationStatusCodeTest_Draft() throws Exception
    {
        pMAM019CheckValidationStatusCode.getValidationStatusCode( getPaymentArrangementDTO_Draft(),
                                                                  Boolean.FALSE,
                                                                  Boolean.FALSE,
                                                                  LocalDate.now(),
                                                                  Boolean.TRUE );
    }

    @Test
    public void getValidationStatusCodeTest_Expired() throws Exception
    {
        pMAM019CheckValidationStatusCode.getValidationStatusCode( getPaymentArrangementDTO_Expired(),
                                                                  Boolean.FALSE,
                                                                  Boolean.FALSE,
                                                                  LocalDate.now(),
                                                                  Boolean.TRUE );
    }

    @Test
    public void getValidationStatusCodeTest_Success_checkAllArrangementConfigured() throws Exception
    {
        pMAM019CheckValidationStatusCode.getValidationStatusCode( getPaymentArrangementDTO_Success_checkAllArrangementConfigured(),
                                                                  Boolean.TRUE,
                                                                  Boolean.TRUE,
                                                                  LocalDate.now(),
                                                                  Boolean.TRUE );
    }

    private PaymentArrangement getPaymentArrangementDTO_failure_checkAllArrangementConfigured()
    {
        PaymentArrangement paymentArrangementDTO = new PaymentArrangement();
        paymentArrangementDTO.setRecordEffectiveDate( LocalDate.now() );
        paymentArrangementDTO.setRecordEndDate( LocalDate.now() );
        return paymentArrangementDTO;
    }

    private PaymentArrangement getPaymentArrangementDTO_Draft()
    {
        PaymentArrangement paymentArrangementDTO = new PaymentArrangement();
        paymentArrangementDTO.setRecordEffectiveDate( LocalDate.of( 2017,
                                                                    12,
                                                                    1 ) );
        paymentArrangementDTO.setRecordEndDate( LocalDate.of( 2017,
                                                              12,
                                                              31 ) );
        return paymentArrangementDTO;
    }

    private PaymentArrangement getPaymentArrangementDTO_Expired()
    {
        PaymentArrangement paymentArrangementDTO = new PaymentArrangement();
        paymentArrangementDTO.setRecordEffectiveDate( LocalDate.of( 2017,
                                                                    12,
                                                                    1 ) );
        paymentArrangementDTO.setRecordEndDate( LocalDate.of( 2017,
                                                              12,
                                                              31 ) );
        paymentArrangementDTO.setPaymentArrangementMemberSubjects( getPaymentArrangementMemberSubjectDTO() );
        paymentArrangementDTO.setPaymentArrangementPayees( getPaymentArrangementPayeesDTO() );
        paymentArrangementDTO.setPaymentArrangementRates( getPaymentArrangementRatesDTO() );
        return paymentArrangementDTO;
    }

    private PaymentArrangement getPaymentArrangementDTO_Success_checkAllArrangementConfigured()
    {
        PaymentArrangement paymentArrangementDTO = new PaymentArrangement();
        paymentArrangementDTO.setRecordEffectiveDate( LocalDate.of( 2020,
                                                                    12,
                                                                    1 ) );
        paymentArrangementDTO.setRecordEndDate( LocalDate.of( 2020,
                                                              12,
                                                              31 ) );
        paymentArrangementDTO.setPaymentArrangementMemberSubjects( getPaymentArrangementMemberSubjectDTO() );
        paymentArrangementDTO.setPaymentArrangementPayees( getPaymentArrangementPayeesDTO() );
        paymentArrangementDTO.setPaymentArrangementRates( getPaymentArrangementRatesDTO() );
        return paymentArrangementDTO;
    }

    private PaymentArrangement getPaymentArrangementDTO_Future_Invalid()
    {
        PaymentArrangement paymentArrangementDTO = new PaymentArrangement();
        paymentArrangementDTO.setRecordEffectiveDate( LocalDate.of( 2019,
                                                                    12,
                                                                    1 ) );
        paymentArrangementDTO.setRecordEndDate( LocalDate.of( 2020,
                                                              1,
                                                              1 ) );
        paymentArrangementDTO.setPaymentArrangementMemberSubjects( getPaymentArrangementMemberSubjectDTO() );
        paymentArrangementDTO.setPaymentArrangementPayees( getPaymentArrangementPayeesDTO() );
        paymentArrangementDTO.setPaymentArrangementRates( getPaymentArrangementRatesDTO() );
        return paymentArrangementDTO;
    }

    private PaymentArrangement getPaymentArrangementDTO_Valid()
    {
        PaymentArrangement paymentArrangementDTO = new PaymentArrangement();
        paymentArrangementDTO.setRecordEffectiveDate( LocalDate.now() );
        paymentArrangementDTO.setRecordEndDate( LocalDate.now() );
        paymentArrangementDTO.setPaymentArrangementMemberSubjects( getPaymentArrangementMemberSubjectDTO() );
        paymentArrangementDTO.setPaymentArrangementPayees( getPaymentArrangementPayeesDTO() );
        paymentArrangementDTO.setPaymentArrangementRates( getPaymentArrangementRatesDTO() );
        return paymentArrangementDTO;
    }

    private List<PaymentArrangementMemberSubject> getPaymentArrangementMemberSubjectDTO()
    {
        List<PaymentArrangementMemberSubject> paymentArrangementMemberSubjectsDTO = new ArrayList<PaymentArrangementMemberSubject>();
        PaymentArrangementMemberSubject paymentArrangementMemberSubjectDTO = new PaymentArrangementMemberSubject();
        paymentArrangementMemberSubjectsDTO.add( paymentArrangementMemberSubjectDTO );
        return paymentArrangementMemberSubjectsDTO;
    }

    private List<PaymentArrangementPayee> getPaymentArrangementPayeesDTO()
    {
        List<PaymentArrangementPayee> paymentArrangementPayeesDTO = new ArrayList<PaymentArrangementPayee>();
        PaymentArrangementPayee paymentArrangementPayeeDTO = new PaymentArrangementPayee();
        paymentArrangementPayeesDTO.add( paymentArrangementPayeeDTO );
        return paymentArrangementPayeesDTO;
    }

    private List<PaymentArrangementRate> getPaymentArrangementRatesDTO()
    {
        List<PaymentArrangementRate> paymentArrangementRatesDTO = new ArrayList<PaymentArrangementRate>();
        PaymentArrangementRate paymentArrangementRateDTO = new PaymentArrangementRate();
        paymentArrangementRatesDTO.add( paymentArrangementRateDTO );
        return paymentArrangementRatesDTO;
    }

}