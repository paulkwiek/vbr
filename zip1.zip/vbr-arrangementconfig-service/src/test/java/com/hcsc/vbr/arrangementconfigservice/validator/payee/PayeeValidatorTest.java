package com.hcsc.vbr.arrangementconfigservice.validator.payee;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import com.hcsc.vbr.arrangementconfigservice.domain.VbrPayee;
import com.hcsc.vbr.common.constant.VBRCommonConstant.RowActionTypes;
import com.hcsc.vbr.common.dto.ReturnMessageDTO;
import com.hcsc.vbr.common.exception.VbrApplicationException;
import com.hcsc.vbr.web.request.PayeeSearchRequest;
import com.hcsc.vbr.web.response.ProviderAPIResponseDTO;
import com.hcsc.vbr.web.response.ProviderAPISearchResponseDTO;

@RunWith( MockitoJUnitRunner.Silent.class )
public class PayeeValidatorTest
{
    @InjectMocks
    PayeeValidator payeeValidator;

    @Mock
    private VBPY001ValidatePinGroupIdInSearch vbpy001ValidatePinGroupIdInSearch;

    @Mock
    private VBPY002ValidateVbrEfffectiveAndEndDate vbpy002ValidateVbrEfffectiveAndEndDate;

    @Mock
    private VBPY004ValidateVbrPayeePfinId vbpy004ValidateVbrPayeePfinId;

    @Mock
    private VBPY005ProviderAPIValidations vbpy005ProviderAPIValidations;

    @Mock
    private VBPY007ValidateUniquePayee vbpy007ValidateUniquePayee;

    @Mock
    private VBPY008ValidateVbrPayeePinGroupId vbpy008ValidateVbrPayeePinGroupId;

    @Mock
    private VBPY009ValidateVbrPayeeTaxIdNumber vbpy009ValidateVbrPayeeTaxIdNumber;

    @Mock
    private VBPY010ValidateVbrPayeeCapitationCode vbpy010ValidateVbrPayeeCapitationCode;

    @Mock
    private VBPY011ValidateVbrPayeeCaptitationProcessCode vbpy011ValidateVbrPayeeCaptitationProcessCode;

    @Mock
    private VBPY012ValidateVbrPayeeCorporateEntityCode vbpy012ValidateVbrPayeeCorporateEntityCode;

    @Mock
    private VBPY013ValidateVbrPayeeNetworkCode vbpy013ValidateVbrPayeeNetworkCode;

    @Mock
    private VBPY014ValidateVbrPayeePinGroupName vbpy014ValidateVbrPayeePinGroupName;

    @Mock
    private VBPY015ValidateVbrPayeeEffDateIsFirstDayOfMonth vbpy015ValidateVbrPayeeEffDateIsFirstDayOfMonth;

    @Mock
    private VBPY016ValidateVbrPayeeEndDateIsLastDayOfMonth vbpy016ValidateVbrPayeeEndDateIsLastDayOfMonth;

    @Mock
    VBPY017ValidateNoRecordsFoundForPayee vbpy017ValidateNoRecordsFoundForPayee;

    @Mock
    VBPY018ValidateNoRecordsFoundForPayeeFromProviderApi vbpy018ValidateNoRecordsFoundForPayeeFromProviderApi;

    @Mock
    VBPY019ValidateStatusOfLinkedArrangementsInUpdatePayee vbpy019ValidateStatusOfLinkedArrangementsInUpdatePayee;

    @Mock
    VBPY020ValidateRetrievePayee vbpy020ValidateRetrievePayee;

    @Mock
    VBPY021ValidateNoMatchingRecordFoundForPayeeFromProviderApi vbpy021ValidateNoMatchingRecordFoundForPayeeFromProviderApi;

    @Test
    public void validateSavePayeeTest() throws Exception
    {

        when( vbpy001ValidatePinGroupIdInSearch.validatePinGroupId( any(),
                                                                    any() ) ).thenReturn( true );
        when( vbpy002ValidateVbrEfffectiveAndEndDate.validateVBRPayeeEffAndEndDate( any(),
                                                                                    any() ) ).thenReturn( true );
        when( vbpy004ValidateVbrPayeePfinId.validateVbrPayeePfinIdFieldLength( any(),
                                                                               any() ) ).thenReturn( true );

        when( vbpy005ProviderAPIValidations.providerAPIValidations( any(),
                                                                    any() ) ).thenReturn( true );
        when( vbpy007ValidateUniquePayee.validateUniquePayee( any(),
                                                              any() ) ).thenReturn( true );
        when( vbpy008ValidateVbrPayeePinGroupId.validateVbrPayeePinGroupIDFieldLength( any(),
                                                                                       any() ) ).thenReturn( true );
        when( vbpy009ValidateVbrPayeeTaxIdNumber.validateVbrPayeeTaxIdNumberFieldLength( any(),
                                                                                         any() ) ).thenReturn( true );
        when( vbpy010ValidateVbrPayeeCapitationCode.validateVbrPayeeCapitationCodeFieldLength( any(),
                                                                                               any() ) ).thenReturn( true );
        when( vbpy011ValidateVbrPayeeCaptitationProcessCode.validateVbrPayeeCapitationProcessCodeFieldLength( any(),
                                                                                                              any() ) )
                                                                                                                      .thenReturn( true );
        when( vbpy012ValidateVbrPayeeCorporateEntityCode.validateVbrPayeeCorporateEntityCodeFieldLength( any(),
                                                                                                         any() ) ).thenReturn( true );
        when( vbpy013ValidateVbrPayeeNetworkCode.validateVbrPayeeNetworkCodeFieldLength( any(),
                                                                                         any() ) ).thenReturn( true );
        when( vbpy014ValidateVbrPayeePinGroupName.validateVbrPayeePinGroupNameFieldLength( any(),
                                                                                           any() ) ).thenReturn( true );
        when( vbpy015ValidateVbrPayeeEffDateIsFirstDayOfMonth.isFirstDayOfMonth( any(),
                                                                                 any() ) ).thenReturn( true );
        when( vbpy016ValidateVbrPayeeEndDateIsLastDayOfMonth.isLastDayOfMonth( any(),
                                                                               any() ) ).thenReturn( true );

        payeeValidator.validateSavePayee( getVbrPayee_Success(),
                                          getReturnMessageDTO() );

    }

    @Test( expected = VbrApplicationException.class )
    public void validateSavePayeeTest_Failure() throws Exception
    {

        when( vbpy001ValidatePinGroupIdInSearch.validatePinGroupId( any(),
                                                                    any() ) ).thenReturn( false );
        when( vbpy002ValidateVbrEfffectiveAndEndDate.validateVBRPayeeEffAndEndDate( any(),
                                                                                    any() ) ).thenReturn( false );
        when( vbpy004ValidateVbrPayeePfinId.validateVbrPayeePfinIdFieldLength( any(),
                                                                               any() ) ).thenReturn( false );

        when( vbpy005ProviderAPIValidations.providerAPIValidations( any(),
                                                                    any() ) ).thenReturn( false );
        when( vbpy007ValidateUniquePayee.validateUniquePayee( any(),
                                                              any() ) ).thenReturn( false );
        when( vbpy008ValidateVbrPayeePinGroupId.validateVbrPayeePinGroupIDFieldLength( any(),
                                                                                       any() ) ).thenReturn( false );
        when( vbpy009ValidateVbrPayeeTaxIdNumber.validateVbrPayeeTaxIdNumberFieldLength( any(),
                                                                                         any() ) ).thenReturn( false );
        when( vbpy010ValidateVbrPayeeCapitationCode.validateVbrPayeeCapitationCodeFieldLength( any(),
                                                                                               any() ) ).thenReturn( false );
        when( vbpy011ValidateVbrPayeeCaptitationProcessCode.validateVbrPayeeCapitationProcessCodeFieldLength( any(),
                                                                                                              any() ) )
                                                                                                                      .thenReturn( false );
        when( vbpy012ValidateVbrPayeeCorporateEntityCode.validateVbrPayeeCorporateEntityCodeFieldLength( any(),
                                                                                                         any() ) ).thenReturn( false );
        when( vbpy013ValidateVbrPayeeNetworkCode.validateVbrPayeeNetworkCodeFieldLength( any(),
                                                                                         any() ) ).thenReturn( false );
        when( vbpy014ValidateVbrPayeePinGroupName.validateVbrPayeePinGroupNameFieldLength( any(),
                                                                                           any() ) ).thenReturn( false );
        when( vbpy015ValidateVbrPayeeEffDateIsFirstDayOfMonth.isFirstDayOfMonth( any(),
                                                                                 any() ) ).thenReturn( false );
        when( vbpy016ValidateVbrPayeeEndDateIsLastDayOfMonth.isLastDayOfMonth( any(),
                                                                               any() ) ).thenReturn( false );

        payeeValidator.validateSavePayee( getVbrPayee_Failure(),
                                          getReturnMessageDTO() );

    }

    @Test
    public void validateSearchPayeeTest() throws Exception
    {
        when( vbpy001ValidatePinGroupIdInSearch.validatePinGroupId( any(),
                                                                    any() ) ).thenReturn( true );
        payeeValidator.validateSearchPayee( getPayeeSearchRequest(),
                                            getReturnMessageDTO() );

    }

    @Test( expected = VbrApplicationException.class )
    public void validateSearchPayeeTest_Failure() throws Exception
    {
        when( vbpy001ValidatePinGroupIdInSearch.validatePinGroupId( any(),
                                                                    any() ) ).thenReturn( false );
        payeeValidator.validateSearchPayee( getPayeeSearchRequest_Failure(),
                                            getReturnMessageDTO() );

    }

    @Test
    public void validateRetrievePayee() throws Exception
    {
        when( vbpy020ValidateRetrievePayee.validatePinGroupId( any(),
                                                               any() ) ).thenReturn( true );
        payeeValidator.validateRetrievePayee( getPayeeRetrieveRequest(),
                                              getReturnMessageDTO() );

    }

    @Test( expected = VbrApplicationException.class )
    public void validateRetrievePayee_Failure() throws Exception
    {
        when( vbpy020ValidateRetrievePayee.validatePinGroupId( any(),
                                                               any() ) ).thenReturn( false );
        payeeValidator.validateRetrievePayee( getPayeeRetrieveRequest_Failure(),
                                              getReturnMessageDTO() );
    }

    @Test
    public void validateUniquePayee() throws Exception
    {
        when( vbpy007ValidateUniquePayee.validateUniquePayee( any(),
                                                              any() ) ).thenReturn( true );
        payeeValidator.validateUniquePayee( getVbrPayee_Success(),
                                            getReturnMessageDTO() );
    }

    @Test( expected = VbrApplicationException.class )
    public void validateUniquePayee_Failure() throws Exception
    {
        when( vbpy007ValidateUniquePayee.validateUniquePayee( any(),
                                                              any() ) ).thenReturn( false );
        payeeValidator.validateUniquePayee( getVbrPayee_Success(),
                                            getReturnMessageDTO() );
    }

    @Test
    public void validateStatusOfLinkedArrangementsInUpdatePayee() throws Exception
    {
        when( vbpy019ValidateStatusOfLinkedArrangementsInUpdatePayee.validateStatusOFLinkedArrangements( any(),
                                                                                                         any() ) ).thenReturn( true );
        payeeValidator.validateStatusOfLinkedArrangementsInUpdatePayee( getVbrPayee_Success(),
                                                                        getReturnMessageDTO() );
    }

    @Test
    public void validateStatusOfLinkedArrangementsInUpdatePayee_Failure() throws Exception
    {
        when( vbpy019ValidateStatusOfLinkedArrangementsInUpdatePayee.validateStatusOFLinkedArrangements( any(),
                                                                                                         any() ) ).thenReturn( false );
        payeeValidator.validateStatusOfLinkedArrangementsInUpdatePayee( getVbrPayee_Success(),
                                                                        getReturnMessageDTO() );
    }

    @Test
    public void validateGetPayees() throws Exception
    {
        when( vbpy017ValidateNoRecordsFoundForPayee.isRecordsFound( any(),
                                                                    any() ) ).thenReturn( true );
        payeeValidator.validateGetPayees( getPayees(),
                                          getReturnMessageDTO() );
    }

    @Test( expected = VbrApplicationException.class )
    public void validateGetPayees_Failure() throws Exception
    {
        when( vbpy017ValidateNoRecordsFoundForPayee.isRecordsFound( any(),
                                                                    any() ) ).thenReturn( false );
        payeeValidator.validateGetPayees( getPayees(),
                                          getReturnMessageDTO() );
    }

    @Test
    public void validateGetPayeesFromProviderApi() throws Exception
    {
        when( vbpy018ValidateNoRecordsFoundForPayeeFromProviderApi.isRecordsFound( any(),
                                                                                   any() ) ).thenReturn( true );
        payeeValidator.validateGetPayeesFromProviderApi( getProviderAPIResponseDTO(),
                                                         getReturnMessageDTO() );
    }

    @Test( expected = VbrApplicationException.class )
    public void validateGetPayeesFromProviderApi_Failure() throws Exception
    {
        when( vbpy018ValidateNoRecordsFoundForPayeeFromProviderApi.isRecordsFound( any(),
                                                                                   any() ) ).thenReturn( false );
        payeeValidator.validateGetPayeesFromProviderApi( getProviderAPIResponseDTO(),
                                                         getReturnMessageDTO() );
    }

    @Test
    public void validateGetPayeesMatchingFromProviderApi() throws Exception
    {
        when( vbpy021ValidateNoMatchingRecordFoundForPayeeFromProviderApi.isRecordsFound( any(),
                                                                                          any() ) ).thenReturn( true );
        payeeValidator.validateGetPayeesMatchingFromProviderApi( getProviderAPISearchResponseDTO(),
                                                                 getReturnMessageDTO() );
    }

    @Test( expected = VbrApplicationException.class )
    public void validateGetPayeesMatchingFromProviderApi_Failure() throws Exception
    {
        when( vbpy021ValidateNoMatchingRecordFoundForPayeeFromProviderApi.isRecordsFound( any(),
                                                                                          any() ) ).thenReturn( false );
        payeeValidator.validateGetPayeesMatchingFromProviderApi( getProviderAPISearchResponseDTO(),
                                                                 getReturnMessageDTO() );
    }

    List<ProviderAPIResponseDTO> getProviderAPIResponseDTO()
    {
        List<ProviderAPIResponseDTO> providerDTOList = new ArrayList<ProviderAPIResponseDTO>();
        ProviderAPIResponseDTO providerAPIResponseDTO = new ProviderAPIResponseDTO();
        providerAPIResponseDTO.setProcessCode( "CP" );
        providerAPIResponseDTO.setPingroupID( "RE1" );
        providerAPIResponseDTO.setPayToPFINId( "00NMCAP001" );
        providerAPIResponseDTO.setCapitationTypeCode( "A1" );
        providerAPIResponseDTO.setPingroupName( "RE1001" );
        providerAPIResponseDTO.setTaxId( "999999999" );
        providerAPIResponseDTO.setNetworkAssociationEffectiveDate( "01/01/2019" );
        providerAPIResponseDTO.setNetworkAssociationEndDate( "12/31/2019" );
        providerAPIResponseDTO.setPfinEffectiveDate( "01/01/2019" );
        providerAPIResponseDTO.setPfinEndDate( "12/31/2019" );
        providerAPIResponseDTO.setPINGroupEndDate( "01/01/2019" );
        providerAPIResponseDTO.setPINGroupEffectiveDate( "12/31/2019" );
        providerAPIResponseDTO.setTinEffectiveDate( "02/22/2019" );
        providerAPIResponseDTO.setTinEndDate( "02/21/2020" );
        providerDTOList.add( providerAPIResponseDTO );

        return providerDTOList;

    }

    List<ProviderAPISearchResponseDTO> getProviderAPISearchResponseDTO()
    {
        List<ProviderAPISearchResponseDTO> providerDTOList = new ArrayList<ProviderAPISearchResponseDTO>();
        ProviderAPISearchResponseDTO providerAPIResponseDTO = new ProviderAPISearchResponseDTO();
        providerAPIResponseDTO.setProcessCode( "CP" );
        providerAPIResponseDTO.setPingroupID( "RE1" );
        providerAPIResponseDTO.setCapitationType( "A1" );
        providerAPIResponseDTO.setPingroupName( "RE1001" );
        providerAPIResponseDTO.setPfinEffectiveDate( "01/01/2019" );
        providerAPIResponseDTO.setPfinEndDate( "12/31/2019" );
        providerDTOList.add( providerAPIResponseDTO );

        return providerDTOList;

    }

    private List<VbrPayee> getPayees()
    {

        List<VbrPayee> payees = new ArrayList<VbrPayee>();
        VbrPayee vbrPayee = new VbrPayee();
        vbrPayee.setCorporateEntityCode( "NM" );
        vbrPayee.setNetworkAssocProviderId( 772129111 );
        vbrPayee.setNetworkCode( "MCD" );
        vbrPayee.setCapitationProcessCode( "CP" );
        vbrPayee.setPinGroupId( "RE1" );
        vbrPayee.setPayToPfinId( "00NMCAP001" );
        vbrPayee.setCapitationCode( "A1" );
        vbrPayee.setPinGroupName( "RE1001" );
        vbrPayee.setTaxIdNumber( "999999999" );
        vbrPayee.setNetworkAssociationEffectiveDate( "01/01/2019" );
        vbrPayee.setNetworkAssociationEndDate( "12/31/2019" );
        vbrPayee.setPfinEffectiveDate( "01/01/2019" );
        vbrPayee.setPfinEndDate( "12/31/2019" );
        vbrPayee.setPinGroupEffectiveDate( "01/01/2019" );
        vbrPayee.setPinGroupEndDate( "12/31/2019" );
        vbrPayee.setTinEffectiveDate( "02/22/2019" );
        vbrPayee.setTinEndDate( "02/21/2020" );
        vbrPayee.setRecordEffectiveDate( LocalDate.of( 2019,
                                                       11,
                                                       01 ) );
        vbrPayee.setRecordEndDate( LocalDate.of( 2019,
                                                 11,
                                                 30 ) );
        vbrPayee.setCreateUserId( "u399768" );
        vbrPayee.setUpdateUserId( "u399768" );
        vbrPayee.setRowAction( RowActionTypes.INSERT );
        payees.add( vbrPayee );
        return payees;

    }

    private PayeeSearchRequest getPayeeSearchRequest()
    {
        PayeeSearchRequest payeeSearchRequest = new PayeeSearchRequest();

        payeeSearchRequest.setCorpEntityCode( "NM1" );
        payeeSearchRequest.setPinGroupId( "RE1" );

        return payeeSearchRequest;
    }

    private PayeeSearchRequest getPayeeSearchRequest_Failure()
    {
        PayeeSearchRequest payeeSearchRequest = new PayeeSearchRequest();

        payeeSearchRequest.setCorpEntityCode( "NM1" );
        payeeSearchRequest.setPinGroupId( "RE1djshdvhjedebkjjkdkjdfuibngcjkdfdg6y" );

        return payeeSearchRequest;
    }

    private PayeeSearchRequest getPayeeRetrieveRequest()
    {
        PayeeSearchRequest payeeSearchRequest = new PayeeSearchRequest();

        payeeSearchRequest.setCorpEntityCode( "NM1" );
        payeeSearchRequest.setPinGroupId( "RE1" );
        payeeSearchRequest.setNetworkCode( "MCD" );
        payeeSearchRequest.setPayToPFIN( "00NMCAP017" );
        payeeSearchRequest.setCapitationTypeCode( "A1" );
        payeeSearchRequest.setProcessCode( "CP" );
        payeeSearchRequest.setNetworkAssociationID( 772129110 );

        return payeeSearchRequest;
    }

    private PayeeSearchRequest getPayeeRetrieveRequest_Failure()
    {
        PayeeSearchRequest payeeSearchRequest = new PayeeSearchRequest();

        payeeSearchRequest.setCorpEntityCode( "NM1" );
        payeeSearchRequest.setPinGroupId( "Hhhsdjdvdhcbdhcdcbdhcbdhchcdccvsfvdvgdfvgg" );
        payeeSearchRequest.setNetworkCode( "MCD" );
        payeeSearchRequest.setPayToPFIN( "00NMCAP017" );
        payeeSearchRequest.setCapitationTypeCode( "A1" );
        payeeSearchRequest.setProcessCode( "CP" );
        payeeSearchRequest.setNetworkAssociationID( 772129110 );

        return payeeSearchRequest;
    }

    private ReturnMessageDTO getReturnMessageDTO()
    {
        ReturnMessageDTO returnMessage = new ReturnMessageDTO();
        return returnMessage;
    }

    private VbrPayee getVbrPayee_Success()
    {
        VbrPayee vbrPayee = new VbrPayee();
        vbrPayee.setCorporateEntityCode( "NM" );
        vbrPayee.setNetworkAssocProviderId( 772129111 );
        vbrPayee.setNetworkCode( "MCD" );
        vbrPayee.setCapitationProcessCode( "CP" );
        vbrPayee.setPinGroupId( "RE1" );
        vbrPayee.setPayToPfinId( "00NMCAP001" );
        vbrPayee.setCapitationCode( "A1" );
        vbrPayee.setPinGroupName( "RE1001" );
        vbrPayee.setTaxIdNumber( "999999999" );
        vbrPayee.setNetworkAssociationEffectiveDate( "01/01/2019" );
        vbrPayee.setNetworkAssociationEndDate( "12/31/2019" );
        vbrPayee.setPfinEffectiveDate( "01/01/2019" );
        vbrPayee.setPfinEndDate( "12/31/2019" );
        vbrPayee.setPinGroupEffectiveDate( "01/01/2019" );
        vbrPayee.setPinGroupEndDate( "12/31/2019" );
        vbrPayee.setTinEffectiveDate( "02/22/2019" );
        vbrPayee.setTinEndDate( "02/21/2020" );
        vbrPayee.setRecordEffectiveDate( LocalDate.of( 2019,
                                                       11,
                                                       01 ) );
        vbrPayee.setRecordEndDate( LocalDate.of( 2019,
                                                 11,
                                                 30 ) );
        vbrPayee.setCreateUserId( "u399768" );
        vbrPayee.setUpdateUserId( "u399768" );
        vbrPayee.setRowAction( RowActionTypes.INSERT );
        return vbrPayee;

    }

    private VbrPayee getVbrPayee_Failure()
    {
        VbrPayee vbrPayee = new VbrPayee();
        vbrPayee.setCorporateEntityCode( "NM" );
        vbrPayee.setNetworkAssocProviderId( 772129111 );
        vbrPayee.setNetworkCode( "MCDhefefefkie" );
        vbrPayee.setCapitationProcessCode( "CPdffjegrwgrgdfhjfhkcdj" );
        vbrPayee.setPinGroupId( "RE1fewkflrjfgrufefcibvcfkjbfceklbjcfkbjj" );
        vbrPayee.setPayToPfinId( "00NMCAP001hfjdhfjdfkdfevcebjuekjeb" );
        vbrPayee.setCapitationCode( "A1" );
        vbrPayee.setPinGroupName( "RE1001" );
        vbrPayee.setTaxIdNumber( "999999999" );
        vbrPayee.setNetworkAssociationEffectiveDate( "01/01/2019" );
        vbrPayee.setNetworkAssociationEndDate( "12/31/2019" );
        vbrPayee.setPfinEffectiveDate( "01/01/2019" );
        vbrPayee.setPfinEndDate( "12/31/2019" );
        vbrPayee.setPinGroupEffectiveDate( "01/01/2019" );
        vbrPayee.setPinGroupEndDate( "12/31/2019" );
        vbrPayee.setTinEffectiveDate( "02/22/2019" );
        vbrPayee.setTinEndDate( "02/21/2020" );
        vbrPayee.setRecordEffectiveDate( LocalDate.of( 2019,
                                                       11,
                                                       30 ) );
        vbrPayee.setRecordEndDate( LocalDate.of( 2019,
                                                 11,
                                                 29 ) );
        vbrPayee.setCreateUserId( "u399768" );
        vbrPayee.setUpdateUserId( "u399768" );
        vbrPayee.setRowAction( RowActionTypes.INSERT );
        return vbrPayee;

    }

}
