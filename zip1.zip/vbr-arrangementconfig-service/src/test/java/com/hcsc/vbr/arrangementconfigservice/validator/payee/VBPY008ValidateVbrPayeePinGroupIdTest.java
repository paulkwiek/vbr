package com.hcsc.vbr.arrangementconfigservice.validator.payee;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnitRunner;

import com.hcsc.vbr.arrangementconfigservice.domain.VbrPayee;
import com.hcsc.vbr.common.dto.ReturnMessageDTO;

@RunWith( MockitoJUnitRunner.Silent.class )
public class VBPY008ValidateVbrPayeePinGroupIdTest
{

    @InjectMocks
    private VBPY008ValidateVbrPayeePinGroupId vbpy008ValidateVbrPayeePinGroupId;

    @Test
    public void validateVbrPayeePinGroupIDFieldLength() throws Exception
    {

        vbpy008ValidateVbrPayeePinGroupId.validateVbrPayeePinGroupIDFieldLength( getVbrPayee_Success(),
                                                                                 getReturnMessageDTO() );
    }

    @Test( expected = NullPointerException.class )
    public void validateVbrPayeePinGroupIDFieldLength_Failure() throws Exception
    {

        vbpy008ValidateVbrPayeePinGroupId.validateVbrPayeePinGroupIDFieldLength( getVbrPayee_Failure(),
                                                                                 getReturnMessageDTO() );
    }

    private VbrPayee getVbrPayee_Failure()
    {
        VbrPayee vbrPayee = new VbrPayee();

        vbrPayee.setPinGroupId( "RE1cdsdnfasdbfjaaabdcsdbcsdcnh" );
        return vbrPayee;

    }

    private VbrPayee getVbrPayee_Success()
    {
        VbrPayee vbrPayee = new VbrPayee();

        vbrPayee.setPinGroupId( "RE1" );
        return vbrPayee;

    }

    private ReturnMessageDTO getReturnMessageDTO()
    {
        ReturnMessageDTO returnMessage = new ReturnMessageDTO();
        return returnMessage;
    }

}
