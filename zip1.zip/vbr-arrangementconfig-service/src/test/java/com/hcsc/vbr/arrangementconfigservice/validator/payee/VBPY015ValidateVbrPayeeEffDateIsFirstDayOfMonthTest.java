package com.hcsc.vbr.arrangementconfigservice.validator.payee;

import java.time.LocalDate;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnitRunner;

import com.hcsc.vbr.arrangementconfigservice.domain.VbrPayee;
import com.hcsc.vbr.common.dto.ReturnMessageDTO;

@RunWith( MockitoJUnitRunner.Silent.class )
public class VBPY015ValidateVbrPayeeEffDateIsFirstDayOfMonthTest
{

    @InjectMocks
    private VBPY015ValidateVbrPayeeEffDateIsFirstDayOfMonth vbpy015ValidateVbrPayeeEffDateIsFirstDayOfMonth;

    @Test
    public void isFirstDayOfMonth() throws Exception
    {

        vbpy015ValidateVbrPayeeEffDateIsFirstDayOfMonth.isFirstDayOfMonth( getVbrPayee_Success(),
                                                                           getReturnMessageDTO() );
    }

    @Test( expected = NullPointerException.class )
    public void isFirstDayOfMonth_Failure() throws Exception
    {

        vbpy015ValidateVbrPayeeEffDateIsFirstDayOfMonth.isFirstDayOfMonth( getVbrPayee_Failure(),
                                                                           getReturnMessageDTO() );
    }

    private VbrPayee getVbrPayee_Failure()
    {
        VbrPayee vbrPayee = new VbrPayee();

        vbrPayee.setRecordEffectiveDate( LocalDate.of( 2019,
                                                       11,
                                                       02 ) );
        vbrPayee.setRecordEndDate( LocalDate.of( 2019,
                                                 11,
                                                 29 ) );
        return vbrPayee;

    }

    private VbrPayee getVbrPayee_Success()
    {
        VbrPayee vbrPayee = new VbrPayee();

        vbrPayee.setRecordEffectiveDate( LocalDate.of( 2019,
                                                       11,
                                                       01 ) );
        vbrPayee.setRecordEndDate( LocalDate.of( 2019,
                                                 11,
                                                 30 ) );
        return vbrPayee;

    }

    private ReturnMessageDTO getReturnMessageDTO()
    {
        ReturnMessageDTO returnMessage = new ReturnMessageDTO();
        return returnMessage;
    }

}
