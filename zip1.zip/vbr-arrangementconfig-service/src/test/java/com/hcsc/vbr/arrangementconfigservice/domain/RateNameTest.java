package com.hcsc.vbr.arrangementconfigservice.domain;

public class RateNameTest
{
    /* @Test
    public void testSetters()
    {
    
        RateName ratename = new RateName();
        ratename.setRateName( "Vbrrate" );
        ratename.setCorporateEntityCode( "VBR1209" );
        ratename.setRateTypeCode( "ab123cd" );
    
        assertEquals( "VBR1209",
                      ratename.getCorporateEntityCode() );
        assertEquals( "Vbrrate",
                      ratename.getRateName() );
        assertEquals( "ab123cd",
                      ratename.getRateTypeCode() );
        assertTrue( ratename.toString().contains( "rateName=Vbrrate" ) );
    
    }*/

}
