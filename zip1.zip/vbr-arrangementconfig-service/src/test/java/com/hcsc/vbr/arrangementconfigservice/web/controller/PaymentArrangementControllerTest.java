package com.hcsc.vbr.arrangementconfigservice.web.controller;

import static org.junit.Assert.assertEquals;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.boot.test.json.JacksonTester;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.hcsc.vbr.arrangementconfigservice.dto.CalculationRequestDTO;
import com.hcsc.vbr.arrangementconfigservice.dto.FlatRateDTO;
import com.hcsc.vbr.arrangementconfigservice.dto.PaymentArrangementDTO;
import com.hcsc.vbr.arrangementconfigservice.dto.PaymentArrangementPayeeDTO;
import com.hcsc.vbr.arrangementconfigservice.dto.PaymentArrangementRateDTO;
import com.hcsc.vbr.arrangementconfigservice.dto.VbrPayeeDTO;
import com.hcsc.vbr.arrangementconfigservice.service.PaymentArrangementRateService;
import com.hcsc.vbr.arrangementconfigservice.service.PaymentArrangementService;
import com.hcsc.vbr.common.constant.VBRCommonConstant.RowActionTypes;
import com.hcsc.vbr.web.controller.PaymentArrangementController;
import com.hcsc.vbr.web.request.CalculationRequestSaveRequest;
import com.hcsc.vbr.web.request.PayeeSearchRequest;
import com.hcsc.vbr.web.request.PaymentArrangementSaveRequest;
import com.hcsc.vbr.web.request.ValidateArrangementPayeeRequest;
import com.hcsc.vbr.web.request.ValidateArrangementRateRequest;
import com.hcsc.vbr.web.response.PaymentArrangementListResponse;

@RunWith( MockitoJUnitRunner.Silent.class )
public class PaymentArrangementControllerTest
{
    @InjectMocks
    private PaymentArrangementController paymentArrangementController;

    @Mock
    private PaymentArrangementService paymentArrangementService;

    @Mock
    private PaymentArrangementRateService paymentArrangementRateService;

    private MockMvc mvc;

    @Before
    public void initTest() throws Exception
    {
        MockitoAnnotations.initMocks( this );
        JacksonTester.initFields( this,
                                  new ObjectMapper() );
        mvc = MockMvcBuilders.standaloneSetup( paymentArrangementController ).setControllerAdvice( new Exception() ).build();
    }

    @Test
    public void testSaveArrangementSuccess() throws Exception
    {
        ObjectMapper map = new ObjectMapper();
        String jsonReq = map.writeValueAsString( paymentArrangementSaveRequest() );
        MvcResult result = null;

        result = mvc
                .perform( MockMvcRequestBuilders.post( "/paymentarrangement/saveArrangement" )
                        .content( jsonReq )
                        .contentType( MediaType.APPLICATION_JSON )
                        .accept( MediaType.APPLICATION_JSON ) )
                .andExpect( status().isOk() )
                .andReturn();

        assertEquals( 200,
                      result.getResponse().getStatus() );

    }

    @Test
    public void testSaveArrangementFailure() throws Exception
    {
        String request = "";
        MockHttpServletResponse result = mvc
                .perform( MockMvcRequestBuilders.post( "/paymentarrangement/saveArrangement" )
                        .content( request )
                        .contentType( MediaType.APPLICATION_JSON )
                        .accept( MediaType.APPLICATION_JSON ) )
                .andReturn()
                .getResponse();
        assertEquals( 400,
                      result.getStatus() );
    }

    @Test
    public void testGetArrangementsSuccess() throws Exception
    {
        List<PaymentArrangementListResponse> retList = new ArrayList<PaymentArrangementListResponse>();

        PaymentArrangementListResponse paymentArrangementListResponse = new PaymentArrangementListResponse();
        paymentArrangementListResponse.setPaymentArrangementId( 1 );
        paymentArrangementListResponse.setPaymentArrangementName( "Arrangement 456789" );
        paymentArrangementListResponse.setPinGroupId( "RSK" );
        paymentArrangementListResponse.setRecordEffectiveDate( "12/12/2019" );
        paymentArrangementListResponse.setRecordEndDate( "12/12/2019" );

        retList.add( paymentArrangementListResponse );

        Mockito.when( paymentArrangementService.getArrangementsByCorporateEntityCode( "NM1" ) ).thenReturn( retList );

        MvcResult result =
            mvc.perform( MockMvcRequestBuilders.get( "/paymentarrangement/getArrangements/NM1" ).accept( MediaType.APPLICATION_JSON ) )
                    .andReturn();

        assertEquals( 200,
                      result.getResponse().getStatus() );
    }

    @Test
    public void testGetArrangementsFailure() throws Exception
    {

        MockHttpServletResponse result = mvc.perform( MockMvcRequestBuilders.get( "/getArrangements/NM1" )
                .contentType( MediaType.APPLICATION_JSON )
                .accept( MediaType.APPLICATION_JSON ) ).andReturn().getResponse();
        assertEquals( 404,
                      result.getStatus() );
    }

    @Test
    public void testGetArrangementByArrangementIdSuccess() throws Exception
    {

        MvcResult result =
            mvc.perform( MockMvcRequestBuilders.get( "/paymentarrangement/getArrangement/1" ).accept( MediaType.APPLICATION_JSON ) )
                    .andReturn();

        assertEquals( 200,
                      result.getResponse().getStatus() );
    }

    @Test
    public void testGetArrangementByArrangementIdFailure() throws Exception
    {

        MockHttpServletResponse result = mvc.perform( MockMvcRequestBuilders.get( "/getArrangement/1" )
                .contentType( MediaType.APPLICATION_JSON )
                .accept( MediaType.APPLICATION_JSON ) ).andReturn().getResponse();
        assertEquals( 404,
                      result.getStatus() );
    }

    @Test
    public void testValidateArrangementPayeeSuccess() throws Exception
    {
        ObjectMapper map = new ObjectMapper();
        String jsonReq = map.writeValueAsString( validateArrangementPayeeRequest() );
        MvcResult result = null;

        result = mvc
                .perform( MockMvcRequestBuilders.post( "/paymentarrangement/validateArrangementPayee" )
                        .content( jsonReq )
                        .contentType( MediaType.APPLICATION_JSON )
                        .accept( MediaType.APPLICATION_JSON ) )
                .andExpect( status().isOk() )
                .andReturn();

        assertEquals( 200,
                      result.getResponse().getStatus() );

    }

    @Test
    public void testValidateArrangementPayeeFailure() throws Exception
    {
        ObjectMapper map = new ObjectMapper();
        String jsonReq = map.writeValueAsString( validateArrangementPayeeRequest() );
        MockHttpServletResponse result = mvc
                .perform( MockMvcRequestBuilders.post( "/validateArrangementPayee" )
                        .content( jsonReq )
                        .contentType( MediaType.APPLICATION_JSON )
                        .accept( MediaType.APPLICATION_JSON ) )
                .andReturn()
                .getResponse();
        assertEquals( 404,
                      result.getStatus() );

    }

    @Test
    public void testgetRunArrangementsSuccess() throws Exception
    {
        ObjectMapper map = new ObjectMapper();
        String jsonReq = map.writeValueAsString( calculationRequestSaveRequest() );
        MvcResult result = null;

        result = mvc
                .perform( MockMvcRequestBuilders.post( "/paymentarrangement/getRunArrangements" )
                        .content( jsonReq )
                        .contentType( MediaType.APPLICATION_JSON )
                        .accept( MediaType.APPLICATION_JSON ) )
                .andExpect( status().isOk() )
                .andReturn();

        assertEquals( 200,
                      result.getResponse().getStatus() );

    }

    @Test
    public void testgetRunArrangementsFailure() throws Exception
    {
        ObjectMapper map = new ObjectMapper();
        String jsonReq = map.writeValueAsString( calculationRequestSaveRequest() );
        MockHttpServletResponse result = null;

        result = mvc
                .perform( MockMvcRequestBuilders.post( "/getRunArrangements" )
                        .content( jsonReq )
                        .contentType( MediaType.APPLICATION_JSON )
                        .accept( MediaType.APPLICATION_JSON ) )
                .andReturn()
                .getResponse();
        assertEquals( 404,
                      result.getStatus() );
    }

    @Test
    public void testValidateArrangementRateSuccess() throws Exception
    {
        ObjectMapper map = new ObjectMapper();
        String jsonReq = map.writeValueAsString( validateArrangementRateRequest() );
        MvcResult result = null;

        result = mvc
                .perform( MockMvcRequestBuilders.post( "/paymentarrangement/validateArrangementRate" )
                        .content( jsonReq )
                        .contentType( MediaType.APPLICATION_JSON )
                        .accept( MediaType.APPLICATION_JSON ) )
                .andExpect( status().isOk() )
                .andReturn();

        assertEquals( 200,
                      result.getResponse().getStatus() );

    }

    @Test
    public void testSearchPayeeSuccess() throws Exception
    {
        ObjectMapper map = new ObjectMapper();
        String jsonReq = map.writeValueAsString( getPayeeSearchRequest() );
        MvcResult result = mvc
                .perform( MockMvcRequestBuilders.post( "/paymentarrangement/searchPayee" )
                        .content( jsonReq )
                        .contentType( MediaType.APPLICATION_JSON )
                        .accept( MediaType.APPLICATION_JSON ) )
                .andExpect( status().isOk() )
                .andReturn();

        assertEquals( 200,
                      result.getResponse().getStatus() );

    }

    private PaymentArrangementSaveRequest paymentArrangementSaveRequest()
    {
        PaymentArrangementSaveRequest paymentArrangementSaveRequest = new PaymentArrangementSaveRequest();
        PaymentArrangementDTO arrangement = new PaymentArrangementDTO();
        arrangement.setArrangementFrequencyCode( "MONTHLY" );
        arrangement.setCorporateEntityCode( "NM1" );
        arrangement.setCreateUserId( "USER1" );
        arrangement.setUpdateUserId( "USER2" );
        arrangement.setRowAction( RowActionTypes.INSERT );
        arrangement.setPaymentTypeCode( "HMO" );
        arrangement.setPaymentArrangementDescription( "desc" );
        arrangement.setPaymentArrangementName( "PNAME" );
        paymentArrangementSaveRequest.setArrangement( arrangement );

        return paymentArrangementSaveRequest;
    }

    private ValidateArrangementPayeeRequest validateArrangementPayeeRequest()
    {
        ValidateArrangementPayeeRequest validateArrangementPayeeRequest = new ValidateArrangementPayeeRequest();
        PaymentArrangementPayeeDTO paymentArrangementPayeeDTO = new PaymentArrangementPayeeDTO();
        paymentArrangementPayeeDTO.setCreateUserId( "USER1" );
        paymentArrangementPayeeDTO.setUpdateUserId( "USER2" );
        paymentArrangementPayeeDTO.setPaymentArrangementId( 1 );
        paymentArrangementPayeeDTO.setRowAction( RowActionTypes.INSERT );
        paymentArrangementPayeeDTO.setRecordEffectiveDate( LocalDate.now().toString() );
        paymentArrangementPayeeDTO.setRecordEndDate( LocalDate.now().toString() );
        paymentArrangementPayeeDTO.setVbrPayee( getVbrPaye() );
        validateArrangementPayeeRequest.setValidateArrangementPayee( paymentArrangementPayeeDTO );
        return validateArrangementPayeeRequest;
    }

    private CalculationRequestSaveRequest calculationRequestSaveRequest()
    {
        CalculationRequestSaveRequest calculationRequestSaveRequest = new CalculationRequestSaveRequest();
        CalculationRequestDTO calculationRequestDTO = new CalculationRequestDTO();
        calculationRequestDTO.setCalculationRequestName( "CALCNAME" );
        calculationRequestDTO.setCreateUserId( "USER1" );
        calculationRequestDTO.setUpdateUserId( "USER2" );
        calculationRequestDTO.setRowAction( RowActionTypes.INSERT );
        calculationRequestSaveRequest.setCalculationRequestDTO( calculationRequestDTO );
        calculationRequestSaveRequest.setWarningState( true );
        return calculationRequestSaveRequest;
    }

    private VbrPayeeDTO getVbrPaye()
    {
        VbrPayeeDTO vbrPayee = new VbrPayeeDTO();
        vbrPayee.setCapitationCode( "CP" );
        vbrPayee.setCorporateEntityCode( "NM1" );
        vbrPayee.setCreateUserId( "USR1" );
        vbrPayee.setUpdateUserId( "USR2" );
        vbrPayee.setRecordEffectiveDate( "01/01/2019" );
        vbrPayee.setRecordEndDate( "12/31/2019" );
        return vbrPayee;

    }

    private ValidateArrangementRateRequest validateArrangementRateRequest()
    {
        ValidateArrangementRateRequest validateArrangementRateRequest = new ValidateArrangementRateRequest();
        validateArrangementRateRequest.setPaymentArrangementRate( getPaymentArrangementRates().get( 0 ) );
        ;
        return validateArrangementRateRequest;
    }

    private List<FlatRateDTO> getFlatRates()
    {
        List<FlatRateDTO> flatRateDTOs = new ArrayList<FlatRateDTO>();
        FlatRateDTO flatRateDTO = new FlatRateDTO();
        flatRateDTO.setCorporateEntityCode( "NM" );
        flatRateDTO.setFlatRateId( Integer.valueOf( 1 ) );
        flatRateDTO.setFemaleFlatRateAmount( 123.5 );
        flatRateDTO.setMaleFlatRateAmount( 124.5 );
        flatRateDTO.setRateName( "RATE1" );
        flatRateDTO.setRecordEffectiveDate( "01/01/2019" );
        flatRateDTO.setRecordEndDate( "12/31/2019" );
        flatRateDTOs.add( flatRateDTO );
        return flatRateDTOs;
    }

    private List<PaymentArrangementRateDTO> getPaymentArrangementRates()
    {
        List<PaymentArrangementRateDTO> paymentArrangementRateDTOs = new ArrayList<PaymentArrangementRateDTO>();
        PaymentArrangementRateDTO paymentArrangementRateDTO = new PaymentArrangementRateDTO();
        paymentArrangementRateDTO.setRecordEffectiveDate( "10/22/2019" );
        paymentArrangementRateDTO.setRecordEndDate( "10/23/2019" );
        paymentArrangementRateDTOs.add( paymentArrangementRateDTO );
        return paymentArrangementRateDTOs;
    }

    private PayeeSearchRequest getPayeeSearchRequest()
    {
        PayeeSearchRequest payeeSearchRequest = new PayeeSearchRequest();

        payeeSearchRequest.setCapitationTypeCode( "IL1" );
        payeeSearchRequest.setProcessCode( "CPC" );
        payeeSearchRequest.setCorpEntityCode( "IC1" );
        payeeSearchRequest.setNetworkAssociationID( 1 );
        payeeSearchRequest.setNetworkCode( "IN1" );
        payeeSearchRequest.setPayToPFIN( "1" );
        payeeSearchRequest.setPinGroupId( "1" );

        return payeeSearchRequest;

    }

}