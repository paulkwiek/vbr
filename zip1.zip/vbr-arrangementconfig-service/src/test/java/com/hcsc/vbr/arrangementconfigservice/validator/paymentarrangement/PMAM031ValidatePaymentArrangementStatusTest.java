package com.hcsc.vbr.arrangementconfigservice.validator.paymentarrangement;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import com.hcsc.vbr.arrangementconfigservice.domain.PaymentArrangement;
import com.hcsc.vbr.arrangementconfigservice.domain.PaymentArrangementMemberSubject;
import com.hcsc.vbr.arrangementconfigservice.domain.PaymentArrangementPayee;
import com.hcsc.vbr.arrangementconfigservice.domain.PaymentArrangementRate;
import com.hcsc.vbr.arrangementconfigservice.utils.ArrangementConfigServiceUtils;
import com.hcsc.vbr.common.dto.ErrorMessageDTO;
import com.hcsc.vbr.common.dto.ReturnMessageDTO;

@RunWith( MockitoJUnitRunner.Silent.class )
public class PMAM031ValidatePaymentArrangementStatusTest
{
    @InjectMocks
    private PMAM031ValidatePaymentArrangementStatus pmam031ValidatePaymentArrangementStatus;

    @Mock
    private ArrangementConfigServiceUtils arrangementConfigServiceUtils;

    @Test( expected = NullPointerException.class )
    public void checkValidationStatusCode_futurerateinvalid() throws Exception
    {
        pmam031ValidatePaymentArrangementStatus.checkValidationStatusCode( getPaymentArrangementDTO_futureinvalid(),
                                                                           Boolean.TRUE,
                                                                           Boolean.FALSE,
                                                                           getReturnMessageDTO() );
    }

    @Test( expected = NullPointerException.class )
    public void checkValidationStatusCode_futurepayeeinvalid() throws Exception
    {
        pmam031ValidatePaymentArrangementStatus.checkValidationStatusCode( getPaymentArrangementDTO_futureinvalid(),
                                                                           Boolean.FALSE,
                                                                           Boolean.TRUE,
                                                                           getReturnMessageDTO() );
    }

    @Test( expected = NullPointerException.class )
    public void checkValidationStatusCode_futureinvalid() throws Exception
    {
        pmam031ValidatePaymentArrangementStatus.checkValidationStatusCode( getPaymentArrangementDTO_futureinvalid(),
                                                                           Boolean.FALSE,
                                                                           Boolean.FALSE,
                                                                           getReturnMessageDTO() );
    }

    @Test( expected = NullPointerException.class )
    public void checkValidationStatusCode_rateinvalid() throws Exception
    {
        pmam031ValidatePaymentArrangementStatus.checkValidationStatusCode( getPaymentArrangementDTO_invalid(),
                                                                           Boolean.TRUE,
                                                                           Boolean.FALSE,
                                                                           getReturnMessageDTO() );
    }

    @Test( expected = NullPointerException.class )
    public void checkValidationStatusCode_payeeinvalid() throws Exception
    {
        pmam031ValidatePaymentArrangementStatus.checkValidationStatusCode( getPaymentArrangementDTO_invalid(),
                                                                           Boolean.FALSE,
                                                                           Boolean.TRUE,
                                                                           getReturnMessageDTO() );
    }

    @Test( expected = NullPointerException.class )
    public void checkValidationStatusCode_invalid() throws Exception
    {
        pmam031ValidatePaymentArrangementStatus.checkValidationStatusCode( getPaymentArrangementDTO_invalid(),
                                                                           Boolean.FALSE,
                                                                           Boolean.FALSE,
                                                                           getReturnMessageDTO() );
    }

    @Test( expected = NullPointerException.class )
    public void checkValidationStatusCode_draft() throws Exception
    {
        pmam031ValidatePaymentArrangementStatus.checkValidationStatusCode( getPaymentArrangementDTO_draft(),
                                                                           Boolean.TRUE,
                                                                           Boolean.TRUE,
                                                                           getReturnMessageDTO() );
    }

    @Test( expected = NullPointerException.class )
    public void checkValidationStatusCode_expired() throws Exception
    {
        pmam031ValidatePaymentArrangementStatus.checkValidationStatusCode( getPaymentArrangementDTO_expired(),
                                                                           Boolean.TRUE,
                                                                           Boolean.TRUE,
                                                                           getReturnMessageDTO() );
    }

    @Test( expected = NullPointerException.class )
    public void checkValidationStatusCode_warning() throws Exception
    {
        pmam031ValidatePaymentArrangementStatus.checkValidationStatusCode( getPaymentArrangementDTO_warning(),
                                                                           Boolean.TRUE,
                                                                           Boolean.TRUE,
                                                                           getReturnMessageDTO() );
    }

    private PaymentArrangement getPaymentArrangementDTO_futureinvalid()
    {
        PaymentArrangement paymentArrangementDTO = new PaymentArrangement();
        paymentArrangementDTO.setOverwriteSaveArrangement( "false" );
        paymentArrangementDTO.setValidationStatusCode( "FI" );
        paymentArrangementDTO.setRecordEffectiveDate( LocalDate.of( 2021,
                                                                    12,
                                                                    1 ) );
        paymentArrangementDTO.setRecordEndDate( LocalDate.of( 2021,
                                                              12,
                                                              31 ) );
        paymentArrangementDTO.setPaymentArrangementMemberSubjects( getPaymentArrangementMemberSubjectDTO() );
        paymentArrangementDTO.setPaymentArrangementPayees( getPaymentArrangementPayeesDTO() );
        paymentArrangementDTO.setPaymentArrangementRates( getPaymentArrangementRatesDTO() );
        return paymentArrangementDTO;
    }

    private PaymentArrangement getPaymentArrangementDTO_invalid()
    {
        PaymentArrangement paymentArrangementDTO = new PaymentArrangement();
        paymentArrangementDTO.setOverwriteSaveArrangement( "false" );
        paymentArrangementDTO.setValidationStatusCode( "IV" );
        paymentArrangementDTO.setRecordEffectiveDate( LocalDate.of( 2021,
                                                                    12,
                                                                    1 ) );
        paymentArrangementDTO.setRecordEndDate( LocalDate.of( 2021,
                                                              12,
                                                              31 ) );
        paymentArrangementDTO.setPaymentArrangementMemberSubjects( getPaymentArrangementMemberSubjectDTO() );
        paymentArrangementDTO.setPaymentArrangementPayees( getPaymentArrangementPayeesDTO() );
        paymentArrangementDTO.setPaymentArrangementRates( getPaymentArrangementRatesDTO() );
        return paymentArrangementDTO;
    }

    private PaymentArrangement getPaymentArrangementDTO_expired()
    {
        PaymentArrangement paymentArrangementDTO = new PaymentArrangement();
        paymentArrangementDTO.setOverwriteSaveArrangement( "false" );
        paymentArrangementDTO.setValidationStatusCode( "EX" );
        paymentArrangementDTO.setRecordEffectiveDate( LocalDate.of( 2017,
                                                                    12,
                                                                    1 ) );
        paymentArrangementDTO.setRecordEndDate( LocalDate.of( 2017,
                                                              12,
                                                              31 ) );
        paymentArrangementDTO.setPaymentArrangementMemberSubjects( getPaymentArrangementMemberSubjectDTO() );
        paymentArrangementDTO.setPaymentArrangementPayees( getPaymentArrangementPayeesDTO() );
        paymentArrangementDTO.setPaymentArrangementRates( getPaymentArrangementRatesDTO() );
        return paymentArrangementDTO;
    }

    private PaymentArrangement getPaymentArrangementDTO_warning()
    {
        PaymentArrangement paymentArrangementDTO = new PaymentArrangement();
        paymentArrangementDTO.setOverwriteSaveArrangement( "false" );
        paymentArrangementDTO.setValidationStatusCode( "WA" );
        paymentArrangementDTO.setRecordEffectiveDate( LocalDate.of( 2017,
                                                                    12,
                                                                    1 ) );
        paymentArrangementDTO.setRecordEndDate( LocalDate.of( 2017,
                                                              12,
                                                              31 ) );
        paymentArrangementDTO.setPaymentArrangementMemberSubjects( getPaymentArrangementMemberSubjectDTO() );
        paymentArrangementDTO.setPaymentArrangementPayees( getPaymentArrangementPayeesDTO() );
        paymentArrangementDTO.setPaymentArrangementRates( getPaymentArrangementRatesDTO() );
        return paymentArrangementDTO;
    }

    private PaymentArrangement getPaymentArrangementDTO_draft()
    {
        PaymentArrangement paymentArrangementDTO = new PaymentArrangement();
        paymentArrangementDTO.setOverwriteSaveArrangement( "false" );
        paymentArrangementDTO.setValidationStatusCode( "DF" );
        paymentArrangementDTO.setRecordEffectiveDate( LocalDate.of( 2020,
                                                                    12,
                                                                    1 ) );
        paymentArrangementDTO.setRecordEndDate( LocalDate.of( 2020,
                                                              12,
                                                              31 ) );
        paymentArrangementDTO.setPaymentArrangementMemberSubjects( null );
        paymentArrangementDTO.setPaymentArrangementPayees( null );
        paymentArrangementDTO.setPaymentArrangementRates( null );
        return paymentArrangementDTO;
    }

    private List<ErrorMessageDTO> getErrorMessageDTOSuccess() throws Exception
    {
        List<ErrorMessageDTO> errors = new ArrayList<ErrorMessageDTO>();
        ErrorMessageDTO errorMessageDTO = new ErrorMessageDTO();

        errorMessageDTO.setErrorMessageCategoryCode( "PCF-PMAM" );
        errorMessageDTO.setErrorMessageId( new Long( 226 ) );
        errorMessageDTO.setErrorMsgDescriptionText( "Payment Type Is Required" );
        errorMessageDTO.setSeveritylevel( "E" );
        errors.add( errorMessageDTO );
        return errors;

    }

    private ReturnMessageDTO getReturnMessageDTO() throws Exception
    {
        ReturnMessageDTO returnMessage = new ReturnMessageDTO();

        returnMessage.setItemName( "PCF-PMAM" );
        returnMessage.setStatus( "SUCCESS" );
        returnMessage.setErrors( getErrorMessageDTOSuccess() );
        return returnMessage;

    }

    private List<PaymentArrangementMemberSubject> getPaymentArrangementMemberSubjectDTO()
    {
        List<PaymentArrangementMemberSubject> paymentArrangementMemberSubjectsDTO = new ArrayList<PaymentArrangementMemberSubject>();
        PaymentArrangementMemberSubject paymentArrangementMemberSubjectDTO = new PaymentArrangementMemberSubject();
        paymentArrangementMemberSubjectsDTO.add( paymentArrangementMemberSubjectDTO );
        return paymentArrangementMemberSubjectsDTO;
    }

    private List<PaymentArrangementPayee> getPaymentArrangementPayeesDTO()
    {
        List<PaymentArrangementPayee> paymentArrangementPayeesDTO = new ArrayList<PaymentArrangementPayee>();
        PaymentArrangementPayee paymentArrangementPayeeDTO = new PaymentArrangementPayee();
        paymentArrangementPayeesDTO.add( paymentArrangementPayeeDTO );
        return paymentArrangementPayeesDTO;
    }

    private List<PaymentArrangementRate> getPaymentArrangementRatesDTO()
    {
        List<PaymentArrangementRate> paymentArrangementRatesDTO = new ArrayList<PaymentArrangementRate>();
        PaymentArrangementRate paymentArrangementRateDTO = new PaymentArrangementRate();
        paymentArrangementRatesDTO.add( paymentArrangementRateDTO );
        return paymentArrangementRatesDTO;
    }

}
