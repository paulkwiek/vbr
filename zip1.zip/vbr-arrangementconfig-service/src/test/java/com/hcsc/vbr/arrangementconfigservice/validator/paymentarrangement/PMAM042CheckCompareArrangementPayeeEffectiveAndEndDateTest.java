package com.hcsc.vbr.arrangementconfigservice.validator.paymentarrangement;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.json.JacksonTester;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.hcsc.vbr.arrangementconfigservice.domain.PaymentArrangementPayee;
import com.hcsc.vbr.common.constant.VBRCommonConstant.RowActionTypes;
import com.hcsc.vbr.common.dto.ErrorMessageDTO;
import com.hcsc.vbr.common.dto.ReturnMessageDTO;
import com.hcsc.vbr.common.utils.VBRDateUtils;

public class PMAM042CheckCompareArrangementPayeeEffectiveAndEndDateTest
{
    @InjectMocks
    PMAM042CheckCompareArrangementPayeeEffectiveAndEndDate pmam042CheckCompareArrangementPayeeEffectiveAndEndDate;

    @Mock
    private VBRDateUtils vbrDateUtils;

    @Before
    public void setUp()
    {
        MockitoAnnotations.initMocks( this );
        JacksonTester.initFields( this,
                                  new ObjectMapper() );

    }

    @Test
    public void compareArrangementPayeeEffectiveAndEndDateSuccess() throws Exception
    {

        pmam042CheckCompareArrangementPayeeEffectiveAndEndDate
                .compareArrangementPayeeEffectiveAndEndDate( getPaymentArrangementPayees_success(),
                                                             getReturnMessageDTO() );
    }

    @Test( expected = NullPointerException.class )
    public void compareArrangementPayeeEffectiveAndEndDateFail() throws Exception
    {

        pmam042CheckCompareArrangementPayeeEffectiveAndEndDate
                .compareArrangementPayeeEffectiveAndEndDate( getPaymentArrangementPayees_fail(),
                                                             getReturnMessageDTO() );
    }

    private List<ErrorMessageDTO> getErrorMessageDTOSuccess() throws Exception
    {
        List<ErrorMessageDTO> errors = new ArrayList<ErrorMessageDTO>();
        ErrorMessageDTO errorMessageDTO = new ErrorMessageDTO();

        errorMessageDTO.setErrorMessageCategoryCode( "PCF-PMAM" );
        errorMessageDTO.setErrorMessageId( new Long( 226 ) );
        errorMessageDTO.setErrorMsgDescriptionText( "Payment Type Is Required" );
        errorMessageDTO.setSeveritylevel( "E" );
        errors.add( errorMessageDTO );
        return errors;

    }

    private ReturnMessageDTO getReturnMessageDTO() throws Exception
    {
        ReturnMessageDTO returnMessage = new ReturnMessageDTO();

        returnMessage.setItemName( "PCF-PMAM" );
        returnMessage.setStatus( "SUCCESS" );
        returnMessage.setErrors( getErrorMessageDTOSuccess() );
        return returnMessage;

    }

    private PaymentArrangementPayee getPaymentArrangementPayees_success()
    {
        PaymentArrangementPayee paymentArrangementPayeeDTO = new PaymentArrangementPayee();
        paymentArrangementPayeeDTO.setRecordEffectiveDate( LocalDate.of( 2019,
                                                                         12,
                                                                         1 ) );
        paymentArrangementPayeeDTO.setRecordEndDate( LocalDate.of( 2019,
                                                                   12,
                                                                   31 ) );
        paymentArrangementPayeeDTO.setCreateUserId( "U402537" );
        paymentArrangementPayeeDTO.setUpdateUserId( "U402537" );
        paymentArrangementPayeeDTO.setRowAction( RowActionTypes.NO_ACTION );
        paymentArrangementPayeeDTO.setPaymentArrangementId( null );
        return paymentArrangementPayeeDTO;
    }

    private PaymentArrangementPayee getPaymentArrangementPayees_fail()
    {
        PaymentArrangementPayee paymentArrangementPayeeDTO = new PaymentArrangementPayee();
        paymentArrangementPayeeDTO.setRecordEffectiveDate( LocalDate.of( 2019,
                                                                         12,
                                                                         31 ) );
        paymentArrangementPayeeDTO.setRecordEndDate( LocalDate.of( 2019,
                                                                   12,
                                                                   1 ) );
        paymentArrangementPayeeDTO.setCreateUserId( "U402537" );
        paymentArrangementPayeeDTO.setUpdateUserId( "U402537" );
        paymentArrangementPayeeDTO.setRowAction( RowActionTypes.NO_ACTION );
        paymentArrangementPayeeDTO.setPaymentArrangementId( null );
        return paymentArrangementPayeeDTO;
    }

}
