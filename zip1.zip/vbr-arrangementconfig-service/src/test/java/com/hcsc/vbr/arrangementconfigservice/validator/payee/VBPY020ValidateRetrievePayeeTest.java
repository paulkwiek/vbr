package com.hcsc.vbr.arrangementconfigservice.validator.payee;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnitRunner;

import com.hcsc.vbr.common.dto.ReturnMessageDTO;
import com.hcsc.vbr.web.request.PayeeSearchRequest;

@RunWith( MockitoJUnitRunner.Silent.class )
public class VBPY020ValidateRetrievePayeeTest
{

    @InjectMocks
    private VBPY020ValidateRetrievePayee vbpy020ValidateRetrievePayee;

    @Test
    public void validatePinGroupId() throws Exception
    {

        vbpy020ValidateRetrievePayee.validatePinGroupId( getPayeeRetrieveRequest(),
                                                         getReturnMessageDTO() );
    }

    @Test( expected = NullPointerException.class )
    public void validatePinGroupId_Failure() throws Exception
    {

        vbpy020ValidateRetrievePayee.validatePinGroupId( getPayeeRetrieveRequest_Failure(),
                                                         getReturnMessageDTO() );
    }

    @Test( expected = NullPointerException.class )
    public void validatePinGroupId_Null() throws Exception
    {

        vbpy020ValidateRetrievePayee.validatePinGroupId( getPayeeRetrieveRequest_Null(),
                                                         getReturnMessageDTO() );
    }

    private PayeeSearchRequest getPayeeRetrieveRequest()
    {
        PayeeSearchRequest payeeSearchRequest = new PayeeSearchRequest();

        payeeSearchRequest.setPinGroupId( "RE1" );

        return payeeSearchRequest;
    }

    private PayeeSearchRequest getPayeeRetrieveRequest_Null()
    {
        PayeeSearchRequest payeeSearchRequest = new PayeeSearchRequest();

        payeeSearchRequest.setPinGroupId( "" );

        return payeeSearchRequest;
    }

    private PayeeSearchRequest getPayeeRetrieveRequest_Failure()
    {
        PayeeSearchRequest payeeSearchRequest = new PayeeSearchRequest();

        payeeSearchRequest.setPinGroupId( "hsdhjsdjdhbcjdbcdcb jdbh jhdbcjhdbcjdbh" );

        return payeeSearchRequest;
    }

    private ReturnMessageDTO getReturnMessageDTO()
    {
        ReturnMessageDTO returnMessage = new ReturnMessageDTO();
        return returnMessage;
    }

}
