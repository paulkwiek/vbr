package com.hcsc.vbr.arrangementconfigservice.validator.ratename;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnitRunner;

import com.hcsc.vbr.common.dto.ReturnMessageDTO;
import com.hcsc.vbr.web.response.PaymentArrangementListResponse;

@RunWith( MockitoJUnitRunner.Silent.class )
public class RTNM013CheckNoRecordsFoundForlinkedArrangementsTest
{

    @InjectMocks
    private RTNM013CheckNoRecordsFoundForlinkedArrangements rtnm013CheckNoRecordsFoundForlinkedArrangements;

    @Test( expected = NullPointerException.class )
    public void isRecordsFound() throws Exception
    {

        rtnm013CheckNoRecordsFoundForlinkedArrangements.isRecordsFound( linkedArrangementResponseList(),
                                                                        getReturnMessageDTO() );
    }

    @Test( expected = NullPointerException.class )
    public void isRecordsFound_Failure() throws Exception
    {

        rtnm013CheckNoRecordsFoundForlinkedArrangements.isRecordsFound( linkedArrangementResponseList_Empty(),
                                                                        getReturnMessageDTO() );
    }

    private List<PaymentArrangementListResponse> linkedArrangementResponseList()
    {
        List<PaymentArrangementListResponse> list = new ArrayList<PaymentArrangementListResponse>();
        PaymentArrangementListResponse response = new PaymentArrangementListResponse();
        response.setPaymentArrangementId( 123 );
        return list;
    }

    private List<PaymentArrangementListResponse> linkedArrangementResponseList_Empty()
    {
        List<PaymentArrangementListResponse> list = new ArrayList<PaymentArrangementListResponse>();
        list.removeAll( list );
        return list;
    }

    private ReturnMessageDTO getReturnMessageDTO()
    {
        ReturnMessageDTO returnMessage = new ReturnMessageDTO();
        return returnMessage;
    }
}
