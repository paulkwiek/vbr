package com.hcsc.vbr.calculationservice.enums;

public class CalculationRequestStatusEnums
{
    public enum Insert
    {

     CRSU,
     CRIP,
     CRVP,
     CRVC,
     CRVD,
     CRCS,
     CRCF,
     CRFL,
     CASU,
     CAIP,
     CAFL,
     CAAP;

    }

    public enum Inprogress
    {
     CRSU,
     CRIP,
     CRVP,
     CRVC,
     CASU,
     CAIP;
    }

    public enum Completed
    {

     CRCS,
     CRCF,
     CRFL,
     CAFL;

    }
}
