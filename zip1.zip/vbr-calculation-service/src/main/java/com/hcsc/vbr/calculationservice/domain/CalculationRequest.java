package com.hcsc.vbr.calculationservice.domain;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.validation.constraints.NotNull;

import org.hibernate.annotations.NotFound;
import org.hibernate.annotations.NotFoundAction;

import com.hcsc.vbr.common.domain.BaseEntity;

import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
@Table( name = "CALCTN_REQ" )
public class CalculationRequest extends BaseEntity
{

    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue( strategy = GenerationType.SEQUENCE, generator = "CALCTN_REQ_SQ_GENERATOR" )
    @SequenceGenerator( name = "CALCTN_REQ_SQ_GENERATOR", sequenceName = "CALCTN_REQ_SQ", allocationSize = 1 )
    @Column( name = "CALCTN_REQ_ID" )
    private Integer calculationRequestId;

    @NotNull
    @Column( name = "CALCTN_RUN_NM", length = 20 )
    private String calculationRunName;

    @NotNull
    @Column( name = "CORP_ENT_CD", length = 3 )
    private String corporateEntityCode;

    @NotNull
    @Column( name = "PROC_PRD_DT" )
    private LocalDate processPeriodDate;

    @NotNull
    @Column( name = "REQ_SBMTD_TS" )
    private LocalDateTime requestSubmittedTimestamp;

    @NotNull
    @Column( name = "REQ_SBMTD_USR_ID", length = 8 )
    private String requestSubmittedUserId;

    @NotNull
    @Column( name = "CALCTN_REQ_STA_CD", length = 20 )
    private String calculationRequestStatusCode;

    @Transient
    private String overwriteCompletedResult;

    @Transient
    private String overwriteApprovedResult;

    @Transient
    private String operationApproveResult;

    @ManyToOne( fetch = FetchType.LAZY )
    @NotFound( action = NotFoundAction.IGNORE )
    @JoinColumns( {
        @JoinColumn( name = "CALCTN_RUN_NM", insertable = false, updatable = false, referencedColumnName = "CALCTN_RUN_NM" ),
        @JoinColumn( name = "CORP_ENT_CD", insertable = false, updatable = false, referencedColumnName = "CORP_ENT_CD" ) } )
    private CalculationRunName parentCalculationRunName;

    @OneToMany( fetch = FetchType.LAZY, mappedBy = "parentCalculationRequest" )
    private List<CalculationRequestHistory> calculationReqiestHistory = new ArrayList<CalculationRequestHistory>();

    @OneToMany( fetch = FetchType.LAZY, mappedBy = "parentCalculationRequest" )
    private List<CalculationErrorLog> calculationErrorLog = new ArrayList<CalculationErrorLog>();

    @OneToMany( fetch = FetchType.LAZY, mappedBy = "parentCalculationRequest" )
    private List<CalculationMemberDetail> calculationMemberDetailList = new ArrayList<CalculationMemberDetail>();

    @OneToMany( fetch = FetchType.LAZY, mappedBy = "parentCalculationRequest" )
    private List<ApprovedCalculationMemberDetail> approvedCalculationMemberDetailList =
        new ArrayList<ApprovedCalculationMemberDetail>();

    @OneToMany( fetch = FetchType.LAZY, mappedBy = "parentCalculationRequest" )
    private List<CalculationRequestGrouping> calculationRequestGrouping = new ArrayList<CalculationRequestGrouping>();

    @OneToMany( fetch = FetchType.LAZY, mappedBy = "parentCalculationRequest" )
    private List<CalculationArrangements> calculationArrangements = new ArrayList<CalculationArrangements>();

}
