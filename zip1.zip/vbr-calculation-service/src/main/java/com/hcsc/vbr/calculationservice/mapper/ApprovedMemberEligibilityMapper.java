package com.hcsc.vbr.calculationservice.mapper;

import java.util.List;

import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import com.hcsc.vbr.calculationservice.domain.ApprovedMemberEligibility;
import com.hcsc.vbr.calculationservice.dto.ApprovedMemberEligibilityDTO;

@Mapper( componentModel = "spring" )
public interface ApprovedMemberEligibilityMapper
{
    ApprovedMemberEligibilityMapper INSTANCE = Mappers.getMapper( ApprovedMemberEligibilityMapper.class );

    /**
     * Method: toApprovedMemberEligibilityDetailDTO
     * @param approvedMemberEligibilityDetail
     * @return
     */
    public ApprovedMemberEligibilityDTO toApprovedMemberEligibilityDTO( ApprovedMemberEligibility approvedMemberEligibility );

    /**
     * Method: toApprovedMemberEligibilityDTOs
     * @param approvedMemberEligibilityList
     * @return
     */
    public List<ApprovedMemberEligibilityDTO> toApprovedMemberEligibilityDTOs(
            List<ApprovedMemberEligibility> approvedMemberEligibilityList );

    /**
     * Method: toApprovedMemberEligibility
     * @param approvedMemberEligibilityDTO
     * @return
     */
    public ApprovedMemberEligibility toApprovedMemberEligibility( ApprovedMemberEligibilityDTO approvedMemberEligibilityDTO );

    /**
     * Method: toApprovedMemberEligibilityList
     * @param approvedMemberEligibilityDTOs
     * @return
     */
    public List<ApprovedMemberEligibility> toApprovedMemberEligibilityList(
            List<ApprovedMemberEligibilityDTO> approvedMemberEligibilityDTOs );
}
