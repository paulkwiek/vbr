package com.hcsc.vbr.calculationservice.mapper;

import java.util.List;

import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import com.hcsc.vbr.calculationservice.domain.CalculationErrorLog;
import com.hcsc.vbr.calculationservice.dto.CalculationErrorLogDTO;

@Mapper( componentModel = "spring" )
public interface CalculationErrorLogMapper
{
    CalculationErrorLogMapper INSTANCE = Mappers.getMapper( CalculationErrorLogMapper.class );

    /**
     * Method: toCalculationErrorLogDTO
     * @param calculationErrorLog
     * @return
     */
    public CalculationErrorLogDTO toCalculationErrorLogDTO( CalculationErrorLog calculationErrorLog );

    /**
     * Method: toCalculationErrorLogDTOs
     * @param calculationErrorLogs
     * @return
     */
    public List<CalculationErrorLogDTO> toCalculationErrorLogDTOs( List<CalculationErrorLog> calculationErrorLogs );

    /**
     * Method: toCalculationErrorLog
     * @param calculationErrorLogDTO
     * @return
     */
    public CalculationErrorLog toCalculationErrorLog( CalculationErrorLogDTO calculationErrorLogDTO );

    /**
     * Method: toCalculationErrorLogs
     * @param calculationErrorLogDTOs
     * @return
     */
    public List<CalculationErrorLog> toCalculationErrorLogs( List<CalculationErrorLogDTO> calculationErrorLogDTOs );

}
