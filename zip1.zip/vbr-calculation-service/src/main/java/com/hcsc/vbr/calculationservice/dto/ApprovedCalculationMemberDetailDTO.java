package com.hcsc.vbr.calculationservice.dto;

import java.util.ArrayList;
import java.util.List;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ApprovedCalculationMemberDetailDTO extends CalculationMemberDetailRecordDTO
{

    private static final long serialVersionUID = 1L;

    private Integer approvedCalculationMemberDetailId;

    private Integer approvedMemberEligibilityId;

    private CalculationRequestDTO parentCalculationRequest;

    private MemberEligibilityDTO parentMemberEligibility;

    private List<FinancePaymentDetailApprovedCalculationMemberDetailReferenceDTO> financePaymentDetailApprovedCalculationMemberDetailReferenceList =
        new ArrayList<FinancePaymentDetailApprovedCalculationMemberDetailReferenceDTO>();

}
