package com.hcsc.vbr.calculationservice.dto;

import java.io.Serializable;
import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CalculationApprovalStatusDTO implements Serializable
{

    private static final long serialVersionUID = 1L;

    private String statusDescription;

    private String approvedBy;

    @JsonFormat( shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss.SSS" )
    //    @DateTimeFormat( iso = ISO.DATE_TIME )
    private LocalDateTime approvedTime;

    private Boolean isOpenForApproval;

}
