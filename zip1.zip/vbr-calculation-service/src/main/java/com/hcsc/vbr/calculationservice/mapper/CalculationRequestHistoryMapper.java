package com.hcsc.vbr.calculationservice.mapper;

import java.util.List;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import com.hcsc.vbr.calculationservice.domain.CalculationRequestHistory;
import com.hcsc.vbr.calculationservice.dto.CalculationRequestDTO;
import com.hcsc.vbr.calculationservice.dto.CalculationRequestHistoryDTO;

@Mapper( componentModel = "spring" )
public interface CalculationRequestHistoryMapper
{
    CalculationRequestHistoryMapper INSTANCE = Mappers.getMapper( CalculationRequestHistoryMapper.class );

    /**
     * Method: toCalculationRequestHistoryDTO
     * @param calculationRequestHistory
     * @return
     */
    public CalculationRequestHistoryDTO toCalculationRequestHistoryDTO( CalculationRequestHistory calculationRequestHistory );

    /**
     * Method: toCalculationRequestHistoryDTOs
     * @param calculationRequestHistory
     * @return
     */
    public List<CalculationRequestHistoryDTO> toCalculationRequestHistoryDTOs(
            List<CalculationRequestHistory> calculationRequestHistory );

    /**
     * Method: toCalculationRequestHistory
     * @param calculationRequestHistoryDTO
     * @return
     */
    public CalculationRequestHistory toCalculationRequestHistory( CalculationRequestHistoryDTO calculationRequestHistoryDTO );

    /**
     * Method: toCalculationRequestHistory
     * @param calculationRequestHistoryDTOs
     * @return
     */
    public List<CalculationRequestHistory> toCalculationRequestHistoryList(
            List<CalculationRequestHistoryDTO> calculationRequestHistoryDTOs );

    /**
     * Method: toCalculationRequestHistory
     * @param calculationRequestDTO
     * @return
     */

    @Mapping( target = "calculationRequestHistoryStatusCode", source = "calculationRequestStatusCode" )
    public CalculationRequestHistory toCalculationRequestHistory( CalculationRequestDTO calculationRequestDTO );
}
