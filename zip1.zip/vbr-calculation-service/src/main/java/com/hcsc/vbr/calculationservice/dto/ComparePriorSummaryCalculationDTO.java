package com.hcsc.vbr.calculationservice.dto;

import java.io.Serializable;

import org.apache.commons.lang3.builder.ReflectionToStringBuilder;

import com.hcsc.vbr.common.utils.MultilineRecursiveToStringStyleCustom;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class ComparePriorSummaryCalculationDTO implements Serializable
{

    private static final long serialVersionUID = 1L;

    private Integer currentMembers = 0;

    private Integer retroMembers = 0;

    private Double currentReimbursementAmount = 0.0;

    private Double retroReimbursementAmount = 0.0;

    private Double totalReimbursementAmount = 0.0;

    private String calculationReviewMonth;

    @Override
    public String toString()
    {
        return new ReflectionToStringBuilder( this,
                                              new MultilineRecursiveToStringStyleCustom() ).toString();
    }
}
