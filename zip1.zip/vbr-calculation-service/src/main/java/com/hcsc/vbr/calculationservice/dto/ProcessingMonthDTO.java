package com.hcsc.vbr.calculationservice.dto;

import java.time.LocalDate;

import com.hcsc.vbr.common.dto.BaseEntityDTO;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ProcessingMonthDTO extends BaseEntityDTO
{

    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    private LocalDate processPeriodDate;

    private String corporateEntityCode;

    private String monthEndProcessStatusCode;

}
