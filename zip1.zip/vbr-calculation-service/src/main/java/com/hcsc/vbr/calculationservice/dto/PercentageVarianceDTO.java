package com.hcsc.vbr.calculationservice.dto;

import java.io.Serializable;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class PercentageVarianceDTO implements Serializable
{
    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    private Double currentMembersVariance = 0.0;

    private Double retroMembersVariance = 0.0;

    private Double currentReimbursementAmountVariance = 0.0;

    private Double retroReimbursementAmountVariance = 0.0;

    private Double totalReimbursementAmountVariance = 0.0;
}
