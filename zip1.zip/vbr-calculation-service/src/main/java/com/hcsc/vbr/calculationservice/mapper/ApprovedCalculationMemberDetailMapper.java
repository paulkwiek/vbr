package com.hcsc.vbr.calculationservice.mapper;

import java.util.List;

import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import com.hcsc.vbr.calculationservice.domain.ApprovedCalculationMemberDetail;
import com.hcsc.vbr.calculationservice.dto.ApprovedCalculationMemberDetailDTO;

@Mapper( componentModel = "spring" )
public interface ApprovedCalculationMemberDetailMapper
{
    ApprovedCalculationMemberDetailMapper INSTANCE = Mappers.getMapper( ApprovedCalculationMemberDetailMapper.class );

    /**
     * Method: toApprovedCalculationMemberDetailDTO
     * @param approvedCalculationMemberDetail
     * @return
     */
    public ApprovedCalculationMemberDetailDTO toApprovedCalculationMemberDetailDTO(
            ApprovedCalculationMemberDetail approvedCalculationMemberDetail );

    /**
     * Method: toApprovedCalculationMemberDetailDTOs
     * @param approvedCalculationMemberDetails
     * @return
     */
    public List<ApprovedCalculationMemberDetailDTO> toApprovedCalculationMemberDetailDTOs(
            List<ApprovedCalculationMemberDetail> approvedCalculationMemberDetails );

    /**
     * Method: toApprovedCalculationMemberDetail
     * @param approvedCalculationMemberDetailDTO
     * @return
     */
    public ApprovedCalculationMemberDetail toApprovedCalculationMemberDetail(
            ApprovedCalculationMemberDetailDTO approvedCalculationMemberDetailDTO );

    /**
     * Method: toApprovedCalculationMemberDetails
     * @param approvedCalculationMemberDetailDTOs
     * @return
     */
    public List<ApprovedCalculationMemberDetail> toApprovedCalculationMemberDetails(
            List<ApprovedCalculationMemberDetailDTO> approvedCalculationMemberDetailDTOs );
}
