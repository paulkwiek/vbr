package com.hcsc.vbr.calculationservice.config;

import java.util.Properties;

import javax.sql.DataSource;

import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

@Configuration
@EnableCaching
@EnableTransactionManagement
@EnableJpaRepositories( basePackages = {
    "com.hcsc.vbr.utility.repository",
    "com.hcsc.vbr.calculationservice.repository" }, entityManagerFactoryRef = "vbrEntityManagerFactory", transactionManagerRef = "vbrTransactionManager" )
@EntityScan( { "com.hcsc.vbr.common.domain", "com.hcsc.vbr.calculationservice.domain" } )
public class VbrCalculationServiceConfig
{
    /**
     * Method: dataSource
     * @return
     */
    @Bean
    @ConfigurationProperties( prefix = "spring.datasource" )
    public DataSource dataSource()
    {
        DataSource ds = DataSourceBuilder.create().build();
        return ds;
    }

    /**
     * Method: pediEntityManager
     * @return
     */
    @Bean( name = "vbrEntityManagerFactory" )
    public LocalContainerEntityManagerFactoryBean vbrEntityManager()
    {
        LocalContainerEntityManagerFactoryBean em = new LocalContainerEntityManagerFactoryBean();
        em.setDataSource( dataSource() );
        em.setPackagesToScan( new String[] { "com.hcsc.vbr.common.domain", "com.hcsc.vbr.calculationservice.domain" } );

        HibernateJpaVendorAdapter vendorAdapter = new HibernateJpaVendorAdapter();
        em.setJpaVendorAdapter( vendorAdapter );
        em.setJpaProperties( additionalJpaProperties() );
        return em;
    }

    /**
     * Method: additionalJpaProperties
     * @return
     */
    private Properties additionalJpaProperties()
    {
        Properties properties = new Properties();
        properties.setProperty( "hibernate.dialect",
                                "org.hibernate.dialect.DB2Dialect" );
        properties.setProperty( "hibernate.show_sql",
                                "true" );
        return properties;
    }

    /**
     * Method: vbrTransactionManager
     * @return
     */
    @Bean( name = "vbrTransactionManager" )
    public PlatformTransactionManager vbrTransactionManager()
    {

        JpaTransactionManager transactionManager = new JpaTransactionManager();
        transactionManager.setEntityManagerFactory( vbrEntityManager().getObject() );
        return transactionManager;
    }

}
