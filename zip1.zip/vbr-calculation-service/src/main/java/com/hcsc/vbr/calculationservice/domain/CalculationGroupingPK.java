package com.hcsc.vbr.calculationservice.domain;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.validation.constraints.NotNull;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Embeddable
public class CalculationGroupingPK implements Serializable
{

    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    @NotNull
    @Column( name = "CALCTN_GRPG_LVL_CD", length = 20 )
    private String calculationGroupingLevelCode;

    @NotNull
    @Column( name = "CALCTN_RUN_NM", length = 20 )
    private String calculationRunName;

    @NotNull
    @Column( name = "CORP_ENT_CD", length = 3 )
    private String corporateEntityCode;

    @NotNull
    @Column( name = "CALCTN_GRPG_LVL_VAL_TXT", length = 50 )
    private String calculationGroupingLevelValueText;

}
