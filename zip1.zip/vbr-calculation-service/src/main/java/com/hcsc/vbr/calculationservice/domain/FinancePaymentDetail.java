package com.hcsc.vbr.calculationservice.domain;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import com.hcsc.vbr.common.domain.BaseEntity;

import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
@Table( name = "FINCL_PMT_DETL" )
public class FinancePaymentDetail extends BaseEntity
{

    /**
     * 
     */

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue( strategy = GenerationType.SEQUENCE, generator = "FINCL_PMT_DETL_SQ_GENERATOR" )
    @SequenceGenerator( name = "FINCL_PMT_DETL_SQ_GENERATOR", sequenceName = "FINCL_PMT_DETL_SQ" )
    @Column( name = "FINCL_PMT_DETL_ID" )
    private Integer financePaymentDetailId;

    @NotNull
    @Column( name = "CORP_ENT_CD", length = 3 )
    private String corporateEntityCode;

    @NotNull
    @Column( name = "VBR_PAYE_ID" )
    private Integer vbrPayeeId;

    @NotNull
    @Column( name = "PAY_TO_PFIN_ID", length = 10 )
    private String payToPfinId;

    @NotNull
    @Column( name = "FINCL_TYP_CD", length = 20 )
    private String financeTypeCode;

    @NotNull
    @Column( name = "PROC_PRD_DT" )
    private LocalDate processPeriodDate;

    @NotNull
    @Column( name = "PMT_EFF_DT" )
    private LocalDate paymentEffectiveDate;

    @NotNull
    @Column( name = "PMT_END_DT" )
    private LocalDate paymentEndDate;

    @NotNull
    @Column( name = "PROD_TYP_CD", length = 20 )
    private String productTypeCode;

    @NotNull
    @Column( name = "PMT_TYP_CD", length = 10 )
    private String paymentTypeCode;

    @NotNull
    @Column( name = "PMT_AMT", precision = 13, scale = 2 )
    private Double paymentAmount;

    @NotNull
    @Column( name = "PMT_STA_CD", length = 20 )
    private String paymentStatusCode;

    @OneToMany( fetch = FetchType.LAZY, mappedBy = "parentFinancePaymentDetail" )
    private List<FinancePaymentFinancePaymentDetailReference> financePaymentFinancePaymentDetailReferenceList =
        new ArrayList<FinancePaymentFinancePaymentDetailReference>();

    @OneToMany( fetch = FetchType.LAZY, mappedBy = "parentFinancePaymentDetail" )
    private List<FinancePaymentDetailApprovedCalculationMemberDetailReference> financePaymentDetailApprovedCalculationMemberDetailReferenceList =
        new ArrayList<FinancePaymentDetailApprovedCalculationMemberDetailReference>();

}
