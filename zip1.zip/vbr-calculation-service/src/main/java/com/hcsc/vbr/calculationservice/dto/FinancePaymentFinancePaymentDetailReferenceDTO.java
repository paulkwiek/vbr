package com.hcsc.vbr.calculationservice.dto;

import com.hcsc.vbr.common.dto.BaseEntityDTO;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class FinancePaymentFinancePaymentDetailReferenceDTO extends BaseEntityDTO
{
    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    private Integer financePaymentId;

    private Integer financePaymentDetailId;

    private FinancePaymentDTO parentFinancePayment;

    private FinancePaymentDetailDTO parentFinancePaymentDetail;

}
