package com.hcsc.vbr.calculationservice.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import com.hcsc.vbr.common.domain.BaseEntity;

import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
@Table( name = "CALCTN_REQ_HIST" )

public class CalculationRequestHistory extends BaseEntity
{
    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue( strategy = GenerationType.SEQUENCE, generator = "CALCTN_REQ_HIST_SQ_GENERATOR" )
    @SequenceGenerator( name = "CALCTN_REQ_HIST_SQ_GENERATOR", sequenceName = "CALCTN_REQ_HIST_SQ", allocationSize = 1 )
    @Column( name = "CALCTN_REQ_HIST_ID" )
    private Integer calculationRequestHistoryId;

    @NotNull
    @Column( name = "CORP_ENT_CD", length = 3 )
    private String corporateEntityCode;

    @NotNull
    @Column( name = "CALCTN_REQ_ID" )
    private Integer calculationRequestId;

    @NotNull
    @Column( name = "CALCTN_REQ_HIST_STA_CD", length = 20 )
    private String calculationRequestHistoryStatusCode;

    @ManyToOne( fetch = FetchType.LAZY )
    @JoinColumn( name = "CALCTN_REQ_ID", insertable = false, updatable = false, referencedColumnName = "CALCTN_REQ_ID" )
    private CalculationRequest parentCalculationRequest;

}
