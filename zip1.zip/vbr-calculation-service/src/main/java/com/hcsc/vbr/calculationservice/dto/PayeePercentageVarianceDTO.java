package com.hcsc.vbr.calculationservice.dto;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class PayeePercentageVarianceDTO extends PercentageVarianceDTO
{

    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    private Double manualReimbursementAmountVariance = 0.0;

    private Double currentPMPMVariance = 0.0;

    private Double overAllPMPMVariance = 0.0;

    private String payToPfinId;

    private String payToPfinName;
}
