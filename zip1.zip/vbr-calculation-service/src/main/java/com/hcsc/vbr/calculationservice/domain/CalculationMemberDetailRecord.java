package com.hcsc.vbr.calculationservice.domain;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.MappedSuperclass;
import javax.validation.constraints.NotNull;

import com.hcsc.vbr.common.domain.BaseEntity;

import lombok.Getter;
import lombok.Setter;

@MappedSuperclass
@Getter
@Setter
public class CalculationMemberDetailRecord extends BaseEntity
{

    private static final long serialVersionUID = 1L;

    @NotNull
    @Column( name = "CORP_ENT_CD", length = 3 )
    private String corporateEntityCode;

    @NotNull
    @Column( name = "CALCTN_REQ_ID" )
    private Integer calculationRequestId;

    @NotNull
    @Column( name = "PMT_ARNGMT_ID" )
    private Integer paymentArrangementId;

    @NotNull
    @Column( name = "PMT_ARNGMT_PAYE_ID" )
    private Integer paymentArrangementPayeeId;

    @NotNull
    @Column( name = "PAY_TO_PFIN_ID", length = 10 )
    private String payToPfinId;

    @NotNull
    @Column( name = "PMT_ARNGMT_RT_ID" )
    private Integer paymentArrangementRateId;

    @NotNull
    @Column( name = "RT_ID" )
    private Integer rateId;

    @NotNull
    @Column( name = "RT_CONFIG_TYP_CD", length = 20 )
    private String rateConfigurationTypeCode;

    @NotNull
    @Column( name = "PROC_PRD_DT" )
    private LocalDate processPeriodDate;

    @NotNull
    @Column( name = "PMT_RT_AMT", precision = 13, scale = 2 )
    private Double paymentRateAmount;

    @NotNull
    @Column( name = "PMT_EFF_DT" )
    private LocalDate paymentEffectiveDate;

    @NotNull
    @Column( name = "PMT_END_DT" )
    private LocalDate paymentEndDate;

    @Column( name = "PREV_APRVD_CALCTN_MBR_DETL_ID" )
    private Integer previousApprovedCalculationMemberDetailId;

    @NotNull
    @Column( name = "RETROACTVY_CHG_CD", length = 20 )
    private String retroActivityChangeCode;

    @NotNull
    @Column( name = "PREV_RT_AMT", precision = 13, scale = 2 )
    private Double previousRateAmount;

    @NotNull
    @Column( name = "CURR_RT_AMT", precision = 13, scale = 2 )
    private Double currentRateAmount;

    @NotNull
    @Column( name = "CALCD_NET_AMT", precision = 13, scale = 2 )
    private Double calculatedNetAmount;

    @NotNull
    @Column( name = "PMT_TYP_CD", length = 10 )
    private String paymentTypeCode;

}
