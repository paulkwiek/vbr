package com.hcsc.vbr.calculationservice.mapper;

import java.util.List;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import com.hcsc.vbr.calculationservice.domain.CalculationMemberDetail;
import com.hcsc.vbr.calculationservice.dto.CalculationMemberDetailDTO;

@Mapper( componentModel = "spring" )
public interface CalculationMemberDetailMapper
{
    CalculationMemberDetailMapper INSTANCE = Mappers.getMapper( CalculationMemberDetailMapper.class );

    /**
     * Method: toCalculationMemberDetailDTO
     * @param calculationMemberDetail
     * @return
     */
    @Mapping( target = "parentMemberEligibility", ignore = true )
    @Mapping( target = "parentCalculationRequest", ignore = true )
    public CalculationMemberDetailDTO toCalculationMemberDetailDTO( CalculationMemberDetail calculationMemberDetail );

    /**
     * Method: toCalculationMemberDetailDTOs
     * @param calculationMemberDetails
     * @return
     */
    public List<CalculationMemberDetailDTO> toCalculationMemberDetailDTOs( List<CalculationMemberDetail> calculationMemberDetails );

    /**
     * Method: toCalculationMemberDetail
     * @param calculationMemberDetailDTO
     * @return
     */
    public CalculationMemberDetail toCalculationMemberDetail( CalculationMemberDetailDTO calculationMemberDetailDTO );

    /**
     * Method: toCalculationMemberDetails
     * @param calculationMemberDetailDTOs
     * @return
     */
    public List<CalculationMemberDetail> toCalculationMemberDetails( List<CalculationMemberDetailDTO> calculationMemberDetailDTOs );
}
