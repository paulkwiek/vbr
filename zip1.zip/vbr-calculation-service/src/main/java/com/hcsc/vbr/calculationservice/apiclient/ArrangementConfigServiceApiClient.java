package com.hcsc.vbr.calculationservice.apiclient;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.stereotype.Component;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.hcsc.vbr.calculationservice.dto.CalculationArrangementsDTO;
import com.hcsc.vbr.common.apiclient.BaseApiClient;
import com.hcsc.vbr.web.request.CalculationRequestSaveRequest;
import com.hcsc.vbr.web.response.CalculationRequestPaymentArrangementResponse;

/**
 * 
 *
 */

@Component
public class ArrangementConfigServiceApiClient extends BaseApiClient
{

    @Autowired
    private RestTemplate restTemplate;

    @Autowired
    @Qualifier( "restRequestHeaderMap" )
    MultiValueMap<String, String> arrangementconfigClientHeadersMap;

    @Value( "${arrangementconfig.service.client.url}" )
    private String arrangementconfigServiceClientUrl;

    public List<CalculationArrangementsDTO> getPayemtArrangementByCorporateEntityCodeAndLineOfBusinessCode(
            CalculationRequestSaveRequest calculationRequestSaveRequest ) throws Exception
    {

        ObjectMapper objectMapper = new ObjectMapper();
        objectMapper.registerModule( new JavaTimeModule() );
        objectMapper.disable( SerializationFeature.WRITE_DATES_AS_TIMESTAMPS );

        HttpEntity<String> request = new HttpEntity<>( objectMapper.writeValueAsString( calculationRequestSaveRequest ),
                                                       getAuthorizationHeader() );

        CalculationRequestPaymentArrangementResponse response = null;

        try
        {
            response = restTemplate.postForObject( arrangementconfigServiceClientUrl,
                                                   request,
                                                   CalculationRequestPaymentArrangementResponse.class );
        }
        catch( HttpClientErrorException e )
        {
            throw new Exception( "Recieved error from PaymentArrangement service: " + e );
        }

        return response.getCalculationArrangementsDTOs();
    }
}
