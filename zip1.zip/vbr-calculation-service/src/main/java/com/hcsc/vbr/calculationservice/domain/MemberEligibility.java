package com.hcsc.vbr.calculationservice.domain;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
@Table( name = "MBR_ELIG" )
public class MemberEligibility extends MemberEligibilityRecord
{

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue( strategy = GenerationType.SEQUENCE, generator = "MBR_ELIG_SQ_GENERATOR" )
    @SequenceGenerator( name = "MBR_ELIG_SQ_GENERATOR", sequenceName = "MBR_ELIG_SQ", allocationSize = 1 )
    @Column( name = "MBR_ELIG_ID" )
    private Integer memberEligibilityId;

    @OneToMany( fetch = FetchType.LAZY, mappedBy = "parentMemberEligibility" )
    private List<CalculationMemberDetail> calculationMemberDetailList = new ArrayList<CalculationMemberDetail>();
    
    @OneToMany( fetch = FetchType.LAZY, mappedBy = "parentMemberEligibility" )
    private List<CalculationErrorLog> calculationErrorLogList = new ArrayList<CalculationErrorLog>();

}
