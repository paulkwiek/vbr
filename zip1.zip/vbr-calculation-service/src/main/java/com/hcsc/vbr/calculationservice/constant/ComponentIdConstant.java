package com.hcsc.vbr.calculationservice.constant;

public class ComponentIdConstant
{
    //Calculation Run
    public static final String CALCULATION_RUN_COMPONENT = "Calculation Run";

    //Finance Request
    public static final String FINANCE_REQUEST_COMPONENT = "Finance Request";

    //Calculation Request Status
    public static final String CALCULATION_REQUEST_STATUS_COMPONENT = "Calculation Request Status";

    //Review Calculation results
    public static final String REVIEW_CALCULATION_RESULT_COMPONENT = "Review Calculation Result";

    //Calculation Approval
    public static final String CALCULATION_APPROVAL_COMPONENT = "Calculation Approval";

    //Calculation Request
    public static final String CALCULATION_REQUEST_COMPONENT = "Calculation Request";

}
