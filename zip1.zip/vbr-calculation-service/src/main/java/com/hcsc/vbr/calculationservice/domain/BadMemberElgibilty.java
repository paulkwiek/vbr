package com.hcsc.vbr.calculationservice.domain;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import com.hcsc.vbr.common.domain.BaseEntity;

import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
@Table( name = "BAD_MBR_ELIG" )
public class BadMemberElgibilty extends BaseEntity
{

    /**
     * 
     */

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue( strategy = GenerationType.SEQUENCE, generator = "BAD_MBR_ELIG_ID_SQ_GENERATOR" )
    @SequenceGenerator( name = "BAD_MBR_ELIG_ID_SQ_GENERATOR", sequenceName = "BAD_MBR_ELIG_ID_SQ" )
    @Column( name = "BAD_MBR_ELIG_ID" )
    private Integer badMemberElgibilityId;

    @NotNull
    @Column( name = "CALCTN_REQ_ID", length = 10 )
    private Integer calculationRequestId;

    @NotNull
    @Column( name = "CORP_ENT_CD", length = 3 )
    private String corporateEntityCode;

    @NotNull
    @Column( name = "PROC_PRD_DT" )
    private LocalDate processPeriodDate;

    @Column( name = "SUB_ID", length = 12 )
    private String subscriberId;

    @Column( name = "LST_NM", length = 50 )
    private String lastName;

    @Column( name = "FST_NM", length = 25 )
    private String firstName;

    @Column( name = "MID_INIT_NM", length = 1 )
    private String middleInitialName;

    @Column( name = "GNDR_CD", length = 1 )
    private String genderCode;

    @Column( name = "MBR_NBR", length = 10 )
    private String memberNumber;

    @Column( name = "STR_ADDR_LN_1_TXT", length = 20 )
    private String streetAddressLine1Text;

    @Column( name = "STR_ADDR_LN_2_TXT", length = 20 )
    private String streetAddressLine2Text;

    @Column( name = "CTY_NM", length = 20 )
    private String cityName;

    @Column( name = "ST_CD", length = 2 )
    private String stateCode;

    @Column( name = "ZIP_CD", length = 9 )
    private String zipCode;

    @Column( name = "DOB" )
    private LocalDate dateOfBirth;

    @Column( name = "CNTY_CD", length = 3 )
    private String countyCode;

    @OneToMany( fetch = FetchType.LAZY, mappedBy = "parentBadMemberEligibility" )
    private List<CalculationErrorLog> calculationErrorLogList = new ArrayList<CalculationErrorLog>();

}
