package com.hcsc.vbr.calculationservice.dto;

import java.time.LocalDate;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.hcsc.vbr.common.dto.BaseEntityDTO;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter

public class FinanceRequestDTO extends BaseEntityDTO
{
    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    private Integer financeRequestId;

    @JsonFormat( shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd" )
    private LocalDate processPeriodDate;

    private String corporateEntityCode;

    private String financeRequestStatusCode;

    private String financeRequestStatusCodeDescription;

    List<FinanceRequestHistoryDTO> financeRequestHistory;

}
