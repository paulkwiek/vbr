package com.hcsc.vbr.calculationservice.dto;

import com.hcsc.vbr.common.dto.BaseEntityDTO;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class HcscBankAccountReferenceDTO extends BaseEntityDTO
{

    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    private String abaNumber;

    private Integer bankAccountNumber;

    private String corporateEntityCode;

    private String bankName;

    private String paymentMethodCode;
    
    private Integer lastUsePaymentNumber;
}
