package com.hcsc.vbr.calculationservice.mapper;

import java.util.List;

import org.mapstruct.IterableMapping;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;
import org.mapstruct.factory.Mappers;

import com.hcsc.vbr.calculationservice.domain.ApprovedCalculationMemberDetail;
import com.hcsc.vbr.calculationservice.domain.CalculationArrangements;
import com.hcsc.vbr.calculationservice.domain.CalculationMemberDetail;
import com.hcsc.vbr.calculationservice.domain.CalculationRequest;
import com.hcsc.vbr.calculationservice.domain.CalculationRequestGrouping;
import com.hcsc.vbr.calculationservice.dto.ApprovedCalculationMemberDetailDTO;
import com.hcsc.vbr.calculationservice.dto.CalculationArrangementsDTO;
import com.hcsc.vbr.calculationservice.dto.CalculationMemberDetailDTO;
import com.hcsc.vbr.calculationservice.dto.CalculationRequestDTO;
import com.hcsc.vbr.calculationservice.dto.CalculationRequestGroupingDTO;
import com.hcsc.vbr.calculationservice.dto.ReviewCalculationRunNameDTO;

@Mapper( componentModel = "spring" )
public interface CalculationRequestMapper
{
    CalculationRequestMapper INSTANCE = Mappers.getMapper( CalculationRequestMapper.class );

    /**
     * Method: toCalculationRequestDTO
     * 
     * @param calculationRequest
     * @return
     */
    @Named( value = "calculationDtoList" )
    @Mapping( source = "calculationErrorLog", target = "calculationErrorLogs" )
    @Mapping( source = "calculationReqiestHistory", target = "calculationHistoryStatusList" )
    @Mapping( target = "parentCalculationRunName", ignore = true )
    @Mapping( source = "calculationRequestGrouping", target = "calculationRequestGroupingDTOs" )
    @Mapping( source = "calculationArrangements", target = "calculationArrangementsList" )
    public CalculationRequestDTO toCalculationRequestDTO( CalculationRequest calculationRequest );

    /**
     * Method: toCalculationRequestDTOs
     * 
     * @param calculationRequests
     * @return
     */
    @IterableMapping( qualifiedByName = "calculationDtoList" )
    public List<CalculationRequestDTO> toCalculationRequestDTOs( List<CalculationRequest> calculationRequests );

    /**
     * Method: toCalculationRequest
     * 
     * @param calculationRequestDTO
     * @return
     */
    public CalculationRequest toCalculationRequest( CalculationRequestDTO calculationRequestDTO );

    /**
     * Method: toCalculationRequests
     * 
     * @param calculationRequestDTOs
     * @return
     */
    public List<CalculationRequest> toCalculationRequests( List<CalculationRequestDTO> calculationRequestDTOs );

    @Mapping( target = "parentCalculationRequest", ignore = true )
    @Mapping( target = "parentMemberEligibility", ignore = true )
    public CalculationMemberDetailDTO toCalculationMemberDetailDTO( CalculationMemberDetail calculationMemberDetail );

    /**
     * Method: toApprovedCalculationMemberDetailDTO
     * @param approvedCalculationMemberDetail
     * @return
     */
    @Mapping( target = "parentCalculationRequest", ignore = true )
    @Mapping( target = "parentMemberEligibility", ignore = true )
    public ApprovedCalculationMemberDetailDTO toApprovedCalculationMemberDetailDTO(
            ApprovedCalculationMemberDetail approvedCalculationMemberDetail );

    /**
     * 
     * Method: toCalculationRequestDTO
     * @param calculationRequest
     * @return
     */
    @Mapping( target = "calculationErrorLogs", ignore = true )
    @Mapping( target = "calculationMemberDetailList", ignore = true )
    @Mapping( target = "approvedCalculationMemberDetailList", ignore = true )
    @Mapping( target = "calculationArrangementsList", ignore = true )
    @Mapping( target = "calculationRequestGroupingDTOs", ignore = true )
    @Mapping( target = "parentCalculationRunName", ignore = true )
    @Mapping( target = "calculationHistoryStatusList", ignore = true )
    public CalculationRequestDTO toApprovedCalculationRequestDTO( CalculationRequest calculationRequest );

    /**
     * 
     * Method: toCalculationRequestDTO
     * @param calculationRequest
     * @return
     */
    @Mapping( target = "calculationErrorLogs", ignore = true )
    @Mapping( target = "calculationMemberDetailList", ignore = true )
    @Mapping( target = "approvedCalculationMemberDetailList", ignore = true )
    @Mapping( target = "calculationArrangementsList", ignore = true )
    @Mapping( target = "calculationRequestGroupingDTOs", ignore = true )
    @Mapping( target = "parentCalculationRunName", ignore = true )
    @Mapping( source = "calculationReqiestHistory", target = "calculationHistoryStatusList" )
    public CalculationRequestDTO toApprovedStatusCalculationRequestDTO( CalculationRequest calculationRequest );

    /**
     * 
     * Method: toCalculationRequestGroupingDTO
     * @param calculationRequestGrouping
     * @return
     */
    public CalculationRequestGroupingDTO toCalculationRequestGroupingDTO( CalculationRequestGrouping calculationRequestGrouping );

    /**
     * 
     * Method: toCalculationArrangementsDTO
     * @param calculationArrangements
     * @return
     */
    public CalculationArrangementsDTO toCalculationArrangementsDTO( CalculationArrangements calculationArrangements );

    /**
     * Method: toReReviewCalculationRunNameDTO
     * @param calculationRequest
     * @return
     */
    public ReviewCalculationRunNameDTO toReviewCalculationRunNameDTO( CalculationRequest calculationRequest );
}
