package com.hcsc.vbr.calculationservice.dto;

import com.hcsc.vbr.common.dto.BaseEntityDTO;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class FinancePaymentDetailApprovedCalculationMemberDetailReferenceDTO extends BaseEntityDTO
{
    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    private Integer approvedCalculationMemberDetailId;

    private Integer financePaymentDetailId;

    private ApprovedCalculationMemberDetailDTO parentApprovedCalculationMemberDetail;

    private FinancePaymentDetailDTO parentFinancePaymentDetail;

}
