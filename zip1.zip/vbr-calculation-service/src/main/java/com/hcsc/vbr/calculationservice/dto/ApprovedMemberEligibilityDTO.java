package com.hcsc.vbr.calculationservice.dto;

import java.util.ArrayList;
import java.util.List;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ApprovedMemberEligibilityDTO extends MemberEligibilityRecordDTO
{

    private static final long serialVersionUID = 1L;

    private Integer approvedMemberEligibilityId;

    private List<ApprovedCalculationMemberDetailDTO> approvedCalculationMemberDetailList =
        new ArrayList<ApprovedCalculationMemberDetailDTO>();

}
