package com.hcsc.vbr.calculationservice.domain;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
@Table( name = "APRVD_CALCTN_MBR_DETL" )
public class ApprovedCalculationMemberDetail extends CalculationMemberDetailRecord
{

    private static final long serialVersionUID = 1L;

    /**
     * This Id is NOT generated from sequence but
     * copied from CALCTN_MBR_DETL.CALCTN_MBR_DETL_ID column.
     * Hence no sequence is used.
     */
    @Id
    @Column( name = "APRVD_CALCTN_MBR_DETL_ID" )
    private Integer approvedCalculationMemberDetailId;

    @NotNull
    @Column( name = "APRVD_MBR_ELIG_ID" )
    private Integer approvedMemberEligibilityId;

    @OneToMany( fetch = FetchType.LAZY, mappedBy = "parentApprovedCalculationMemberDetail" )
    private List<FinancePaymentDetailApprovedCalculationMemberDetailReference> financePaymentDetailApprovedCalculationMemberDetailReferenceList =
        new ArrayList<FinancePaymentDetailApprovedCalculationMemberDetailReference>();

    @ManyToOne( fetch = FetchType.LAZY )
    @JoinColumn( name = "CALCTN_REQ_ID", insertable = false, updatable = false, referencedColumnName = "CALCTN_REQ_ID" )
    private CalculationRequest parentCalculationRequest;

    @ManyToOne( fetch = FetchType.LAZY )
    @JoinColumn( name = "APRVD_MBR_ELIG_ID", insertable = false, updatable = false, referencedColumnName = "APRVD_MBR_ELIG_ID" )
    private ApprovedMemberEligibility parentApprovedMemberEligibility;

}
