package com.hcsc.vbr.calculationservice.mapper;

import java.util.List;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import com.hcsc.vbr.calculationservice.domain.CalculationArrangements;
import com.hcsc.vbr.calculationservice.dto.CalculationArrangementsDTO;

@Mapper( componentModel = "spring" )
public interface CalculationArrangementsMapper
{
    CalculationArrangementsMapper INSTANCE = Mappers.getMapper( CalculationArrangementsMapper.class );

    /**
     * Method: toCalculationArrangmentsDTO
     * @param <CalculationArrangements>
     * @param calculationArrangments
     * @return
     */
    @Mapping( source = "paymentArrangementId", target = "calculationArrangementPK.paymentArrangementId" )
    @Mapping( source = "calculationRequestId", target = "calculationArrangementPK.calculationRequestId" )
    public CalculationArrangements toCalculationArrangments( CalculationArrangementsDTO calculationArrangementsDTO );

    public List<CalculationArrangements> toCalculationArrangmentsList( List<CalculationArrangementsDTO> calculationArrangementsDTOs );

    @Mapping( source = "calculationArrangementPK.paymentArrangementId", target = "paymentArrangementId" )
    @Mapping( source = "calculationArrangementPK.calculationRequestId", target = "calculationRequestId" )
    public CalculationArrangementsDTO toCalculationArrangmentsDTO( CalculationArrangements calculationArrangements );

    public List<CalculationArrangementsDTO> toCalculationArrangmentsDTOs( List<CalculationArrangements> calculationArrangmentsList );

}
