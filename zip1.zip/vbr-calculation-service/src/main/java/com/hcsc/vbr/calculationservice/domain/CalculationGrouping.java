package com.hcsc.vbr.calculationservice.domain;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.hibernate.annotations.NotFound;
import org.hibernate.annotations.NotFoundAction;
import org.hibernate.annotations.Type;

import com.hcsc.vbr.common.domain.BaseEntity;
import com.hcsc.vbr.common.utils.MultilineRecursiveToStringStyleCustom;

import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
@Table( name = "CALCTN_GRPG" )
public class CalculationGrouping extends BaseEntity
{

    private static final long serialVersionUID = 1L;

    @EmbeddedId
    private CalculationGroupingPK calculationGroupingPK;

    @NotNull
    @Column( name = "SEL_IND" )
    @Type( type = "yes_no" )
    private Boolean selectedIndicator = Boolean.TRUE;

    @ManyToOne( fetch = FetchType.LAZY )
    @NotFound( action = NotFoundAction.IGNORE )
    @JoinColumns( {
        @JoinColumn( name = "CALCTN_RUN_NM", insertable = false, updatable = false, referencedColumnName = "CALCTN_RUN_NM" ),
        @JoinColumn( name = "CORP_ENT_CD", insertable = false, updatable = false, referencedColumnName = "CORP_ENT_CD" ) } )
    private CalculationRunName parentCalculationRunName;

    @Override
    public String toString()
    {
        return ReflectionToStringBuilder.toString( this,
                                                   new MultilineRecursiveToStringStyleCustom() )
                .toString();
    }

}
