package com.hcsc.vbr.calculationservice.dto;

import java.util.List;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CalculationRunError
{
    private Integer errorCount;

    private String arrangementName;

    private List<String> errors;
}
