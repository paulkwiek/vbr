package com.hcsc.vbr.calculationservice.constant;

public class CalculationServiceErrorMessageConstant
{
    //Error Message for Finance Status
    public static final Long FINANCIAL_CALCULATION_REQUEST_STATUS_CODE_FFL_ERR = Long.valueOf( 232 );

    public static final Long CALCULATION_RUN_NAME_FORMAT_ERROR = Long.valueOf( 285 );

    public static final Long UNKNOWN_EXCEPTION = new Long( 3 );
    public static final Long DUPLICATE_CALCULATION_RUN_NAME_OR_GRAIN = new Long( 67 );
    public static final Long CALCULATION_RUN_NAME_STATUS_FOR_INPROGRESS_OR_SCHEDULED = new Long( 68 );
    public static final Long CALCULATION_RUN_NAME_STATUS_FOR_COMPLETED_OR_APPROVED = new Long( 69 );
    public static final Long NO_CALCULATION_REVIEW_RECORDS_FOUND = new Long( 233 );
    public static final Long CALCULATION_REQUEST_ARRANGEMENT_LIST = new Long( 234 );
    public static final Long CALCULATION_REQUEST_GROUPINGS = new Long( 235 );
    public static final Long NO_CURRENT_PROCESSING_MONTH_FOUND = new Long( 236 );
    public static final Long NO_CALCULATION_COMPLETED_STATUS_FOUND = new Long( 252 );
    public static final Long CALCULATION_REQUEST_INPROGRESS_MESSAGE = new Long( 245 );
    public static final Long CALCULATION_REQUEST_COMPLETED_MESSAGE = new Long( 249 );
    public static final Long CALCULATION_REQUEST_APPROVED_MESSAGE = new Long( 250 );
    public static final Long NO_MATCHING_CALCULATION_RUN_RECORDS_FOUND = new Long( 238 );
    public static final Long NO_MATCHING_CALCULATION_GRAIN_RECORDS_FOUND = new Long( 239 );
    public static final Long NO_CALCULATION_RUN_RECORD_FOUND = new Long( 240 );
    public static final Long NO_CALCULATION_GRAIN_RECORD_FOUND = new Long( 241 );
    public static final Long CALCULATION_RUN_NAME_ATTRIBUTE_CANNOT_BE_BLANK = new Long( 246 );
    public static final Long CALCULATION_RUN_CORPORATE_ENTITY_CODE_CANNOT_BE_BLANK = new Long( 247 );
    public static final Long CALCULATION_RUN_RUN_TYPE_CODE_CANNOT_BE_BLANK = new Long( 248 );
    public static final Long NO_CALCULATION_GROUPINGS_SELECTED = new Long( 251 );
    public static final Long NO_CALCULATION_GROUPINGS_FOUND = new Long( 273 );
    public static final Long CALCULATION_RUN_NAME_ATTRIBUTES_ERR = new Long( 273 );
    public static final Long CALCULATION_RUN_NAME_RUNTYPE_ATTRIBUTE = new Long( 295 );
    public static final Long CALCULATION_GROUPING_LOB_ATTRIBUTE = new Long( 296 );
    public static final Long ACCESS_DENIED_EXCEPTION_ERROR_MESSAGE_ID = Long.valueOf( 401 );

}
