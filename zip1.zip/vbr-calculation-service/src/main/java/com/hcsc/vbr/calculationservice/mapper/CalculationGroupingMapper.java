package com.hcsc.vbr.calculationservice.mapper;

import java.util.List;

import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import com.hcsc.vbr.calculationservice.domain.CalculationGrouping;
import com.hcsc.vbr.calculationservice.dto.CalculationGroupingDTO;
import com.hcsc.vbr.calculationservice.dto.CalculationRequestGroupingDTO;

@Mapper( componentModel = "spring" )
public interface CalculationGroupingMapper
{
    CalculationGroupingMapper INSTANCE = Mappers.getMapper( CalculationGroupingMapper.class );

    /**
     * Method: toCalculationGroupingDTO
     * @param calculationGrouping
     * @return
     */
    @Mapping( source = "calculationGroupingPK.calculationGroupingLevelCode", target = "calculationGroupingLevelCode" )
    @Mapping( source = "calculationGroupingPK.calculationRunName", target = "calculationRunName" )
    @Mapping( source = "calculationGroupingPK.calculationGroupingLevelValueText", target = "calculationGroupingLevelValueText" )
    @Mapping( source = "calculationGroupingPK.corporateEntityCode", target = "corporateEntityCode" )
    public CalculationGroupingDTO toCalculationGroupingDTO( CalculationGrouping calculationGrouping );

    /**
     * Method: toCalculationGroupingDTOs
     * @param calculationGroupings
     * @return
     */
    public List<CalculationGroupingDTO> toCalculationGroupingDTOs( List<CalculationGrouping> calculationGroupings );

    /**
     * Method: toCalculationGrouping
     * @param calculationGroupingDTO
     * @return
     */
    @InheritInverseConfiguration
    public CalculationGrouping toCalculationGrouping( CalculationGroupingDTO calculationGroupingDTO );

    /**
     * Method: toCalculationGroupings
     * @param calGroupDTOs
     * @return
     */
    @InheritInverseConfiguration
    public List<CalculationGrouping> toCalculationGroupings( List<CalculationGroupingDTO> calculationGroupingDTOs );

    /**
     * Method: toCalculationRunRequestGroupingDTO
     * @param calculationGrouping
     * @return
     */
    @Mapping( source = "calculationGroupingPK.calculationGroupingLevelCode", target = "calculationGroupingLevelCode" )
    @Mapping( source = "calculationGroupingPK.calculationRunName", target = "calculationRunName" )
    @Mapping( source = "calculationGroupingPK.calculationGroupingLevelValueText", target = "calculationGroupingLevelValueText" )
    @Mapping( source = "calculationGroupingPK.corporateEntityCode", target = "corporateEntityCode" )
    public CalculationRequestGroupingDTO toCalculationRequestGroupingDTO( CalculationGrouping calculationGrouping );

    public List<CalculationRequestGroupingDTO> toCalculationRequestGroupingDTOs( List<CalculationGrouping> calculationGrouping );

}
