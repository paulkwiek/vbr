package com.hcsc.vbr.calculationservice.domain;

import java.io.Serializable;
import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.validation.constraints.NotNull;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Embeddable
public class FinanceRequestPK implements Serializable
{
    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    @NotNull
    @Column( name = "FINC_REQ_ID", length = 20 )
    private Integer financeRequestId;

    @NotNull
    @Column( name = "PROC_PRD_DT" )
    private LocalDate processPeriodDate;

    @NotNull
    @Column( name = "CORP_ENT_CD", length = 3 )
    private String corporateEntityCode;
}
