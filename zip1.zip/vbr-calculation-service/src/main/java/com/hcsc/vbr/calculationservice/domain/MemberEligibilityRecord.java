package com.hcsc.vbr.calculationservice.domain;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.MappedSuperclass;
import javax.validation.constraints.NotNull;

import com.hcsc.vbr.common.domain.BaseEntity;

import lombok.Getter;
import lombok.Setter;

@MappedSuperclass
@Getter
@Setter
public class MemberEligibilityRecord extends BaseEntity
{

    private static final long serialVersionUID = 1L;

    @NotNull
    @Column( name = "CORP_ENT_CD", length = 3 )
    private String corporateEntityCode;

    @NotNull
    @Column( name = "LOB_CD", length = 10 )
    private String lineOfBusinessCode;

    @Column( name = "SUB_SEQ_NBR" )
    private Integer subscribeSequenceNumber;

    @NotNull
    @Column( name = "PROC_PRD_DT" )
    private LocalDate processPeriodDate;

    @Column( name = "PROD_TYP_CD", length = 6 )
    private String productTypeCode;

    @NotNull
    @Column( name = "SUB_ID", length = 12 )
    private String subscriberId;

    @Column( name = "MBR_NBR" )
    private Integer memberNumber;

    @Column( name = "GRP_NBR", length = 6 )
    private String groupNumber;

    @Column( name = "SECT_NBR", length = 4 )
    private String sectionNumber;

    @NotNull
    @Column( name = "LST_NM", length = 50 )
    private String lastName;

    @NotNull
    @Column( name = "FST_NM", length = 25 )
    private String firstName;

    @Column( name = "MID_INIT_NM", length = 1 )
    private String middleInitialName;

    @Column( name = "GNDR_CD", length = 1 )
    private String genderCode;

    @Column( name = "DOB" )
    private LocalDate dateOfBirth;

    @NotNull
    @Column( name = "EFF_DT" )
    private LocalDate effectiveDate;

    @NotNull
    @Column( name = "CAN_DT" )
    private LocalDate cancelDate;

    @Column( name = "STR_ADDR_LN_1_TXT", length = 20 )
    private String streetAddressLine1Text;

    @Column( name = "STR_ADDR_LN_2_TXT", length = 20 )
    private String streetAddressLine2Text;

    @Column( name = "CTY_NM", length = 20 )
    private String cityName;

    @Column( name = "ST_CD", length = 2 )
    private String stateCode;

    @Column( name = "CNTY_CD", length = 3 )
    private String countyCode;

    @Column( name = "ZIP_CD", length = 9 )
    private String zipCode;

    @Column( name = "CAP_ENT_CD", length = 6 )
    private String capitationEntityCode;

    @Column( name = "MBR_PROV_EFF_DT" )
    private LocalDate memberProviderEffectiveDate;

    @Column( name = "MBR_PROV_END_DT" )
    private LocalDate memberProviderEndDate;

    @Column( name = "MBR_SRC_CD", length = 1 )
    private String memberSourceCode;

    @Column( name = "HCN_MBI_NBR", length = 12 )
    private String hcnMbiNumber;

    @Column( name = "PCP_ID", length = 20 )
    private String pcpId;

    @Column( name = "ACCT_NBR", length = 10 )
    private String accountNumber;

    @Column( name = "FUNDG_TYP_CD", length = 6 )
    private String fundingTypeCode;

    @Column( name = "BNFT_AGRMT_NBR" )
    private Integer benefitAgreementNumber;

    @Column( name = "MKTG_PLN_ID", length = 13 )
    private String marketingPlanId;
}
