package com.hcsc.vbr.calculationservice.dto;

import java.time.LocalDate;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.hcsc.vbr.common.dto.BaseEntityDTO;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CalculationMemberDetailRecordDTO extends BaseEntityDTO
{

    private static final long serialVersionUID = 1L;

    private String corporateEntityCode;

    private Integer calculationRequestId;

    private Integer paymentArrangementId;

    private Integer paymentArrangementPayeeId;

    private String payToPfinId;

    private Integer paymentArrangementRateId;

    private Integer rateId;

    private String rateConfigurationTypeCode;

    @JsonFormat( shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd" )
    private LocalDate processPeriodDate;

    private Double paymentRateAmount;

    @JsonFormat( shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd" )
    private LocalDate paymentEffectiveDate;

    @JsonFormat( shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd" )
    private LocalDate paymentEndDate;

    private Integer previousApprovedCalculationMemberDetailId;

    private String retroActivityChangeCode;

    private Double previousRateAmount;

    private Double currentRateAmount;

    private Double calculatedNetAmount;

    private String paymentTypeCode;

}
