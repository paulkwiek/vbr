package com.hcsc.vbr.calculationservice.domain;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.validation.constraints.NotNull;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Embeddable
public class FinancePaymentFinancePaymentDetailReferencePK implements Serializable
{
    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    @NotNull
    @Column( name = "FINCL_PMT_ID" )
    private Integer financePaymentId;

    @NotNull
    @Column( name = "FINCL_PMT_DETL_ID" )
    private Integer financePaymentDetailId;

}
