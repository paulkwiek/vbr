package com.hcsc.vbr.calculationservice.constant;

public class FieldIdConstant
{
    //CalculationRun
    public static final String CAL_RUN_TYPE_ATTRIBUTE = "calculationRunType";
    public static final String CALCULATION_RUN_NAME_FIELD = "calculationRunName";
    public static final String CALCULATION_GROUPING_FIELD = "calculationGrouping";

    //CalculationRequestStatus
    public static final String CALCULATION_STATUS_PROCESSING_MONTH_FIELD = "processPeriodDate";

    //CalculationGrouping
    public static final String CAL_GROUP_LOB_ATTRIBUTE = "LOB";
    
    //financeProcessingMonth
    public static final String FINANCE_PROCESSING_MONTH_FIELD = "financeProcessingMonth";
    
    //financeProcessingMonth
    public static final String CALCULATION_REQUEST_STATUS_CODE = "statusCode";

    //CalculationRun
    public static final String CALCULATION_REQUEST_FIELD = "calculationRequest";
}
