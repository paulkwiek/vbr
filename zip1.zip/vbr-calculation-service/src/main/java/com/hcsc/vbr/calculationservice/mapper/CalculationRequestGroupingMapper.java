package com.hcsc.vbr.calculationservice.mapper;

import java.util.List;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import com.hcsc.vbr.calculationservice.domain.CalculationRequestGrouping;
import com.hcsc.vbr.calculationservice.dto.CalculationRequestGroupingDTO;

@Mapper( componentModel = "spring" )
public interface CalculationRequestGroupingMapper
{
    CalculationRequestGroupingMapper INSTANCE = Mappers.getMapper( CalculationRequestGroupingMapper.class );

    /**
     * Method: toCalculationRequestGroupingDTO
     * @param calculationRequestGrouping
     * @return
     */
    @Mapping( source = "calculationRequestGroupingPK.calculationRequestId", target = "calculationRequestId" )
    @Mapping( source = "calculationRequestGroupingPK.calculationGroupingLevelCode", target = "calculationGroupingLevelCode" )
    @Mapping( source = "calculationRequestGroupingPK.calculationRunName", target = "calculationRunName" )
    @Mapping( source = "calculationRequestGroupingPK.calculationGroupingLevelValueText", target = "calculationGroupingLevelValueText" )
    @Mapping( source = "calculationRequestGroupingPK.corporateEntityCode", target = "corporateEntityCode" )
    public CalculationRequestGroupingDTO toCalculationRequestGroupingDTO( CalculationRequestGrouping calculationRequestGrouping );

    /**
     * Method: toCalculationRequestDTOs
     * @param calculationRequestGrouping
     * @return
     */
    public List<CalculationRequestGroupingDTO> toCalculationRequestGroupingDTOs(
            List<CalculationRequestGrouping> calculationRequestGrouping );

    /**
     * Method: toCalculationRequestGrouping
     * @param calculationRequestGroupingDTO
     * @return
     */
    @Mapping( source = "calculationRequestId", target = "calculationRequestGroupingPK.calculationRequestId" )
    @Mapping( source = "calculationGroupingLevelCode", target = "calculationRequestGroupingPK.calculationGroupingLevelCode" )
    @Mapping( source = "calculationRunName", target = "calculationRequestGroupingPK.calculationRunName" )
    @Mapping( source = "calculationGroupingLevelValueText", target = "calculationRequestGroupingPK.calculationGroupingLevelValueText" )
    @Mapping( source = "corporateEntityCode", target = "calculationRequestGroupingPK.corporateEntityCode" )
    public CalculationRequestGrouping toCalculationRequestGrouping( CalculationRequestGroupingDTO calculationRequestGroupingDTO );

    /**
     * Method: toCalculationRequestsGroupings
     * @param calculationRequestGroupingDTOs
     * @return
     */
    public List<CalculationRequestGrouping> toCalculationRequestsGroupings(
            List<CalculationRequestGroupingDTO> calculationRequestGroupingDTOs );

}
