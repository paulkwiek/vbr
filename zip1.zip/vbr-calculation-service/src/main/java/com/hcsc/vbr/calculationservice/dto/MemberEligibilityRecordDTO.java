package com.hcsc.vbr.calculationservice.dto;

import java.time.LocalDate;

import com.hcsc.vbr.common.dto.BaseEntityDTO;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class MemberEligibilityRecordDTO extends BaseEntityDTO
{

    private static final long serialVersionUID = 1L;

    private String corporateEntityCode;

    private String lineOfBusinessCode;

    private Integer subscribeSequenceNumber;

    private LocalDate processPeriodDate;

    private String productTypeCode;

    private String subscriberId;

    private Integer memberNumber;

    private String groupNumber;

    private String sectionNumber;

    private String lastName;

    private String firstName;

    private String middleInitialName;

    private String genderCode;

    private LocalDate dateOfBirth;

    private LocalDate effectiveDate;

    private LocalDate cancelDate;

    private String streetAddressLine1Text;

    private String streetAddressLine2Text;

    private String cityName;

    private String stateCode;

    private String countyCode;

    private String zipCode;

    private String capitationEntityCode;

    private LocalDate memberProviderEffectiveDate;

    private LocalDate memberProviderEndDate;

    private String memberSourceCode;

    private String hcnMbiNumber;

    private String pcpId;

    private String accountNumber;

    private String fundingTypeCode;

    private Integer benefitAgreementNumber;

    private String marketingPlanId;
}
