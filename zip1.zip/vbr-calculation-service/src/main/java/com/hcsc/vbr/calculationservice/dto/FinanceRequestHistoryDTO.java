package com.hcsc.vbr.calculationservice.dto;

import java.time.LocalDate;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.hcsc.vbr.common.dto.BaseEntityDTO;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class FinanceRequestHistoryDTO extends BaseEntityDTO
{
    /**
     * 
     */

    private static final long serialVersionUID = 1L;

    private Integer financeRequestHistoryId;

    private Integer financeRequestId;

    @JsonFormat( shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd" )
    private LocalDate processPeriodDate;

    private String corporateEntityCode;

    private String financeRequestHistoryStatusCode;
}
