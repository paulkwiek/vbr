package com.hcsc.vbr.calculationservice.mapper;

import java.util.List;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import com.hcsc.vbr.calculationservice.domain.CalculationGrouping;
import com.hcsc.vbr.calculationservice.domain.CalculationRequest;
import com.hcsc.vbr.calculationservice.domain.CalculationRunName;
import com.hcsc.vbr.calculationservice.dto.CalculationGroupingDTO;
import com.hcsc.vbr.calculationservice.dto.CalculationRequestDTO;
import com.hcsc.vbr.calculationservice.dto.CalculationRunNameDTO;

@Mapper( componentModel = "spring" )
public interface CalculationRunNameMapper
{
    CalculationRunNameMapper INSTANCE = Mappers.getMapper( CalculationRunNameMapper.class );

    /**
     * Method: toCalculationRunNameDTO
     * @param calculationRunName
     * @return
     */
    @Mapping( target = "calculationRequests", ignore = true )
    @Mapping( source = "calculationRunNamePK.calculationRunName", target = "calculationRunName" )
    @Mapping( source = "calculationRunNamePK.corporateEntityCode", target = "corporateEntityCode" )
    public CalculationRunNameDTO toCalculationRunNameDTO( CalculationRunName calculationRunName );

    /**
     * Method: toCalculationRunNameDTOs
     * @param calculationRunNames
     * @return
     */

    public List<CalculationRunNameDTO> toCalculationRunNameDTOs( List<CalculationRunName> calculationRunNames );

    /**
     * Method: toCalculationGroupingDTO
     * @param calculationGrouping
     * @return
     */
    @Mapping( target = "parentCalculationRunName", ignore = true )
    @Mapping( source = "calculationGroupingPK.calculationGroupingLevelCode", target = "calculationGroupingLevelCode" )
    @Mapping( source = "calculationGroupingPK.calculationRunName", target = "calculationRunName" )
    @Mapping( source = "calculationGroupingPK.calculationGroupingLevelValueText", target = "calculationGroupingLevelValueText" )
    @Mapping( source = "calculationGroupingPK.corporateEntityCode", target = "corporateEntityCode" )
    public CalculationGroupingDTO toCalculationGroupingDTO( CalculationGrouping calculationGrouping );

    /**
     * Method: toCalculationRequestDTO
     * @param calculationRequest
     * @return
     */
    @Mapping( target = "parentCalculationRunName", ignore = true )
    public CalculationRequestDTO toCalculationRequestDTO( CalculationRequest calculationRequest );

    /**
     * Method: toCalculationRunName
     * @param calculationRunNameDTO
     * @return
     */
    @Mapping( source = "calculationRunName", target = "calculationRunNamePK.calculationRunName" )
    @Mapping( source = "corporateEntityCode", target = "calculationRunNamePK.corporateEntityCode" )
    public CalculationRunName toCalculationRunName( CalculationRunNameDTO calculationRunNameDTO );

    /**
     * Method: toCalculationGrouping
     * @param calculationGroupingDTO
     * @return
     */
    @Mapping( source = "calculationGroupingLevelCode", target = "calculationGroupingPK.calculationGroupingLevelCode" )
    @Mapping( source = "calculationRunName", target = "calculationGroupingPK.calculationRunName" )
    @Mapping( source = "calculationGroupingLevelValueText", target = "calculationGroupingPK.calculationGroupingLevelValueText" )
    public CalculationGrouping toCalculationGrouping( CalculationGroupingDTO calculationGroupingDTO );

    /**
     * Method: toCalculationRunNames
     * @param calculationRunNameDTOs
     * @return
     */
    public List<CalculationRunName> toCalculationRunNames( List<CalculationRunNameDTO> calculationRunNameDTOs );

}
