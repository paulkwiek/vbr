package com.hcsc.vbr.calculationservice.enums;

public class CalculationArrangementStatusCodes
{
    public enum CalcArrangementStatus
    {
     ASU,
     AIP,
     AVA,
     AIV,
     ACS,
     ACF,
     AFL,
     AAP,
     VA,
     IV
    }

}
