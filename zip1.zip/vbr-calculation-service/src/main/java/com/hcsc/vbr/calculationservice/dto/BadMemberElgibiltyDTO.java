package com.hcsc.vbr.calculationservice.dto;

import java.time.LocalDate;

import org.apache.commons.lang3.builder.ReflectionToStringBuilder;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.hcsc.vbr.common.dto.BaseEntityDTO;
import com.hcsc.vbr.common.utils.MultilineRecursiveToStringStyleCustom;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonInclude( JsonInclude.Include.NON_NULL )
public class BadMemberElgibiltyDTO extends BaseEntityDTO
{

    private static final long serialVersionUID = 1L;

    private Integer badMemberElgibilityId;

    private Integer calculationRequestId;

    private String corporateEntityCode;

    @JsonFormat( shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd" )
    private LocalDate processPeriodDate;

    private String subscriberId;

    private String lastName;

    private String firstName;

    private String middleInitialName;

    private String genderCode;

    private String memberNumber;

    private Integer streetAddressLine1Text;

    private Integer streetAddressLine2Text;

    private Integer cityName;

    private Integer stateCode;

    private Integer zipCode;

    @JsonFormat( shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd" )
    private LocalDate dateOfBirth;

    private String countyCode;

    @Override
    public String toString()
    {
        return new ReflectionToStringBuilder( this,
                                              new MultilineRecursiveToStringStyleCustom() ).toString();
    }

}
