package com.hcsc.vbr.calculationservice.enums;

import org.apache.commons.lang3.StringUtils;

import com.hcsc.vbr.calculationservice.constant.CalculationServiceConstant;

public enum FinancialCalculationRequestStatusEnum
{
 //  This Status are not coming from DB this will used when display finance status in UI
 NA(CalculationServiceConstant.FINANCIAL_CALCULATION_REQUEST_STATUS_CODE_NOT_APPLICABLE),
 PENDING(CalculationServiceConstant.FINANCIAL_CALCULATION_REQUEST_STATUS_CODE_PENDING),
 
 //  This Status are coming from DB this will used when display finance status in UI
 SUBMITTED(CalculationServiceConstant.FINANCIAL_CALCULATION_REQUEST_STATUS_CODE_FSU),
 IN_PROGRESS(CalculationServiceConstant.FINANCIAL_CALCULATION_REQUEST_STATUS_CODE_FIP),
 FAILED(CalculationServiceConstant.FINANCIAL_CALCULATION_REQUEST_STATUS_CODE_FFL),
 APPROVED(CalculationServiceConstant.FINANCIAL_CALCULATION_REQUEST_STATUS_CODE_FAP);

    String statusCode;

    FinancialCalculationRequestStatusEnum( String pStatusCode )
    {
        statusCode = pStatusCode;
    }

    /**
     * Method: getStatusCode
     * @return
     */
    public String getStatusCode()
    {
        return statusCode;
    }

    /**
     * Method: fromValue
     * @param statusCode
     * @return
     */
    public static FinancialCalculationRequestStatusEnum fromValue( String statusCode )
    {
        for( FinancialCalculationRequestStatusEnum statusEnum : FinancialCalculationRequestStatusEnum.values() )
        {
            if( StringUtils.equals( StringUtils.trim( statusEnum.getStatusCode() ),
                                    StringUtils.trim( statusCode ) ) )
            {
                return statusEnum;
            }
        }

        return null;
    }
}
