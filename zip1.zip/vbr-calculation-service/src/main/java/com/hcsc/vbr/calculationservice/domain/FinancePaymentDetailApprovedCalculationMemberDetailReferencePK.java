package com.hcsc.vbr.calculationservice.domain;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.validation.constraints.NotNull;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Embeddable
public class FinancePaymentDetailApprovedCalculationMemberDetailReferencePK implements Serializable
{
    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    @NotNull
    @Column( name = "APRVD_CALCTN_MBR_DETL_ID" )
    private Integer approvedCalculationMemberDetailId;

    @NotNull
    @Column( name = "FINCL_PMT_DETL_ID" )
    private Integer financePaymentDetailId;

}
