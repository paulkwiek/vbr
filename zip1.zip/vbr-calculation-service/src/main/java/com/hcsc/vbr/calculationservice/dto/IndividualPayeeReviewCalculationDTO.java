package com.hcsc.vbr.calculationservice.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class IndividualPayeeReviewCalculationDTO extends IndividualSummaryReviewCalculationDTO
{
    private static final long serialVersionUID = 1L;

    private String payToPfinId;

    private String payToPfinName;

    private Double manualAdjustmentAmount;

    private Double currentPMPM;

    private Double overallPMPM;
}
