package com.hcsc.vbr.calculationservice.domain;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import com.hcsc.vbr.common.domain.BaseEntity;

import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
@Table( name = "PROCG_MO" )
public class ProcessingMonth extends BaseEntity
{

    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    @EmbeddedId
    private ProcessingMonthPK processingMonthPK;

    @NotNull
    @Column( name = "MO_END_PROC_STA_CD", length = 20 )
    private String monthEndProcessStatusCode;

}
