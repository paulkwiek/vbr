package com.hcsc.vbr.calculationservice.domain;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import com.hcsc.vbr.common.domain.BaseEntity;

import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
@Table( name = "HCSC_BANK_ACCT_REF" )
public class HcscBankAccountReference extends BaseEntity
{

    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    @EmbeddedId
    private HcscBankAccountReferencePK hcscBankAccountReferencePK;

    @NotNull
    @Column( name = "BANK_NM", length = 35 )
    private String bankName;
    
    @NotNull
    @Column( name = "PMT_METH_CD", length = 3 )
    private String paymentMethodCode;
    
    @NotNull
    @Column( name = "LST_USE_PMT_NBR" )
    private Integer lastUsePaymentNumber;
    
}
