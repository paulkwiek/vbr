package com.hcsc.vbr.calculationservice.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

@Configuration
public class RestConfiguration
{

    @Bean
    public RestTemplate restTemplate()
    {
        return new RestTemplate();
    }

    @Bean( "restRequestHeaderMap" )
    public MultiValueMap<String, String> restRequestHeaders()
    {
        MultiValueMap<String, String> headers = new LinkedMultiValueMap<>();
        headers.add( "Content-Type",
                     "application/json" );
        return headers;
    }
}
