package com.hcsc.vbr.calculationservice.dto;

import java.io.Serializable;

import org.apache.commons.lang3.builder.ReflectionToStringBuilder;

import com.hcsc.vbr.common.utils.MultilineRecursiveToStringStyleCustom;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class IndividualSummaryReviewCalculationDTO implements Serializable
{
    private static final long serialVersionUID = 1L;

    private Integer currentMembers;

    private Integer retroMembers;

    private Double currentReimbursementAmount;

    private Double retroReimbursementAmount;

    private Double totalReimbursementAmount;

    @Override
    public String toString()
    {
        return new ReflectionToStringBuilder( this,
                                              new MultilineRecursiveToStringStyleCustom() ).toString();
    }
}
