package com.hcsc.vbr.calculationservice.apiclient;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.stereotype.Component;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.hcsc.vbr.calculationservice.dto.ErrorMessageDTO;
import com.hcsc.vbr.common.apiclient.BaseApiClient;
import com.hcsc.vbr.web.request.ErrorMessage;

@Component
public class CodeApiClient extends BaseApiClient
{
    private static final Logger LOGGER = LoggerFactory.getLogger( CodeApiClient.class );

    @Autowired
    @Qualifier( "restRequestHeaderMap" )
    MultiValueMap<String, String> errCodeClientHeadersMap;

    @Autowired
    private RestTemplate restTemplate;

    @Value( "${code.service.client.url}" )
    private String codeServiceClientUrl;

    public List<ErrorMessageDTO> getErrorByIds( ErrorMessage errorMsg ) throws Exception
    {
        /*
            HttpEntity<ErrorMessage> request = new HttpEntity<>( errorMsg,
                                                             errCodeClientHeadersMap );
        */

        HttpEntity<String> request = new HttpEntity<>( new ObjectMapper().writeValueAsString( errorMsg ),
                                                       getAuthorizationHeader() );

        ErrorMessage response = null;

        try
        {
            response = restTemplate.postForObject( codeServiceClientUrl,
                                                   request,
                                                   ErrorMessage.class );
        }
        catch( HttpClientErrorException e )
        {
            throw new Exception( "Recieved error from Code service: " + e );
        }

        return response.getErrors();
    }

}
