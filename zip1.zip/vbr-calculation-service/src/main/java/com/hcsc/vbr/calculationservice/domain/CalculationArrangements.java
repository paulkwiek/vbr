package com.hcsc.vbr.calculationservice.domain;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.apache.commons.lang3.builder.ReflectionToStringBuilder;

import com.hcsc.vbr.common.domain.BaseEntity;
import com.hcsc.vbr.common.utils.MultilineRecursiveToStringStyleCustom;

import lombok.Getter;
import lombok.Setter;

/**
 * @author i264680
 *
 */
@Entity
@Getter
@Setter
@Table( name = "CALCTN_ARNGMT_LIST" )
public class CalculationArrangements extends BaseEntity
{
    private static final long serialVersionUID = 1L;

    @EmbeddedId
    private CalculationArrangementPK calculationArrangementPK;

    @NotNull
    @Column( name = "CORP_ENT_CD", length = 3 )
    private String corporateEntityCode;

    @NotNull
    @Column( name = "LOB_CD", length = 10 )
    private String lineOfBusinessCode;

    @NotNull
    @Column( name = "CALCTN_ARNGMT_STA_CD", length = 20 )
    private String validationStatusCode;

    @ManyToOne( fetch = FetchType.LAZY )
    @JoinColumn( name = "CALCTN_REQ_ID", insertable = false, updatable = false, referencedColumnName = "CALCTN_REQ_ID" )
    private CalculationRequest parentCalculationRequest;

    @Override
    public String toString()
    {
        return new ReflectionToStringBuilder( this,
                                              new MultilineRecursiveToStringStyleCustom() ).toString();
    }
}
