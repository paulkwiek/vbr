package com.hcsc.vbr.calculationservice.domain;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
@Table( name = "APRVD_MBR_ELIG" )
public class ApprovedMemberEligibility extends MemberEligibilityRecord
{

    private static final long serialVersionUID = 1L;

    /**
     * This Id is NOT generated from sequence but
     * copied from MBR_ELIG.MBR_ELIG_ID column.
     * Hence no sequence is used.
     */
    @Id
    @Column( name = "APRVD_MBR_ELIG_ID" )
    private Integer approvedMemberEligibilityId; 

    @OneToMany( fetch = FetchType.LAZY, mappedBy = "parentApprovedMemberEligibility" )
    private List<ApprovedCalculationMemberDetail> approvedCalculationMemberDetailList =
        new ArrayList<ApprovedCalculationMemberDetail>();

}
