package com.hcsc.vbr.calculationservice.dto;

import com.hcsc.vbr.common.dto.BaseEntityDTO;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CalculationRequestGroupingDTO extends BaseEntityDTO
{

    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    private Integer calculationRequestId;

    private String calculationGroupingLevelCode;

    private String calculationRunName;

    private String calculationGroupingLevelValueText;

    private String corporateEntityCode;

    //    private CalculationRequest calculationRequest;

    //    private CalculationGrouping calculationGrouping;
    //
    //    private CalculationRequestDTO parentCalculationRequest;

}
