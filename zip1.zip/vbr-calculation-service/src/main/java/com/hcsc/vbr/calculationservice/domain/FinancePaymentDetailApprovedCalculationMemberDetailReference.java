package com.hcsc.vbr.calculationservice.domain;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.hcsc.vbr.common.domain.BaseEntity;

import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
@Table( name = "FINCL_PMT_DETL_APRVD_CALC_MBR" )
public class FinancePaymentDetailApprovedCalculationMemberDetailReference extends BaseEntity
{
    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    @EmbeddedId
    private FinancePaymentDetailApprovedCalculationMemberDetailReferencePK financePaymentDetailApprovedCalculationMemberDetailReferencePK;

    @ManyToOne( fetch = FetchType.LAZY )
    @JoinColumn( name = "APRVD_CALCTN_MBR_DETL_ID", insertable = false, updatable = false, referencedColumnName = "APRVD_CALCTN_MBR_DETL_ID" )
    private ApprovedCalculationMemberDetail parentApprovedCalculationMemberDetail;

    @ManyToOne( fetch = FetchType.LAZY )
    @JoinColumn( name = "FINCL_PMT_DETL_ID", insertable = false, updatable = false, referencedColumnName = "FINCL_PMT_DETL_ID" )
    private FinancePaymentDetail parentFinancePaymentDetail;

}
