package com.hcsc.vbr.calculationservice.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
@Table( name = "CALCTN_MBR_DETL" )
public class CalculationMemberDetail extends CalculationMemberDetailRecord
{

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue( strategy = GenerationType.SEQUENCE, generator = "CALCTN_MBR_DETL_SQ_GENERATOR" )
    @SequenceGenerator( name = "CALCTN_MBR_DETL_SQ_GENERATOR", sequenceName = "CALCTN_MBR_DETL_SQ", allocationSize = 1 )
    @Column( name = "CALCTN_MBR_DETL_ID" )
    private Integer calculationMemberDetailId;

    @NotNull
    @Column( name = "MBR_ELIG_ID" )
    private Integer memberEligibilityId;

    @ManyToOne( fetch = FetchType.LAZY )
    @JoinColumn( name = "CALCTN_REQ_ID", insertable = false, updatable = false, referencedColumnName = "CALCTN_REQ_ID" )
    private CalculationRequest parentCalculationRequest;

    @ManyToOne( fetch = FetchType.LAZY )
    @JoinColumn( name = "MBR_ELIG_ID", insertable = false, updatable = false, referencedColumnName = "MBR_ELIG_ID" )
    private MemberEligibility parentMemberEligibility;
}
