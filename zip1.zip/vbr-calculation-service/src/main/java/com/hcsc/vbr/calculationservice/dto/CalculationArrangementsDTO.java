package com.hcsc.vbr.calculationservice.dto;

import org.apache.commons.lang3.builder.ReflectionToStringBuilder;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.hcsc.vbr.common.dto.DateRecordDTO;
import com.hcsc.vbr.common.utils.MultilineRecursiveToStringStyleCustom;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@JsonInclude( JsonInclude.Include.NON_NULL )
public class CalculationArrangementsDTO extends DateRecordDTO
{

    private static final long serialVersionUID = 1L;

    private Integer paymentArrangementId;

    private String corporateEntityCode;

    private String validationStatusCode;

    private String lineOfBusinessCode;

    private Integer calculationRequestId;

    //    private CalculationRequestDTO parentCalculationRequest;

    @Override
    public String toString()
    {
        return new ReflectionToStringBuilder( this,
                                              new MultilineRecursiveToStringStyleCustom() ).toString();
    }
}
