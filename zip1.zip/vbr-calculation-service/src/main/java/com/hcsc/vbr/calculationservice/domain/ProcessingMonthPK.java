package com.hcsc.vbr.calculationservice.domain;

import java.io.Serializable;
import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.validation.constraints.NotNull;

import org.apache.commons.lang3.builder.ReflectionToStringBuilder;

import com.hcsc.vbr.common.utils.MultilineRecursiveToStringStyleCustom;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Embeddable
public class ProcessingMonthPK implements Serializable
{

    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    @NotNull
    @Column( name = "PROC_PRD_DT" )
    private LocalDate processPeriodDate;

    @NotNull
    @Column( name = "CORP_ENT_CD", length = 3 )
    private String corporateEntityCode;

    @Override
    public String toString()
    {
        return new ReflectionToStringBuilder( this,
                                              new MultilineRecursiveToStringStyleCustom() ).toString();
    }

}
