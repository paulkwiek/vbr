package com.hcsc.vbr.calculationservice.mapper;

import java.util.List;

import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import com.hcsc.vbr.calculationservice.domain.FinancePaymentDetailApprovedCalculationMemberDetailReference;
import com.hcsc.vbr.calculationservice.dto.FinancePaymentDetailApprovedCalculationMemberDetailReferenceDTO;

@Mapper( componentModel = "spring" )
public interface FinancePaymentDetailApprovedCalculationMemberDetailReferenceMapper
{
	FinancePaymentDetailApprovedCalculationMemberDetailReferenceMapper INSTANCE =
        Mappers.getMapper( FinancePaymentDetailApprovedCalculationMemberDetailReferenceMapper.class );

    /**
     * Method: toFinancePaymentDetailApprovedCalculationMemberDetailReferenceDTO
     * @param financePaymentDetailApprovedCalculationMemberDetailReference
     * @return
     */
    @Mapping( source = "financePaymentDetailApprovedCalculationMemberDetailReferencePK.approvedCalculationMemberDetailId", target = "approvedCalculationMemberDetailId" )
    @Mapping( source = "financePaymentDetailApprovedCalculationMemberDetailReferencePK.financePaymentDetailId", target = "financePaymentDetailId" )
    public FinancePaymentDetailApprovedCalculationMemberDetailReferenceDTO toFinancePaymentDetailApprovedCalculationMemberDetailReferenceDTO(
    		FinancePaymentDetailApprovedCalculationMemberDetailReference financePaymentDetailApprovedCalculationMemberDetailReference );

    /**
     * Method: toFinancePaymentDetailApprovedCalculationMemberDetailReferenceDTOs
     * @param financePaymentDetailApprovedCalculationMemberDetailReference
     * @return
     */
    public List<FinancePaymentDetailApprovedCalculationMemberDetailReferenceDTO> toFinancePaymentDetailApprovedCalculationMemberDetailReferenceDTOs(
            List<FinancePaymentDetailApprovedCalculationMemberDetailReference> financePaymentDetailApprovedCalculationMemberDetailReference );

    /**
     * Method: toFinancePaymentDetailApprovedCalculationMemberDetailReference
     * @param financePaymentDetailApprovedCalculationMemberDetailReferenceDTO
     * @return
     */
    @InheritInverseConfiguration
    public FinancePaymentDetailApprovedCalculationMemberDetailReference toFinancePaymentDetailApprovedCalculationMemberDetailReference(
    		FinancePaymentDetailApprovedCalculationMemberDetailReferenceDTO financePaymentDetailApprovedCalculationMemberDetailReferenceDTO );

    /**
     * Method: toFinancePaymentDetailApprovedCalculationMemberDetailReferences
     * @param financePaymentDetailApprovedCalculationMemberDetailReferenceDTOs
     * @return
     */
    @InheritInverseConfiguration
    public List<FinancePaymentDetailApprovedCalculationMemberDetailReference> toFinancePaymentDetailApprovedCalculationMemberDetailReferences(
            List<FinancePaymentDetailApprovedCalculationMemberDetailReferenceDTO> financePaymentDetailApprovedCalculationMemberDetailReferenceDTOs );

}
