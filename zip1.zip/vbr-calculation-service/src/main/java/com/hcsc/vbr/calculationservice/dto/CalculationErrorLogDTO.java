package com.hcsc.vbr.calculationservice.dto;

import com.hcsc.vbr.common.dto.BaseEntityDTO;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class CalculationErrorLogDTO extends BaseEntityDTO
{
    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    private Integer errorMessageId;

    private Integer calculationRequestId;

    private String paymentArrangementId;

    private String paymentArrangementName;

    private String paymentTypeCode;

    private String lobCode;

    private String jobName;

    private String memberEligibilityId;

    private String payToPfinId;

    private String errorMessageContextText;
}