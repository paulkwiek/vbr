import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";

import { HttpClientModule } from "@angular/common/http";

import { HcscLibSsoComponent } from "./hcsc-lib-sso.component";
import { SsoWrapperComponent } from "./components/sso-wrapper/sso-wrapper.component";

@NgModule({
  declarations: [HcscLibSsoComponent, SsoWrapperComponent],
  imports: [CommonModule, HttpClientModule],
  providers: [HttpClientModule],
  exports: [HcscLibSsoComponent, SsoWrapperComponent]
})
export class HcscLibSsoModule {}
