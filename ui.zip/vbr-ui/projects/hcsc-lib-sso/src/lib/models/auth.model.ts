export const AUTH_HEADER_NAME = "Authorization";
export const AUTH_TOKEN = "jwt_token";
export const REFRESH_TOKEN = "refresh_token";

export interface DecodedToken {
  uuid?: string;
  sub?: string;
  hcsc_private_claims?: {
    corpcode?: string;
    locationcode?: string;
    permissions?: string[];
  };
  iat?: number;
  exp?: number;
  lastActivity?: Date;
}

export interface Role {
  roleName?: string;
}

export enum AuthorizationState {
  IS_AUTHORIZED = "IS_AUTHORIZED",
  IS_NOT_AUTHORIZED = "IS_NOT_AUTHORIZED",
  IS_FAILED_AUTHORIZED = "IS_FAILED_AUTHORIZED"
}

export enum RoleTypes {
  NGTF_REF_DATA_ADMIN = "Ref_Data_Admin",
  NGTF_REF_DATA_WRITE = "Ref_Data_Write",
  NGTF_REF_DATA_READ = "Ref_Data_Read"
}

export const INTERNAL_HEADER = "HTTP_HCSC_Internal_User";

export const refDataAdminRoles = [RoleTypes.NGTF_REF_DATA_ADMIN];
export const refDataWriteRoles = [
  RoleTypes.NGTF_REF_DATA_ADMIN,
  RoleTypes.NGTF_REF_DATA_WRITE
];
export const refDataReadRoles = [
  RoleTypes.NGTF_REF_DATA_READ,
  RoleTypes.NGTF_REF_DATA_ADMIN,
  RoleTypes.NGTF_REF_DATA_WRITE
];
export const allRoles = [
  RoleTypes.NGTF_REF_DATA_ADMIN,
  RoleTypes.NGTF_REF_DATA_WRITE,
  RoleTypes.NGTF_REF_DATA_READ
];
