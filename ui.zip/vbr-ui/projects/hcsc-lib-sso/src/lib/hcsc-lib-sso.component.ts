import { Component, OnInit } from "@angular/core";

@Component({
  selector: "hcsc-lib-sso",
  template: `
    <p>
      hcsc-lib-sso works!
    </p>
  `,
  styles: []
})
export class HcscLibSsoComponent implements OnInit {
  constructor() {}

  ngOnInit() {}
}
