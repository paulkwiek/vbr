import { HttpClient, HttpHeaders } from "@angular/common/http";
import { Injectable, OnDestroy, Inject } from "@angular/core";
import { JwtHelperService } from "@auth0/angular-jwt";
import { Store, select } from "@ngrx/store";
import { Router } from "@angular/router";
import Cookies from "js-cookie";
import getValue from "object-getvalue";

import { switchMap } from "rxjs/operators";
import { Subscription, Observable, of } from "rxjs";

import * as fromRoot from "../store/reducers/app.states";
import {
  AUTH_TOKEN,
  AuthorizationState,
  DecodedToken
} from "../models/auth.model";
import {
  AuthorizationTokenExpired,
  AuthorizationRefreshToken
} from "../store/actions/auth.actions";

//This has to be removed from here 
import { AppConfigService } from 'src/app/app-config.service';

@Injectable({
  providedIn: "root"
})
export class AuthService {
  readonly SM_SESSION_API_PATH;
  readonly DELETE_COOKIE;

  private user: DecodedToken;

  private intervalRef;
  private recentAuthState;

  constructor(
    public store: Store<fromRoot.AppState>,
    private http: HttpClient,
    // private jwtHelper: JwtHelperService,
    private router: Router,
    @Inject("env") private env
  ) {
    // console.log("env: ", env);
    //this.SM_SESSION_API_PATH = env.SSO_CONFIG.authSmSesssionApiUri;

    // console.log(">>>> Cookies ", Cookies.get("SMSESSION"));

    this.store.pipe(select("authState")).subscribe(({ data, original }) => {
      // console.log("data: ", data);
      // this.refreshTokenState = data.

      this.user = data.decodedToken;

      const isNewTimerRequired = data.decodedToken.iat
        ? data.decodedToken.iat !== this.recentAuthState.decodedToken.iat
        : false;
      this.recentAuthState = data;

      if (!this.intervalRef || isNewTimerRequired) {
        clearInterval(this.intervalRef);
        this.handleRefreshCall();
      }
    });
  }

  public clearRefreshTimer() {
    clearInterval(this.intervalRef);
  }

  private handleRefreshCall() {
    if (
      this.recentAuthState.authorizationStatus ===
      AuthorizationState.IS_AUTHORIZED
    ) {
      const {
        decodedToken: { iat, exp }
      } = this.recentAuthState;

      const jwtExipiryDurationInSec = Math.floor(exp - iat);
      console.log(">>>> jwtExipiryDurationInSec: ", jwtExipiryDurationInSec);

      const defaultActivityThresholdInSec = 60 * 5;
      const nextRefreshIntervalInSec =
        jwtExipiryDurationInSec -
        (this.env.SSO_CONFIG.activityThresholdInSec ||
          defaultActivityThresholdInSec);

      console.log(">>>> nextRefreshIntervalInSec: ", nextRefreshIntervalInSec);

      this.intervalRef = setInterval(() => {
        // Check if user is active
        if (this.recentAuthState.userLastActivityTime) {
          this.store.dispatch(new AuthorizationRefreshToken());
        } else {
          console.log("JWT Expired as user was not active");
          clearInterval(this.intervalRef);

          this.store.dispatch(new AuthorizationTokenExpired());

          // TODO : Need to clear the storage so that NEXT call header will be empty and response comes as 401
          // window.localStorage.clear(); // This is already done on page_load

          const { deleteCookieOnAuthTokenExpiry } = this.env;
          if (deleteCookieOnAuthTokenExpiry) {
            console.log(">>>> Cookies Before ", Cookies.get("SMSESSION"));
            this.deleteSmSessionCookie();
            console.log(">>>> Cookies After ", Cookies.get("SMSESSION"));
          }
        }
      }, 1000 * nextRefreshIntervalInSec); // takes in milliseconds
    }
  }

  private deleteSmSessionCookie() {
    const url = window.location.hostname;
    const urlArr = url.split(".");
    while (urlArr.length >= 2) {
      const newUrl = urlArr.join(".");
      const deleteCookieUrl = `.${newUrl}`;

      Cookies.remove("SMSESSION", {
        path: "/",
        domain: deleteCookieUrl
      });

      urlArr.shift();
    }
  }

  public authenticateSmSession(): Observable<any> {
    return this.http
      .get(AppConfigService.settings.baseUrls.SSO_BASE_URL+this.env.SSO_CONFIG.authSmSesssionApiUri, {
        observe: "response",
        withCredentials: true
      })
      .pipe(
        // tap(val => {
        //   console.log(">>>> server res : ,", val);
        // }),
        switchMap(response => {
          const token = this.parseJwtFromResponse(response);
          return of({ token, original: response.body });
        })
      );
  }

  parseJwtFromResponse(response): any {
    const token = response.body.jwt_token;
    const jwtHelper = new JwtHelperService();
    const decodedToken = jwtHelper.decodeToken(token);

    return decodedToken;
  }

  // TODO : This functionality will be replaced in future
  public isAuthorized(requiredPermissions: string[]): boolean {
    const permissions = getValue(this, "user.hcsc_private_claims.permissions");
    if (!permissions) {
      return false;
    }
    return (
      this.user.hcsc_private_claims.permissions.find(permission => {
        return (
          requiredPermissions.find(
            permissionName => permission === permissionName
          ) != null
        );
      }) != null
    );
  }
}
