import { REFRESH_TOKEN, AUTH_TOKEN } from "../../models/auth.model";

export function beforeSsoInit() {
  // localStorage.setItem(REFRESH_TOKEN, null);
  // localStorage.setItem(AUTH_TOKEN, null);
}

// export function getTokenGetter() {
//   return localStorage.getItem(AUTH_TOKEN);
// }
