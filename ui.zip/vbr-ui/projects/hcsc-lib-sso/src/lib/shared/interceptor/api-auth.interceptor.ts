import {
  HttpEvent,
  HttpHandler,
  HttpInterceptor,
  HttpRequest,
  HttpResponse,
  HttpErrorResponse
} from "@angular/common/http";
import { Injectable, Inject } from "@angular/core";
import { Observable } from "rxjs";
import "rxjs/add/operator/do";

import { AUTH_TOKEN, AUTH_HEADER_NAME } from "../../models/auth.model";
import { AuthService } from "../../service/auth.service";
import {
  AuthorizationNewTokenFailed,
  AuthorizationApiAccessDeniedOccurred
} from "../../store/actions/auth.actions";
import { Store, select } from "@ngrx/store";

import * as fromRoot from "../../store/reducers/app.states";

const EXPIRED_MESSAGE = "[Unauthorized] Token Expired";

@Injectable()
export class ApiAuthRequestInterceptor implements HttpInterceptor {
  private authToken = "";

  constructor(
    private authService: AuthService,
    @Inject("env") private env,
    public store: Store<fromRoot.AppState>
  ) {
    this.store.pipe(select("authState")).subscribe(({ original }) => {
      this.authToken = original.jwt_token;
    });
  }

  intercept(
    request: HttpRequest<any>,
    next: HttpHandler
  ): Observable<HttpEvent<any>> {
    if (this.env.SSO_CONFIG.enableSSO) {
      // TODO : Only intercept the REQUIRED API request and respective response
      // if (request.url.includes("authorization")) {
      //   console.log(">>>> request: ", request);
      //   // return next.handle(request);
      // }

      return next
        .handle(
          request.clone({
            headers: request.headers.set(
              AUTH_HEADER_NAME,
              // `Bearer ${localStorage.getItem(AUTH_TOKEN) || ""}`
              `Bearer ${this.authToken}`
            )
          })
        )
        .do(
          (event: HttpEvent<any>) => {
            if (event instanceof HttpResponse) {
              // TODO only API which arre intercepted with Auth Header should be intercepted
              // console.log(">>>> event: ", event);
            }
          },
          (err: any) => {
            if (err instanceof HttpErrorResponse) {
              const {
                authorizationAPIErrorCodes = [401]
              } = this.env.SSO_CONFIG;

              if (authorizationAPIErrorCodes.indexOf(err.status) > -1) {
                // this.authService.clearRefreshTimer(); // Should not clear the timer as User has option to go back to screen
                this.store.dispatch(new AuthorizationApiAccessDeniedOccurred());
              }
            }
          }
        );
    } else {
      return next.handle(request);
    }
  }
}
