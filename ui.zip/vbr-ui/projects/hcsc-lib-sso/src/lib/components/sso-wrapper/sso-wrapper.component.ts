import { Component, OnInit, Inject } from "@angular/core";
import { Store, select } from "@ngrx/store";
import getValue from "object-getvalue";

import { AppState } from "../../store/reducers/app.states";
import { AuthState } from "../../store/reducers/auth.reducer";
import {
  AuthorizationNewToken,
  AuthorizationApiAccessDeniedClear
} from "../../store/actions/auth.actions";

@Component({
  selector: "hcsc-lib-sso-wrapper",
  templateUrl: "./sso-wrapper.component.html",
  styleUrls: ["./sso-wrapper.component.css"]
})
export class SsoWrapperComponent implements OnInit {
  public authState: AuthState;
  public isDataLoaded = false;
  public userRoles = [];
  public authTokenExpiryErrorText: string;
  public authErrorText: string;
  public enableSSO = true;
  public handleSSOErrors = true;
  public defaultAuthorizationAPIErrorHandling = true;
  public isApiAccessError = false;
  public defaultSessionTimeoutErrorHandling = true;
  public defaultAuthorizationErrorHandling = true;

  constructor(public store: Store<AppState>, @Inject("env") env) {
    const { SSO_CONFIG } = env;

    this.authTokenExpiryErrorText = SSO_CONFIG.authTokenExpiryErrorText;
    this.authErrorText = SSO_CONFIG.authErrorText;

    this.enableSSO = SSO_CONFIG.enableSSO;
    this.defaultAuthorizationAPIErrorHandling = getValue(
      SSO_CONFIG,
      "defaultAuthorizationAPIErrorHandling",
      true
    );

    this.defaultSessionTimeoutErrorHandling = getValue(
      SSO_CONFIG,
      "defaultSessionTimeoutErrorHandling",
      true
    );

    this.defaultAuthorizationErrorHandling = getValue(
      SSO_CONFIG,
      "defaultAuthorizationErrorHandling",
      true
    );
  }

  ngOnInit() {
    if (this.enableSSO) {
      setTimeout(() => {
        this.store.dispatch(new AuthorizationNewToken());

        this.store.pipe(select("authState")).subscribe(authState => {
          this.authState = authState;
          this.isDataLoaded = authState.meta.isDataLoaded;

          this.isApiAccessError = getValue(
            authState,
            "data.isApiAccessError",
            false
          );

          this.userRoles = getValue(
            authState,
            "data.decodedToken.hcsc_private_claims.permissions",
            []
          );
        });
      }, 2000);
    }
  }

  clearAccessDenied() {
    this.store.dispatch(new AuthorizationApiAccessDeniedClear());
  }
}
