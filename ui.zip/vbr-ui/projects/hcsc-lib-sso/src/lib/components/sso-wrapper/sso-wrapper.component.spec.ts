import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SsoWrapperComponent } from './sso-wrapper.component';

describe('SsoWrapperComponent', () => {
  let component: SsoWrapperComponent;
  let fixture: ComponentFixture<SsoWrapperComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SsoWrapperComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SsoWrapperComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
