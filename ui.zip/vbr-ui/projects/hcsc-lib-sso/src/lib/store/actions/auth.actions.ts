import { Action } from "@ngrx/store";

// import { DecodedToken } from "../../models/auth.model";

export enum AuthActionTypes {
  AUTHORIZATION_NEW_TOKEN = "[Authorization] New Token", // Will be helpful for Loading Page
  AUTHORIZATION_NEW_TOKEN_SUCCESS = "[Authorization] New Token Success", // Will hide Loading Page and show Main App
  AUTHORIZATION_NEW_TOKEN_FAILED = "[Authorization] New Token Failed", // Will hide Loading Page and show Access Denied Page

  AUTHORIZATION_REFRESH_TOKEN = "[Authorization] Refresh Token", // Refresh Token - No Loading Page
  AUTHORIZATION_REFRESH_TOKEN_SUCCESS = "[Authorization] Refresh Token Success",
  AUTHORIZATION_REFRESH_TOKEN_FAILED = "[Authorization] Refresh Token Failed", // Complete Access Denied Page

  AUTHORIZATION_USER_ACTIVE = "[Authorization] Authorized User Active",
  AUTHORIZATION_TOKEN_EXPIRED = "[Authorization] Token Expired", // Complete Access Denied Page

  // API Error
  AUTHORIZATION_API_ACCESS_DENIED_OCCURRED = "[Authorization] API Access Denied Occurred", // Complete Access Denied Page
  AUTHORIZATION_API_ACCESS_DENIED_CLEAR = "[Authorization] API Access Denied Clear" // Will be used only for Custom 401 handling
}

export class AuthorizationNewToken implements Action {
  readonly type = AuthActionTypes.AUTHORIZATION_NEW_TOKEN;
}

export class AuthorizationNewTokenSuccess implements Action {
  readonly type = AuthActionTypes.AUTHORIZATION_NEW_TOKEN_SUCCESS;
  constructor(public payload) {}
}

export class AuthorizationNewTokenFailed implements Action {
  readonly type = AuthActionTypes.AUTHORIZATION_NEW_TOKEN_FAILED;
  constructor(public payload: string) {}
}

export class AuthorizationRefreshToken implements Action {
  readonly type = AuthActionTypes.AUTHORIZATION_REFRESH_TOKEN;
}

export class AuthorizationRefreshTokenSuccess implements Action {
  readonly type = AuthActionTypes.AUTHORIZATION_REFRESH_TOKEN_SUCCESS;
  constructor(public payload) {}
}

export class AuthorizationRefreshTokenFailed implements Action {
  readonly type = AuthActionTypes.AUTHORIZATION_REFRESH_TOKEN_FAILED;
  constructor(public payload: any) {}
}

export class AuthorizationUserActive implements Action {
  readonly type = AuthActionTypes.AUTHORIZATION_USER_ACTIVE;
}

export class AuthorizationTokenExpired implements Action {
  readonly type = AuthActionTypes.AUTHORIZATION_TOKEN_EXPIRED;
}

export class AuthorizationApiAccessDeniedOccurred implements Action {
  readonly type = AuthActionTypes.AUTHORIZATION_API_ACCESS_DENIED_OCCURRED;
}

export class AuthorizationApiAccessDeniedClear implements Action {
  readonly type = AuthActionTypes.AUTHORIZATION_API_ACCESS_DENIED_CLEAR;
}

export type AuthUserActions =
  | AuthorizationNewToken
  | AuthorizationNewTokenSuccess
  | AuthorizationNewTokenFailed
  | AuthorizationRefreshToken
  | AuthorizationRefreshTokenSuccess
  | AuthorizationRefreshTokenFailed
  | AuthorizationUserActive
  | AuthorizationTokenExpired
  | AuthorizationApiAccessDeniedOccurred
  | AuthorizationApiAccessDeniedClear;
