import * as auth from "../actions/auth.actions";
import { AuthorizationState, DecodedToken } from "../../models/auth.model";
import { state } from "@angular/animations";

export interface AuthState {
  meta: {
    isDataLoading: boolean;
    isDataLoaded: boolean; // True after first application load
    errors: Array<string>;
  };
  data: {
    decodedToken: DecodedToken;
    authorizationStatus: AuthorizationState;
    userLastActivityTime?: Date;
    isTokenExpired?: boolean;
    isApiAccessError?: boolean;
  };
  original: {};
}

function extractPermissions(permissions) {
  const filteredPermissions = [];

  permissions.split(";").forEach(param => {
    param.split(",").forEach(newParam => {
      if (newParam.includes("cn=")) {
        filteredPermissions.push(newParam.split("=")[1]);
      }
    });
  });

  return filteredPermissions;
}

function getDataObj(param) {
  return {
    ...state,
    decodedToken: {
      ...param,
      hcsc_private_claims: {
        ...param.hcsc_private_claims,
        permissions: extractPermissions(param.hcsc_private_claims.permissions)
      }
    },
    authorizationStatus: AuthorizationState.IS_AUTHORIZED,
    userLastActivityTime: null,
    isApiAccessError: initializeState().data.isApiAccessError
  };
}

function initializeState(): AuthState {
  return {
    meta: {
      isDataLoading: false,
      isDataLoaded: false,
      errors: []
    },
    data: {
      decodedToken: {},
      authorizationStatus: AuthorizationState.IS_NOT_AUTHORIZED,
      userLastActivityTime: null,
      isTokenExpired: false,
      isApiAccessError: false
    },
    original: {}
  };
}

export const initialState: AuthState = initializeState();

export function reducer(
  state = initialState,
  action: auth.AuthUserActions
): AuthState {
  switch (action.type) {
    case auth.AuthActionTypes.AUTHORIZATION_NEW_TOKEN: {
      return {
        ...state,
        meta: {
          ...state.meta,
          isDataLoading: true,
          isDataLoaded: false
        }
      };
    }

    case auth.AuthActionTypes.AUTHORIZATION_REFRESH_TOKEN: {
      return {
        ...state,
        meta: {
          ...state.meta,
          isDataLoading: true
          // Don't touch isDataLoaded
        }
      };
    }

    case auth.AuthActionTypes.AUTHORIZATION_NEW_TOKEN_SUCCESS: {
      return {
        ...state,
        meta: {
          ...state.meta,
          isDataLoading: false,
          isDataLoaded: true
        },
        data: getDataObj(action.payload.token),
        original: action.payload.original
      };
    }

    case auth.AuthActionTypes.AUTHORIZATION_REFRESH_TOKEN_SUCCESS: {
      return {
        ...state,
        meta: {
          ...state.meta,
          isDataLoading: false
        },
        data: getDataObj(action.payload.token),
        original: action.payload.original
      };
    }

    case auth.AuthActionTypes.AUTHORIZATION_USER_ACTIVE: {
      return {
        ...state,
        data: {
          ...state.data,
          userLastActivityTime: new Date()
        }
      };
    }

    case auth.AuthActionTypes.AUTHORIZATION_NEW_TOKEN_FAILED:
    case auth.AuthActionTypes.AUTHORIZATION_REFRESH_TOKEN_FAILED: {
      return {
        ...initializeState(),
        meta: {
          isDataLoading: false,
          isDataLoaded: true,
          errors: [action.payload]
        }
      };
    }

    case auth.AuthActionTypes.AUTHORIZATION_TOKEN_EXPIRED: {
      return {
        ...state,
        data: {
          ...state.data,
          isTokenExpired: true
        }
      };
    }

    case auth.AuthActionTypes.AUTHORIZATION_API_ACCESS_DENIED_OCCURRED: {
      return {
        ...state,
        data: {
          ...state.data,
          isApiAccessError: true
        }
      };
    }

    case auth.AuthActionTypes.AUTHORIZATION_API_ACCESS_DENIED_CLEAR: {
      return {
        ...state,
        data: {
          ...state.data,
          isApiAccessError: false
        }
      };
    }

    default: {
      return state;
    }
  }
}

export const getAuthorizationStates = (state: AuthState) =>
  state.data.authorizationStatus;

export const getDecodedToken = (state: AuthState) => state.data.decodedToken;
