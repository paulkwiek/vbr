import {
  getAuthorizationStates,
  getDecodedToken,
  AuthState,
  reducer
} from "./auth.reducer";
import { ActionReducer, createSelector } from "@ngrx/store";
import { localStorageSync } from "ngrx-store-localstorage";
//This has to be removed
import { CalculationReducer } from 'src/app/store/calculations/calculations.reducer';
import { ReportsReducer } from 'src/app/store/reports/reports.reducer';
import { CorporateEntityReducer } from 'src/app/store/corporate-entity/corporate-entity.reducer';

export interface AppState {
  authState: AuthState;
}

export const reducers = {
  authState: reducer,
  //This has to be removed from here 
  calculations: CalculationReducer,
  reports: ReportsReducer,
  corpEntity: CorporateEntityReducer,
};

export const getAuthState = (state: AppState) => state.authState;

export const getAuthenticationState = createSelector(
  getAuthState,
  getAuthorizationStates
);

export const getAuthUserState = createSelector(
  getAuthState,
  getDecodedToken
);

// export const metaReducers: MetaReducer<AppState>[] = !env.production
//   ? []
//   : [];

// export function localStorageSyncReducer(
//   reducer: ActionReducer<any>
// ): ActionReducer<any> {
//   return localStorageSync({
//     keys: ["authState"],
//     rehydrate: true
//   })(reducer);
// }

export function ssoMetaReducers() {
  // return [localStorageSyncReducer];
  return [];
}
