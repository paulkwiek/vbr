export const APPVERSION = {
    version: '0.0.12',
    buildDate: 'Thu Nov 14 2019 17:21:19 GMT+0530 (India Standard Time)'
};
