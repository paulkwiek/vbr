export const environment = {
  production: true,

  // ****** SSO Settings - Starts ******
  SSO_CONFIG: {
    enableSSO: true, // default is false
    authSmSesssionApiUri: '/users/smsession',

    // In general - JWT Expiry is ~3650seconds i.e. ~ 1hr
    activityThresholdInSec: 300, // default value : 300 seconds

    authErrorText: 'Authorization failed',
    authTokenExpiryErrorText: 'Session expired, please try logging in again',

    handleSSOErrors: false, // default value : true
    defaultAuthorizationAPIErrorHandling: true, // default value : true  - Only for API Call
    // authorizationAPIErrorCodes: [401, 403] // default value : [401]
    defaultSessionTimeoutErrorHandling: true, // default value : true
    defaultAuthorizationErrorHandling: true // default value : true - For role check after Loading screen
    // deleteCookieOnAuthTokenExpiry: false // default value : false
  },
  FEATURE_FLAGS: {
    configurations: true,
    calculations: true,
    reports: true
  }
  // ****** SSO Settings - Ends ******
};

