import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

// SSO
import { AppRouterGuard } from './guards/app-routing.guard';
import { FeatureFlagGuard } from './guards/feature-flag.guard';

const routes: Routes = [
  { path: '', loadChildren: './modules/home/home.module#HomeModule', canActivate: [FeatureFlagGuard, AppRouterGuard]},
  {
    path: 'configurations',
    loadChildren:
      './modules/configurations/configurations.module#ConfigurationsModule',
      canActivate: [FeatureFlagGuard, AppRouterGuard]
  },
  {
    path: 'calculations',
    loadChildren:
      './modules/calculations/calculations.module#CalculationsModule',
      canActivate: [FeatureFlagGuard, AppRouterGuard]
  },
  {
    path: 'reports',
    loadChildren:
      './modules/reports/reports.module#ReportsModule',
      canActivate: [FeatureFlagGuard, AppRouterGuard]
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes, { useHash: true })],
  exports: [RouterModule]
})
export class AppRoutingModule {}
