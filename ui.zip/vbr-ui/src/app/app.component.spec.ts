import { TestBed, ComponentFixture, async } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { AppComponent } from './app.component';
import { ConfigurationsModule } from './modules/configurations/configurations.module';
import { environment } from '../environments/environment';
import { Store, StoreModule } from '@ngrx/store';
import {ReportsModule } from '../app/modules/reports/reports.module';
import { HcscLibSsoModule } from '../../projects/hcsc-lib-sso/src/lib/hcsc-lib-sso.module';

describe('AppComponent', () => {
  let component: AppComponent;
  let fixture: ComponentFixture<AppComponent>;
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule, ConfigurationsModule,  ReportsModule, HcscLibSsoModule, StoreModule.forRoot({})],
      declarations: [AppComponent],
      providers: [Store, { provide: 'env', useValue: environment }]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AppComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create the app', () => {
    expect(component).toBeTruthy();
  });

  it('should have as title "VBR"', () => {
    expect(component.title).toEqual('VBR');
  });

  it('menuClick - component.isOpened should be false', () => {
    component.isOpened = true;
    component.menuClick();
    expect(component.isOpened).toBeFalsy();
  });
  it('menuClick - component.isOpened should be true', () => {
    component.isOpened = false;
    component.menuClick();
    expect(component.isOpened).toBeTruthy();
  });

  it('onMinClick - component.isMin should be false', () => {
    component.isMin = true;
    component.onMinClick();
    expect(component.isMin).toBeFalsy();
  });

  it('onMinClick - component.isMin should be true', () => {
    component.isMin = false;
    component.onMinClick();
    expect(component.isMin).toBeTruthy();
  });

  it('reportToggle - component.isCollapsed should be true', () => {
    component.isCollapsed = false;
    component.reportToggle();
    expect(component.isCollapsed).toBeTruthy();
  });

  it('reportToggle - component.isCollapsed should be false', () => {
    component.isCollapsed = true;
    component.reportToggle();
    expect(component.isCollapsed).toBeFalsy();
  });

  it('collapseReport - component.isCollapsed should be false', () => {
    component.collapseReport();
    expect(component.isCollapsed).toBeFalsy();
  });



});
