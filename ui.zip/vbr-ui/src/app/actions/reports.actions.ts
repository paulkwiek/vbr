import { Action } from '@ngrx/store';
import { Report } from '../models/configuration.model';

export enum AppActionTypes {
  SetReport = '0'
}

export class SetActiveReport implements Action {
  readonly type = AppActionTypes.SetReport;

  constructor(public payload: Report) {}
}

export type AppActions = SetActiveReport;
