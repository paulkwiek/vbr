import { Action } from '@ngrx/store';

export enum AppGlobalActionTypes {
  APP_GLOBAL_RESET_ACTION = '[AppGlobal] Reset Action'
}

export class AppGlobalReset implements Action {
  readonly type = AppGlobalActionTypes.APP_GLOBAL_RESET_ACTION;
  constructor() { }
}
