import { Action } from '@ngrx/store';
import { Tab } from '../models/calculation.model';

export enum AppActionTypes {
  SetTab = 'nm-preliminary-1'
}

export class SetActiveTab implements Action {
  readonly type = AppActionTypes.SetTab;

  constructor(public payload: Tab) {}
}

export type AppActions = SetActiveTab;
