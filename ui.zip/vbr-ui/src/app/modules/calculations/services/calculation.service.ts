import { Injectable } from '@angular/core';
import { resourceEndPoints } from '../../../shared/constants/app.constants';
import { HttpdataService } from '../../../shared/services/httpdata.service';
import { AppConfigService } from '../../../app-config.service';


@Injectable({
  providedIn: 'root'
})

export class CalculationService {

  protected BASE_URL = AppConfigService.settings.baseUrls.BASE_URL;
  protected BASE_URL_CALCULATION_SERVICE = AppConfigService.settings.baseUrls.BASE_URL_CALCULATION_SERVICE;
  protected BASE_URL_CODE_SERVICE = AppConfigService.settings.baseUrls.BASE_URL_CODE_SERVICE;

  constructor(private http: HttpdataService) { }

  /* Method : getLineOfBusinessList
   * This method is used to get the line of business list
   */
  getLineOfBusinessList(lob: string) {
    return this.http.get(this.BASE_URL_CALCULATION_SERVICE + resourceEndPoints.RETRIEVE_LINE_OF_BUSINESS + '?' + lob);
  }

  /* Method : saveCalculationRun
   * This method is used to save the calculation Run
   */
  saveCalculationRun(param: object) {
    return this.http.post(this.BASE_URL_CALCULATION_SERVICE + resourceEndPoints.SAVE_CALCULATION_RUN, param);
  }

  /* Method : deleteCalculationRun
   * This method is used to delete the calculation Run
   */
  deleteCalculationRun(param: object) {
    return this.http.post(this.BASE_URL_CALCULATION_SERVICE + resourceEndPoints.DELETE_CALCULATION_RUN, param);
  }

  /* Method : getCalculationRunList
   * This method is used to retrieve the list of calculation runs
   */
  getCalculationRunList(corporateEntity: string) {
    return this.http.get(this.BASE_URL_CALCULATION_SERVICE + resourceEndPoints.RETRIEVE_CALCULATION_RUN + '?' + corporateEntity);
  }

  /* Method : getCalculationRunStatus
   * This method is used to retrieve the list of calculation runs status
   */
  getCalculationRunStatus(param: object) {
    return this.http.post(this.BASE_URL_CALCULATION_SERVICE + resourceEndPoints.RETRIEVE_LINE_OF_CALCULATION_STATUS, param);
  }

  /* Method : saveCalculationRequest
   * This method is used to save the calculation Run Request
   */
  saveCalculationRequest(param: object) {
    return this.http.post(this.BASE_URL_CALCULATION_SERVICE + resourceEndPoints.SAVE_CALCULATION_REQUEST, param);
  }

  /* Method : getReviewCalculationRunName
   * This method is used to retrieve the list of review calculation runs
   */
  getReviewCalculationRunName(param: object) {
    return this.http.post(this.BASE_URL_CALCULATION_SERVICE + resourceEndPoints.REVIEW_CALCULATION_RUN_NAME, param);
  }

  /* Method : getProcessingMonth
   * This method is used to retrieve the list of calculation runs
   */
  getProcessingMonth(corporateEntity: string) {
    return this.http.get(this.BASE_URL_CALCULATION_SERVICE + resourceEndPoints.PROCESSING_MONTH + '/' + corporateEntity);
  }


  /**
   * getReviewCalculationResults
   * @param param
   * Method to retrieve all the calculation results for the requested report type
   */
  getReviewCalculationResults(param: object, reportType: string) {
    const endPoint = (reportType == 'INDV') ? resourceEndPoints.REVIEW_CALC_RESULT_INDIVIDUAL : resourceEndPoints.REVIEW_CALC_RESULT_COMPARE_PRIOR;
    return this.http.post(this.BASE_URL_CALCULATION_SERVICE + endPoint, param);
  }

  /* Method : getCalcApprovalStatus
  * This method is used to retrieve the calculation run approval status
  */
  getCalcApprovalStatus(param: object) {
    return this.http.post(this.BASE_URL_CALCULATION_SERVICE + resourceEndPoints.CALC_APPROVAL_STATUS, param);
  }

  /* Method : submitOperationalApproval
   * This method is used to submit operational approval for calculation run
   */
  submitOperationalApproval(param: object) {
    return this.http.post(this.BASE_URL_CALCULATION_SERVICE + resourceEndPoints.SUBMIT_OPERATIONAL_APPROVAL, param);
  }

  /* Method : submitFinanceApproval
   * This method is used to submit finance approval for calculation run
   */
  submitFinanceApproval(param: object) {
    return this.http.post(this.BASE_URL_CALCULATION_SERVICE + resourceEndPoints.SUBMIT_FINANCE_APPROVAL, param);
  }
}
