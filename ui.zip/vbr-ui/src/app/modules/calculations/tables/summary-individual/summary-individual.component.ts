import { Component, OnInit, Input } from '@angular/core';
import { DataTableResource } from '../../../../shared/modules/data-table';
import { ModalService } from '../../../../shared/services/modal.service';
import { IndividualReviewCalculation } from '../../../../models/calculation.model';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-summary-individual',
  providers: [],
  templateUrl: './summary-individual.component.html',
  styleUrls: ['./summary-individual.component.scss']
})
export class SummaryIndividualComponent implements OnInit {
  dataitemResource: any;
  dataitems = [];
  dataitemCount = 0;
  loaded = false;
  item: {};
  @Input() reviewingResults: IndividualReviewCalculation;
  @Input() compare_prior: boolean;
  individualSummaryResults = [];

  constructor(
    private modalService: ModalService,
    private route: ActivatedRoute
  ) { }

  ngOnInit() {
    this.route.snapshot.paramMap.get('id');
    this.individualSummaryResults = [];
    this.individualSummaryResults.push(this.reviewingResults.individualSummaryReviewCalculation);
    this.dataitemResource = new DataTableResource(this.individualSummaryResults);
    this.dataitemResource.count().then((count: any) => (this.dataitemCount = count));
  }

  reloadItems(params: any) {
    this.dataitemResource
      .query(params)
      .then((dataitems: any) => (this.dataitems = dataitems));
  }
  edit(id: string) {
    this.modalService.open(id);
  }
  view(id: string) {
    this.modalService.open(id);
  }
}
