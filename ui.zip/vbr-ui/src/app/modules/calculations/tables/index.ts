import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { DataTableModule } from '../../../shared/modules/data-table';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { SummaryComponent } from './summary/summary.component';
import { SummaryIndividualComponent } from './summary-individual/summary-individual.component';
import { IndividualResultsComponent } from './individual-results/individual-results.component';
import { ComparePriorResultsComponent } from './compare-prior-results/compare-prior-results.component';
import { RollingComponent } from './rolling-table/rolling-table.component';
import { CalculationRunManagerComponent } from './calculation-run-manager/calculation-run-manager';

@NgModule({
  imports: [CommonModule, FormsModule, DataTableModule, NgbModule],
  declarations: [
    SummaryComponent,
    SummaryIndividualComponent,
    IndividualResultsComponent,
    ComparePriorResultsComponent,
    RollingComponent,
    CalculationRunManagerComponent
  ],
  exports: [
    SummaryComponent,
    SummaryIndividualComponent,
    IndividualResultsComponent,
    ComparePriorResultsComponent,
    RollingComponent,
    CalculationRunManagerComponent
  ]
})
export class CalculationTablesModule {}
