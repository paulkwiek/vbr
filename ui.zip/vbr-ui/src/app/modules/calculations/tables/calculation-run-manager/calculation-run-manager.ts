import { Component, OnInit, OnChanges, Input } from '@angular/core';
import { DataTableResource } from '../../../../shared/modules/data-table';
import { ModalService } from '../../../../shared/services/modal.service';
import { CalculationService } from 'src/app/modules/calculations/services/calculation.service';
import { UtilService } from 'src/app/shared/services/util.service';
import { SearchPipe } from '../../../../shared/pipes/search.pipe';
import { CalculationRunComponent } from '../../components/calculation-run/calculation_run.component';
@Component({
  selector: 'app-calculation-run-manager-table',
  providers: [],
  templateUrl: './calculation-run-manager.html',
  styleUrls: ['calculation-run-manager.scss']
})
export class CalculationRunManagerComponent implements OnInit, OnChanges {
  dataitemResource;
  dataitems = [];
  dataitemCount = 0;
  @Input() calculation_runs;
  filterPipe = new SearchPipe();
  constructor(
    private modalService: ModalService,
    private calculationService: CalculationService,
    private utilService: UtilService,
    private calculationRunComponent: CalculationRunComponent
  ) { }

  ngOnInit() {

  }

  ngOnChanges() {
    this.dataitemResource = new DataTableResource(this.calculation_runs.calculationRunNames);
    this.dataListCount();
  }
  dataListCount() {
    this.dataitemResource.count().then((count: any) => (this.dataitemCount = count));
  }

  reloadItems(params) {
    this.dataitemResource
      .query(params)
      .then(dataitems => (this.dataitems = dataitems));
  }
  /**
   * Method: edit
   * @param editPopup - popup windo id
   *        calculaionRunRecord - Calculation Run Object to delete
   * Method is userd to change the time stamp into formatted date and time
   */
  edit(editPopup: string, calculaionRunRecord: any) {
    this.calculationRunComponent.editCalculationRun(calculaionRunRecord);
    this.modalService.open(editPopup);
  }
  /**
   * Method: deleteCalculation
   * @param item - Selected calculation Run Object
   * Method is userd to change the time stamp into formatted date and time
   */
  deleteCalculation(item: any) {
    this.calculationRunComponent.deleteCalculationRun(item);
  }
  /**
   * Method: getFormattedDateAndTime
   * @param timestamp-string dateOrTime -string
   * Method is userd to change the time stamp into formatted date and time
   */
  getFormattedDateAndTime(timeStamp: string, dateOrTime: string): string {
    if (dateOrTime === 'date') {
      return this.utilService.getFormattedDate(timeStamp);
    } else {
      return this.utilService.getFormattedTime(timeStamp);
    }
  }
  /**
   * Method: filterCalculationRunName
   * @param searchParam string
   * Method is userd to filter the Calculation Run based on the search param
   */
  filterCalculationRunName(searchParam: any) {
    this.dataitemResource = (searchParam == '') ? new DataTableResource(this.calculation_runs.calculationRunNames) : new DataTableResource(this.filterPipe.transform(this.calculation_runs.calculationRunNames, { searchParam, searchKey: 'calculationRunName' }));
    this.dataListCount();
    this.reloadItems({ 'offset': 0, 'limit': 25 });
  }
}
