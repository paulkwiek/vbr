import { Component, OnInit, Input } from '@angular/core';
import { DataTableResource } from '../../../../shared/modules/data-table';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-rolling',
  providers: [],
  templateUrl: './rolling-table.component.html'
})
export class RollingComponent implements OnInit {
  // dataitemResource = new DataTableResource(ROLLING12);
  dataitems = [];
  dataitemCount = 0;
  loaded = false;
  payment_types: {};
  january;
  item: {};
  @Input() reviewingResultsByYear;

  constructor(private route: ActivatedRoute) {
    // this.dataitemResource.count().then(count => (this.dataitemCount = count));
  }

  ngOnInit() {
    this.route.snapshot.paramMap.get('id');
    // this.payment_types = ROLLING12;
    // console.log(this.payment_types);
  }

  reloadItems(params) {
   // this.dataitemResource.query(params).then(dataitems => (this.dataitems = dataitems));
  }
}
