import { Component, OnInit, Input } from '@angular/core';
import { DataTableResource } from '../../../../shared/modules/data-table';
import { ModalService } from '../../../../shared/services/modal.service';
import { ActivatedRoute } from '@angular/router';
import { UtilService } from '../../../../shared/services/util.service';
import _ from 'lodash';

@Component({
  selector: 'app-compare-prior-results',
  providers: [],
  templateUrl: './compare-prior-results.component.html',
  styleUrls: ['./compare-prior-results.component.scss']
})
export class ComparePriorResultsComponent implements OnInit {
  dataitemResource;
  dataitems = [];
  dataitemCount = 0;
  loaded = false;
  payment_types: {};
  item: {};
  resultsTable = [];
  currentMonth: string;
  priorMonth: string;
  @Input() reviewingResults;
  @Input() payee: boolean;
  @Input() line_of_business: boolean;
  @Input() payment_type: boolean;

  constructor(
    private modalService: ModalService,
    private route: ActivatedRoute,
    private utilService: UtilService
  ) { }

  /**
   * LifeCycle hook on component initialization
   */
  ngOnInit() {
    this.route.snapshot.paramMap.get('id');
    this.getResults();
    this.dataitemResource = new DataTableResource(this.resultsTable);
    this.dataitemResource.count().then(count => (this.dataitemCount = count));
    this.payment_types = _.forEach(this.resultsTable, function (value, key) {
      // console.log(key);
      // console.log(value.payee);
    });
  }

  /**
   * reloadItems
   * @param params
   * Method called on every event change
   */
  reloadItems(params) {
    this.getResults();
    this.dataitemResource
      .query(params)
      .then(dataitems => (this.dataitems = dataitems));
  }

  /**
   * Method for data manipulation
   */
  getResults() {
    this.resultsTable = [];
    this.currentMonth = this.reviewingResults.currentComparePriorPayeeCalculation[0].calculationReviewMonth;
    this.priorMonth = this.reviewingResults.previousComparePriorPayeeCalculation[0].calculationReviewMonth;
    for (let i = 0; i < this.reviewingResults.currentComparePriorPayeeCalculation.length; i++) {
      let requestObject = {};
      const currentPayee = [];
      const priorPayee = [];
      const absoluteVariance = [];
      const percentageVariance = [];
      currentPayee.push(this.reviewingResults.currentComparePriorPayeeCalculation[i]);
      priorPayee.push(this.reviewingResults.previousComparePriorPayeeCalculation[i]);
      absoluteVariance.push(this.reviewingResults.payeeAbsoluteVarianceDTO[i]);
      percentageVariance.push(this.reviewingResults.payeePercentageVarianceDTO[i]);

      requestObject = {
        id: this.reviewingResults.currentComparePriorPayeeCalculation[i].payToPfinName,
        currentComparePriorPayeeCalculation: currentPayee,
        payeeAbsoluteVarianceDTO: absoluteVariance,
        payeePercentageVarianceDTO: percentageVariance,
        previousComparePriorPayeeCalculation: priorPayee
      };
      this.resultsTable.push(requestObject);
    }
  }

  edit(id: string) {
    this.modalService.open(id);
  }
  view(id: string) {
    this.modalService.open(id);
  }
}
