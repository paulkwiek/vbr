import { Component, OnInit, Input } from '@angular/core';
import { DataTableResource } from '../../../../shared/modules/data-table';
import { ModalService } from '../../../../shared/services/modal.service';
import { ActivatedRoute } from '@angular/router';
import _ from 'lodash';

@Component({
  selector: 'app-financial-review',
  providers: [],
  templateUrl: './financial-review.component.html',
  styleUrls: ['./financial-review.component.scss']
})
export class FinancialReviewComponent implements OnInit {
  dataitemResource;
  dataitems = [];
  dataitemCount = 0;
  loaded = false;
  january;
  item: {};
  @Input() financialReviewResults;
  @Input() payee: boolean;

  constructor(
    private modalService: ModalService,
    private route: ActivatedRoute
  ) { }

  ngOnInit() {
    this.route.snapshot.paramMap.get('id');
    this.dataitemResource = new DataTableResource(this.financialReviewResults);
    this.dataitemResource.count().then(count => (this.dataitemCount = count));
  }

  reloadItems(params) {
    this.dataitemResource
      .query(params)
      .then(dataitems => (this.dataitems = dataitems));
  }
  edit(id: string) {
    this.modalService.open(id);
  }
  view(id: string) {
    this.modalService.open(id);
  }
}
