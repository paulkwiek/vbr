import { Component, OnInit, Input } from '@angular/core';
import { DataTableResource } from '../../../../shared/modules/data-table';
import { ModalService } from '../../../../shared/services/modal.service';
import { ActivatedRoute } from '@angular/router';
import { UtilService } from '../../../../shared/services/util.service';

@Component({
  selector: 'app-summary',
  providers: [],
  templateUrl: './summary.component.html',
  styleUrls: ['./summary.component.scss']
})
export class SummaryComponent implements OnInit {
  dataitemResource;
  dataitems = [];
  dataitemCount = 0;
  loaded = false;
  item: {};
  currentMonth: string;
  priorMonth: string;
  @Input() reviewingResults;
  @Input() compare_prior: boolean;
  summaryResults = [];

  constructor(
    private modalService: ModalService,
    private route: ActivatedRoute,
    private utilService: UtilService
  ) { }

  /**
   * Life cycle hook after component initialization
   */
  ngOnInit() {
    this.route.snapshot.paramMap.get('id');
    this.getResults();
    this.dataitemResource = new DataTableResource(this.summaryResults);
    this.dataitemResource.count().then(count => (this.dataitemCount = count));
  }

  /**
   * reloadItems
   * @param params
   * Method to reload items after any event change
   */
  reloadItems(params) {
    this.getResults();
    this.dataitemResource
      .query(params)
      .then(dataitems => (this.dataitems = dataitems));
  }
  /**
   * Method to manipulate the data
   */
  getResults() {
    this.currentMonth = this.reviewingResults.comparePriorCurrentSummaryReviewCalculation.calculationReviewMonth;
    this.priorMonth = this.reviewingResults.comparePriorPreviousSummaryReviewCalculation.calculationReviewMonth;
    this.summaryResults = [];
    const CPCurrentSummay = [];
    const CPPreviousSummary = [];
    const percentageVariance = [];
    const absVariance = [];
    CPCurrentSummay.push(this.reviewingResults.comparePriorCurrentSummaryReviewCalculation);
    CPPreviousSummary.push(this.reviewingResults.comparePriorPreviousSummaryReviewCalculation);
    percentageVariance.push(this.reviewingResults.percentageVariance);
    absVariance.push(this.reviewingResults.absVariance);

    const resultsObject = {
      comparePriorCurrentSummaryReviewCalculation: CPCurrentSummay,
      comparePriorPreviousSummaryReviewCalculation: CPPreviousSummary,
      percentageVariance: percentageVariance,
      absVariance: absVariance
    };
    this.summaryResults.push(resultsObject);
  }
  edit(id: string) {
    this.modalService.open(id);
  }
  view(id: string) {
    this.modalService.open(id);
  }
}
