import { Component, OnInit, Input } from '@angular/core';
import { DataTableResource } from '../../../../shared/modules/data-table';
import { ModalService } from '../../../../shared/services/modal.service';
import { IndividualReviewCalculation } from '../../../../models/calculation.model';
import { ActivatedRoute } from '@angular/router';
import _ from 'lodash';

@Component({
  selector: 'app-individual-results',
  providers: [],
  templateUrl: './individual-results.component.html',
  styleUrls: ['./individual-results.component.scss']
})
export class IndividualResultsComponent implements OnInit {
  dataitemResource;
  dataitems = [];
  dataitemCount = 0;
  loaded = false;
  payment_types: {};
  item: {};
  @Input() reviewingResults: IndividualReviewCalculation;
  @Input() payee: boolean;
  @Input() line_of_business: boolean;
  @Input() payment_type: boolean;

  constructor(
    private modalService: ModalService,
    private route: ActivatedRoute
  ) { }

  ngOnInit() {
    this.route.snapshot.paramMap.get('id');
    this.dataitemResource = new DataTableResource(this.reviewingResults.individualPayeeReviewCalculations);
    this.dataitemResource.count().then((count: any) => (this.dataitemCount = count));
  }

  reloadItems(params: any) {
    this.dataitemResource
      .query(params)
      .then((dataitems: any) => (this.dataitems = dataitems));
  }
  edit(id: string) {
    this.modalService.open(id);
  }
  view(id: string) {
    this.modalService.open(id);
  }
}
