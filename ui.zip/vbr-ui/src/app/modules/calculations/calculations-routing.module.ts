import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';

import { ReviewingResultsComponent } from './components/reviewingresults/reviewingresults.component';
import { CalculationRunComponent } from './components/calculation-run/calculation_run.component';

const routes: Routes = [
  { path: 'reviewingresults', component: ReviewingResultsComponent },
  { path: 'calculationrun', component: CalculationRunComponent }
];
@NgModule({
  imports: [CommonModule, RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class CalculationsRoutingModule {}
