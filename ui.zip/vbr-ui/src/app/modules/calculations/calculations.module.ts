import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { CalculationsRoutingModule } from './calculations-routing.module';
import { CustomDateParserFormatter } from '../../shared/modules/ui/components/datepicker/customdateparserformatter';
import { NgbDateParserFormatter } from '@ng-bootstrap/ng-bootstrap';
import { ReviewingResultsComponent } from './components/reviewingresults/reviewingresults.component';
import { ResultsComponent } from './components/reviewingresults/results/results.component';
import { CalculationTablesModule } from './tables';
import { CalculationRunComponent } from './components/calculation-run/calculation_run.component';
import { FinancialReviewComponent } from './tables/financial-review/financial-review.component';
import { TableModule } from '../configurations/tables';
import { SharedModule } from 'src/app/shared/shared.module';
import { PipesModule } from 'src/app/shared/pipes/pipes.module';
import { CalculationStatusComponent } from './components/calculation-run/calculation-status/calculation_status.component';
import { CalculationStatusCardComponent } from './components/calculation-run/calculation-status/calculation-status-card/calculation_status_card.component';
import { ErrorStatusComponent } from './components/calculation-run/calculation-status/error-status/error_status.component';
import { ErrorStatusCardComponent } from './components/calculation-run/calculation-status/error-status/error-status-card/error_status_card.component';
import { CalculationRunDataCardComponent } from './components/calculation-run/calculation-run-data-card/calculation_run_data_card.component';
import { CalculationRunTabsComponent } from './components/calculation-run/calculation-run-tabs/calculation_run_tabs.component';
import { StoreModule } from '@ngrx/store';
import { LocalStorageService } from 'src/app/shared/services/localstorage.service';
import * as fromReducer from '../../reducers/tabs.reducer';
import {
  TABS_CONFIG_TOKEN,
  TABS_LOCAL_STORAGE_KEY,
  TABS_STORAGE_KEYS
} from '../calculations/calculations.tokens';
import { storageMetaReducer } from 'src/app/shared/services/storage-metareducer';

export function getTabsConfig(
  saveKeys: string[],
  localStorageKey: string,
  storageService: LocalStorageService
) {
  return {
    metaReducers: [
      storageMetaReducer(saveKeys, localStorageKey, storageService)
    ]
  };
}
@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    CalculationsRoutingModule,
    NgbModule,
    ReactiveFormsModule,
    CalculationTablesModule,
    TableModule,
    SharedModule,
    PipesModule,
    StoreModule.forFeature('tabs', fromReducer.reducer, TABS_CONFIG_TOKEN)
  ],
  declarations: [
    ReviewingResultsComponent,
    ResultsComponent,
    CalculationRunComponent,
    CalculationStatusComponent,
    CalculationStatusCardComponent,
    ErrorStatusComponent,
    ErrorStatusCardComponent,
    CalculationRunDataCardComponent,
    CalculationRunTabsComponent,
    FinancialReviewComponent
  ],
  providers: [
    LocalStorageService,
    { provide: NgbDateParserFormatter, useClass: CustomDateParserFormatter },
    { provide: TABS_LOCAL_STORAGE_KEY, useValue: '__tabs_storage__' },
    { provide: TABS_STORAGE_KEYS, useValue: ['tab'] },
    {
      provide: TABS_CONFIG_TOKEN,
      deps: [TABS_STORAGE_KEYS, TABS_LOCAL_STORAGE_KEY, LocalStorageService],
      useFactory: getTabsConfig
    },
    SharedModule,
    PipesModule
  ]
})
export class CalculationsModule {}
