import { InjectionToken } from '@angular/core';
import { StoreConfig } from '@ngrx/store/src/store_module';
import * as fromReducer from '../../reducers/tabs.reducer';
import * as fromActions from '../../actions/tabs.actions';

export const TABS_STORAGE_KEYS = new InjectionToken<keyof fromReducer.State[]>(
  'TabsStorageKeys'
);
export const TABS_LOCAL_STORAGE_KEY = new InjectionToken<string[]>(
  'TabsStorage'
);
export const TABS_CONFIG_TOKEN = new InjectionToken<
  StoreConfig<fromReducer.State, fromActions.AppActions>
>('TabsConfigToken');
