import {
  Component,
  OnInit,
  Input,
  DoCheck
} from '@angular/core';
import { FormGroup, FormBuilder, FormControl } from '@angular/forms';
import { Observable } from 'rxjs';
import {
  Results,
  ResultsService
} from '../../../../../shared/services/results.service';
import { CalculationService } from '../../../services/calculation.service';

@Component({
  selector: 'app-results',
  templateUrl: './results.component.html',
  styleUrls: ['./results.component.scss'],
  providers: [ResultsService]
})
export class ResultsComponent implements OnInit, DoCheck {
  results: Observable<Results>;
  form: FormGroup;
  summary: boolean;
  defaultAdjustment = 'All Adjustments';
  defaultLineOfBusiness = 'All Lines of Business';
  defaultProductType = 'All Product Types';
  defaultPaymentType = 'All Payment Types';
  @Input() selector: string;
  @Input() reportType: string;
  @Input() reviewingCalculationResults: any;
  reviewingResults = [];
  headers: any;
  adjustment: any;
  line_of_business: any;
  product_type: any;
  name: string;
  checkForData = false;
  checkForYearData = false;
  reviewingResultsByYear = [];

  constructor(
    private resultsService: ResultsService,
    private formBuilder: FormBuilder,
    private calculationService: CalculationService
  ) {
    this.results = this.resultsService.results;

    this.form = new FormGroup({
      adjustment: new FormControl(true),
      product_type: new FormControl(true),
      payment_type: new FormControl(true),
      line_of_business: new FormControl(true)
    });

    this.form = this.formBuilder.group({
      adjustment: true,
      product_type: true,
      line_of_business: true,
      payment_type: true
    });
    this.form.controls['adjustment'].setValue(this.defaultAdjustment, {
      onlySelf: true
    });
    this.form.controls['product_type'].setValue(this.defaultProductType, {
      onlySelf: true
    });
    this.form.controls['payment_type'].setValue(this.defaultPaymentType, {
      onlySelf: true
    });
    this.form.controls['line_of_business'].setValue(
      this.defaultLineOfBusiness,
      {
        onlySelf: true
      }
    );
    this.form.valueChanges.subscribe(value => {
      this.resultsService.updateDropdowns(value.adjustment);
    });
  }
  /**
   * Life cycle hook after initalizing the componnet
   */
  ngOnInit() {
    this.headers = [''];
    this.reviewingResults = this.reviewingCalculationResults;
  }

  /**
   * Life cycle hook after every change
   */
  ngDoCheck() {
    if (
      this.reviewingResults === undefined ||
      this.reviewingResults.length === 0
    ) {
      this.checkForData = false;
    } else {
      this.checkForData = true;
    }
    if (
      this.reviewingResultsByYear === undefined ||
      this.reviewingResultsByYear.length === 0
    ) {
      this.checkForYearData = false;
    } else {
      this.checkForYearData = true;
    }
  }

}
