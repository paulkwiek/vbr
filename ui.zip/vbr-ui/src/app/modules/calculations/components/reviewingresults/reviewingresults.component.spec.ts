import { TestBed, ComponentFixture, async } from '@angular/core/testing';
import { ReviewingResultsComponent } from './reviewingresults.component';
import { CommonModule, CurrencyPipe } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { LoadingModule } from 'src/app/shared/modules/loading/loading.module';
import { RouterTestingModule } from '@angular/router/testing';
import { SharedModule } from '../../../../shared/shared.module';
import { ResultsComponent } from './results/results.component';
import { CalculationTablesModule } from '../../tables/index';
import { Store, StoreModule } from '@ngrx/store';
describe('ReviewingResultsComponent', () => {
    let component: ReviewingResultsComponent;
    let fixture: ComponentFixture<ReviewingResultsComponent>;
    beforeEach(async(() => {
        TestBed.configureTestingModule({
            imports: [CommonModule, FormsModule, ReactiveFormsModule, HttpClientModule, HttpClientTestingModule, LoadingModule, RouterTestingModule, SharedModule, CalculationTablesModule, StoreModule.forRoot({})],
            declarations: [ReviewingResultsComponent, ResultsComponent],
            providers: [CurrencyPipe, Store]
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(ReviewingResultsComponent);
        component = fixture.componentInstance;
        // component.reviewingResults= [];
        fixture.detectChanges();
    });
    it('should create the ReviewingResults Component', () => {
        expect(component).toBeTruthy();
    });
    // it('show() - calling method', () => {
    //     component.show();
    // });

    it('operationsCheck - Equals to false', () => {
        component.operationsMarked = false;
        component.approveOperations();
        // jasmine.clock().tick(10);
        expect(component.operationsCheck).toEqual(false);
    });
    it('crate() -calling method', () => {
        spyOn(component.modalService, 'open');
        const id: any = '1';
        component.create(id);
        expect(component.modalService.open).toHaveBeenCalled();
    });
    it('close() -calling method', () => {
        spyOn(component.modalService, 'close');
        const id: any = '1';
        component.close(id);
        expect(component.modalService.close).toHaveBeenCalled();
    });
    it('save() -calling method', () => {
        spyOn(component.modalService, 'close');
        const id: any = '1';
        component.save(id);
        expect(component.modalService.close).toHaveBeenCalled();
    });
    it('displayResults() - calling method', () => {
        const name = 'Payee';
        const reporttypt = 'Individual';
        component.displayResults(name, reporttypt);
    });
    it('marked - equals to true', () => {
        const event: any = {
            target: {
                checked: true
            }
        };
        component.toggleOperations(event);
        expect(component.operationsMarked).toEqual(true);
    });
    it('enablesummary - equeis to true', () => {
        component.createReport();
        expect(component.enableSummary).toEqual(true);

    });
});
