import { TestBed, ComponentFixture, async } from '@angular/core/testing';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { ResultsComponent } from './results.component';
import { HcscLibSsoModule } from 'hcsc-lib-sso';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AppConfigService } from 'src/app/app-config.service';
import { ResultsService } from 'src/app/shared/services/results.service';

describe('ResultsComponent', () => {
  let component: ResultsComponent;
  let fixture: ComponentFixture<ResultsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
      imports: [
        HcscLibSsoModule,
        FormsModule,
        ReactiveFormsModule,
      ],
      declarations: [ResultsComponent],
      providers: [ResultsService]
    }).compileComponents();
  }));

  beforeEach(() => {
    AppConfigService.settings = {
      'env': {
        'name': 'DEV2'
      },
      'baseUrls': {
        'BASE_URL': 'https://vbr-arrangementconfig-service-dev2.cfaa.hcsctest.net',
        'BASE_URL_CODE_SERVICE': 'https://vbr-code-service-dev2.cfaa.hcsctest.net',
        'BASE_URL_CALCULATION_SERVICE': 'https://vbr-calculation-service-dev2.cfaa.hcsctest.net',
        'BASE_URL_REPORT': 'https://tableau.test.fyiblue.com/views/'
      },
      'reportUrls': {
        'CAP_SUMMARY_REPORT': 'CapSummaryReport_15735714904500/CapSummaryReport?iframeSizedToWindow=true&:embed=y&:showAppBanner=false&:display_count=no&:showVizHome=no',
        'MEMBERSHIP_ERROR_REPORT': 'MembershipErrorReport_15736417170040/MembershipErrorReport?iframeSizedToWindow=true&:embed=y&:showAppBanner=false&:display_count=no&:showVizHome=no',
        'COMPARISON_REPORT_FOR_APPROVED_FINANCIAL_CALCULATION_DATA': 'ComparisonReportforFinancialCalculationData_15735718388110/ComparisonReportforFinancialcalculationData?iframeSizedToWindow=true&:embed=y&:showAppBanner=false&:display_count=no&:showVizHome=no',
        'COMPARISON_REPORT_FOR_PRELIMINARY_RUN_CALCULATION_DATA': 'ComparisonReportforPreliminaryCalculationData_15735719621730/ComparisonReportforPreliminaryCalculationData?iframeSizedToWindow=true&:embed=y&:showAppBanner=false&:display_count=no&:showVizHome=no',
        'COMPARISON_REPORT_FOR_APPROVED_CALCULATION_DATA': '',
        'RETROACTIVITY_SUMMARY_REPORT': '',
        'NM10931_CAP_DISTRIBUTION_REPORT': 'NM10931-CapDistributionReport_15736400047190/NM10931-CAPDISTRIBUTIONREPORT?iframeSizedToWindow=true&:embed=y&:showAppBanner=false&:display_count=no&:showVizHome=no',
        'NM10940_PRELIMINARY_EFT_REGISTER': 'NM10940-PreliminaryEFTRegisterReport/NM10940-PreliminaryCapEFTRegisterReport?iframeSizedToWindow=true&:embed=y&:showAppBanner=false&:display_count=no&:showVizHome=no',
        'NM10940_FINAL_EFT_REGISTER': 'NM10940-FinalEFTRegisterReport_15736399695060/NM10941-FinalEFTRegisterReport?iframeSizedToWindow=true&:embed=y&:showAppBanner=false&:display_count=no&:showVizHome=no',
        'NM10932_FINAL_OPEN_ITEM_REGISTER': ''
      }
    };

    fixture = TestBed.createComponent(ResultsComponent);
    component = fixture.componentInstance;
    component.reviewingCalculationResults = [
      {
        'id': 0,
        'current_members': '5.00%',
        'retro_members': '5.00%',
        'current_reimbursement_amount': '-7.09%',
        'retro_reimbursement_amount': '-7.09%',
        'total_reimbursement_amount': '-7.09%',
        'manual_reimbursement_amount': '-7.09%',
        'current_pmpm': '-0.90%',
        'overall_pmpm': '-0.90%'
      },
      {
        'id': 1,
        'current_members': '5.00%',
        'retro_members': '5.00%',
        'current_reimbursement_amount': '-7.09%',
        'retro_reimbursement_amount': '-7.09%',
        'total_reimbursement_amount': '-7.09%',
        'manual_reimbursement_amount': '-7.09%',
        'current_pmpm': '-0.90%',
        'overall_pmpm': '-0.90%'
      },
      {
        'id': 2,
        'current_members': '5.00%',
        'retro_members': '5.00%',
        'current_reimbursement_amount': '-7.09%',
        'retro_reimbursement_amount': '-7.09%',
        'total_reimbursement_amount': '-7.09%',
        'manual_reimbursement_amount': '-7.09%',
        'current_pmpm': '-0.90%',
        'overall_pmpm': '-0.90%'
      },
      {
        'id': 3,
        'current_members': '5.00%',
        'retro_members': '5.00%',
        'current_reimbursement_amount': '-7.09%',
        'retro_reimbursement_amount': '-7.09%',
        'total_reimbursement_amount': '-7.09%',
        'manual_reimbursement_amount': '-7.09%',
        'current_pmpm': '-0.90%',
        'overall_pmpm': '-0.90%'
      },
      {
        'id': 4,
        'current_members': '5.00%',
        'retro_members': '5.00%',
        'current_reimbursement_amount': '-7.09%',
        'retro_reimbursement_amount': '-7.09%',
        'total_reimbursement_amount': '-7.09%',
        'manual_reimbursement_amount': '-7.09%',
        'current_pmpm': '-0.90%',
        'overall_pmpm': '-0.90%'
      },
      {
        'id': 5,
        'current_members': '5.00%',
        'retro_members': '5.00%',
        'current_reimbursement_amount': '-7.09%',
        'retro_reimbursement_amount': '-7.09%',
        'total_reimbursement_amount': '-7.09%',
        'manual_reimbursement_amount': '-7.09%',
        'current_pmpm': '-0.90%',
        'overall_pmpm': '-0.90%'
      },
      {
        'id': 6,
        'current_members': '5.00%',
        'retro_members': '5.00%',
        'current_reimbursement_amount': '-7.09%',
        'retro_reimbursement_amount': '-7.09%',
        'total_reimbursement_amount': '-7.09%',
        'manual_reimbursement_amount': '-7.09%',
        'current_pmpm': '-0.90%',
        'overall_pmpm': '-0.90%'
      },
      {
        'id': 7,
        'current_members': '5.00%',
        'retro_members': '5.00%',
        'current_reimbursement_amount': '-7.09%',
        'retro_reimbursement_amount': '-7.09%',
        'total_reimbursement_amount': '-7.09%',
        'manual_reimbursement_amount': '-7.09%',
        'current_pmpm': '-0.90%',
        'overall_pmpm': '-0.90%'
      },
      {
        'id': 8,
        'current_members': '5.00%',
        'retro_members': '5.00%',
        'current_reimbursement_amount': '-7.09%',
        'retro_reimbursement_amount': '-7.09%',
        'total_reimbursement_amount': '-7.09%',
        'manual_reimbursement_amount': '-7.09%',
        'current_pmpm': '-0.90%',
        'overall_pmpm': '-0.90%'
      },
      {
        'id': 9,
        'current_members': '5.00%',
        'retro_members': '5.00%',
        'current_reimbursement_amount': '-7.09%',
        'retro_reimbursement_amount': '-7.09%',
        'total_reimbursement_amount': '-7.09%',
        'manual_reimbursement_amount': '-7.09%',
        'current_pmpm': '-0.90%',
        'overall_pmpm': '-0.90%'
      },
      {
        'id': 10,
        'current_members': '5.00%',
        'retro_members': '5.00%',
        'current_reimbursement_amount': '-7.09%',
        'retro_reimbursement_amount': '-7.09%',
        'total_reimbursement_amount': '-7.09%',
        'manual_reimbursement_amount': '-7.09%',
        'current_pmpm': '-0.90%',
        'overall_pmpm': '-0.90%'
      }
    ];
    component.reviewingResultsByYear = [
      {
        'id': 0,
        'total_mem_count': [{
          'id': 0,
          'jan_2019': '1,000'
        },
        {
          'id': 1,
          'feb_2019': '1,000'
        },
        {
          'id': 2,
          'mar_2019': '1,000'
        },
        {
          'id': 3,
          'apr_2019': '1,000'
        },
        {
          'id': 4,
          'may_2019': '1,000'
        },
        {
          'id': 5,
          'jun_2019': '1,000'
        },
        {
          'id': 6,
          'jul_2019': '1,000'
        },
        {
          'id': 7,
          'aug_2019': '1,000'
        },
        {
          'id': 8,
          'sep_2019': '1,000'
        },
        {
          'id': 9,
          'oct_2019': '1,000'
        },
        {
          'id': 10,
          'nov_2019': '1,000'
        },
        {
          'id': 11,
          'dec_2019': '1,000'
        }
        ]
      }
    ];
    component.reviewingResults = component.reviewingCalculationResults;
    component.defaultAdjustment = 'All Adjustments';
    component.defaultLineOfBusiness = 'All Lines of Business';
    component.defaultProductType = 'All Product Types';
    component.defaultPaymentType = 'All Payment Types';
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('ngOnInit - component should have been called', () => {
    component.ngOnInit();
  });
  
  it('ngDoCheck - checkForData value checking false', () => {
    component.reviewingResults = undefined;
    component.ngDoCheck();
    expect(component.checkForData).toEqual(false);
  });

  it('ngDoCheck - checkForData value checking false', () => {
    component.reviewingResults.length = 0;
    component.ngDoCheck();
    expect(component.checkForData).toEqual(false);
  });

  it('ngDoCheck - checkForData value checking true', () => {
    component.reviewingResults !== [undefined || 0];
    component.ngDoCheck();
    expect(component.checkForData).toEqual (true);
  });

  it('ngDoCheck - checkForYearData value checking false', () => {
    component.reviewingResultsByYear = undefined;
    component.ngDoCheck();
    expect(component.checkForYearData).toEqual(false);
  });

  it('ngDoCheck - checkForYearData value checking false', () => {
    component.reviewingResultsByYear.length = 0;
    component.ngDoCheck();
    expect(component.checkForYearData).toEqual(false);
  });
 
  it('ngDoCheck - checkForYearData value checking true', () => {
    component.reviewingResultsByYear.length >= 1;
    component.ngDoCheck();
    expect(component.checkForYearData).toEqual(true);
  })
  

});
