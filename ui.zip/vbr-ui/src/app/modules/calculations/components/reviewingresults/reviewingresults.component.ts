import { Component, OnInit, Input, ViewChild, OnDestroy, Inject } from '@angular/core';
import { formatDate, CurrencyPipe } from '@angular/common';
import { ModalService } from '../../../../shared/services/modal.service';
import { ReviewCalculationRunNames, IndividualReviewCalculation, Errors, ComparePriorReviewCalculationResults } from '../../../../models/calculation.model';
import { CalculationService } from '../../services/calculation.service';
import { ResultsComponent } from './results/results.component';
import { LoadingService } from 'src/app/shared/modules/loading/loading.module';
import { ActivatedRoute, Params } from '@angular/router';
import { UserCacheService } from '../../../../shared/services/user-cache.service';
import { SharedService } from '../../../../shared/services/shared.service';
import { CodeSetValueItems } from '../../../../models/shared.model';
import { ExcelService } from '../../../../shared/services/excel.service';
import { UtilService } from 'src/app/shared/services/util.service';
import { AuthService } from '../../../../shared/services/auth.service';
import { CALC_OP_APPROVAL_ROLES, CALC_FIN_APPROVAL_ROLES } from '../../../../shared/constants/app.constants';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-reviewingresults',
  templateUrl: './reviewingresults.component.html',
  styleUrls: ['./reviewingresults.component.scss']
})
export class ReviewingResultsComponent implements OnInit, OnDestroy {
  errorMsgList: Errors;
  isErrorMsgDisplay: boolean;
  corporateEntityCode: string;
  reviewCalculationRunNames: ReviewCalculationRunNames;
  approveCheck: boolean;
  approveFinanceCheck: boolean;
  reviewingCalculationResults: any;
  individualReviewCalculation: IndividualReviewCalculation;
  comparePriorReviewResults: ComparePriorReviewCalculationResults;
  approvalStatus: any;
  financeApprovalStatusDescription = 'N/A';
  operationalApprovalStatusDescription: any;
  operationsApprovedBy = '';
  operationsApprovedTime: any;
  financeApprovedBy = '';
  financeApprovedTime: any;
  operationalApprovalSubmitStatus: any;
  financeApprovalSubmitStatus: any;
  financeSubmitted = false;
  operationsSubmitted = false;

  individualSummaryAttributes = [];
  workBook: any;
  fieldsToExclude = ['calculationReviewMonth', 'payToPfinName'];
  corporateEntityDescription: string;

  constructor(
    public modalService: ModalService,
    private loadingService: LoadingService,
    private userCacheService: UserCacheService,
    private calculationService: CalculationService,
    private route: ActivatedRoute,
    private sharedService: SharedService,
    private excelService: ExcelService,
    private currencyPipe: CurrencyPipe,
    private utilService: UtilService,
    private authService: AuthService,
    // @Inject('env') public env: any
  ) {
    this.sharedService.getCorpEntityCode().subscribe(data => this.corporateEntityCode = data);

    this.sharedService.getCorpEntityDescription().subscribe(data => this.corporateEntityDescription = data);
  }
  reportTypes: CodeSetValueItems;
  reportType: string;
  calculationRun: string;
  selector: string;
  operationsMarked: boolean;
  financeMarked: boolean;
  operationsCheck: boolean;
  enableSummary = false;
  financeCheck: boolean;
  showResults: boolean;
  @Input() calculationStatus;

  reviewResults = [
    {
      name: 'Summary'
    },
    {
      name: 'Payee'
    }
    // {
    //   name: 'Line of Business'
    // },
    // {
    //   name: 'Payment Type'
    // }
  ];
  selectedItem: string;
  @ViewChild('nameChange') nameChange: ResultsComponent;
  reviewingResults: any;
  processPeriodDate: string;
  checkFinApprovalAuthRoles: any;
  checkOpApprovalAuthRoles: any;
  env = environment;
  /**
   * ngOnInit
   * Lifecycle hook called on initalization of component
   */
  ngOnInit() {
    this.checkFinApprovalAuthRoles = this.env.SSO_CONFIG.enableSSO ? !this.authService.isAuthorized(CALC_FIN_APPROVAL_ROLES) : false;
    this.checkOpApprovalAuthRoles = this.env.SSO_CONFIG.enableSSO ? !this.authService.isAuthorized(CALC_OP_APPROVAL_ROLES) : false;
    this.operationsCheck = false;
    this.financeCheck = false;
    this.financeMarked = false;
    this.operationsMarked = false;
    this.selectedItem = 'Summary';
    this.getReportTypeList();
    this.getProcessMonth();
  }

  /**
   * getReportTypeList
   * Method to list all the report types from backend
   */
  getReportTypeList() {
    this.sharedService.getCodeValues('CALCREPORTTYPE').subscribe((data) => {
      this.reportTypes = data;

    },
      error => {
        console.log(error);
      });
  }

  /* Method : getprocessingmonth
    * This method is used to retrieve the processPeriodDate value.
  */
  getProcessMonth() {
    this.loadingService.show();
    this.calculationService.getProcessingMonth(this.corporateEntityCode).subscribe(
      (data) => {
        this.loadingService.hide();
        this.processPeriodDate = data.processPeriodDate;
        this.getReviewCalculationRunName(this.processPeriodDate);
      },
      error => {
        this.loadingService.hide();
      }
    );
  }

  /* Method : getReviewCalculationRunName
    * This method is used to retrieve the Review Calculation Run Name based on corporateEntityCode and processPeriodDate
    */
  getReviewCalculationRunName(processPeriodDate: string) {
    const reqParam: any = {
      'corporateEntityCode': this.corporateEntityCode,
      'processPeriodDate': processPeriodDate
    };
    this.loadingService.show();
    this.calculationService.getReviewCalculationRunName(reqParam).subscribe((data: ReviewCalculationRunNames) => {
      this.loadingService.hide();
      this.reviewCalculationRunNames = data;
    },
      (error: any) => {
        this.loadingService.hide();
      });
  }

  /**
   * approveOperations
   *
   * Method to submit operations approval request
   */
  approveOperations() {
    if (this.operationsMarked === true) {
      this.loadingService.show();
      this.calculationService.submitOperationalApproval(this.generateOperationalApproveRequest()).subscribe((data: any) => {
        this.loadingService.hide();
        this.operationalApprovalSubmitStatus = data;
        this.operationsSubmitted = true;
        if (this.operationalApprovalSubmitStatus != null && this.operationalApprovalSubmitStatus != undefined) {
          this.operationalApprovalStatusDescription = this.operationalApprovalSubmitStatus.calculationRequestDTO.calculationRequestStatusCodeDescription;
          this.operationsApprovedBy = this.operationalApprovalSubmitStatus.calculationRequestDTO.updateUserId;
          this.operationsApprovedTime = this.operationalApprovalSubmitStatus.calculationRequestDTO.updateRecordTimestamp;
          this.operationsMarked = false;
        }
      },
        (error: any) => {
          this.handleErrorResponse(error);
        });
    }
  }

  /**
   * generateOperationalApproveRequest
   *
   * Method to generate operations approval request params
   */
  generateOperationalApproveRequest() {
    const reqParam: any = {
      'calculationRequestId': this.getSelectedRunId(),
      'createUserId': this.userCacheService.getUserCacheData('USER_ID'),
      'updateUserId': this.userCacheService.getUserCacheData('USER_ID'),
      'createRecordTimestamp': null,
      'updateRecordTimestamp': null,
      'warningState': false
    };
    return reqParam;
  }


  /**
  * approveFinance
  *
  * Method to submit finance approval request
  */
  approveFinance() {
    this.loadingService.show();
    setTimeout(() => {
      this.financeCheck = true;
    }, 3000);
    this.calculationService.submitFinanceApproval(this.generateFinanceApproveRequest()).subscribe((data: any) => {
      this.loadingService.hide();
      this.financeApprovalSubmitStatus = data;
      this.showResults = true;
      this.financeSubmitted = true;
      if (this.financeApprovalSubmitStatus != null && this.financeApprovalSubmitStatus != undefined) {
        if (this.financeApprovalSubmitStatus.financeRequestDTO.financeRequestStatusCodeDescription != null) {
          this.financeApprovalStatusDescription = this.financeApprovalSubmitStatus.financeRequestDTO.financeRequestStatusCodeDescription;
        }
        this.financeApprovedBy = this.financeApprovalSubmitStatus.financeRequestDTO.updateUserId;
        this.financeApprovedTime = this.financeApprovalSubmitStatus.financeRequestDTO.updateRecordTimestamp;
        this.financeMarked = false;
      }

    },
      (error: any) => {
        this.handleErrorResponse(error);
      });

  }

  /**
    * generateFinanceApproveRequest
    *
    * Method to generate finance approval request params
    */
  generateFinanceApproveRequest() {
    const reqParam: any = {
      'corporateEntityCode': this.corporateEntityCode,
      'processPeriodDate': this.processPeriodDate,
      'createUserId': this.userCacheService.getUserCacheData('USER_ID'),
      'updateUserId': this.userCacheService.getUserCacheData('USER_ID'),
      'createRecordTimestamp': null,
      'updateRecordTimestamp': null
    };
    return reqParam;
  }

  create(id: string) {
    this.modalService.open(id);
  }

  close(id: string) {
    this.modalService.close(id);
  }
  save(id: string) {
    this.modalService.close(id);
  }

  /**
   * Method to create report based on calculation run and report type
   */
  createReport() {
    this.clearErrorMessage();
    this.displayResults('Summary', this.reportType);
    this.getReviewingResults();
  }

  /**
   * Method to display results
   * @param name
   * @param report
   */
  displayResults(name: string, report: string) {
    this.selector = name;
    this.selectedItem = name;
    this.reportType = report;
  }

  /* Method : getReviewingResults
   * This method is used to call service API based on the report selection
   */
  getReviewingResults() {
    this.clearErrorMessage();
    this.sharedService.clearToasts();
    this.loadingService.show();
    this.calculationService.getReviewCalculationResults(this.generateReviewCalcRequest(), this.reportType).subscribe((data: IndividualReviewCalculation) => {
      this.loadingService.hide();
      this.reviewingCalculationResults = data;
      this.showResults = true;
    },
      (error: any) => {
        this.handleErrorResponse(error);
      });
  }

  /* Method : generateReviewCalcRequest
   * This method is used to generate review calculation object
   */
  generateReviewCalcRequest() {
    const reqParam: any = {
      'calculationRunName': this.calculationRun,
      'corporateEntityCode': this.corporateEntityCode,
      'processPeriodDate': this.processPeriodDate
    };
    return reqParam;
  }

  getSelectedRunId() {
    let selectedRunId;
    this.reviewCalculationRunNames.reviewCalculationRunNames.forEach(element => {
      if (this.calculationRun === element.calculationRunName) {
        selectedRunId = element.calculationRequestId;
      }
    });
    return selectedRunId;
  }

  /* Method : generateCalcAprrovalStatusRequest
   * This method is used to generate calculation run approval status
   */
  generateCalcAprrovalStatusRequest() {

    const reqParam: any = {
      'calculationRequestId': this.getSelectedRunId(),
      'corporateEntityCode': this.corporateEntityCode,
      'processPeriodDate': this.processPeriodDate
    };
    return reqParam;
  }
  /* Method : getReviewCalcResultIndividual
  * This method is used to retrieve the Review Calculation results for individual report
  */
  getCalcApprovalStatus() {
    this.loadingService.show();
    this.calculationService.getCalcApprovalStatus(this.generateCalcAprrovalStatusRequest()).subscribe((data: any) => {
      this.loadingService.hide();
      this.approvalStatus = data;
      if (this.approvalStatus != null && this.approvalStatus != undefined) {
        if (this.approvalStatus.operationalApprovalStatus.statusDescription != null) {
          this.operationalApprovalStatusDescription = this.approvalStatus.operationalApprovalStatus.statusDescription;
        }
        if (this.approvalStatus.financeApprovalStatus.statusDescription != null) {
          this.financeApprovalStatusDescription = this.approvalStatus.financeApprovalStatus.statusDescription;
        }
        this.operationsMarked = this.approvalStatus.operationalApprovalStatus.isOpenForApproval;
        this.financeMarked = this.approvalStatus.financeApprovalStatus.isOpenForApproval;
        this.operationsApprovedBy = this.approvalStatus.operationalApprovalStatus.approvedBy;
        this.operationsApprovedTime = this.approvalStatus.operationalApprovalStatus.approvedTime;
        this.financeApprovedBy = this.approvalStatus.financeApprovalStatus.approvedBy;
        this.financeApprovedTime = this.approvalStatus.financeApprovalStatus.approvedTime;
      }
    },
      (error: any) => {
        this.handleErrorResponse(error);
      });
  }

handleErrorResponse(error: any) {
  this.sharedService.clearToasts();
  this.loadingService.hide();
  // on failure, call method to display error
  this.sharedService.handleErrorSuccessWarningInfo('FAILURE', error, 'Review Results Warnings');
}

  toggleOperations(e) {
    this.operationsCheck = e.target.checked;
  }
  toggleFinance(e) {
    this.financeCheck = e.target.checked;
  }
  /**
   * Method to clear error messages
   */
  clearErrorMessage() {
    this.showResults = false;
    this.isErrorMsgDisplay = false;
  }

  /**
   * Method called on change of report type
   */
  validateReportType() {
    this.showResults = false;
  }

  /**
   * Method - generateReport
   * This method is called when user click on download button
   */
  generateReport() {
    switch (this.reportType) {
      case 'INDV':
        this.mapKeyName();  // based on the key the actual names are displayed in worksheet
        this.workBook = this.excelService.generateWorkBook(); // Generate the Workbook
        this.individualSummaryReport();
        this.individualPayeeReport();
        this.excelService.downloadFile(this.workBook, 'Review Calc Results_Report type-Individual');
        break;
      case 'CMPP':
        this.mapKeyName();
        this.workBook = this.excelService.generateWorkBook();
        this.comparePriorSummaryReport();
        this.comparePriorPayeeReport();
        this.excelService.downloadFile(this.workBook, 'Review Calc Results_Report type-Compare Prior');
        break;
    }
  }
  /**
   * Method - individualSummaryReport
   * This method is used to create the worksheet(Summary) in workbook for report type 'Individual'.
   * Define the column header, title & formating the data in sheet based on API response
   * Generating work sheet for Summary
   */
  individualSummaryReport() {
    this.excelService.generateWorkSheet(this.workBook, 'Summary');
    const title = 'Processing Period - ' + this.reviewingCalculationResults.calculationReviewMonth;
    const headers = ['User ID', 'Date', 'Calculation Run Name', 'Report Type', 'Attributes', 'Calculation Results'];
    const summaryData = this.formatDataForIndividualSummaryReport();
    this.workBook = this.excelService.generateExcel(this.workBook, 'Summary', title, headers, summaryData, 'A1:F1', [15, 15, 25, 15, 30, 25]);
  }
  /**
   * Method - formatDataForIndividualSummaryReport
   * This method is used to create the list of rows required for Individual summary Report
   * and updating the common column fields
   */
  formatDataForIndividualSummaryReport() {
    const individualSummaryArr = [];
    this.createIndividualRecordRowForSummary(this.reviewingCalculationResults.individualSummaryReviewCalculation, individualSummaryArr);
    this.updateOtherReportInformation(individualSummaryArr);
    return individualSummaryArr;
  }
  /**
   * Method - createIndividualRecordRowForSummary
   * This method is used to create the rows and convert the currency field if required
   */
  createIndividualRecordRowForSummary(resultData: any, dataContainer: any) {
    dataContainer.push(['', '', '', '', this.getkeyValue('currentMembers'), resultData.currentMembers]);
    dataContainer.push(['', '', '', '', this.getkeyValue('retroMembers'), resultData.retroMembers]);
    dataContainer.push(['', '', '', '', this.getkeyValue('currentReimbursementAmount'), this.updateCurrencySign(resultData.currentReimbursementAmount)]);
    dataContainer.push(['', '', '', '', this.getkeyValue('retroReimbursementAmount'), this.updateCurrencySign(resultData.retroReimbursementAmount)]);
    dataContainer.push(['', '', '', '', this.getkeyValue('totalReimbursementAmount'), this.updateCurrencySign(resultData.totalReimbursementAmount)]);
  }
  /**
   * Method - individualPayeeReport
   * This method is used to create the worksheet(Payee) in workbook for report type 'Individual'.
   * Define the column header, title & formating the data in sheet based on API response
   * Generating work sheet for Payee
   */
  individualPayeeReport() {
    this.excelService.generateWorkSheet(this.workBook, 'Payee');
    const title = 'Processing Period - ' + this.reviewingCalculationResults.calculationReviewMonth;
    const headers = ['User ID', 'Date', 'Calculation Run Name', 'Report Type', 'Payee', 'Attributes', 'Calculation Results'];
    const summaryData = this.formatDataForIndividualPayeeReport();
    this.workBook = this.excelService.generateExcel(this.workBook, 'Payee', title, headers, summaryData, 'A1:G1', [15, 15, 20, 15, 15, 30, 25]);
  }
  /**
* Method - formatDataForIndividualPayeeReport
* This method is used to create the list of rows required for Individual payee Report
* and updating the common column fields
*/
  formatDataForIndividualPayeeReport() {
    const individualPayeeArr = [];
    this.createIndividualRecordRowForPayee(this.reviewingCalculationResults.individualPayeeReviewCalculations, individualPayeeArr);
    this.updateOtherReportInformation(individualPayeeArr);
    return individualPayeeArr;
  }
  /**
   * Method - createIndividualRecordRowForPayee
   * This method is used to create the dats rows and convert the currency field if required for Individual payee Report
   */
  createIndividualRecordRowForPayee(resultData: any, dataContainer: any) {
    if (resultData != '') {
      const payeeListLength = resultData.length;
      if (payeeListLength > 0) {
        for (let i = 0; i < payeeListLength; i++) {
          dataContainer.push(['', '', '', '', resultData[i].payToPfinName, this.getkeyValue('currentMembers'), resultData[i].currentMembers]);
          dataContainer.push(['', '', '', '', '', this.getkeyValue('retroMembers'), resultData[i].retroMembers]);
          dataContainer.push(['', '', '', '', '', this.getkeyValue('currentReimbursementAmount'), this.updateCurrencySign(resultData[i].currentReimbursementAmount)]);
          dataContainer.push(['', '', '', '', '', this.getkeyValue('retroReimbursementAmount'), this.updateCurrencySign(resultData[i].retroReimbursementAmount)]);
          dataContainer.push(['', '', '', '', '', this.getkeyValue('totalReimbursementAmount'), this.updateCurrencySign(resultData[i].totalReimbursementAmount)]);
          dataContainer.push(['', '', '', '', '', this.getkeyValue('manualAdjustmentAmount'), this.updateCurrencySign(resultData[i].manualAdjustmentAmount)]);
          dataContainer.push(['', '', '', '', '', this.getkeyValue('currentPMPM'), this.updateCurrencySign(resultData[i].currentPMPM)]);
          dataContainer.push(['', '', '', '', '', this.getkeyValue('overallPMPM'), this.updateCurrencySign(resultData[i].overallPMPM)]);
        }
      }
    }
  }
  /**
   * Method - comparePriorSummaryReport
   * This method is used to create the worksheet(summary) in workbook for report type 'Compare Prior'.
   * Define the column header, title & formating the data in sheet based on API response
   * Generating work sheet for summary
   */
  comparePriorSummaryReport() {
    this.excelService.generateWorkSheet(this.workBook, 'Summary');
    const title = 'Processing Period - ' + this.reviewingCalculationResults.comparePriorSummaryDTO.comparePriorCurrentSummaryReviewCalculation.calculationReviewMonth;
    const headers = ['User ID', 'Date', 'Calculation Run Name', 'Report Type', 'Attributes',
      'Processing Period (' + this.reviewingCalculationResults.comparePriorSummaryDTO.comparePriorPreviousSummaryReviewCalculation.calculationReviewMonth + ') - Approved',
      'Processing Period (' + this.reviewingCalculationResults.comparePriorSummaryDTO.comparePriorCurrentSummaryReviewCalculation.calculationReviewMonth + ') - Unapproved', '% Var', 'Abs Var'];
    const summaryData = this.formatDataForComparePriorSummaryReport();
    this.workBook = this.excelService.generateExcel(this.workBook, 'Summary', title, headers, summaryData, 'A1:I1', [10, 10, 20, 10, 20, 20, 20]);
  }
  /**
   * Method - formatDataForComparePriorSummaryReport
   * This method is used to create the 'Summary' data rows for 'Compare Prior' Report
   */
  formatDataForComparePriorSummaryReport() {
    const comparePriorSummaryArr = [];
    this.createComparePriorRecordRowForSummary(this.reviewingCalculationResults.comparePriorSummaryDTO, comparePriorSummaryArr);
    this.updateOtherReportInformation(comparePriorSummaryArr);
    return comparePriorSummaryArr;
  }
  /**
   * Method - createComparePriorRecordRowForSummary
   * This method is used to create the rows and convert the currency field if required
   */
  createComparePriorRecordRowForSummary(resultData: any, dataContainer: any) {
    const previousMonth = resultData.comparePriorPreviousSummaryReviewCalculation;
    const currentMonth = resultData.comparePriorCurrentSummaryReviewCalculation;
    const percentageVariance = resultData.percentageVariance;
    const absVariance = resultData.absVariance;
    dataContainer.push(['', '', '', '', this.getkeyValue('currentMembers'), previousMonth.currentMembers, currentMonth.currentMembers, percentageVariance.currentMembersVariance, absVariance.currentMembersVariance]);
    dataContainer.push(['', '', '', '', this.getkeyValue('retroMembers'), previousMonth.retroMembers, currentMonth.retroMembers, percentageVariance.retroMembersVariance, absVariance.retroMembersVariance]);
    dataContainer.push(['', '', '', '', this.getkeyValue('currentReimbursementAmount'), this.updateCurrencySign(previousMonth.currentReimbursementAmount), this.updateCurrencySign(currentMonth.currentReimbursementAmount), percentageVariance.currentReimbursementAmountVariance, this.updateCurrencySign(absVariance.currentReimbursementAmountVariance)]);
    dataContainer.push(['', '', '', '', this.getkeyValue('retroReimbursementAmount'), this.updateCurrencySign(previousMonth.retroReimbursementAmount), this.updateCurrencySign(currentMonth.retroReimbursementAmount), percentageVariance.retroReimbursementAmountVariance, this.updateCurrencySign(absVariance.retroReimbursementAmountVariance)]);
    dataContainer.push(['', '', '', '', this.getkeyValue('totalReimbursementAmount'), this.updateCurrencySign(previousMonth.totalReimbursementAmount), this.updateCurrencySign(currentMonth.totalReimbursementAmount), percentageVariance.totalReimbursementAmountVariance, this.updateCurrencySign(absVariance.totalReimbursementAmountVariance)]);

  }
  /**
   * Method - comparePriorPayeeReport
   * This method is used to create the worksheet(payee) in workbook for report type 'Compare Prior'.
   * Define the column header, title & formating the data in sheet based on API response
   * Generating work sheet for payee
   */
  comparePriorPayeeReport() {
    this.excelService.generateWorkSheet(this.workBook, 'Payee');
    const title = 'Processing Period - ' + this.reviewingCalculationResults.comparePriorPayeeDTO.currentComparePriorPayeeCalculation[0].calculationReviewMonth;
    const headers = ['User ID', 'Date', 'Calculation Run Name', 'Report Type', 'Payee', 'Attributes',
      'Processing Period (' + this.reviewingCalculationResults.comparePriorPayeeDTO.previousComparePriorPayeeCalculation[0].calculationReviewMonth + ') - Approved',
      'Processing Period (' + this.reviewingCalculationResults.comparePriorPayeeDTO.currentComparePriorPayeeCalculation[0].calculationReviewMonth + ') - Unapproved', '% Var', 'Abs Var'];
    const summaryData = this.formatDataForComparePriorPayeeReport();
    this.workBook = this.excelService.generateExcel(this.workBook, 'Payee', title, headers, summaryData, 'A1:J1', [10, 10, 20, 10, 30, 20, 20, 10, 10]);
  }

  /**
   * Method - formatDataForComparePriorPayeeReport
   * This method is used to create the 'Payee' data rows for 'Compare Prior' Report
   */
  formatDataForComparePriorPayeeReport() {
    const comparePriorPayeeArr = [];
    this.createComparePriorRecordRowForPayee(this.reviewingCalculationResults.comparePriorPayeeDTO, comparePriorPayeeArr);
    this.updateOtherReportInformation(comparePriorPayeeArr);
    return comparePriorPayeeArr;
  }

  /**
   * Method - createComparePriorRecordRowForPayee
   * This method is used to create the dats rows and convert the currency field if required for Individual payee Report
   */
  createComparePriorRecordRowForPayee(resultData: any, dataContainer: any) {
    if (resultData != '') {
      const previousMonth = resultData.previousComparePriorPayeeCalculation;
      const currentMonth = resultData.currentComparePriorPayeeCalculation;
      const percentageVariance = resultData.payeePercentageVarianceDTO;
      const absVariance = resultData.payeeAbsoluteVarianceDTO;
      const payeeListLength = resultData.previousComparePriorPayeeCalculation.length;
      if (payeeListLength > 0) {
        for (let i = 0; i < payeeListLength; i++) {
          dataContainer.push(['', '', '', '', currentMonth[i].payToPfinName, this.getkeyValue('currentMembers'), previousMonth[i].currentMembers, currentMonth[i].currentMembers, percentageVariance[i].currentMembersVariance, absVariance[i].currentMembersVariance]);
          dataContainer.push(['', '', '', '', '', this.getkeyValue('retroMembers'), previousMonth[i].retroMembers, currentMonth[i].retroMembers, percentageVariance[i].retroMembersVariance, absVariance[i].retroMembersVariance]);
          dataContainer.push(['', '', '', '', '', this.getkeyValue('currentReimbursementAmount'), this.updateCurrencySign(previousMonth[i].currentReimbursementAmount), this.updateCurrencySign(currentMonth[i].currentReimbursementAmount), this.updateCurrencySign(percentageVariance[i].currentReimbursementAmountVariance), this.updateCurrencySign(absVariance[i].currentReimbursementAmountVariance)]);
          dataContainer.push(['', '', '', '', '', this.getkeyValue('retroReimbursementAmount'), this.updateCurrencySign(previousMonth[i].retroReimbursementAmount), this.updateCurrencySign(currentMonth[i].retroReimbursementAmount), this.updateCurrencySign(percentageVariance[i].retroReimbursementAmountVariance), this.updateCurrencySign(absVariance[i].retroReimbursementAmountVariance)]);
          dataContainer.push(['', '', '', '', '', this.getkeyValue('totalReimbursementAmount'), this.updateCurrencySign(previousMonth[i].totalReimbursementAmount), this.updateCurrencySign(currentMonth[i].totalReimbursementAmount), this.updateCurrencySign(percentageVariance[i].totalReimbursementAmountVariance), this.updateCurrencySign(absVariance[i].totalReimbursementAmountVariance)]);
          dataContainer.push(['', '', '', '', '', this.getkeyValue('manualAdjustmentAmount'), this.updateCurrencySign(previousMonth[i].manualAdjustmentAmount), this.updateCurrencySign(currentMonth[i].manualAdjustmentAmount), this.updateCurrencySign(percentageVariance[i].manualReimbursementAmountVariance), this.updateCurrencySign(absVariance[i].manualReimbursementAmountVariance)]);
          dataContainer.push(['', '', '', '', '', this.getkeyValue('currentPMPM'), this.updateCurrencySign(previousMonth[i].currentPMPM), this.updateCurrencySign(currentMonth[i].currentPMPM), this.updateCurrencySign(percentageVariance[i].currentPMPMVariance), this.updateCurrencySign(absVariance[i].currentPMPMVariance)]);
          dataContainer.push(['', '', '', '', '', this.getkeyValue('overallPMPM'), this.updateCurrencySign(previousMonth[i].overallPMPM), this.updateCurrencySign(currentMonth[i].overallPMPM), this.updateCurrencySign(percentageVariance[i].overAllPMPMVariance), this.updateCurrencySign(absVariance[i].overAllPMPMVariance)]);
        }
      }
    }
  }

  /**
  * Method - mapKeyName
  * This method is used to map the API response key with actual name in worksheet
  */
  mapKeyName() {
    this.individualSummaryAttributes['currentMembers'] = 'Current Members';
    this.individualSummaryAttributes['retroMembers'] = 'Retro Members';
    this.individualSummaryAttributes['currentReimbursementAmount'] = 'Current Reimbutsement Amount';
    this.individualSummaryAttributes['retroReimbursementAmount'] = 'Retro Reimbursement Amount';
    this.individualSummaryAttributes['totalReimbursementAmount'] = 'Total Reimbursement Amount';
    this.individualSummaryAttributes['manualAdjustmentAmount'] = 'Manual Reimbursement Amount';
    this.individualSummaryAttributes['currentPMPM'] = 'Current PMPM';
    this.individualSummaryAttributes['overallPMPM'] = 'Overall PMPM';

  }
  /**
   * Method - mapKeyName
   * This method is used to get the API response key with actual name in worksheet
   */
  getkeyValue(key: string) {
    return this.individualSummaryAttributes[key];
  }
  /**
   * Method - updateCurrencySign
   * This method is used to update the currency sign for the  mentioned cells in the work sheet
   */
  updateCurrencySign(value: number) {
    return this.currencyPipe.transform(value, 'USD');
  }

  /**
   * Method - updateOtherReportInformation
   * This method is used to update the common information like creator user id,
   * created date, Run name and report type in Individual and compare prior Report
   */
  updateOtherReportInformation(otherInfo: any) {
    otherInfo[0][0] = this.userCacheService.getUserCacheData('USER_ID');
    otherInfo[0][1] = formatDate(new Date(), 'MM/dd/yyyy', 'en');
    otherInfo[0][2] = this.calculationRun;
    otherInfo[0][3] = this.getReportTypeDescription();
  }

  /**
   * Method - getReportTypeDescription
   * This method is used to retrieve the Report Type Description
   */
  getReportTypeDescription() {
    return this.utilService.getDataFromCode(this.reportType, this.reportTypes).codeValueDescription;
  }

  /**
   * Life cycle hook after destory
   */
  ngOnDestroy() {
    this.sharedService.clearToasts();
  }
}


