import {
  Component,
  OnInit,
  Input,
  OnChanges,
  DoCheck,
  Output,
  EventEmitter
} from '@angular/core';
import { Tab } from '../../../../../models/calculation.model';
import _ from 'lodash';
import { Store } from '@ngrx/store';
import { AppState } from '../../../../../store/app.state';
import { TabChangedAction } from '../../../../../store/calculations/calculations.actions';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-calculation-run-tabs',
  templateUrl: './calculation_run_tabs.component.html',
  styleUrls: ['./calculation_run_tabs.component.scss']
})
export class CalculationRunTabsComponent implements OnInit, OnChanges, DoCheck {
  selectedTab: Observable<string>;
  @Input() tabs: Tab[];
  @Output() tabSelected = new EventEmitter<Tab>();
  calculationRunData = [
    { type: 'Line Of Business', name: 'Medicare Advantage - Daily' },
    { type: 'Payment Types', name: 'HME 2' },
    { type: 'Payees', name: 'HME 2 Specialist Inc' },
    { type: 'Product Types', name: 'MAHMO1' }
  ];
  constructor(private store: Store<AppState>) {
    this.selectedTab = this.store.select(
      state => state.calculations.selectedTab
    );
  }

  ngOnInit() {}

  ngOnChanges() {}

  ngDoCheck() {}

  onChangeTab(id) {
    this.store.dispatch(new TabChangedAction(id));
  }
}
