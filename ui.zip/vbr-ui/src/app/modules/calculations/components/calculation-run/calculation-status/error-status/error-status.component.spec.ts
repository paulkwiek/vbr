import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { DataTableModule } from 'src/app/shared/modules/data-table';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { AppConfigService } from 'src/app/app-config.service';
import { ErrorStatusComponent } from './error_status.component';
import { CalculationService } from 'src/app/modules/calculations/services/calculation.service';
import { LoadingModule } from 'src/app/shared/modules/loading/loading.module';
import {ErrorStatusCardComponent } from '../error-status/error-status-card/error_status_card.component';


export function initializeApp(appConfigService: AppConfigService) {
    return (): Promise<any> => {
        return appConfigService.load();
    };
}

describe('ErrorStatusComponent', () => {
    let component: ErrorStatusComponent;
    let fixture: ComponentFixture<ErrorStatusComponent>;

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            imports: [
                CommonModule,
                FormsModule,
                ReactiveFormsModule,
                NgbModule,
                DataTableModule,
                RouterTestingModule,
                HttpClientTestingModule,
                LoadingModule
            ],
            declarations: [
                ErrorStatusComponent, ErrorStatusCardComponent
            ],
            providers: [CalculationService]
        }).compileComponents();
    }));

    beforeEach(() => {
        AppConfigService.settings = {
            'env': {
                'name': 'DEV2'
            },
            'baseUrls': {
                'BASE_URL': 'https://vbr-arrangementconfig-service-dev2.cfaa.hcsctest.net',
                'BASE_URL_CODE_SERVICE': 'https://vbr-code-service-dev2.cfaa.hcsctest.net',
                'BASE_URL_CALCULATION_SERVICE': 'https://vbr-calculation-service-dev2.cfaa.hcsctest.net',
                'BASE_URL_REPORT': 'https://tableau.test.fyiblue.com/views/'
            },
            'reportUrls': {
                'CAP_SUMMARY_REPORT': 'CapSummaryReport_15735714904500/CapSummaryReport?iframeSizedToWindow=true&:embed=y&:showAppBanner=false&:display_count=no&:showVizHome=no',
                'MEMBERSHIP_ERROR_REPORT': 'MembershipErrorReport_15736417170040/MembershipErrorReport?iframeSizedToWindow=true&:embed=y&:showAppBanner=false&:display_count=no&:showVizHome=no',
                'COMPARISON_REPORT_FOR_APPROVED_FINANCIAL_CALCULATION_DATA': 'ComparisonReportforFinancialCalculationData_15735718388110/ComparisonReportforFinancialcalculationData?iframeSizedToWindow=true&:embed=y&:showAppBanner=false&:display_count=no&:showVizHome=no',
                'COMPARISON_REPORT_FOR_PRELIMINARY_RUN_CALCULATION_DATA': 'ComparisonReportforPreliminaryCalculationData_15735719621730/ComparisonReportforPreliminaryCalculationData?iframeSizedToWindow=true&:embed=y&:showAppBanner=false&:display_count=no&:showVizHome=no',
                'COMPARISON_REPORT_FOR_APPROVED_CALCULATION_DATA': '',
                'RETROACTIVITY_SUMMARY_REPORT': '',
                'NM10931_CAP_DISTRIBUTION_REPORT': 'NM10931-CapDistributionReport_15736400047190/NM10931-CAPDISTRIBUTIONREPORT?iframeSizedToWindow=true&:embed=y&:showAppBanner=false&:display_count=no&:showVizHome=no',
                'NM10940_PRELIMINARY_EFT_REGISTER': 'NM10940-PreliminaryEFTRegisterReport/NM10940-PreliminaryCapEFTRegisterReport?iframeSizedToWindow=true&:embed=y&:showAppBanner=false&:display_count=no&:showVizHome=no',
                'NM10940_FINAL_EFT_REGISTER': 'NM10940-FinalEFTRegisterReport_15736399695060/NM10941-FinalEFTRegisterReport?iframeSizedToWindow=true&:embed=y&:showAppBanner=false&:display_count=no&:showVizHome=no',
                'NM10932_FINAL_OPEN_ITEM_REGISTER': ''
            }
        };
        fixture = TestBed.createComponent(ErrorStatusComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });
    it('should create', () => {
        expect(component).toBeTruthy();
    });
    it('ngOnInit - component.loadCards should have been called', () => {
        spyOn(component, 'loadCards');
        component.ngOnInit();
        expect(component.loadCards).toHaveBeenCalled();
    });

});
