import { Component, OnInit, Input } from '@angular/core';
import _ from 'lodash';
import { DataTableResource } from '../../../../../shared/modules/data-table';
import { ActivatedRoute } from '@angular/router';
import { formatDate } from '@angular/common';

@Component({
  selector: 'app-calculation-run-data-card',
  templateUrl: './calculation_run_data_card.component.html',
  styleUrls: ['./calculation_run_data_card.component.scss']
})
export class CalculationRunDataCardComponent implements OnInit {
  dataitemResource;
  dataitems = [];
  dataitemCount = 0;
  @Input() tab;
  public grains = [
    { type: 'Line Of Business' },
    { type: 'Payment Types' },
    { type: 'Payees' },
    { type: 'Product Types' }
  ];
  currentRows: any;
  filteredRows: any;
  grainFilterCheck: boolean;
  byGrainSelect: any;
  constructor(private route: ActivatedRoute) {}

  ngOnInit() {
    this.dataitemResource = new DataTableResource(this.tab.list);
    this.dataitemResource.count().then(count => (this.dataitemCount = count));
    this.onCurrentRowChange(this.tab.list);
    this.grainFilterCheck = false;
    this.tab.date_modified = formatDate(new Date(), 'MM/dd/yyyy', 'en');
  }
  reloadItems(params) {
    this.dataitemResource
      .query(params)
      .then(dataitems => (this.dataitems = dataitems));
  }
  onCurrentRowChange(currentRow: any) {
    this.currentRows = currentRow;
  }
  onGrainChange(change) {
    if (change) {
      this.grainFilterCheck = true;
      this.filteredRows = _.filter(this.currentRows, function(o) {
        return o.type === change;
      });
    }
    if (change.includes('0')) {
      this.filteredRows = this.currentRows;
    }
  }
}
