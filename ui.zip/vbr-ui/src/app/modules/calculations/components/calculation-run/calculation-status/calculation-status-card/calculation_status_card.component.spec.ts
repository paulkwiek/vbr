import { CalculationStatusCardComponent } from './calculation_status_card.component';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { DataTableModule } from 'src/app/shared/modules/data-table';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { calculationStatusCard } from 'src/testing/mock';

describe('CalculationStatusCardComponent', () => {
  let component: CalculationStatusCardComponent;
  let fixture: ComponentFixture<CalculationStatusCardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
        NgbModule,
        DataTableModule,
        RouterTestingModule,
        HttpClientTestingModule
      ],
      declarations: [
        CalculationStatusCardComponent
      ],
      providers: []
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CalculationStatusCardComponent);
    component = fixture.componentInstance;
    component.reviewStatusItem = calculationStatusCard;
    fixture.detectChanges();
  });
  it('should create', () => {
    expect(component).toBeTruthy();
  })
 

});