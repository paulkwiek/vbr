import { CommonModule, CurrencyPipe } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { CalculationRunComponent } from './calculation_run.component'
import { CalculationStatusComponent } from '../calculation-run/calculation-status/calculation_status.component';
import { ErrorStatusComponent } from '../calculation-run/calculation-status/error-status/error_status.component';
import { CalculationStatusCardComponent } from '../calculation-run/calculation-status/calculation-status-card/calculation_status_card.component';
import { ErrorStatusCardComponent } from '../calculation-run/calculation-status/error-status/error-status-card/error_status_card.component';
import { UIModule } from '../../../../shared/modules/ui/ui.module';
import { DragDropListModule } from '../../../../shared/modules/dragDropLists/dragDropLists.module';
import { PipesModule } from '../../../../shared/pipes/pipes.module';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { ModalService } from '../../../../shared/services/modal.service';
import { CalculationTablesModule } from '../../tables/index';

import { Store, StoreModule, ActionReducerMap } from '@ngrx/store';
import { LocalStorageService } from 'src/app/shared/services/localstorage.service';
import { storageMetaReducer } from 'src/app/shared/services/storage-metareducer';
import { MetaReducer } from '@ngrx/store';
import { storeFreeze } from 'ngrx-store-freeze';
import { environment } from 'src/environments/environment';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { TOAST_CONFIG, DefaultNoComponentGlobalConfig, OverlayContainer } from 'src/app/shared/modules/toast';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ConfigurationsModule } from 'src/app/modules/configurations/configurations.module';
import { reducers } from 'src/app/reducers';
import { EffectsModule } from '@ngrx/effects';
import { StoreDevtoolsModule } from '@ngrx/store-devtools';
import { AppConfigService } from 'src/app/app-config.service';
import { CalculationService } from '../../services/calculation.service';
import { LoadingService } from 'src/app/shared/modules/loading/loading.module';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { AuthService } from 'src/app/shared/services/auth.service';


export function getTabsConfig(
  saveKeys: string[],
  localStorageKey: string,
  storageService: LocalStorageService,
) {
  return {
    metaReducers: [
      storageMetaReducer(saveKeys, localStorageKey, storageService)
    ]
  };
}
export function getMetaReducers(
  saveKeys: string[],
  localStorageKey: string,
  storageService: LocalStorageService
): MetaReducer<any>[] {
  return [storageMetaReducer(saveKeys, localStorageKey, storageService)];
}
export const metaReducers: MetaReducer<{}>[] = !environment.production
  ? [storeFreeze]
  : [];

export function initializeApp(appConfigService: AppConfigService) {
  return (): Promise<any> => {
    return appConfigService.load();
  };
}

describe('CalculationRunComponent', () => {
  let component: CalculationRunComponent;
  let fixture: ComponentFixture<CalculationRunComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        CommonModule,
        FormsModule,
        HttpClientModule,
        UIModule,
        DragDropListModule,
        PipesModule,
        NgbModule,
        CalculationTablesModule,
        HttpClientTestingModule,
        ConfigurationsModule, StoreModule.forRoot(reducers as ActionReducerMap<{}>, { metaReducers }),
        EffectsModule.forRoot([]),
        !environment.production ? StoreDevtoolsModule.instrument() : [],
      ],
      declarations: [
        CalculationRunComponent,
        CalculationStatusComponent,
        ErrorStatusComponent,
        CalculationStatusCardComponent,
        ErrorStatusCardComponent,

      ],
      providers: [
        ModalService,
        OverlayContainer,
        CalculationService,
        LoadingService
      ],
      schemas: [NO_ERRORS_SCHEMA]

    }).compileComponents();
  }));

  beforeEach(async () => {
    AppConfigService.settings = {
      'env': {
        'name': 'DEV2'
      },
      'baseUrls': {
        'BASE_URL': 'https://vbr-arrangementconfig-service-dev2.cfaa.hcsctest.net',
        'BASE_URL_CODE_SERVICE': 'https://vbr-code-service-dev2.cfaa.hcsctest.net',
        'BASE_URL_CALCULATION_SERVICE': 'https://vbr-calculation-service-dev2.cfaa.hcsctest.net',
        'BASE_URL_REPORT': 'https://tableau.test.fyiblue.com/views/'
      },
      'reportUrls': {
        'CAP_SUMMARY_REPORT': 'CapSummaryReport_15735714904500/CapSummaryReport?iframeSizedToWindow=true&:embed=y&:showAppBanner=false&:display_count=no&:showVizHome=no',
        'MEMBERSHIP_ERROR_REPORT': 'MembershipErrorReport_15736417170040/MembershipErrorReport?iframeSizedToWindow=true&:embed=y&:showAppBanner=false&:display_count=no&:showVizHome=no',
        'COMPARISON_REPORT_FOR_APPROVED_FINANCIAL_CALCULATION_DATA': 'ComparisonReportforFinancialCalculationData_15735718388110/ComparisonReportforFinancialcalculationData?iframeSizedToWindow=true&:embed=y&:showAppBanner=false&:display_count=no&:showVizHome=no',
        'COMPARISON_REPORT_FOR_PRELIMINARY_RUN_CALCULATION_DATA': 'ComparisonReportforPreliminaryCalculationData_15735719621730/ComparisonReportforPreliminaryCalculationData?iframeSizedToWindow=true&:embed=y&:showAppBanner=false&:display_count=no&:showVizHome=no',
        'COMPARISON_REPORT_FOR_APPROVED_CALCULATION_DATA': '',
        'RETROACTIVITY_SUMMARY_REPORT': '',
        'NM10931_CAP_DISTRIBUTION_REPORT': 'NM10931-CapDistributionReport_15736400047190/NM10931-CAPDISTRIBUTIONREPORT?iframeSizedToWindow=true&:embed=y&:showAppBanner=false&:display_count=no&:showVizHome=no',
        'NM10940_PRELIMINARY_EFT_REGISTER': 'NM10940-PreliminaryEFTRegisterReport/NM10940-PreliminaryCapEFTRegisterReport?iframeSizedToWindow=true&:embed=y&:showAppBanner=false&:display_count=no&:showVizHome=no',
        'NM10940_FINAL_EFT_REGISTER': 'NM10940-FinalEFTRegisterReport_15736399695060/NM10941-FinalEFTRegisterReport?iframeSizedToWindow=true&:embed=y&:showAppBanner=false&:display_count=no&:showVizHome=no',
        'NM10932_FINAL_OPEN_ITEM_REGISTER': ''
      }
    };
    window.jasmine.DEFAULT_TIMEOUT_INTERVAL = 10000;
    fixture = TestBed.createComponent(CalculationRunComponent);
    component = fixture.componentInstance;
    component.env = environment;
    component.calculationRunType = {
      createUserId: 'U402537',
      updateUserId: 'U402537',
      calculationRunName: 'RUN1',
      corporateEntityCode: 'NM1'
    }
    component.processMonthDate = '2019-10-11';
    component.corporateEntityCode = 'NM1';
    component.lineOfBusinessToAdd = [

    ]
    fixture.detectChanges();


  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });


  it('ngOnInit - component should have been called', () => {
    component.ngOnInit();
  });


  it('ngDoCheck - runsCheck value checking true', () => {
    component.calculationRunType = 'Preliminary';
    component.ngDoCheck();
    expect(component.runsCheck).toEqual(true);
  });

  it('ngDoCheck - runsCheck value checking false', () => {
    component.calculationRunType = 'Approval';
    component.ngDoCheck();
    expect(component.runsCheck).toEqual(false);
  });

  it('ngDoCheck - calculationRunType is equal to test. runsCheck value checking false', () => {
    component.calculationRunType = 'test';
    component.ngDoCheck();
    expect(component.runsCheck).toEqual(false);
  });

  it('calculationRunManager - calling method', () => {
    const id = 'calculation-run-manager';
    component.calculationRunManager(id)
    component.modalService.open(id);
  });

  it('openModal - calling method', () => {
    const id = 'calculation-run-manager';
    component.openModal(id)
    component.modalService.open(id);
  });

  it('close - calling method', () => {
    const id = 'calculation-run-manager';
    component.close(id)
  });

  it('displayResults - calling method', () => {
    const name = ''
    const report = ''
    component.displayResults(name, report);
  });

  it('save - calling method', () => {
    const id = 'create-new-run';
    component.save(id)
  });

  it('removeItem - calling method', () => {
    const item = ''
    const list = []
    component.removeItem(item, list);
  });

  it('changeResults - calling method', () => {
    const value = 'Preliminary';
    component.changeResults(value)
  });

  it('changeResults - runsCheck value checking false', () => {
    const value = 'NM1';
    component.changeResults(value);
    expect(component.runsCheck).toEqual(false);
  });

  it('changeResults - confirmModalCheck value checking true', () => {
    component.calculationRunType = 'NM Preliminary';
    const value = 'Preliminary';
    component.changeResults(value);
    expect(component.confirmModalCheck).toEqual(true);
  });


  it('clickForStatus - selectedStatus value checking true', () => {
    component.selectedStatus = true;
    const event = 'status';
    component.clickForStatus(event);
    expect(component.selectedStatus).toEqual(true);
  });

  it('clickForStatus - activeButton assign to event value', () => {
    component.activeButton = 'status';
    const event = 'status';
    component.clickForStatus(event);
    expect(component.activeButton).toEqual(event);
  });

  it('clickForRun - selectedStatus value checking false', () => {
    component.selectedStatus = false;
    const event = 'status';
    component.clickForRun(event);
    expect(component.selectedStatus).toEqual(false);
  });

  it('clickForRun - activeButton assign to event value', () => {
    component.activeButton = 'status';
    const event = 'status';
    component.clickForRun(event);
    expect(component.activeButton).toEqual(event);
  });



  it('submit - calling method', () => {
    component.submit()
  });


  it('confirmModalOpen - calling method', () => {
    spyOn(component.modalService, 'open');
    component.confirmModalOpen();
    expect(component.modalService.open).toHaveBeenCalled();
  });

  it('deleteCalcRun - calling method', () => {
    const data = component.deleteCalculationRunObj = {
      calculationRunName: "run6",
      corporateEntityCode: "NM1",
      runTypeCode: 'test',
      runNameStatusCode: 'test',
      rowAction: "NO_ACTION",
      createUserId: "U402537",
      updateUserId: "U402537",
      calculationGroupings: [
        {

          calculationGroupingLevelCode: "LOB",
          calculationRunName: "run6",
          calculationGroupingLevelValueText: "Medicare Advantage Membership Cohort",
          selectedIndicator: 'test',
          createUserId: "U402537",
          updateUserId: "U402537",
          createRecordTimestamp: "2019-10-21T10:06:55.301",
          updateRecordTimestamp: "2019-10-21T10:06:55.302",
          rowAction: "NO_ACTION"
        }
      ]
    }
    component.deleteCalculationRunObj.calculationGroupings = data.calculationGroupings;
    const id = 'delete-calculation-run'
    component.deleteCalcRun(id);
  });

  it('deleteCalcRun - close model is calling', () => {
    const data = component.deleteCalculationRunObj = {
      calculationRunName: "run6",
      corporateEntityCode: "NM1",
      runTypeCode: 'test',
      runNameStatusCode: 'test',
      rowAction: "NO_ACTION",
      createUserId: "U402537",
      updateUserId: "U402537",
      calculationGroupings: [
        {

          calculationGroupingLevelCode: "LOB",
          calculationRunName: "run6",
          calculationGroupingLevelValueText: "Medicare Advantage Membership Cohort",
          selectedIndicator: 'test',
          createUserId: "U402537",
          updateUserId: "U402537",
          createRecordTimestamp: "2019-10-21T10:06:55.301",
          updateRecordTimestamp: "2019-10-21T10:06:55.302",
          rowAction: "NO_ACTION"
        }
      ]
    }
    component.deleteCalculationRunObj.calculationGroupings = data.calculationGroupings;
    spyOn(component.modalService, 'close');
    const id = 'delete-calculation-run'
    component.deleteCalcRun(id);
    expect(component.modalService.close).toHaveBeenCalled();
  });

  it('calculationRunRequest - calling method', () => {
    const runRequestObject = {
      createUserId: 'U402537',
      updateUserId: 'U402537',
      createRecordTimestamp: null,
      updateRecordTimestamp: null,
      rowAction: 'INSERT',
      calculationRequestId: null,
      calculationRunName: 'RUN1',
      corporateEntityCode: 'NM1',
      processPeriodDate: '2019-10-11',
      requestSubmittedUserId: 'U402537',
      requestCommentText: 'Calculation Run',
      overwriteCompletedResult: false,
      overwriteApprovedResult: true
    };

    const context = '';
    const completed = false;
    const approved = true;
    component.calculationRunRequest(context, completed, approved);
    expect(component.runRequestObject).toEqual(runRequestObject);
  });

  it('setUpperCase - calling method', () => {
    component.setUpperCase();
  });

  it('editCalculationRun - calling method', () => {
    const calculationRunRecord = {
      calculationRunName: "CALC 5",
      corporateEntityCode: "NM1",
      createRecordTimestamp: "2019-12-03T17:03:44.267",
      createUserId: "U402537",
      rowAction: "NO_ACTION",
      runNameStatusCode: "VA",
      runTypeCode: "APPR",
      updateRecordTimestamp: "2019-12-03T17:03:44.267",
      updateUserId: "U402537",
      calculationGroupings: [
        {
          calculationGroupingLevelCode: "LOB",
          calculationRunName: "CALC 5",
          calculationGroupingLevelValueText: "MAPD",
          selectedIndicator: '',
          createUserId: "U402537",
          updateUserId: "U402537",
          createRecordTimestamp: "2019-12-03T17:03:44.268",
          updateRecordTimestamp: "2019-12-03T17:03:44.268",
          rowAction: "NO_ACTION",
        },
      ],
    };
    const id = 'editCalculationRun'
    component.editCalculationRun(id);
    component.calculationRunObj = calculationRunRecord;
  });

  it('createCalculationRun - calling method', () => {
    const id = 'create-new-run';
    component.createCalculationRun(id);
  });

  it('createCalculationRun - calling method', () => {
    spyOn(component.modalService, 'open');
    const id = 'create-new-run';
    component.createCalculationRun(id);
    expect(component.modalService.open).toHaveBeenCalled();
  });

  it('deleteCalculationRun - calling method', () => {
    const calcRunRecord = {
      calculationRunName: "CALC 5",
      corporateEntityCode: "NM1",
      createRecordTimestamp: "2019-12-03T17:03:44.267",
      createUserId: "U402537",
      rowAction: "NO_ACTION",
      runNameStatusCode: "VA",
      runTypeCode: "APPR",
      updateRecordTimestamp: "2019-12-03T17:03:44.267",
      updateUserId: "U402537",
      calculationGroupings: [
        {
          calculationGroupingLevelCode: "LOB",
          calculationRunName: "CALC 5",
          calculationGroupingLevelValueText: "MAPD",
          selectedIndicator: '',
          createUserId: "U402537",
          updateUserId: "U402537",
          createRecordTimestamp: "2019-12-03T17:03:44.268",
          updateRecordTimestamp: "2019-12-03T17:03:44.268",
          rowAction: "NO_ACTION",
        },
      ],
    };
    component.deleteCalculationRun(calcRunRecord);
    component.calculationRunObj = calcRunRecord;
  });

  it('saveCalculationRun - calling method', () => {
    const id = 'create-new-run';
    component.saveCalculationRun(id);
  });
  it('generateGroupingObjects - calling method', () => {
    component.generateGroupingObjects();
  });

  it('saveCalculationRunServiceCall - calling method', () => {
    const requestObject = {
      calculationRunName: "CALC 5",
      corporateEntityCode: "NM1",
      createRecordTimestamp: "2019-12-03T17:03:44.267",
      createUserId: "U402537",
      rowAction: "NO_ACTION",
      runNameStatusCode: "VA",
      runTypeCode: "APPR",
      updateRecordTimestamp: "2019-12-03T17:03:44.267",
      updateUserId: "U402537",
      calculationGroupings: [
        {
          calculationGroupingLevelCode: "LOB",
          calculationRunName: "CALC 5",
          calculationGroupingLevelValueText: "MAPD",
          selectedIndicator: '',
          createUserId: "U402537",
          updateUserId: "U402537",
          createRecordTimestamp: "2019-12-03T17:03:44.268",
          updateRecordTimestamp: "2019-12-03T17:03:44.268",
          rowAction: "NO_ACTION",
        },
      ],
    };
    const id = 'create-new-run';
    component.saveCalculationRun(id);
    component.saveCalculationRunServiceCall(id, requestObject);
  });
  it('validateCalRunName - calling method', () => {
    component.validateCalRunName();
  });
  it('addLineOfBusiness - calling method', () => {
    const item = {
      codeSetDescription: "Line of Business",
      codeSetName: "LOB",
      codeValueDescription: "Medicare Advantage Membership Cohort",
      codeValueText: "MAPD",
      corporateEntityCode: "NM1"
    }
    const evntType = 'click';
    const list = [];
    component.addLineOfBusiness(item, evntType, list);
  });
  it('removeItem - calling method', () => {
    const item = {
      codeSetDescription: "Line of Business",
      codeSetName: "LOB",
      codeValueDescription: "Medicare Advantage Membership Cohort",
      codeValueText: "MAPD",
      corporateEntityCode: "NM1"
    }
    const list = [];
    component.removeItem(item, list);
  });
  it('removeLineOfBusiness - calling method', () => {
    const item = {
      codeSetDescription: "Line of Business",
      codeSetName: "LOB",
      codeValueDescription: "Medicare Advantage Membership Cohort",
      codeValueText: "MAPD",
      corporateEntityCode: "NM1"
    }
    const evntType = 'click';
    component.removeLineOfBusiness(item, evntType);
  });
  it('LineOfBusinessGroupingList - calling method', () => {
    const item = {
      codeSetDescription: "Line of Business",
      codeSetName: "LOB",
      codeValueDescription: "Medicare Advantage Membership Cohort",
      codeValueText: "MAPD",
      corporateEntityCode: "NM1"
    }
    component.LineOfBusinessGroupingList(item);
  });
  it('handleRunMessageResponse - calling method', () => {
    const message = {
      returnMessage: {
        errors: [
          {
            omponentName: "Calculation Request",
            errorMessageCategoryCode: "PCF-CALC",
            errorMessageId: 249,
            errorMsgDescriptionText: "This will overwrite the current calculcation run results.  Are you sure you want to continue?",
            fieldId: "calculationRequest",
            severitylevel: "E",
            validationClass: "CARQ003CheckCalculationRequestCompleted"
          }
        ],
        itemName: null,
        status: null,
        warnings: []
      }
    }
    component.handleRunMessageResponse(message);
  });

  it('handleErrorResponse - calling method', () => {
    const message = {
      returnMessage: {
        errors: [
          {
            omponentName: "Calculation Request",
            errorMessageCategoryCode: "PCF-CALC",
            errorMessageId: 249,
            errorMsgDescriptionText: "This will overwrite the current calculcation run results.  Are you sure you want to continue?",
            fieldId: "calculationRequest",
            severitylevel: "E",
            validationClass: "CARQ003CheckCalculationRequestCompleted"
          }
        ],
        itemName: null,
        status: null,
        warnings: []
      }
    }
    component.handleErrorResponse(message);
  });

  it('getCalculationStatus - calling method', () => {
    const processPeriodDate = '2019-12-01'
    component.getCalculationStatus(processPeriodDate);
  });

  it('addAllLineOfBusiness - calling method', () => {
    component.lineOfBusinessListActual = {
      codeSetValueItems: [
        {
          codeSetDescription: "Line of Business",
          codeSetName: "LOB",
          codeValueDescription: "Medicare Advantage Membership Cohort",
          codeValueText: "MAPD",
          corporateEntityCode: "NM1"
        }
      ]
    }
    component.addAllLineOfBusiness();
  });
  it('removeAllLineOfBusiness - calling method', () => {
    component.lineOfBusinessListActual = {
      codeSetValueItems: [
        {
          codeSetDescription: "Line of Business",
          codeSetName: "LOB",
          codeValueDescription: "Medicare Advantage Membership Cohort",
          codeValueText: "MAPD",
          corporateEntityCode: "NM1"
        }
      ]
    }
    component.removeAllLineOfBusiness();
  });
  it('getLOBDescription - calling method', () => {
    component.lineOfBusinessListActual = {
      codeSetValueItems: [
        {
          codeSetDescription: "Line of Business",
          codeSetName: "LOB",
          codeValueDescription: "Medicare Advantage Membership Cohort",
          codeValueText: "MAPD",
          corporateEntityCode: "NM1"
        }
      ]
    }
    const code = '';
    component.getLOBDescription(code);
  });
});
