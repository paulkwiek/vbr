import { Component, OnInit, Input } from '@angular/core';
import _ from 'lodash';
import { ReviewStatus } from 'src/app/models/calculation.model';
import { Router } from '@angular/router';

@Component({
  selector: 'app-calculation-status-card',
  templateUrl: './calculation_status_card.component.html',
  styleUrls: ['./calculation_status_card.component.scss']
})
export class CalculationStatusCardComponent implements OnInit {
  @Input() reviewStatusItem: ReviewStatus;
  constructor(public router: Router) {}

  ngOnInit() {}
}
