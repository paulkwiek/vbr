import { Component, OnInit } from '@angular/core';

import _ from 'lodash';
import { CalculationService } from '../../../services/calculation.service';
import { ReviewStatusItems } from 'src/app/models/calculation.model';
import { UserCacheService } from 'src/app/shared/services/user-cache.service';
import { DataService } from 'src/app/shared/services/data.service';
import { LoadingService } from 'src/app/shared/modules/loading/loading.module';
import { SharedService } from 'src/app/shared/services/shared.service';

@Component({
  selector: 'app-calculation-status',
  templateUrl: './calculation_status.component.html'
})
export class CalculationStatusComponent implements OnInit {


  calculationStatusItems: ReviewStatusItems;
  calculationStatus: boolean;
  corporateEntityCode: string;
  processPeriodDate: string;
  corporateEntityDescription: any;
  constructor(
    private calculationService: CalculationService,
    private userCacheService: UserCacheService,
    private dataService: DataService,
    private loadingService: LoadingService,
    private sharedService: SharedService) {
      this.sharedService.getCorpEntityCode().subscribe(data => this.corporateEntityCode = data);

      this.sharedService.getCorpEntityDescription().subscribe(data => this.corporateEntityDescription = data);

  }
  ngOnInit() {
    this.procesingMonth();
    this.loadCards();
  }

  /* Method : getprocessingmonth
   * This method is used to retrieve the processPeriodDate value.
  */
  procesingMonth() {
    this.loadingService.show();
    this.dataService.setProcessingMonth().subscribe(data => {
      this.loadingService.hide();
      this.processPeriodDate = data.processPeriodDate;
    },
    error => {
      this.loadingService.hide();
    });
  }

  /* Method : loadCards
  * This method is used to retrieve the CalculationStatus service.
 */
  loadCards() {
    const reqParam: any = {
      'corporateEntityCode': this.corporateEntityCode,
      'processPeriodDate': this.processPeriodDate
    };
    this.loadingService.show();
    this.calculationService
      .getCalculationRunStatus(reqParam)
      .subscribe((data) => {
        this.loadingService.hide();
        this.calculationStatusItems = data.calcualtionRequestStatusList;
      },
      error => {
        this.loadingService.hide();
      });
  }
}
