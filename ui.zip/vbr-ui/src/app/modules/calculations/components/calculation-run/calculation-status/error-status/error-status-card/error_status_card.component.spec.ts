import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { DataTableModule } from 'src/app/shared/modules/data-table';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { AppConfigService } from 'src/app/app-config.service';
import { CalculationService } from 'src/app/modules/calculations/services/calculation.service';
import { ErrorStatusCardComponent } from './error_status_card.component';


export function initializeApp(appConfigService: AppConfigService) {
  return (): Promise<any> => {
    return appConfigService.load();
  };
}

describe('ErrorStatusCardComponent', () => {
  let component: ErrorStatusCardComponent;
  let fixture: ComponentFixture<ErrorStatusCardComponent>;
  const errorItem = {
    calculationRunName: 'QARunTest1',
    calculationRequestId: 283,
    calculationRequestStatusCode: 'CASU',
    calculationRequestStatusDescription: 'Calculation Approval Submitted',
    approvedBy: null,
    requestedTime: '2019-11-04T13:05:03.399',
    errorsOccuredDuringRun: [
      'INVALID ARRANGEMENT PAYEE', 'INVALID ARRANGEMENT RATE'
    ],
    processingTimeInMinutes: 1440
  };
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
        NgbModule,
        DataTableModule,
        RouterTestingModule,
        HttpClientTestingModule
      ],
      declarations: [
        ErrorStatusCardComponent
      ],
      providers: [CalculationService],
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ErrorStatusCardComponent);
    component = fixture.componentInstance;
    const ReviewStatus = {
      calculationRunName: 'RUN1',
      calculationRequestId: 1,
      approvedBy: null,
      requestedTime: '2019-09-20T14:48:01',
      calculationRequestStatusCode: 'CASU',
      calculationRequestStatusDescription: 'Calculation Approval Submitted',
      processingTimeInMinutes: 1440,
      errorsOccuredDuringRun: ['INVALID ARRANGEMENT PAYEE', 'INVALID ARRANGEMENT RATE']
    };
    component.errorItem = ReviewStatus;
    fixture.detectChanges();

  });
  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
