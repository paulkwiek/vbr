import {
  Component,
  OnInit,
  OnChanges,
  DoCheck,
  QueryList,
  Renderer2,
  ViewChildren,
  VERSION,
  OnDestroy,
  Inject
} from '@angular/core';
import { ModalService } from '../../../../shared/services/modal.service';
import { Tab } from '../../../../models/calculation.model';
import _ from 'lodash';
import { CalculationService } from '../../services/calculation.service';
import { Observable } from 'rxjs';
import { Store } from '@ngrx/store';
import { TABS } from '../../../../shared/constants/app.constants';
import { SetActiveTab } from '../../../../actions/tabs.actions';
import * as fromReducer from '../../../../reducers';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import {
  GlobalConfig,
  ToastService,
  ToastContainerDirective,
  Message,
  types
} from '../../../../shared/modules/toast';
import {
  CalculationRunNames,
  SaveCalculationRun,
  CalculationRunTypes,
  Errors
} from '../../../../models/calculation.model';
import { UserCacheService } from '../../../../shared/services/user-cache.service';
import { UtilService } from '../../../../shared/services/util.service';
import { DataService } from 'src/app/shared/services/data.service';
import { SharedService } from '../../../../shared/services/shared.service';
import { LoadingService } from 'src/app/shared/modules/loading/loading.module';
import { ReturnMessage } from 'src/app/models/shared.model';
import { CALCULATION_RUN_NAME_PATTERN, CALCULATION_RUN_ROLES } from '../../../../shared/constants/app.constants';
import { AuthService } from '../../../../shared/services/auth.service';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-calculation-run',
  templateUrl: './calculation_run.component.html',
  styleUrls: ['./calculation_run.component.scss']
})
export class CalculationRunComponent implements OnInit, DoCheck, OnDestroy {
  corporateEntityCode: string;
  corporateEntityDescription: string;
  calculationRunObj: SaveCalculationRun;
  deleteCalculationRunObj: SaveCalculationRun;
  calculationRunTypeList: CalculationRunTypes;
  calculationRunNamesList: CalculationRunNames;
  lineOfBusinessListActual: any;
  lineOfBusinessToAdd: any;
  lineOfBusinessToAdded = [];
  isValidCalRunName: boolean;
  calRunName: string;

  reportType: string;
  calculationRun: string;
  selector: string;
  selectedList: number;
  calculationRunType: any;
  currentDate: string;
  name: any;
  selectedStatus: boolean;
  activeButton: string;
  selectedTab: Observable<string>;
  runsCheck: boolean;
  tabs = TABS;
  createNewRunForm: FormGroup;
  editCalculationRunForm: FormGroup;
  selectionChange: any;
  calculationRunTypeName: string;
  calculationRunTypeNewRun: string;

  options: GlobalConfig;
  text = '';
  type = types[0];
  message: any;
  version = VERSION;
  enableBootstrap = false;
  private lastInserted: number[] = [];
  inline = false;
  inlinePositionIndex = 0;
  @ViewChildren(ToastContainerDirective) inlineContainers: QueryList<
    ToastContainerDirective
  >;
  messages: Message[];
  confirmModalCheck: boolean;
  runRequestObject: any;
  inProgressMessage: boolean;
  finErrorArray: [];
  isPopupMessage: string;
  isPopupBtnChk: any;
  processMonthDate: any;
  public activeTab$: Observable<Tab>;
  isErrorMsgDisplay: boolean;
  finCalStatus: any;
  checkAuthorizedRoles: boolean;

  constructor(
    public modalService: ModalService,
    private calculationService: CalculationService,
    private store: Store<fromReducer.State>,
    private formBuilder: FormBuilder,
    public toast: ToastService,
    private renderer: Renderer2,
    private userCacheService: UserCacheService,
    private utilService: UtilService,
    private dataService: DataService,
    private sharedService: SharedService,
    private loadingService: LoadingService,
    private authService: AuthService,
    // @Inject('env') private env: any
  ) {
    this.options = this.toast.toastConfig;

    this.sharedService.getCorpEntityCode().subscribe(data => this.corporateEntityCode = data);

    this.sharedService.getCorpEntityDescription().subscribe(data => this.corporateEntityDescription = data);
  }

  selectedItem: string;
  returnMessage: ReturnMessage;
  env = environment;

  ngOnInit() {
    this.checkAuthorizedRoles = this.env.SSO_CONFIG.enableSSO ? !this.authService.isAuthorized(CALCULATION_RUN_ROLES) : false;
    this.getProcessMonth();
    this.getcalculationRunTypeList();
    this.initializeCalculationRun();
    this.getLineOfBusinessList();
    this.getCalculationRunList();

    this.selectedItem = 'Summary';
    this.selectedList = 11;
    this.selectedStatus = false;
    this.activeButton = 'run';
    // this.loadCalculationRuns();
    this.runsCheck = false;
    this.activeTab$ = this.store.select(fromReducer.getActiveTab);
    this.createNewRunForm = this.formBuilder.group({
      calculationRunName: ['', Validators.required]
    });
    this.editCalculationRunForm = this.formBuilder.group({
      calculationRunName: ['', Validators.required]
    });

  }

  ngDoCheck() {
    if (this.calculationRunType && this.calculationRunType === 'Preliminary') {
      this.runsCheck = true;
      this.createNewRunForm.patchValue({
        calculationRunName: this.calculationRunType
      });
      this.editCalculationRunForm.patchValue({
        calculationRunName: this.calculationRunType
      });
      this.calculationRunTypeName = this.calculationRunType;
    } else if (
      this.calculationRunType &&
      this.calculationRunType !== 'Preliminary'
    ) {
      this.createNewRunForm.patchValue({
        calculationRunName: this.calculationRunType
      });
      this.editCalculationRunForm.patchValue({
        calculationRunName: this.calculationRunType
      });
      this.runsCheck = false;
      this.calculationRunTypeName = this.calculationRunType;
    } else {
      this.runsCheck = false;
    }
  }

  /**
   * Method: calculationRunManager
   * @param id
   * Method to open the calculationRunManager modal based on id
   * And calling API to list the list of calculation runs
   */
  calculationRunManager(id: string) {
    this.clearErrorMessage();
    this.getLineOfBusinessList();
    this.getCalculationRunList();
    this.modalService.open(id);
  }
  /**
   * Method: openModal
   * @param id :string - modal window name
   * Method to open the modal window
   */
  openModal(id: string) {
    this.modalService.open(id);
  }

  close(id: string) {
    if (id === 'calculation-run-manager') {
      this.calculationRunType = undefined;
    }
    this.clearErrorMessage();
    this.modalService.close(id);
    this.getLineOfBusinessList();
    this.modalService.close(id);
    this.isValidCalRunName = false;
  }



  save(id: string) {
    this.modalService.close(id);
  }
  displayResults(name: string, report: string) {
    this.selector = name;
    this.selectedItem = name;
    this.reportType = report;
  }

  public removeItem(item: any, list: any[]): void {
    // console.log('Add to ::: ', list);
    list.splice(list.indexOf(item), 1);
  }


  clickForStatus(event) {
    this.selectedStatus = true;
    this.activeButton = event;
  }
  clickForRun(event) {
    this.selectedStatus = false;
    this.activeButton = event;
  }

  changeResults(value) {
    if (value === 'Preliminary') {
      this.runsCheck = true;
    } else {
      this.runsCheck = false;
    }
    this.createNewRunForm.patchValue({
      calculationRunName: value
    });
    this.editCalculationRunForm.patchValue({
      calculationRunName: value
    });
    if (this.calculationRunType === 'NM Preliminary') {
      this.confirmModalCheck = true;
    } else {
      this.confirmModalCheck = false;
    }
  }

  submit() {
    if (this.createNewRunForm.valid) {
      // console.log(this.createNewRunForm.value);
    }
  }

  confirmModalOpen() {
    this.modalService.open('confirm-modal-calculation-run');
  }
  /* Method : deleteCalcRun
   * This method is used to call save Calculation Run Service
   */
  deleteCalcRun(id: string) {
    this.sharedService.clearToasts();
    this.loadingService.show();
    this.modalService.close(id);
    this.deleteCalculationRunObj.rowAction = 'DELETE';
    this.deleteCalculationRunObj.calculationGroupings.forEach((data: any) => {
      data.rowAction = 'DELETE';
      data.selectedIndicator = false;
    });
    const requestObject = {
      calRun: this.deleteCalculationRunObj
    };
    this.calculationService.saveCalculationRun(requestObject)
      .subscribe(
        (data: any) => {
          this.loadingService.hide();
          this.sharedService.handleErrorSuccessWarningInfo('SUCCESS', data);
          this.getCalculationRunList();
        },
        error => {
          this.loadingService.hide();
          this.handleErrorResponse(error);
        }
      );
  }

  /* Method : calculationRunRequest
   * This method is used to form the request object and call the save calculation request
   */
  calculationRunRequest(context: string, completed: boolean, approved: boolean) {
    this.generateRunRequestObjects(completed, approved);
    const requestObject = {
      calculationRequestDTO: this.runRequestObject,
      warningState: false
    };
    if (completed || approved) {
      this.modalService.close('calculation-popup-message');
    }
    this.saveCalculationRequestServiceCall(context, requestObject);
  }

  /* Method : generateRunRequestObjects
   * This method is used to obtaining the request object based on the run name selection
   */
  generateRunRequestObjects(completed: boolean, approved: boolean) {
    this.runRequestObject = {
      createUserId: this.calculationRunType.createUserId,
      updateUserId: this.calculationRunType.updateUserId,
      createRecordTimestamp: null,
      updateRecordTimestamp: null,
      rowAction: 'INSERT',
      calculationRequestId: null,
      calculationRunName: this.calculationRunType.calculationRunName,
      corporateEntityCode: this.calculationRunType.corporateEntityCode,
      processPeriodDate: this.processMonthDate,
      requestSubmittedUserId: this.calculationRunType.createUserId,
      requestCommentText: 'Calculation Run',
      overwriteCompletedResult: completed,
      overwriteApprovedResult: approved
    };
  }

  /* Method : saveCalculationRequestServiceCall
 * Param : context and requestObject
 * This method is used to save  and valiidate Calculation request Run.
 */
  saveCalculationRequestServiceCall(context: string, requestObject: any) {
    this.sharedService.clearToasts();
    this.loadingService.show();
    this.clearErrorMessage();
    this.calculationService.saveCalculationRequest(requestObject)
      .subscribe(
        (data: any) => {
          this.loadingService.hide();
          this.sharedService.handleErrorSuccessWarningInfo('SUCCESS', data);
        },
        error => {
          this.loadingService.hide();
          this.handleRunMessageResponse(error);
        }
      );
  }


  /***DEV Changes** */
  /* Method : setUpperCase
 * This method is used to convert the string to upper case
 */
  setUpperCase() {
    this.calculationRunObj.calculationRunName = this.calculationRunObj.calculationRunName.toUpperCase();
  }

  initializeCalculationRun() {
    this.calculationRunObj = {
      calculationRunName: '',
      corporateEntityCode: this.corporateEntityCode,
      runTypeCode: undefined,
      runNameStatusCode: '',
      rowAction: 'INSERT',
      createUserId: this.userCacheService.getUserCacheData('USER_ID'),
      updateUserId: this.userCacheService.getUserCacheData('USER_ID'),
      calculationGroupings: []
    };
  }
  editCalculationRun(calculaionRunRecord: any) {
    this.name = '';
    this.calculationRunObj = calculaionRunRecord;
    this.LineOfBusinessGroupingList(this.calculationRunObj);
  }

  /* Method : createCalculationRun
   * This method is used to initialize the model values for Create New run Screen.
   */
  createCalculationRun(id: string) {
    this.name = '';
    this.initializeCalculationRun();
    this.getLineOfBusinessList();
    this.clearErrorMessage();
    this.modalService.open(id);
  }

  /* Method : deleteCalculationRun
   * This method is used to do the soft delete for the calculation Run..
   */
  deleteCalculationRun(calcRunRecord: any) {
    this.deleteCalculationRunObj = calcRunRecord;
    this.modalService.open('delete-calculation-run');
  }

  /* Method : saveCalculationRun
   * This method is used to call save Calculation Run Service
   */
  saveCalculationRun(id: string) {
    if (this.validateCalNewRun() === false) {
      this.generateGroupingObjects();
      const requestObject = {
        calRun: this.calculationRunObj
      };
      this.saveCalculationRunServiceCall(id, requestObject);
    }
  }

  /* Method : saveCalculationRunServiceCall
   * Param : id and requestObject
   * This method is used to save/update the New Calculation Run.
   */
  saveCalculationRunServiceCall(id: string, requestObject: any) {
    this.sharedService.clearToasts();
    this.loadingService.show();
    this.clearErrorMessage();
    this.calculationService.saveCalculationRun(requestObject)
      .subscribe(
        (data: any) => {
          this.loadingService.hide();
          this.modalService.close(id);
          this.sharedService.handleErrorSuccessWarningInfo('SUCCESS', data);
          this.getCalculationRunList();
        },
        error => {
          this.loadingService.hide();
          this.handleErrorResponse(error);
        }
      );
  }

  /* Method : generateGroupingObjects
   * This method is used to update the key names from business object.
   */
  generateGroupingObjects() {
    this.calculationRunObj.calculationGroupings = [];
    const fliterarrayVal = this.lineOfBusinessToAdded;
    let obj: any;
    for (let i = 0; i < fliterarrayVal.length; i++) {
      obj = {
        calculationGroupingLevelCode: fliterarrayVal[i].codeSetName,
        calculationRunName: this.calculationRunObj.calculationRunName,
        calculationGroupingLevelValueText: fliterarrayVal[i].codeValueText,
        selectedIndicator: true,
        corporateEntityCode: this.calculationRunObj.corporateEntityCode,
        createUserId: this.calculationRunObj.createUserId,
        updateUserId: this.calculationRunObj.updateUserId,
        createRecordTimestamp: '',
        updateRecordTimestamp: '',
        rowAction: this.calculationRunObj.rowAction
      };
      this.calculationRunObj.calculationGroupings.push(obj);
    }

  }


  /* Method : getCalculationRunList
   * This method is used to retrieve the Calculation Run List.
   */
  getCalculationRunList() {
    this.clearErrorMessage();
    this.loadingService.show();
    this.calculationRunNamesList = null;
    const param = 'corporateEntity=' + this.corporateEntityCode;
    this.calculationService.getCalculationRunList(param).subscribe((data: CalculationRunNames) => {
      this.loadingService.hide();
      this.calculationRunNamesList = data;
    },
      error => {
        this.loadingService.hide();
        // on failure, call method to display error
        this.sharedService.handleErrorSuccessWarningInfo('FAILURE', error, 'Calculation Error');
      });
  }

  /* Method : validateCalRunName
   * This method is used to validate the Calculation Run Name.
   */
  validateCalRunName() {
    this.isValidCalRunName =
      this.calculationRunObj.calculationRunName === ''
        ? false
        : !this.utilService.patterMatch(
          CALCULATION_RUN_NAME_PATTERN,
          this.calculationRunObj.calculationRunName.replace(/\s\s+/g, ' ').trim()
        );
    this.calculationRunObj.calculationRunName = this.calculationRunObj.calculationRunName.replace(/\s\s+/g, ' ').trim();

  }

  /* Method : validateCalNewRun
   * This method is used to Enable/Disable "Save" button of the Create New Run Screen
   */
  validateCalNewRun() {
    if (this.calculationRunObj.calculationRunName.trim() == '' || this.calculationRunObj.runTypeCode == undefined || !this.utilService.patterMatch(CALCULATION_RUN_NAME_PATTERN, this.calculationRunObj.calculationRunName) || this.lineOfBusinessToAdded.length <= 0) {
      return true;
    } else {
      return false;
    }

  }
  /* Method : getcalculationRunTypeList
   * This method is used to get the Calculation Run Type list
   */
  getcalculationRunTypeList() {
    this.sharedService.getCodeValues('CALCRUNTYPE').subscribe(
      (data: CalculationRunTypes) => {
        this.calculationRunTypeList = data;
      },
      error => {
        console.log('error  == >', JSON.stringify(error));
      }
    );
  }
  /* Method : getLineOfBusinessList
   * This method is used to get the line of business list
   */
  getLineOfBusinessList() {
    this.loadingService.show();
    this.sharedService.getCodeValues('LOB').subscribe(
      (data: any) => {
        this.loadingService.hide();
        this.lineOfBusinessListActual = JSON.parse(JSON.stringify(data));
        this.removeAllLineOfBusiness();
      },
      error => {
        this.loadingService.hide();
      }
    );
  }
  /* Method : addLineOfBusiness
   * This method is used to remove the "line of business" from Left container and add it into the Right container
   */
  addLineOfBusiness(item: any, evntType: string, list: any[]) {
    if (evntType === 'click') {
      this.lineOfBusinessToAdd.splice(
        this.lineOfBusinessToAdd.indexOf(item),
        1
      );
      this.lineOfBusinessToAdded.push(item);
    } else {
      this.removeItem(item, list);
    }
  }
  /* Method : removeLineOfBusiness
   * This method is used to remove the "line of business" from Right container and add it into the Left container
   */
  removeLineOfBusiness(item: any, evntType: string) {
    if (evntType == 'click') {
      this.lineOfBusinessToAdded.splice(this.lineOfBusinessToAdded.indexOf(item), 1);
      this.lineOfBusinessToAdd.push(item);
    }
  }
  /* Method : addAllLineOfBusiness
   * This method is used to remove all the "line of business" from Left container and them into the Right container
   */
  addAllLineOfBusiness() {
    this.lineOfBusinessToAdded = JSON.parse(
      JSON.stringify(this.lineOfBusinessListActual.codeSetValueItems)
    );
    this.lineOfBusinessToAdd = [];
  }
  /* Method : removeAllLineOfBusiness
   * This method is used to remove all the "line of business" from Right container and them into the left container.
   * Also this method is called when the page gets loaded.
   */
  removeAllLineOfBusiness() {
    this.lineOfBusinessToAdd = JSON.parse(JSON.stringify(this.lineOfBusinessListActual.codeSetValueItems));
    this.lineOfBusinessToAdded = [];
  }
  /* Method : LineOfBusinessGroupingList
   * This method is used to show  the existing Grouped "line of business" into Right container
   * and remove the respective LOB from the Left container .
   */
  LineOfBusinessGroupingList(item: any) {
    for (let i = 0; i < this.lineOfBusinessToAdd.length; i++) {
      for (let j = 0; j < item.calculationGroupings.length; j++) {
        const calculationGroupingLevelValueText = this.getLOBDescription(item.calculationGroupings[j].calculationGroupingLevelValueText);
        if (this.lineOfBusinessToAdd[i].codeValueText == item.calculationGroupings[j].calculationGroupingLevelValueText) {
          this.lineOfBusinessToAdd.splice(i, 1);
          this.lineOfBusinessToAdded.push(calculationGroupingLevelValueText);
        }
      }
    }
  }

  /* Method : getLOBDescription
   * This method is used to get  the LOB description based on code
   */
  getLOBDescription(code: string) {
    const value = this.utilService.getDataFromCode(code, this.lineOfBusinessListActual);
    return value ? value.codeValueDescription : '';
  }

  /**
   * Method to handle run message from API
   * @param: message
   */
  handleRunMessageResponse(message: any) {
    if (message.returnMessage && message.returnMessage.errors.length > 0) {
      if (message.returnMessage.errors[0].errorMessageId == 245 || message.returnMessage.errors[0].errorMessageId == 249 || message.returnMessage.errors[0].errorMessageId == 250) {
        this.isPopupMessage = message.returnMessage.errors[0].errorMsgDescriptionText;
        this.isPopupBtnChk = message.returnMessage.errors[0].errorMessageId;
        this.modalService.open('calculation-popup-message');
      } else {
        this.sharedService.handleErrorSuccessWarningInfo('FAILURE', message);
      }
    }
  }

  /**
   * Method to handle error from API
   * @param: error
   */
  handleErrorResponse(error: any) {
    if (error.returnMessage && error.returnMessage.errors.length > 0) {
      this.returnMessage = error;
      this.isErrorMsgDisplay = true;
    } else {
      console.log('error  == >', JSON.stringify(error));
    }
  }

  /**
   * Method to clear error messages
   */
  clearErrorMessage() {
    this.isErrorMsgDisplay = false;
    this.isPopupBtnChk = null;
  }

  /* Method : getprocessingmonth
   * This method is used to retrieve the processPeriodDate value.
  */
  getProcessMonth() {
    this.loadingService.show();
    this.calculationService.getProcessingMonth(this.corporateEntityCode).subscribe(
      (data) => {
        this.loadingService.hide();
        this.dataService.getProcessingMonth(data);
        this.processMonthDate = data.processPeriodDate;
        const processDateSplit = this.processMonthDate.split('-');
        this.currentDate = processDateSplit[1] + '/' + processDateSplit[0];
        this.getCalculationStatus(data.processPeriodDate);
      },
      error => {
        this.sharedService.handleErrorSuccessWarningInfo('FAILURE', error.returnMessage, 'Calculation Error');
        this.loadingService.hide();
      }
    );
  }

  /* Method : getCalculationStatus
   * This method is used to retrieve the CalculationStatus service.
  */
  getCalculationStatus(processPeriodDate) {
    const reqParam: any = {
      'corporateEntityCode': this.corporateEntityCode,
      'processPeriodDate': processPeriodDate
    };
    this.loadingService.show();
    this.calculationService
      .getCalculationRunStatus(reqParam)
      .subscribe((data) => {
        this.loadingService.hide();
        this.finCalStatus = data;
        this.finErrorArray = data.financialCalculationRequestStatus.errorsOccured;
      },
        error => {
          this.loadingService.hide();
        });
  }
  /**
   * Life cycle hook component destroy
   */
  ngOnDestroy() {
    this.sharedService.clearToasts();
  }
}

