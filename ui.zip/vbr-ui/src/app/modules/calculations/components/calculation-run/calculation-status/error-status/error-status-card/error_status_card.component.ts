import { Component, OnInit, Input } from '@angular/core';
import _ from 'lodash';
import { ReviewStatus } from 'src/app/models/calculation.model';
@Component({
  selector: 'app-error-status-card',
  templateUrl: './error_status_card.component.html',
  styleUrls: ['./error_status_card.component.scss']
})
export class ErrorStatusCardComponent {
  @Input() errorItem: ReviewStatus;
  splitArray: any;
  constructor() {}
  public isCollapsed = false;
}
