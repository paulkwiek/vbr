import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';

import { HomeScreenComponent } from './components/home-screen/home-screen.component';
//SSO
import { UnauthorizedComponent } from './components/unauthorized/unauthorized.component';

const routes: Routes = [
  { path: 'home', component: HomeScreenComponent },
  { path: '', component: HomeScreenComponent, pathMatch: 'full' },
  { path: 'unauthorized', component: UnauthorizedComponent },
];

@NgModule({
  imports: [CommonModule, RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class HomeRoutingModule { }
