import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { HomeRoutingModule } from './home-routing.module';
import { HomeScreenComponent } from './components/home-screen/home-screen.component';
//SSO
import { UnauthorizedComponent } from './components/unauthorized/unauthorized.component';


@NgModule({
  imports: [
    CommonModule, FormsModule, HomeRoutingModule
  ],
  declarations: [HomeScreenComponent, UnauthorizedComponent]
})
export class HomeModule { }
