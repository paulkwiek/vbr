import { Component, OnDestroy, OnInit } from '@angular/core';
import { State, Store } from '@ngrx/store';
import { environment } from 'src/environments/environment';
import { LoadingService } from '../../../../shared/modules/loading/loading.module';
import { AuthService } from '../../../../shared/services/auth.service';
import { SharedService } from '../../../../shared/services/shared.service';
import { AppState } from '../../../../store/app.state';
import { SetCorporateEntityCodeAction, SetCorporateEntityDescriptionAction, SetCorporateEntityListAction } from '../../../../store/corporate-entity/corporate-entity.actions';

@Component({
  selector: 'app-home-screen',
  templateUrl: './home-screen.component.html',
  styleUrls: ['./home-screen.component.scss']
})
export class HomeScreenComponent implements OnInit, OnDestroy {
  today = Date.now();
  homeLabels: any;
  corporateEntity: string;
  NM: string;
  corporateEntityCode: string;
  corporateEntityDescription: string;
  env = environment;
  corporateEntityList: any;
  retrievedCorporateEntityList: any;


  constructor(private store: Store<AppState>,
    private state: State<AppState>,
    private sharedService: SharedService,
    private authService: AuthService,
    private loadingService: LoadingService) {
    this.setCorporateEntityInfo();

    this.sharedService.getCorpEntityList().subscribe(data => this.corporateEntityList = data);
    this.sharedService.getCorpEntityCode().subscribe(data => this.corporateEntityCode = data);
    this.sharedService.getCorpEntityDescription().subscribe(data => this.corporateEntityDescription = data);
  }

  ngOnInit() {
  }

  /* Method : setCorporateEntityInfo
   * This method is used to set corporate entity info
   */
  setCorporateEntityInfo() {
    this.sharedService
      .getEntityCorpValues()
      .subscribe(
        // On success, return Sucess message
        (data: any) => {
          this.retrievedCorporateEntityList = data;
          this.store.dispatch(new SetCorporateEntityListAction(this.retrievedCorporateEntityList.corporateEntities));
          if (this.env.SSO_CONFIG.enableSSO) {
            const userCorpEntityCode = this.authService.getCorpCode();
            this.setCorporateEntityStore(userCorpEntityCode);
          } else {
            this.setCorporateEntityStore(this.retrievedCorporateEntityList.corporateEntities[0].corporateEntityCode);
          }
        },
        error => {
        }
      );
  }

  /* Method : setCorporateEntityStore
  * This method is used to set corporate entity code and description in store
  */
  setCorporateEntityStore(code: any) {
    this.store.dispatch(new SetCorporateEntityCodeAction(code));
    this.store.dispatch(new SetCorporateEntityDescriptionAction(this.sharedService.selectedCorpEntityDescription(this.retrievedCorporateEntityList.corporateEntities, code)));
  }
  /* Method : setCorporateEntityStore
     * This method is used to set corporate entity code and description in store
     */
  selectCorporateEntity(selectedCorporateEntity: any) {
    this.store.dispatch(new SetCorporateEntityCodeAction(selectedCorporateEntity));
    this.store.dispatch(new SetCorporateEntityDescriptionAction(this.sharedService.selectedCorpEntityDescription(this.corporateEntityList, selectedCorporateEntity)));
  }

  ngOnDestroy() { }
}
