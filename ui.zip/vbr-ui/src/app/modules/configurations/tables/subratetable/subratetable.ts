import { Component, OnInit, ViewChild, Input, OnChanges } from '@angular/core';
import {
  DataTableResourceCustomized,
  DataTableComponent
} from '../../../../shared/modules/data-table';
import { ModalService } from '../../../../shared/services/modal.service';
import { ActivatedRoute, Router } from '@angular/router';
import { RateComponent } from '../../components/rates/rate/rate.component';
import { RateName } from '../../../../models/configuration.model';

@Component({
  selector: 'app-subrate',
  providers: [],
  templateUrl: './subratetable.html',
  styleUrls: ['./subratetable.scss']
})
export class SubRateComponent implements OnInit, OnChanges {
  @Input() rateDetails: RateName;
  dataitemResource: any;
  dataitemCount = 0;
  dataitems = [];
  loaded = false;
  rate = {
    name: null
  };
  id = 0;
  sendRate: {
    id: number;
  };
  rowColors: any;

  constructor(
    private modalService: ModalService,
    private route: ActivatedRoute,
    private rateComponent: RateComponent
  ) {}

  ngOnInit() {
    // const id = this.route.snapshot.paramMap.get('id');
    // // tslint:disable-next-line: radix
    // this.id = parseInt(id);
    // if (this.id !== 0) {
    //   this.rate = RATES.find(rate => rate.id === this.id);
    // }
  }

  ngOnChanges() {
    this.dataitemResource = new DataTableResourceCustomized(this.rateDetails.flatRates);
    this.dataitemResource
      .count()
      .then((count: any) => (this.dataitemCount = count));
    this.dataitems = this.rateDetails.flatRates;
  }

  reloadItems(params) {
    this.dataitemResource
      .query(params)
      .then(dataitems => (this.dataitems = dataitems));
  }
  edit(id: string, rateDetails: any) {
    const rate: any = rateDetails;
    this.rateComponent.editRate(id, rate);
  }
  view(id: string) {
    this.modalService.open(id);
  }
}
