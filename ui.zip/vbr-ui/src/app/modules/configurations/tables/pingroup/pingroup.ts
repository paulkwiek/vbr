import { Component, Input, OnChanges } from '@angular/core';
import { DataTableResource } from '../../../../shared/modules/data-table';
import { PayeesComponent } from '../../components/payees/payees.component';
import { Payees } from '../../../../models/configuration.model';

@Component({
  selector: 'app-pingroup',
  providers: [],
  templateUrl: './pingroup.html',
  styleUrls: ['./pingroup.scss']
})
export class PinGroupComponent implements OnChanges {
  @Input() payeesList: Payees;
  dataitemResource: any;
  dataitems = [];
  dataitemCount = 0;

  constructor(private payeesComponent: PayeesComponent) {
    // this.dataitemResource.count().then(count => (this.dataitemCount = count));
  }
  ngOnChanges() {
    this.dataitemResource = new DataTableResource(this.payeesList.payees);
    // tslint:disable-next-line: no-shadowed-variable
    this.dataitemResource.count().then(count => (this.dataitemCount = count));
  }

  reloadItems(params) {
    this.dataitemResource
      .query(params)
      .then(dataitems => (this.dataitems = dataitems));
  }

  edit(id: string, payeeRecord: any) {
    this.payeesComponent.editPayee(id, payeeRecord);
  }
}
