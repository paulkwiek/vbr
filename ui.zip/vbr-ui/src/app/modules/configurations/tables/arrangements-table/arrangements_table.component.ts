import {
  Component,
  OnInit,
  Input,
  OnChanges
} from '@angular/core';
import { DataTableResource } from '../../../../shared/modules/data-table';
import _ from 'lodash';
import { ConfigurationService } from '../../services/configuration.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-arrangements-table',
  providers: [],
  templateUrl: './arrangements_table.component.html',
  styleUrls: ['./arrangements_table.component.scss']
})
export class ArrangementsTableComponent implements OnInit, OnChanges {
  dataitemResource: any;
  dataitems = [];
  dataitemCount = 0;
  loaded = false;
  @Input() arrangements;
  arrangementCheck: boolean;
  arrangementIds;
  paymentArrangements = [];


  constructor(
    public configurationService: ConfigurationService,
    private router: Router
  ) {}

  ngOnInit() {
    if (this.arrangements === undefined || _.size(this.arrangements) === 0) {
      this.arrangementCheck = false;
    } else {
      this.arrangementCheck = true;
      this.dataitemCount = _.size(this.dataitems);
      this.loadArrangements();
    }
    this.dataitems = this.dataitemResource.dataitems;
  }

  ngOnChanges() {
    if (this.arrangements === undefined || _.size(this.arrangements) === 0) {
      this.arrangementCheck = false;
    } else {
      this.arrangementCheck = true;
      this.dataitemCount = _.size(this.dataitems);
      this.loadArrangements();
    }
     this.dataitems = this.dataitemResource.dataitems;
     // this.dataitems = this.arrangements;
  }
  loadArrangements() {
    if (this.arrangementCheck) {
      this.dataitemResource = new DataTableResource(this.arrangements);
      // this.dataitems = this.arrangements;
      this.dataitemResource
        .count()
        .then((count: any) => (this.dataitemCount = count));
    }
  }

  reloadItems(params) {
    if (this.dataitemResource === undefined) {
      console.log('Cannot Reload Table');
      this.loadArrangements();
    } else {
      // this.dataitemResource = new DataTableResource(this.arrangements);
      this.dataitemResource
        .query(params)
        .then((dataitems: any) => (this.dataitems = dataitems));
    }
  }
  navigate(id: any) {
    this.router.navigate(['configurations/arrangements', id]);
  }


}
