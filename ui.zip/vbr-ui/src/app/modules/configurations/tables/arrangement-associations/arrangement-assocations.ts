import { Component, OnInit, Input, OnChanges } from '@angular/core';
import { DataTableResource } from '../../../../shared/modules/data-table';
import { ModalService } from '../../../../shared/services/modal.service';
import { GetLinkedArrangement } from '../../../../models/configuration.model';

@Component({
  selector: 'app-arrangement-associations',
  providers: [],
  templateUrl: './arrangement-associations.html'
})
export class ArrangementAssociationsComponent implements OnInit, OnChanges {
  dataitemResource: any;
  dataitems = [];
  dataitemCount = 0;
  loaded = false;
  @Input() linkedArrangementList: GetLinkedArrangement[];

  constructor(private modalService: ModalService) { }

  ngOnInit() { }

  ngOnChanges() {
    this.dataitemResource = new DataTableResource(
      this.linkedArrangementList
    );
    this.dataitemResource
      .count()
      .then((count: any) => (this.dataitemCount = count));
  }

  reloadItems(params) {
    this.dataitemResource
      .query(params)
      .then((dataitems: any) => (this.dataitems = dataitems));
  }
  edit(id: string) {
    this.modalService.open(id);
  }
  view(id: string) {
    this.modalService.open(id);
  }
}
