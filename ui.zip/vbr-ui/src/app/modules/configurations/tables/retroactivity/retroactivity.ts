import { Component, OnInit } from '@angular/core';
import { DataTableResource } from '../../../../shared/modules/data-table';
import { ModalService } from '../../../../shared/services/modal.service';

@Component({
  selector: 'app-retroactivity',
  providers: [],
  templateUrl: './retroactivity.html',
  styleUrls: ['./retroactivity.scss']
})
export class RetroactivityComponent {
  // dataitemResource = new DataTableResource(RETROACTIVITY_SETTINGS);
  dataitems = [];
  dataitemCount = 0;

  constructor(private modalService: ModalService) {
   // this.dataitemResource.count().then(count => (this.dataitemCount = count));
  }

  reloadItems(params) {
    // this.dataitemResource.query(params).then(dataitems => (this.dataitems = dataitems));
  }
  edit(id: string) {
    this.modalService.open(id);
  }
}
