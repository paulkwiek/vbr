import { Component, Input, OnChanges } from '@angular/core';
import { DataTableResource } from '../../../../shared/modules/data-table';
import { ArrangementComponent } from '../../../configurations/components/arrangements/arrangement/arrangement.component';
import { ModalService } from '../../../../shared/services/modal.service';
import { PaymentArrangementRate } from '../../../../models/configuration.model';
@Component({
  selector: 'app-ratestable',
  providers: [],
  templateUrl: './rates.html',
  styleUrls: ['./rates.scss']
})
export class RatesTableComponent implements OnChanges {
  @Input() paymentArrangementRates: PaymentArrangementRate[];
  @Input() lengthParam: number;
  @Input() checkRoles: boolean;
  dataitemResource: any;
  dataitems = [];
  dataitemCount = 0;
  recordEffectiveDate: any;
  recordEndDate: any;
  isChanged = false;
  constructor(
    private modalService: ModalService,
    private arrangementComponent: ArrangementComponent
  ) {}

  ngOnChanges() {
    this.dataitemResource = new DataTableResource(this.paymentArrangementRates);
    this.dataitemResource
      .count()
      .then((count: any) => (this.dataitemCount = count));
    this.rowColors = this.rowColors.bind(this);
    this.dataitems = this.paymentArrangementRates;
  }

  reloadItems(params) {
    this.dataitemResource
      .query(params)
      .then(dataitems => (this.dataitems = dataitems));
  }
  edit(id: string) {
    this.modalService.open(id);
  }
  view(id: string) {
    this.modalService.open(id);
  }
  viewRates(rateName: any, id: string) {
    this.arrangementComponent.viewRates(rateName, id);
  }
  editRates(rateName: any, id: string) {
    this.arrangementComponent.editRates(rateName, id);
  }
  rowColors(item) {
    if (
      (this.arrangementComponent.validateDate(item.recordEffectiveDate) ===
        false ||
      this.arrangementComponent.validateDate(item.recordEndDate) === false) && this.isChanged
    ) {
      return 'rgb(255, 255, 197)';
    }
  }

  validateAllDataItems() {
    this.isChanged = this.arrangementComponent.validateRates();
  }
  displayDate = date => {
    return `${date.month}/${date.day}/${date.year}`;
  }
}
