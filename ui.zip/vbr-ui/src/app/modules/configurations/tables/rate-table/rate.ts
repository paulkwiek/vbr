import { Component, Input, OnChanges } from '@angular/core';
import { DataTableResourceCustomized } from '../../../../shared/modules/data-table';
import { RateName } from '../../../../models/configuration.model';
import { ModalService } from '../../../../shared/services/modal.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-ratetable',
  providers: [],
  templateUrl: './rate.html'
})
export class RateTableComponent implements OnChanges {
  @Input() rateDetails: RateName;
  dataitemResource: any;
  dataitems = [];
  dataitemCount = 0;
  constructor(
    private modalService: ModalService,
    private route: ActivatedRoute,
    private router: Router
  ) {}

  ngOnChanges() {
    this.dataitemResource = new DataTableResourceCustomized(
      this.rateDetails.flatRates
    );
    this.dataitemResource
      .count()
      .then((count: any) => (this.dataitemCount = count));
    this.dataitems = this.rateDetails.flatRates;
  }

  reloadItems(params) {
    this.dataitemResource
      .query(params)
      .then(dataitems => (this.dataitems = dataitems));
  }

  edit(id: string) {
    this.modalService.open(id);
  }
  view(id: string) {
    this.modalService.open(id);
  }
}
