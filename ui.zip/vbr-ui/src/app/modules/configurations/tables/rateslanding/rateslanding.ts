import {
  Component,
  OnInit,
  Input,
  Inject,
  forwardRef,
  OnChanges,
  Output
} from '@angular/core';
import {
  DataTableResource,
  DataTableComponent
} from '../../../../shared/modules/data-table';
import { ModalService } from '../../../../shared/services/modal.service';
import { Router, ActivatedRoute } from '@angular/router';
import { RateNames } from '../../../../models/configuration.model';
import { UtilService } from 'src/app/shared/services/util.service';
import _ from 'lodash';
import {RateFilterPipe} from '../../../../shared/pipes/rate-filter.pipe';

@Component({
  selector: 'app-rateslanding',
  templateUrl: './rateslanding.html',
  styleUrls: ['./rateslanding.scss']
})
export class RatesLandingComponent implements OnInit, OnChanges {
  rowColors: any;
  dataitemResource: any;
  dataitems = [];
  dataitemCount = 0;
  loaded = false;
  searchRateName: string;
  @Input() index: number;
  @Input() rateNameList: RateNames;
  filterPipe =  new RateFilterPipe();
  constructor(
    private modalService: ModalService,
    private route: ActivatedRoute,
    private router: Router,
    private utilService: UtilService
  ) {}

  ngOnInit() {}

  ngOnChanges() {
    this.dataitemResource = new DataTableResource(this.rateNameList.rateNames);
    this.dataListCount();
  }
  dataListCount() {
    this.dataitemResource.count().then((count: any) => (this.dataitemCount = count));
  }


  reloadItems(params) {
    this.dataitemResource.query(params).then((dataitems: any) => (this.dataitems = dataitems));
  }
  /* Method : filterByRateName
   * This method is called from child component (table.ts) and filtering entire data set based on the search param
  */
  filterByRateName(searchParam: any) {
    this.dataitemResource = (searchParam == '') ? new DataTableResource(this.rateNameList.rateNames) : new DataTableResource(this.filterPipe.transform(this.rateNameList.rateNames, searchParam));
    this.dataListCount();
    this.reloadItems({'offset': 0, 'limit': 25});
  }

  edit(id: string) {
    this.modalService.open(id);
  }

  view(id: string) {
    this.modalService.open(id);
  }

  getFormattedDateAndTime(timeStamp: string, dateOrTime: string): string {
    if (dateOrTime === 'date') {
      return this.utilService.getFormattedDate(timeStamp);
    } else {
      return this.utilService.getFormattedTime(timeStamp);
    }
  }

  navigate(rateName: string) {
    this.router.navigate(['configurations/rates/', rateName]);
  }
}
