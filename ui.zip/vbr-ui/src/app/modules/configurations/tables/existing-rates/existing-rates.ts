import { Component, Input, OnChanges } from '@angular/core';
import { DataTableResource } from '../../../../shared/modules/data-table';
import { ModalService } from '../../../../shared/services/modal.service';
import { RateNames } from '../../../../models/configuration.model';
import { ArrangementComponent } from '../../components/arrangements/arrangement/arrangement.component';
import { UtilService } from 'src/app/shared/services/util.service';
import { RateFilterPipe } from '../../../../shared/pipes/rate-filter.pipe';
@Component({
  selector: 'app-existingrates',
  providers: [],
  templateUrl: './existing-rates.html',
  styleUrls: ['./existing-rates.scss']
})
export class ExistingRatesComponent implements OnChanges {
  @Input() rateNameList: RateNames;
  dataitemResource: any;
  dataitems = [];
  dataitemCount = 0;
  rowColors: any;
  filterPipe = new RateFilterPipe();
  constructor(
    private modalService: ModalService,
    private arrangementComponent: ArrangementComponent,
    private utilService: UtilService
  ) {}

  ngOnChanges() {
    this.dataitemResource = new DataTableResource(this.rateNameList.rateNames);
    this.dataListCount();
  }
  dataListCount() {
    this.dataitemResource
      .count()
      .then((count: any) => (this.dataitemCount = count));
  }

  reloadItems(params: any) {
    this.dataitemResource
      .query(params)
      .then((dataitems: any) => (this.dataitems = dataitems));
  }
  /* Method : filterByRateName
   * This method is called from child component (table.ts) and filtering entire data set based on the search param
   */
  filterByRateName(searchParam: any) {
    // console.log(searchParam)
    this.dataitemResource =
      searchParam === ''
        ? new DataTableResource(this.rateNameList.rateNames)
        : new DataTableResource(
            this.filterPipe.transform(this.rateNameList.rateNames, searchParam)
          );
    this.dataListCount();
    this.reloadItems({ offset: 0, limit: 25 });
  }

  selectRate(selectedRate: any) {
    this.arrangementComponent.selectRate(selectedRate);
  }

  edit(id: string) {
    this.modalService.open(id);
  }
  view(id: string) {
    this.modalService.open(id);
  }

  getFormattedDateAndTime(timeStamp: string, dateOrTime: string) {
    if (dateOrTime === 'date') {
      return this.utilService.getFormattedDate(timeStamp);
    } else {
      return this.utilService.getFormattedTime(timeStamp);
    }
  }
}
