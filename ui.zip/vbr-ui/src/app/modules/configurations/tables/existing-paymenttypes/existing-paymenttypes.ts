import { Component, ViewChild, Input, OnChanges, DoCheck, OnInit } from '@angular/core';
import {
  DataTableResource,
  DataTableComponent
} from '../../../../shared/modules/data-table';
import { ModalService } from '../../../../shared/services/modal.service';
import { PaymentTypesComponent } from '../../components/paymenttypes/paymenttypes.component';
import { PaymentTypes } from '../../../../models/configuration.model';
import { PaymentTypeFilterPipe } from '../../../../shared/pipes/payment-type-filter.pipe';
import { DescriptionPipe } from '../../../../shared/pipes/description-filter.pipe';

@Component({
  selector: 'app-existingpaymenttypes',
  providers: [],
  templateUrl: './existing-paymenttypes.html',
  styleUrls: ['./existing-paymenttypes.scss']
})
export class ExistingPaymentTypesComponent implements OnChanges {
  @Input() paymentTypesList: PaymentTypes;
  dataitemResource: any;
  dataitems = [];
  dataitemCount = 0;
  searchPayment: string;
  searchDesc: string;
  rowColors: any;
  paymentTypeCodeFilterPipe = new PaymentTypeFilterPipe();
  paymentTypeDescriptionFilterPipe = new DescriptionPipe();
  paymenttype: {
    id: number;
  };
  initialReload = {
    'limit': 25,
    'offset': 0
  };
  searchPaymentTypeCode = '';
  searchPaymentTypeDescription = '';

  @ViewChild(DataTableComponent) itemsTable: DataTableComponent;

  constructor(
    private modalService: ModalService,
    private paymenttypeComponent: PaymentTypesComponent
  ) { }

  ngOnChanges() {
    this.dataitemResource = new DataTableResource(this.paymentTypesList.paymentTypes);
    this.dataitemResource.count().then((count: any) => (this.dataitemCount = count));
    // Below conditions are used to iterate the data with filter condition.
    if (this.searchPaymentTypeCode != '') {
      this.filterByPaymentTypeCode(this.searchPaymentTypeCode);
    }
    if (this.searchPaymentTypeDescription != '') {
      this.filterByPaymentTypeDescription(this.searchPaymentTypeDescription);
    }
    this.reloadItems(this.initialReload);
  }

  reloadItems(params: any) {
    this.initialReload = params;
    this.dataitemResource
      .query(params)
      .then((dataitems: any) => (this.dataitems = dataitems));
  }

  edit(id: string, paymentType: any) {
    this.paymenttypeComponent.editPaymentType(id, paymentType);
  }

  view(id: string) {
    this.modalService.open(id);
  }

  /* Method : filterByPaymentTypeCode
    * This method is called from child component (table.ts) and filtering entire data set based on the search param
    */
  filterByPaymentTypeCode(searchParam: any) {
    this.searchPaymentTypeCode = searchParam;
    const dataitemType = (searchParam == '') ? this.paymentTypesList.paymentTypes : this.paymentTypeCodeFilterPipe.transform(this.paymentTypesList.paymentTypes, searchParam);
    this.dataitemResource = (this.searchPaymentTypeDescription == '') ? new DataTableResource(dataitemType) : new DataTableResource(this.paymentTypeDescriptionFilterPipe.transform(dataitemType, this.searchPaymentTypeDescription));
    this.dataitemResource.count().then((count: any) => (this.dataitemCount = count));
    this.reloadItems({ 'offset': 0, 'limit': 25 });
  }

  /* Method : filterByPaymentTypeDescription
    * This method is called from child component (table.ts) and filtering entire data set based on the search param
    */
  filterByPaymentTypeDescription(searchParam: any) {
    this.searchPaymentTypeDescription = searchParam;
    const dataitemDescription = (searchParam == '') ? this.paymentTypesList.paymentTypes : this.paymentTypeDescriptionFilterPipe.transform(this.paymentTypesList.paymentTypes, searchParam);
    this.dataitemResource = (this.searchPaymentTypeCode == '') ? new DataTableResource(dataitemDescription) : new DataTableResource(this.paymentTypeCodeFilterPipe.transform(dataitemDescription, this.searchPaymentTypeCode));
    this.dataitemResource.count().then((count: any) => (this.dataitemCount = count));
    this.reloadItems({ 'offset': 0, 'limit': 25 });
  }

}
