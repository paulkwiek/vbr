import { Component, OnInit, Input, OnChanges, AfterViewChecked } from '@angular/core';
import { DataTableResource } from '../../../../shared/modules/data-table';

@Component({
  selector: 'app-line-of-business-run',
  providers: [],
  templateUrl: './line-of-business-run.component.html',
  styleUrls: ['line-of-business-run.component.scss']
})
export class LineOfBusinessRunComponent implements OnInit {
  @Input() lineOfBusiness;
  dataitemResource: any;
  dataitems = [];
  dataitemCount = 0;
  loaded = false;

  constructor() {}

  ngOnInit() {
    this.dataitemResource = new DataTableResource(this.lineOfBusiness);
    this.dataitemResource.count().then(count => (this.dataitemCount = count));
  }

  reloadItems(params) {
    this.dataitemResource
      .query(params)
      .then(dataitems => (this.dataitems = dataitems));
  }
  deleteLineOfBusiness(name: string) {
    this.dataitems = this.dataitems.filter(item => item.name !== name);
  }
}
