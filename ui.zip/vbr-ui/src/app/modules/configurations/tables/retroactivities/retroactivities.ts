import { Component } from '@angular/core';
import { DataTableResource } from '../../../../shared/modules/data-table';
import { ModalService } from '../../../../shared/services/modal.service';

@Component({
  selector: 'app-retroactivities',
  providers: [],
  templateUrl: './retroactivities.html'
})
export class RetroactivitiesComponent {
  // dataitemResource = new DataTableResource(RETROACTIVITY_SETTINGS);
  dataitems = [];
  dataitemCount = 0;

  constructor(private modalService: ModalService) {
    // this.dataitemResource.count().then(count => (this.dataitemCount = count));
  }

  reloadItems(params) {
    // this.dataitemResource.query(params).then(dataitems => (this.dataitems = dataitems));
  }
  edit(id: string) {
    this.modalService.open(id);
  }
}
