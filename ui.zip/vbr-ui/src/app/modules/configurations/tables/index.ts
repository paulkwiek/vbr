import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { SubRateComponent } from './subratetable/subratetable';
import { RatesLandingComponent } from './rateslanding/rateslanding';
import { ArrangementAssociationsComponent } from './arrangement-associations/arrangement-assocations';
import { ExistingPaymentTypesComponent } from './existing-paymenttypes/existing-paymenttypes';
import { ExistingRatesComponent } from './existing-rates/existing-rates';
import { PinGroupComponent } from './pingroup/pingroup';
import { RateTableComponent } from './rate-table/rate';
import { RatesTableComponent } from './rates-table/rates';
import { SharedModule } from '../../../shared/shared.module';
import { RetroactivitiesComponent } from './retroactivities/retroactivities';
import { RetroactivityComponent } from './retroactivity/retroactivity';
import { RetroactivityLandingComponent } from './retroactivity-landing/retroactivity-landing';
import { LineOfBusinessRunComponent } from './line-of-business-run/line-of-business-run.component';
import { ArrangementsTableComponent } from './arrangements-table/arrangements_table.component';

@NgModule({
  imports: [CommonModule, FormsModule, SharedModule],
  declarations: [
    SubRateComponent,
    RatesLandingComponent,
    ArrangementAssociationsComponent,
    ExistingPaymentTypesComponent,
    ExistingRatesComponent,
    PinGroupComponent,
    RateTableComponent,
    RatesTableComponent,
    RetroactivitiesComponent,
    RetroactivityComponent,
    RetroactivityLandingComponent,
    LineOfBusinessRunComponent,
    ArrangementsTableComponent
  ],
  exports: [
    SubRateComponent,
    RatesLandingComponent,
    ArrangementAssociationsComponent,
    ExistingPaymentTypesComponent,
    ExistingRatesComponent,
    PinGroupComponent,
    RateTableComponent,
    RatesTableComponent,
    RetroactivitiesComponent,
    RetroactivityComponent,
    RetroactivityLandingComponent,
    LineOfBusinessRunComponent,
    ArrangementsTableComponent
  ],
  bootstrap: [
    SubRateComponent,
    RatesLandingComponent,
    ArrangementAssociationsComponent,
    ExistingPaymentTypesComponent,
    ExistingRatesComponent,
    PinGroupComponent,
    RateTableComponent,
    RatesTableComponent,
    RetroactivitiesComponent,
    RetroactivityComponent,
    RetroactivityLandingComponent,
    LineOfBusinessRunComponent,
    ArrangementsTableComponent
  ]
})
export class TableModule {}
