import { Injectable } from '@angular/core';
import { resourceEndPoints } from '../../../shared/constants/app.constants';
import { HttpdataService } from '../../../shared/services/httpdata.service';
import { AppConfigService } from '../../../app-config.service';


@Injectable({
  providedIn: 'root'
})
export class ConfigurationService {

  protected BASE_URL = AppConfigService.settings.baseUrls.BASE_URL;
  protected BASE_URL_CODE_SERVICE = AppConfigService.settings.baseUrls.BASE_URL_CODE_SERVICE;
  protected BASE_URL_REPORT = AppConfigService.settings.baseUrls.BASE_URL_REPORT;

  constructor(private http: HttpdataService) { }

  getAllArrangementsFromDB(param: string) {
    return this.http.get(this.BASE_URL + resourceEndPoints.GET_ARRANGEMENTS + '/' + param);
  }

  getArrangementFromDB(id: number) {
    return this.http.get(this.BASE_URL + resourceEndPoints.GET_ARRANGEMENT + '/' + id);
  }

  saveArrangementToDB(searchParam: object) {
    return this.http.post(this.BASE_URL + resourceEndPoints.SAVE_ARRANGEMENT, searchParam);
  }
  getCorporateEntities() {
    return this.http.get('assets/mocks/data/corporate-entity.json');
  }

  getPayeesFromDB(searchParam: object) {
    return this.http.post(this.BASE_URL + resourceEndPoints.SEARCH_PAYEE, searchParam);
  }

  getPayeesFromProviderAPI(searchParam: object) {
    return this.http.post(this.BASE_URL + resourceEndPoints.RETRIEVE_PAYEE, searchParam);
  }

  getProviderPayees(searchParam: object) {
    return this.http.post(
      this.BASE_URL + resourceEndPoints.RETRIEVE_PAYEE_LIST,
      searchParam
    );
  }

  savePayeesToDB(searchParam: object) {
    return this.http.post(this.BASE_URL + resourceEndPoints.SAVE_PAYEE, searchParam);
  }

  /**
   * getArrangementPaymentTypes  - Method to retrieve arrangement payment types
   */
  getArrangementPaymentTypes(param: string) {
    return this.http.get(this.BASE_URL_CODE_SERVICE + resourceEndPoints.RETRIEVE_PAYMENT_TYPES + '/' + param);
  }

  /**
   * getRatesFromDB  - Method to retrieve Rates
   */
  getRatesFromDB(param: string) {
    return this.http.get(this.BASE_URL + resourceEndPoints.RETRIEVE_RATES + '/' + param);
  }

  /**
   * getRatesFromDB  - Method to retrieve Rate Details
   */
  getRatesDetails(rateName: string) {
    return this.http.get(
      this.BASE_URL + resourceEndPoints.GET_RATE_DETAILS + '/' + rateName
    );
  }

  /**
   * getRatesFromDB  - Method to retrieve linked arrangement list
   */
  getLinkedArrangements(rateName: string) {
    return this.http.get(
      this.BASE_URL + resourceEndPoints.GET_LINKED_ARRANGEMENTS + '/' + rateName
    );
  }

  /**
   * saveOrUpdateRate  - Method to save or update the RATE
   * @param - param - Rate information Object
   */
  saveOrUpdateRate(param: object) {
    return this.http.post(this.BASE_URL + resourceEndPoints.SAVE_OR_UPDATE_RATE, param);
  }

  /**
   * SaveOrUpdatePaymentType - Method to add or edit payment type
   * @param param - payement type information object

   */
  saveOrUpdatePaymentType(param: object) {
    return this.http.post(
      this.BASE_URL_CODE_SERVICE + resourceEndPoints.SAVE_OR_UPDATE_PAYMENT_TYPE,
      param
    );
  }

  /**
   * ValidateRateTableName  - Method to validate Rate table name(duplicate, naming constraints)
   * @rateTableName - String - Rate Table name
   */
  validateRateTableName(rateTableName: string) {
    return this.http.get(
      this.BASE_URL + resourceEndPoints.VALIDATE_RATE_TABLE_NAME + '/' + rateTableName
    );
  }

  /**
   * validateArrangementPayee - Method to validate the arrangement dates
   * @param request
   */
  validateArrangementPayee(request: object) {
    return this.http.post(
      this.BASE_URL + resourceEndPoints.VALIDATE_ARRANGEMEMT_PAYEE,
      request
    );
  }
  /**
   * validateArrangementRate - Method to validate arrangement rate and global rate date validation
   * @param request
   */
  validateArrangementRate(request: object) {
    return this.http.post(this.BASE_URL + resourceEndPoints.VALIDATE_ARRANGEMEMT_RATE, request);
  }

  /**
   * Method to build the request for validating unique payee
   * @param requestParam
   */
  buildRequestToValidateUniquePayee(requestParam: any) {
    const requestObject = {
      payee: {
        corporateEntityCode: requestParam.corporateEntityCode,
        pinGroupId: requestParam.pinGroupId,
        networkAssociationID: requestParam.networkAssociationID,
        networkCode: requestParam.networkCode,
        capitationProcessCode: requestParam.capitationProcessCode,
        payToPfinId: requestParam.payToPfinId,
        capitationCode: requestParam.capitationCode,
        pinGroupName: requestParam.pinGroupName,
        taxIdNumber: requestParam.taxIdNumber
      }
    };

    return requestObject;
  }

  /**
   * API call to validate the unique payee
   * @param requestParam
   */
  validateUniquePayee(requestParam: Object) {
    return this.http.post(this.BASE_URL + resourceEndPoints.VALIDATE_UNIQUE_PAYEE, requestParam);
  }

  /**
   * Method to build the request to save payee
   */
  buildRequestToSavePayee(requestInfo: any) {
    const requestObject = {
      corporateEntityCode: requestInfo.providerData.corporateEntityCode,
      networkAssociationID: requestInfo.providerData.networkAssociationID,
      networkCode: requestInfo.providerData.networkCode,
      capitationProcessCode: requestInfo.providerData.capitationProcessCode,
      pinGroupId: requestInfo.providerData.pinGroupId,
      payToPfinId: requestInfo.providerData.payToPfinId,
      capitationCode: requestInfo.providerData.capitationCode,
      pinGroupName: requestInfo.providerData.pinGroupName,
      taxIdNumber: requestInfo.providerData.taxIdNumber,
      networkAssociationEffectiveDate: requestInfo.providerData.networkAssociationEffectiveDate,
      networkAssociationEndDate: requestInfo.providerData.networkAssociationEndDate,
      pfinEffectiveDate: requestInfo.providerData.pfinEffectiveDate,
      pfinEndDate: requestInfo.providerData.pfinEndDate,
      pinGroupEffectiveDate: requestInfo.providerData.pinGroupEffectiveDate,
      pinGroupEndDate: requestInfo.providerData.pinGroupEndDate,
      pingroupCapitationEffectiveDate: requestInfo.providerData.pingroupCapitationEffectiveDate,
      pingroupCapitationEndDate: requestInfo.providerData.pingroupCapitationEndDate,
      tinEffectiveDate: requestInfo.providerData.tinEffectiveDate,
      tinEndDate: requestInfo.providerData.tinEndDate,
      recordEffectiveDate: requestInfo.recordEffectiveDate,
      recordEndDate: requestInfo.recordEndDate,
      createUserId: requestInfo.userId,
      updateUserId: requestInfo.userId,
      createRecordTimestamp: requestInfo.createRecordTimestamp,
      updateRecordTimestamp: requestInfo.updateRecordTimestamp
    };
    return requestObject;
  }

  /**
   * searchExistingPayees
   * @param requestObject
   * Method to search existing payees
   */
  searchExistingPayees(requestObject: Object) {
    return this.http.post(this.BASE_URL + resourceEndPoints.SEARCH_EXISTING_PAYEES, requestObject);
  }
}

