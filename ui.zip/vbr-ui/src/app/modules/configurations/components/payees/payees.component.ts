import {
  Component,
  OnInit,
  OnDestroy
} from '@angular/core';
import { ModalService } from '../../../../shared/services/modal.service';
import { CustomDateParserFormatter } from '../../../../shared/modules/ui/components/datepicker/customdateparserformatter';
import { ConfigurationService } from '../../services/configuration.service';
import { UserCacheService } from '../../../../shared/services/user-cache.service';
import {
  PayeeSearch,
  CorporateEntity,
  Payees,
  Providers,
  Provider,
  SavePayee,
  Errors,
  Error,
  VBRDates
} from '../../../../models/configuration.model';
import {
  ALPHA_NUMERIC_PATTERN,
  DATE_PATTERN,
  PAYEES_ROLES
} from '../../../../shared/constants/app.constants';
import { UtilService } from 'src/app/shared/services/util.service';
import _ from 'lodash';
import { SharedService } from 'src/app/shared/services/shared.service';
import { LoadingService } from '../../../../shared/modules/loading/loading.module';
import {
  ReturnMessage
} from '../../../../models/shared.model';
import { AuthService } from '../../../../shared/services/auth.service';
import { environment } from '../../../../../environments/environment';

@Component({
  selector: 'app-payees',
  templateUrl: './payees.component.html',
  styleUrls: ['./payees.component.scss']
})
export class PayeesComponent implements OnInit, OnDestroy {
  corporateEntityCode: string;
  corporateEntityDescription: string;

  constructor(
    public modalService: ModalService,
    public customDateParserFormatter: CustomDateParserFormatter,
    private configurationService: ConfigurationService,
    public utilService: UtilService,
    private userCacheService: UserCacheService,
    public sharedService: SharedService,
    public loadingService: LoadingService,
    public authService: AuthService,
  ) {
    this.sharedService.getCorpEntityCode().subscribe(data => this.corporateEntityCode = data);

    this.sharedService.getCorpEntityDescription().subscribe(data => this.corporateEntityDescription = data);
  }
  env = environment;
  payeeSearch: PayeeSearch;
  addPayeeVBRDates: VBRDates;
  editPayeeVBRDates: VBRDates;
  retrieveReqObj: PayeeSearch = {};
  addPayeeSearch: PayeeSearch;
  corporateEntityList: CorporateEntity;
  payeesList: Payees;
  savePayee: SavePayee;
  providerList: Providers;
  providerInfo: Provider = {};
  isSearchError: boolean;
  editErrorList: Errors;
  isEditError: boolean;
  noRecordMsg: Error;
  isNoRecordsDisplay: boolean;
  isViewable: boolean;
  modelPayee: any = false;
  isPatternError: boolean;
  isEffDateError: boolean;
  isEndDateError: boolean;
  isEditEffDateError: boolean;
  isEditEndDateError: boolean;
  editPayeeEffDate: any;
  editPayeeEndDate: any;
  vbrPayeeId: number;
  createRecordTimestamp: any = null;
  updateRecordTimestamp: any = null;
  payeeType: string;
  currentRows: any;
  pinGroupName: any;
  rowData: any;
  selectPremierPayee: any;
  payeeArrang: boolean;
  payeeErrorCheck: boolean;
  returnMessage: ReturnMessage;
  checkRoles: boolean;
  vbrPayeeProviderEffectiveAndEndDates: boolean;
  vbrPayeeEffectiveDate: boolean;
  vbrPayeeEndDate: boolean;
  vbrPayeePinGroupId: boolean;
  vbrPayeeEffectiveAndEndDate: boolean;
  /**
   * Method: ngOnInit
   * Method called after the constructor and after the first ngOnChanges()
   * ngOnInit, get called after Component initialised!
   */
  ngOnInit() {
    this.initializeAddPayeeSearchForm();
    this.initializePayeeSearch();
    this.getCorporateEntities();
    this.initializeVBRDates();
    this.isViewable = false;
    this.payeeArrang = true;
    this.payeeErrorCheck = false;
    this.checkRoles = this.env.SSO_CONFIG.enableSSO ? !this.authService.isAuthorized(PAYEES_ROLES) : false;
  }

  /* Method : initializeVBRDates
   * This method is used to initialize the values to empty
   */
  initializeVBRDates() {
    this.addPayeeVBRDates = { VBRPayeeEffectiveDate: '', VBRPayeeEndDate: '' };
    this.editPayeeVBRDates = { VBRPayeeEffectiveDate: '', VBRPayeeEndDate: '' };
  }

  /* Method : initializeAddPayeeSearchForm
   * This method is used to set the default values for the search fields in add payee screen
   */
  initializeAddPayeeSearchForm() {
    this.addPayeeSearch = {
      corpEntityCode: this.corporateEntityCode,
      pinGroupId: ''
    };
  }

  /* Method : initializePayeeSearch
   * This method is used to set the default values for the search fields in payee search screen
   */
  initializePayeeSearch() {
    this.payeeSearch = {
      corpEntityCode: this.corporateEntityCode,
      pinGroupId: ''
    };
  }
  /* Method : getCorporateEntities
   * This method is used to retrieve list of corporate entity codes
   */
  getCorporateEntities() {
    this.loadingService.show();
    this.configurationService.getCorporateEntities().subscribe(
      (data: CorporateEntity) => {
        this.loadingService.hide();
        this.corporateEntityList = data;
      },
      error => {
        this.loadingService.hide();
      }
    );
  }

  /* Method : search
   * This method is used to call the service method to retrieve the payees
   */
  search() {
    this.isViewable = false;
    this.loadingService.show();
    this.sharedService.clearToasts();
    this.configurationService.getPayeesFromDB(this.payeeSearch).subscribe(
      (data: Payees) => {
        this.loadingService.hide();
        if (data.payees.length > 0) {
          this.isViewable = true;
          this.payeesList = data;
        }
      },
      error => {
        this.loadingService.hide();
        this.sharedService.handleErrorSuccessWarningInfo('FAILURE', error, 'Payees Warnings');
      }
    );
  }

  /**
   * retrieveProviderRecords
   * @param requestParam
   * @param id
   * Method to retrieve Provider records and display in UI
   */
  retrieveProviderRecords(requestParam, id: string) {
    this.payeeErrorCheck = false;
    this.isNoRecordsDisplay = false;
    this.providerInfo = {};
    this.rowData = {};
    this.loadingService.show();
    this.configurationService.getProviderPayees(requestParam).subscribe((data: any) => {
      this.loadingService.hide();
      this.providerDataOnSuccess(data, id);
    },
      error => {
        this.loadingService.hide();
        this.returnMessage = error;
        this.isNoRecordsDisplay = true;
      });
  }

  /**
   * retrieveProviderRecord
   * @param reqParam
   * @param id
   * Method to retrieve provider record and display in UI
   */
  retrieveProviderRecord(reqParam: any, id: string) {
    this.isEditError = false;
    this.providerInfo = {};
    this.rowData = {};
    this.sharedService.clearToasts();
    this.loadingService.show();
    this.configurationService.getPayeesFromProviderAPI(reqParam).subscribe(
      (data: any) => {
        this.loadingService.hide();
        this.providerDataOnSuccess(data, id);
      },
      error => {
        this.loadingService.hide();
        this.sharedService.handleErrorSuccessWarningInfo('FAILURE', error, 'Payee Warnings');
      }
    );
  }

  /**
   * outlineFieldsForError
   * @param errorFieldList
   * Method to outline elements based on error from API
   */
  outlineFieldsForError(errorFieldList: any) {
    if (errorFieldList && errorFieldList.returnMessage && errorFieldList.returnMessage.errors) {
      errorFieldList.returnMessage.errors.forEach((data: any) => {
        if (data.fieldId === 'vbrPayeeProviderEffectiveAndEndDates') {
          this.vbrPayeeProviderEffectiveAndEndDates = true;
        }
        if (data.fieldId === 'vbrPayeeEffectiveDate') {
          this.vbrPayeeEffectiveDate = true;
        }
        if (data.fieldId === 'vbrPayeeEndDate') {
          this.vbrPayeeEndDate = true;
        }
        if (data.fieldId === 'vbrPayeePinGroupId') {
          this.vbrPayeePinGroupId = true;
        }
        if (data.fieldId === 'vbrPayeeEffectiveAndEndDate') {
          this.vbrPayeeEffectiveAndEndDate = true;
        }
      });
    }
  }

  /**
   * providerDataOnSuccess
   * @param data
   * @param id
   * Method to update the success message and warnings
   */
  providerDataOnSuccess(data: any, id: string) {
    let providerData: any = [];
    if (id === 'edit-payee-1') {
      providerData.push(data.vbrPayee);
      this.providerInfo = data.vbrPayee;
      this.modalService.open(id);
    } else if (id === 'select-payee-step-1') {
      providerData = data.payees;
      this.addPayeeSearchResult(id);
    }
    this.providerList = providerData;
    this.rowData = this.providerList;
    this.pinGroupName = 'pinGroupName';
    this.onCurrentRowChange(this.providerList);
  }

  /* Method : savePayee
   * This method is used to save the payee record in DB
   */
  savePayeeRecord(reqParam: any, id: string) {
    this.vbrPayeeProviderEffectiveAndEndDates = false;
    this.vbrPayeeEffectiveDate = false;
    this.vbrPayeeEndDate = false;
    this.sharedService.clearToasts();
    this.isEditError = false;
    this.loadingService.show();
    this.configurationService.savePayeesToDB(reqParam).subscribe(
      (data: any) => {
        this.loadingService.hide();
        // on success, call method to display warnings
        if (id === 'select-payee-step-3') {
          this.initializeVBRDates();
          this.sharedService.handleErrorSuccessWarningInfo('SUCCESS', data);
          this.modalService.close(id);
        } else {
          this.updatePayeeRecord(data, id);
        }
      },
      error => {
        this.loadingService.hide();
        this.outlineFieldsForError(error);
        this.returnMessage = error;
        this.isEditError = true;
      }
    );
  }

  /**
   * @param data, id
   * Method: updatePayeeRecord
   * Method to update the effective and end date in payee list
   */
  updatePayeeRecord(data: any, id: string) {
    this.search();
    this.modalService.close(id);
    this.sharedService.handleErrorSuccessWarningInfo('SUCCESS', data);
    if (data.returnMessage && data.returnMessage.warnings.length > 0) {
      this.sharedService.handleErrorSuccessWarningInfo('FAILURE', data, 'Payee Warnings');
    }
  }

  /**
   * @param id
   * Method: add
   * Method to open the select-payee-step-1 modal pop window
   */
  add(id: string) {
    this.sharedService.clearToasts();
    this.initializeAddPayeeSearchForm();
    this.isPatternError = false;
    this.isEffDateError = false;
    this.isEndDateError = false;
    this.isNoRecordsDisplay = false;
    this.isEditError = false;
    this.clearOutlinedError();
    this.modalService.open(id);
  }

  /**
   * clearOutlinedError
   * Method to clear the outline errors
   */
  clearOutlinedError() {
    this.vbrPayeeEffectiveDate = false;
    this.vbrPayeeEffectiveAndEndDate = false;
    this.vbrPayeeProviderEffectiveAndEndDates = false;
    this.vbrPayeeEndDate = false;
    this.vbrPayeePinGroupId = false;
  }

  /* Method : validatePinGroupId
   * Args: matchString - Pin group Id
   * This method is used to validate the pin group id Add Payee search model and show error message below the field.
   */
  validatePinGroupId(matchString: any) {
    this.isPatternError = !this.pinGroupValidation(matchString);
  }

  /* Method : validateSearchPinGroupId
   * Args: matchString - Pin group Id
   * This method is used to validate the pin group id in payee search screen and show error message below the field.
   */
  validateSearchPinGroupId(matchString: any) {
    this.isSearchError = !this.pinGroupValidation(matchString);
  }

  /* Method : pinGroupValidation
   * Args: matchString - Pin group Id
   * This method is used to validate the pin group id with the pattern
   */
  pinGroupValidation(matchString: any) {
    return this.utilService.patterMatch(ALPHA_NUMERIC_PATTERN, matchString);
  }

  /**
   * @param id, searchProviderData
   *  Method : editPayee
   * This method is used to retrieve the individual payee record.
   */
  editPayee(id: string, searchProviderData: any) {
    this.clearOutlinedError();
    this.retrieveReqObj.corpEntityCode = searchProviderData.corporateEntityCode;
    this.retrieveReqObj.networkAssociationID =
      searchProviderData.networkAssociationID;
    this.retrieveReqObj.networkCode = searchProviderData.networkCode;
    this.retrieveReqObj.pinGroupId = searchProviderData.pinGroupId;
    this.retrieveReqObj.payToPFIN = searchProviderData.payToPfinId;
    this.retrieveReqObj.capitationTypeCode = searchProviderData.capitationCode;
    this.retrieveReqObj.processCode = searchProviderData.capitationProcessCode;
    this.editPayeeEffDate = searchProviderData.recordEffectiveDate;
    this.editPayeeEndDate = searchProviderData.recordEndDate;
    this.vbrPayeeId = searchProviderData.vbrPayeeId;
    this.retrieveReqObj.pinGroupName = searchProviderData.pinGroupName;
    this.retrieveReqObj.taxIdNumber = searchProviderData.taxIdNumber;
    this.retrieveReqObj.vbrPayeeId = searchProviderData.vbrPayeeId;
    this.createRecordTimestamp = searchProviderData.createRecordTimestamp;
    this.updateRecordTimestamp = searchProviderData.updateRecordTimestamp;
    this.editPayeeVBRDates.VBRPayeeEffectiveDate = this.customDateParserFormatter.parse(
      this.editPayeeEffDate
    );
    this.editPayeeVBRDates.VBRPayeeEndDate = this.customDateParserFormatter.parse(
      this.editPayeeEndDate
    );
    this.retrieveProviderRecord(this.retrieveReqObj, id);
  }

  /* Method : validateVBRDate
   * This method is used to validate VBR date and show/hide the error message
   */
  validateVBRDate(date: string, errorId: string) {
    if (!this.validateDate(date)) {
      this.setErrorMessage(errorId, true);
    } else {
      this.setErrorMessage(errorId, false);
    }
  }

  /* Method : setErrorMessage
   * This method is used to show/hide the error message
   */
  setErrorMessage(errorId, trueOrFalse: boolean) {
    switch (errorId) {
      case 'isEffDateError':
        this.isEffDateError = trueOrFalse;
        break;
      case 'isEndDateError':
        this.isEndDateError = trueOrFalse;
        break;
      case 'isEditEffDateError':
        this.isEditEffDateError = trueOrFalse;
        break;
      case 'isEditEndDateError':
        this.isEditEndDateError = trueOrFalse;
        break;
    }
  }

  /* Method : setUpperCase
   * This method is used to convert the string to upper case
   */
  setUpperCase() {
    this.payeeSearch.pinGroupId = this.payeeSearch.pinGroupId.toUpperCase();
    this.addPayeeSearch.pinGroupId = this.addPayeeSearch.pinGroupId.toUpperCase();
  }

  /* Method : validateDate
   * This method is used to do date validation
   */
  validateDate(date: any) {
    return date !== '' && date !== null && date !== undefined
      ? this.utilService.patterMatch(DATE_PATTERN, this.customDateParserFormatter.format(date))
      : false;
  }

  /* Method : editPayeeReset
   * This method to reset the user modified dates to orginal dates
   */
  editPayeeReset() {
    this.vbrPayeeProviderEffectiveAndEndDates = false;
    this.vbrPayeeEndDate = false;
    this.vbrPayeeEffectiveDate = false;
    this.editPayeeVBRDates.VBRPayeeEffectiveDate = this.customDateParserFormatter.parse(
      this.editPayeeEffDate
    );
    this.editPayeeVBRDates.VBRPayeeEndDate = this.customDateParserFormatter.parse(
      this.editPayeeEndDate
    );
    this.isEditEffDateError = false;
    this.isEditEndDateError = false;
    this.isEditError = false;
  }

  /* Method : searchProvider
   * This method is called when the user click on search or Next button of the Add payee Model
   */
  searchProvider() {
    this.selectPremierPayee = '';
    const requestParam: PayeeSearch[] = [];
    requestParam.push(this.addPayeeSearch);
    this.retrieveProviderRecords(requestParam, 'select-payee-step-1');
  }

  /* Method : searchProvider
   * This method is used to close and open the models of add payee screen
   */
  addPayeeSearchResult(id: string) {
    this.modalService.close(id);
    this.modalService.open('select-payee-step-2');
    this.payeeType = 'premier_provider';
  }

  /**
   * cancelStep1
   * @param id
   * Method to cancel step 1
   */
  cancelStep1(id: string) {
    this.initializeAddPayeeSearchForm();
    this.isNoRecordsDisplay = false;
    this.isEditError = false;
    this.modalService.close(id);
  }

  /**
   * cancelStep2
   * @param id
   * Method to cancel step 2
   */
  cancelStep2(id: string) {
    this.payeeErrorCheck = false;
    this.modelPayee = false;
    this.modalService.close(id);
  }

  /**
   * navigateToAddPayeeDates
   * @param id
   * Method to navigate to add Payee Dates
   */
  navigateToAddPayeeDates(id: string) {
    this.payeeErrorCheck = false;
    this.modalService.close(id);
    this.modalService.open('select-payee-step-3');
  }

  /**
   * cancelStep3
   * @param id
   * Method to cancel step 3
   */
  cancelStep3(id: string) {
    this.initializeVBRDates();
    this.isEditError = false;
    this.modalService.close(id);
  }

  /**
   * modifySearch
   * @param id
   * Method to modify search
   */
  modifySearch(id: string) {
    this.modelPayee = false;
    this.modalService.close(id);
    this.modalService.open('select-payee-step-1');
  }

  /**
   * newSearch
   * @param id
   * Method to search new
   */
  newSearch(id: string) {
    this.modelPayee = false;
    this.modalService.close(id);
    this.modalService.open('select-payee-step-1');
    this.initializeAddPayeeSearchForm();
  }


  /**
   * editSaveProvider
   * @param id
   * Method to edit  provider
   */
  editSaveProvider(id: string) {
    this.generateProviderObject(this.editPayeeVBRDates);
    this.savePayee.payee.vbrPayeeId = this.vbrPayeeId;
    this.savePayee.payee.createRecordTimestamp = this.createRecordTimestamp;
    this.savePayee.payee.updateRecordTimestamp = this.updateRecordTimestamp;
    this.savePayee.payee.rowAction = 'UPDATE';
    this.savePayeeRecord(this.savePayee, id);
  }

  /**
   * generateProviderObject
   * @param VBRDates
   * Method to generate provider request object
   */
  generateProviderObject(VBRDates: any) {
    const requestObject = {
      providerData: this.providerInfo,
      userId: this.userCacheService.getUserCacheData('USER_ID'),
      recordEffectiveDate: this.customDateParserFormatter.format(VBRDates.VBRPayeeEffectiveDate),
      recordEndDate: this.customDateParserFormatter.format(VBRDates.VBRPayeeEndDate),
      createRecordTimestamp: null,
      updateRecordTimestamp: null
    };
    this.savePayee = {
      payee: this.configurationService.buildRequestToSavePayee(requestObject)
    };
  }

  /**
   * saveProvider
   * @param id
   * Method to save add provider
   */
  saveProvider(id: string) {
    this.generateProviderObject(this.addPayeeVBRDates);
    this.savePayee.payee.rowAction = 'INSERT';
    this.savePayeeRecord(this.savePayee, id);
  }

  /**
   * cancelEdit
   * @param id
   * Method to cancel Edit payee
   */
  cancelEdit(id: string) {
    this.vbrPayeeEffectiveDate = false;
    this.vbrPayeeEndDate = false;
    this.isEditEffDateError = false;
    this.isEditEndDateError = false;
    this.isEditError = false;
    this.isNoRecordsDisplay = false;
    this.providerInfo = {};
    this.modalService.close(id);
  }

  /* Method : toggle
   * This method is used to do validate the search fields
   */
  public toggle(): void {
    this.isSearchError = this.isViewable = false;
    if (this.payeeSearch.pinGroupId !== '') {
      if (this.pinGroupValidation(this.payeeSearch.pinGroupId)) {
        this.search();
      } else {
        this.isSearchError = true;
      }
    } else {
      this.search();
    }
  }

  /**
   * selectProvider
   * @param provider
   * Method to select provider and check for unique payee
   */
  selectProvider(provider: object) {
    this.modelPayee = false;
    this.payeeErrorCheck = false;
    this.loadingService.show();
    this.configurationService.validateUniquePayee(this.configurationService.buildRequestToValidateUniquePayee(provider)).subscribe((data: any) => {
      this.loadingService.hide();
      this.payeeErrorCheck = false;
      this.modelPayee = true;
      this.providerInfo = provider;
    },
      error => {
        this.loadingService.hide();
        this.modelPayee = false;
        this.payeeErrorCheck = true;
        this.returnMessage = error;
      });
  }

  /**
   * onCurrentRowChange
   * @param currentRow
   * Method to update current row
   */
  onCurrentRowChange(currentRow: any) {
    this.currentRows = currentRow;
  }

  /**
   * Life cycle hook after component destroy
   */
  ngOnDestroy() {
    this.sharedService.clearToasts();
  }
}
