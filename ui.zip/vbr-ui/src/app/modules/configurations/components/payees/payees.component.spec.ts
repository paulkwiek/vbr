import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CommonModule, CurrencyPipe } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { PayeesComponent } from './payees.component';
import { UIModule } from '../../../../shared/modules/ui/ui.module';

import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { ModalService } from '../../../../shared/services/modal.service';
import { TableModule } from '../../tables';
import { CustomDateParserFormatter } from '../../../../shared/modules/ui/components/datepicker/customdateparserformatter';
import { NgbDateParserFormatter } from '@ng-bootstrap/ng-bootstrap';
import { LoadingModule } from '../../../../shared/modules/loading/loading.module';
import { AppConfigService } from '../../../../app-config.service';
import { Store, StoreModule } from '@ngrx/store';
import { environment } from '../../../../../environments/environment';

describe('PayeesComponent', () => {
  let component: PayeesComponent;
  let fixture: ComponentFixture<PayeesComponent>;
  AppConfigService.settings = {
    'env': {
      'name': 'DEV2'
    },
    'baseUrls': {
      'BASE_URL': 'https://vbr-arrangementconfig-service-dev2.cfaa.hcsctest.net',
      'BASE_URL_CODE_SERVICE': 'https://vbr-code-service-dev2.cfaa.hcsctest.net',
      'BASE_URL_CALCULATION_SERVICE': 'https://vbr-calculation-service-dev2.cfaa.hcsctest.net',
      'BASE_URL_REPORT': 'https://tableau.test.fyiblue.com/views/'
    },
    'reportUrls': {
      'CAP_SUMMARY_REPORT': 'CapSummaryReport_15735714904500/CapSummaryReport?iframeSizedToWindow=true&:embed=y&:showAppBanner=false&:display_count=no&:showVizHome=no',
      'MEMBERSHIP_ERROR_REPORT': 'MembershipErrorReport_15736417170040/MembershipErrorReport?iframeSizedToWindow=true&:embed=y&:showAppBanner=false&:display_count=no&:showVizHome=no',
      'COMPARISON_REPORT_FOR_APPROVED_FINANCIAL_CALCULATION_DATA': 'ComparisonReportforFinancialCalculationData_15735718388110/ComparisonReportforFinancialcalculationData?iframeSizedToWindow=true&:embed=y&:showAppBanner=false&:display_count=no&:showVizHome=no',
      'COMPARISON_REPORT_FOR_PRELIMINARY_RUN_CALCULATION_DATA': 'ComparisonReportforPreliminaryCalculationData_15735719621730/ComparisonReportforPreliminaryCalculationData?iframeSizedToWindow=true&:embed=y&:showAppBanner=false&:display_count=no&:showVizHome=no',
      'COMPARISON_REPORT_FOR_APPROVED_CALCULATION_DATA': '',
      'RETROACTIVITY_SUMMARY_REPORT': '',
      'NM10931_CAP_DISTRIBUTION_REPORT': 'NM10931-CapDistributionReport_15736400047190/NM10931-CAPDISTRIBUTIONREPORT?iframeSizedToWindow=true&:embed=y&:showAppBanner=false&:display_count=no&:showVizHome=no',
      'NM10940_PRELIMINARY_EFT_REGISTER': 'NM10940-PreliminaryEFTRegisterReport/NM10940-PreliminaryCapEFTRegisterReport?iframeSizedToWindow=true&:embed=y&:showAppBanner=false&:display_count=no&:showVizHome=no',
      'NM10940_FINAL_EFT_REGISTER': 'NM10940-FinalEFTRegisterReport_15736399695060/NM10941-FinalEFTRegisterReport?iframeSizedToWindow=true&:embed=y&:showAppBanner=false&:display_count=no&:showVizHome=no',
      'NM10932_FINAL_OPEN_ITEM_REGISTER': ''
    }
  };

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        CommonModule,
        FormsModule,
        HttpClientModule,
        UIModule,
        NgbModule,
        TableModule,
        LoadingModule,
        StoreModule.forRoot({})
      ],
      declarations: [PayeesComponent],
      providers: [
        CurrencyPipe,
        {
          provide: NgbDateParserFormatter,
          useClass: CustomDateParserFormatter
        },
        CustomDateParserFormatter,
        ModalService, Store
      ]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PayeesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    component.env = environment;
    component.payeesList = {
      payees: [
        {
          recordEffectiveDate: '02/01/2006',
          recordEndDate: '11/29/2006',
          vbrPayeeId: 1,
          corporateEntityCode: 'NM1',
          pinGroupId: 'RSK',
          pinGroupName: 'RSK009',
          capitationProcessCode: 'CP',
          networkCode: 'MCD',
          taxIdNumber: '999999999',
          capitationCode: 'A1',
          payToPfinId: '00NMCAP015',
          networkAssocProviderId: '772129110'
        },
        {
          recordEffectiveDate: '10/20/2017',
          recordEndDate: '02/03/2018',
          vbrPayeeId: 2,
          corporateEntityCode: 'NM1',
          pinGroupId: 'RSK',
          pinGroupName: 'RSK009',
          capitationProcessCode: 'CP',
          networkCode: 'MCD',
          capitationCode: 'A1',
          payToPfinId: '00NMCAP015'
        },
        {
          recordEffectiveDate: '10/20/2017',
          recordEndDate: '02/03/2018',
          vbrPayeeId: 3,
          corporateEntityCode: 'NM1',
          pinGroupId: 'RSK',
          pinGroupName: 'RSK009',
          capitationProcessCode: 'CP',
          networkCode: 'MCD',
          capitationCode: 'A1',
          payToPfinId: '00NMCAP015'
        },
        {
          recordEffectiveDate: '02/01/2006',
          recordEndDate: '12/31/2006',
          vbrPayeeId: 4,
          corporateEntityCode: 'NM1',
          pinGroupId: 'RSK',
          pinGroupName: 'MJKNMCAPPIGLET',
          capitationProcessCode: 'CP',
          networkCode: 'MCD',
          taxIdNumber: '999999999',
          capitationCode: 'A1',
          payToPfinId: '00NMCAP015',
          networkAssocProviderId: '772129110'
        },
        {
          recordEffectiveDate: '02/01/2006',
          recordEndDate: '11/07/2006',
          vbrPayeeId: 5,
          corporateEntityCode: 'NM1',
          pinGroupId: 'RSK',
          pinGroupName: 'RSK009',
          capitationProcessCode: 'CP',
          networkCode: 'MCD',
          taxIdNumber: '999999999',
          capitationCode: 'A1',
          payToPfinId: '00NMCAP016',
          networkAssocProviderId: '772129110'
        },
        {
          recordEffectiveDate: '02/01/2006',
          recordEndDate: '11/30/2006',
          vbrPayeeId: 6,
          corporateEntityCode: 'NM1',
          pinGroupId: 'RSK',
          pinGroupName: 'RSK009',
          capitationProcessCode: 'CP',
          networkCode: 'MCD',
          taxIdNumber: '999999999',
          capitationCode: 'A1',
          payToPfinId: '00NMCAP016',
          networkAssocProviderId: '772129110'
        },
        {
          recordEffectiveDate: '02/01/2006',
          recordEndDate: '11/30/2006',
          vbrPayeeId: 7,
          corporateEntityCode: 'NM1',
          pinGroupId: 'RSK',
          pinGroupName: 'RSK009',
          capitationProcessCode: 'CP',
          networkCode: 'MCD',
          taxIdNumber: '999999999',
          capitationCode: 'A1',
          payToPfinId: '00NMCAP015',
          networkAssocProviderId: '772129110'
        },
        {
          recordEffectiveDate: '02/01/2006',
          recordEndDate: '12/31/2006',
          vbrPayeeId: 8,
          corporateEntityCode: 'NM1',
          pinGroupId: 'RSK',
          pinGroupName: 'MJKNMCAPPIGLET',
          capitationProcessCode: 'CP',
          networkCode: 'MCD',
          taxIdNumber: '999999999',
          capitationCode: 'A1',
          payToPfinId: '00NMCAP015',
          networkAssocProviderId: '772129110'
        },
        {
          recordEffectiveDate: '02/01/2006',
          recordEndDate: '12/31/2006',
          vbrPayeeId: 9,
          corporateEntityCode: 'NM1',
          pinGroupId: 'RSK',
          pinGroupName: 'MJKNMCAPPIGLET',
          capitationProcessCode: 'CP',
          networkCode: 'MCD',
          taxIdNumber: '999999999',
          capitationCode: 'A1',
          payToPfinId: '00NMCAP015',
          networkAssocProviderId: '772129110'
        },
        {
          recordEffectiveDate: '11/01/2006',
          recordEndDate: '12/01/2006',
          vbrPayeeId: 10,
          corporateEntityCode: 'NM1',
          pinGroupId: 'RSK',
          pinGroupName: 'MJKNMCAPPIGLET',
          capitationProcessCode: 'CP',
          networkCode: 'MCD',
          taxIdNumber: '999999999',
          capitationCode: 'A1',
          payToPfinId: '00NMCAP015',
          networkAssocProviderId: '772129110'
        },
        {
          recordEffectiveDate: '11/01/2006',
          recordEndDate: '12/01/2006',
          vbrPayeeId: 11,
          corporateEntityCode: 'NM1',
          pinGroupId: 'RSK',
          pinGroupName: 'MJKNMCAPPIGLET',
          capitationProcessCode: 'CP',
          networkCode: 'MCD',
          taxIdNumber: '999999999',
          capitationCode: 'A1',
          payToPfinId: '00NMCAP015',
          networkAssocProviderId: '772129110'
        },
        {
          recordEffectiveDate: '06/12/2006',
          recordEndDate: '06/20/2006',
          vbrPayeeId: 12,
          corporateEntityCode: 'NM1',
          pinGroupId: 'RSK',
          pinGroupName: 'RSK009',
          capitationProcessCode: 'CP',
          networkCode: 'MCD',
          taxIdNumber: '999999999',
          capitationCode: 'A1',
          payToPfinId: '00NMCAP015',
          networkAssocProviderId: '772129110'
        },
        {
          recordEffectiveDate: '02/01/2006',
          recordEndDate: '10/30/2006',
          vbrPayeeId: 13,
          corporateEntityCode: 'NM1',
          pinGroupId: 'RSK',
          pinGroupName: 'RSK009',
          capitationProcessCode: 'CP',
          networkCode: 'MCD',
          taxIdNumber: '999999999',
          capitationCode: 'A1',
          payToPfinId: '00NMCAP015',
          networkAssocProviderId: '772129110'
        },
        {
          recordEffectiveDate: '02/01/2006',
          recordEndDate: '10/30/2006',
          vbrPayeeId: 14,
          corporateEntityCode: 'NM1',
          pinGroupId: 'RSK',
          pinGroupName: 'RSK009',
          capitationProcessCode: 'CP',
          networkCode: 'MCD',
          taxIdNumber: '999999999',
          capitationCode: 'A1',
          payToPfinId: '00NMCAP015',
          networkAssocProviderId: '772129110'
        },
        {
          recordEffectiveDate: '02/01/2006',
          recordEndDate: '12/31/2006',
          vbrPayeeId: 15,
          corporateEntityCode: 'NM1',
          pinGroupId: 'RSK',
          pinGroupName: 'MJKNMCAPPIGLET',
          capitationProcessCode: 'CP',
          networkCode: 'MCD',
          taxIdNumber: '999999999',
          capitationCode: 'A1',
          payToPfinId: '00NMCAP015',
          networkAssocProviderId: '772129110'
        },
        {
          recordEffectiveDate: '02/22/2006',
          recordEndDate: '12/31/2006',
          vbrPayeeId: 16,
          corporateEntityCode: 'NM1',
          pinGroupId: 'RSK',
          pinGroupName: 'MJKNMCAPPIGLET',
          capitationProcessCode: 'CP',
          networkCode: 'MCD',
          taxIdNumber: '999999999',
          capitationCode: 'A1',
          payToPfinId: '00NMCAP015',
          networkAssocProviderId: '772129110'
        },
        {
          recordEffectiveDate: '07/04/2006',
          recordEndDate: '07/15/2006',
          vbrPayeeId: 17,
          corporateEntityCode: 'NM1',
          pinGroupId: 'RSK',
          pinGroupName: 'RSK009',
          capitationProcessCode: 'CP',
          networkCode: 'MCD',
          taxIdNumber: '999999999',
          capitationCode: 'A1',
          payToPfinId: '00NMCAP015',
          networkAssocProviderId: '772129110'
        },
        {
          recordEffectiveDate: '02/01/2006',
          recordEndDate: '12/31/2006',
          vbrPayeeId: 18,
          corporateEntityCode: 'NM1',
          pinGroupId: 'RSK',
          pinGroupName: 'MJKNMCAPPIGLET',
          capitationProcessCode: 'CP',
          networkCode: 'MCD',
          taxIdNumber: '999999999',
          capitationCode: 'A1',
          payToPfinId: '00NMCAP015',
          networkAssocProviderId: '772129110'
        },
        {
          recordEffectiveDate: '02/01/2006',
          recordEndDate: '12/31/2006',
          vbrPayeeId: 19,
          corporateEntityCode: 'NM1',
          pinGroupId: 'RSK',
          pinGroupName: 'MJKNMCAPPIGLET',
          capitationProcessCode: 'CP',
          networkCode: 'MCD',
          taxIdNumber: '999999999',
          capitationCode: 'A1',
          payToPfinId: '00NMCAP015',
          networkAssocProviderId: '772129110'
        },
        {
          recordEffectiveDate: '02/01/2006',
          recordEndDate: '12/31/2006',
          vbrPayeeId: 20,
          corporateEntityCode: 'NM1',
          pinGroupId: 'RSK',
          pinGroupName: 'MJKNMCAPPIGLET',
          capitationProcessCode: 'CP',
          networkCode: 'MCD',
          taxIdNumber: '999999999',
          capitationCode: 'A1',
          payToPfinId: '00NMCAP015',
          networkAssocProviderId: '772129110'
        },
        {
          recordEffectiveDate: '02/01/2006',
          recordEndDate: '12/31/2006',
          vbrPayeeId: 21,
          corporateEntityCode: 'NM1',
          pinGroupId: 'RSK',
          pinGroupName: 'MJKNMCAPPIGLET',
          capitationProcessCode: 'CP',
          networkCode: 'MCD',
          taxIdNumber: '999999999',
          capitationCode: 'A1',
          payToPfinId: '00NMCAP015',
          networkAssocProviderId: '772129110'
        },
        {
          recordEffectiveDate: '07/01/2006',
          recordEndDate: '07/31/2006',
          vbrPayeeId: 22,
          corporateEntityCode: 'NM1',
          pinGroupId: 'RSK',
          pinGroupName: 'RSK010',
          capitationProcessCode: 'CP',
          networkCode: 'MCD',
          taxIdNumber: '999999999',
          capitationCode: 'A1',
          payToPfinId: '00NMCAP016',
          networkAssocProviderId: '772129110'
        },
        {
          recordEffectiveDate: '02/01/2006',
          recordEndDate: '12/31/2006',
          vbrPayeeId: 23,
          corporateEntityCode: 'NM1',
          pinGroupId: 'RSK',
          pinGroupName: 'MJKNMCAPPIGLET',
          capitationProcessCode: 'CP',
          networkCode: 'MCD',
          taxIdNumber: '999999999',
          capitationCode: 'A1',
          payToPfinId: '00NMCAP015',
          networkAssocProviderId: '772129110'
        },
        {
          recordEffectiveDate: '02/01/2006',
          recordEndDate: '12/31/2006',
          vbrPayeeId: 24,
          corporateEntityCode: 'NM1',
          pinGroupId: 'RSK',
          pinGroupName: 'MJKNMCAPPIGLET',
          capitationProcessCode: 'CP',
          networkCode: 'MCD',
          taxIdNumber: '999999999',
          capitationCode: 'A1',
          payToPfinId: '00NMCAP015',
          networkAssocProviderId: '772129110'
        },
        {
          recordEffectiveDate: '02/01/2006',
          recordEndDate: '12/31/2006',
          vbrPayeeId: 25,
          corporateEntityCode: 'NM1',
          pinGroupId: 'RSK',
          pinGroupName: 'MJKNMCAPPIGLET',
          capitationProcessCode: 'CP',
          networkCode: 'MCD',
          taxIdNumber: '999999999',
          capitationCode: 'A1',
          payToPfinId: '00NMCAP015',
          networkAssocProviderId: '772129110'
        },
        {
          recordEffectiveDate: '02/01/2006',
          recordEndDate: '12/31/2006',
          vbrPayeeId: 26,
          corporateEntityCode: 'NM1',
          pinGroupId: 'RSK',
          pinGroupName: 'MJKNMCAPPIGLET',
          capitationProcessCode: 'CP',
          networkCode: 'MCD',
          taxIdNumber: '999999999',
          capitationCode: 'A1',
          payToPfinId: '00NMCAP015',
          networkAssocProviderId: '772129110'
        },
        {
          recordEffectiveDate: '02/01/2006',
          recordEndDate: '12/31/2006',
          vbrPayeeId: 27,
          corporateEntityCode: 'NM1',
          pinGroupId: 'RSK',
          pinGroupName: 'MJKNMCAPPIGLET',
          capitationProcessCode: 'CP',
          networkCode: 'MCD',
          taxIdNumber: '999999999',
          capitationCode: 'A1',
          payToPfinId: '00NMCAP015',
          networkAssocProviderId: '772129110'
        },
        {
          recordEffectiveDate: '02/01/2006',
          recordEndDate: '12/31/2006',
          vbrPayeeId: 28,
          corporateEntityCode: 'NM1',
          pinGroupId: 'RSK',
          pinGroupName: 'MJKNMCAPPIGLET',
          capitationProcessCode: 'CP',
          networkCode: 'MCD',
          taxIdNumber: '999999999',
          capitationCode: 'A1',
          payToPfinId: '00NMCAP015',
          networkAssocProviderId: '772129110'
        },
        {
          recordEffectiveDate: '02/01/2006',
          recordEndDate: '12/31/2006',
          vbrPayeeId: 29,
          corporateEntityCode: 'NM1',
          pinGroupId: 'RSK',
          pinGroupName: 'MJKNMCAPPIGLET',
          capitationProcessCode: 'CP',
          networkCode: 'MCD',
          taxIdNumber: '999999999',
          capitationCode: 'A1',
          payToPfinId: '00NMCAP015',
          networkAssocProviderId: '772129110'
        },
        {
          recordEffectiveDate: '02/01/2006',
          recordEndDate: '12/31/2006',
          vbrPayeeId: 30,
          corporateEntityCode: 'NM1',
          pinGroupId: 'RSK',
          pinGroupName: 'MJKNMCAPPIGLET',
          capitationProcessCode: 'CP',
          networkCode: 'MCD',
          taxIdNumber: '999999999',
          capitationCode: 'A1',
          payToPfinId: '00NMCAP015',
          networkAssocProviderId: '772129110'
        },
        {
          recordEffectiveDate: '02/01/2006',
          recordEndDate: '12/31/2006',
          vbrPayeeId: 31,
          corporateEntityCode: 'NM1',
          pinGroupId: 'RSK',
          pinGroupName: 'MJKNMCAPPIGLET',
          capitationProcessCode: 'CP',
          networkCode: 'MCD',
          taxIdNumber: '999999999',
          capitationCode: 'A1',
          payToPfinId: '00NMCAP015',
          networkAssocProviderId: '772129110'
        },
        {
          recordEffectiveDate: '02/01/2006',
          recordEndDate: '12/31/2006',
          vbrPayeeId: 32,
          corporateEntityCode: 'NM1',
          pinGroupId: 'RSK',
          pinGroupName: 'MJKNMCAPPIGLET',
          capitationProcessCode: 'CP',
          networkCode: 'MCD',
          taxIdNumber: '999999999',
          capitationCode: 'A1',
          payToPfinId: '00NMCAP015',
          networkAssocProviderId: '772129110'
        },
        {
          recordEffectiveDate: '02/01/2006',
          recordEndDate: '12/31/2006',
          vbrPayeeId: 33,
          corporateEntityCode: 'NM1',
          pinGroupId: 'RSK',
          pinGroupName: 'MJKNMCAPPIGLET',
          capitationProcessCode: 'CP',
          networkCode: 'MCD',
          taxIdNumber: '999999999',
          capitationCode: 'A1',
          payToPfinId: '00NMCAP015',
          networkAssocProviderId: '772129110'
        },
        {
          recordEffectiveDate: '02/01/2006',
          recordEndDate: '12/31/2006',
          vbrPayeeId: 34,
          corporateEntityCode: 'NM1',
          pinGroupId: 'RSK',
          pinGroupName: 'MJKNMCAPPIGLET',
          capitationProcessCode: 'CP',
          networkCode: 'MCD',
          taxIdNumber: '999999999',
          capitationCode: 'A1',
          payToPfinId: '00NMCAP015',
          networkAssocProviderId: '772129110'
        },
        {
          recordEffectiveDate: '04/01/2006',
          recordEndDate: '05/01/2006',
          vbrPayeeId: 35,
          corporateEntityCode: 'NM1',
          pinGroupId: 'RSK',
          pinGroupName: 'RSK010',
          capitationProcessCode: 'CP',
          networkCode: 'MCD',
          taxIdNumber: '999999999',
          capitationCode: 'A1',
          payToPfinId: '00NMCAP016',
          networkAssocProviderId: '772129110'
        },
        {
          recordEffectiveDate: '02/01/2006',
          recordEndDate: '12/31/2006',
          vbrPayeeId: 36,
          corporateEntityCode: 'NM1',
          pinGroupId: 'RSK',
          pinGroupName: 'MJKNMCAPPIGLET',
          capitationProcessCode: 'CP',
          networkCode: 'MCD',
          taxIdNumber: '999999999',
          capitationCode: 'A1',
          payToPfinId: '00NMCAP015',
          networkAssocProviderId: '772129110'
        },
        {
          recordEffectiveDate: '02/01/2006',
          recordEndDate: '12/31/2006',
          vbrPayeeId: 37,
          corporateEntityCode: 'NM1',
          pinGroupId: 'RSK',
          pinGroupName: 'MJKNMCAPPIGLET',
          capitationProcessCode: 'CP',
          networkCode: 'MCD',
          taxIdNumber: '999999999',
          capitationCode: 'A1',
          payToPfinId: '00NMCAP015',
          networkAssocProviderId: '772129110'
        },
        {
          recordEffectiveDate: '04/01/2006',
          recordEndDate: '05/01/2006',
          vbrPayeeId: 38,
          corporateEntityCode: 'NM1',
          pinGroupId: 'RSK',
          pinGroupName: 'RSK009',
          capitationProcessCode: 'CP',
          networkCode: 'MCD',
          taxIdNumber: '999999999',
          capitationCode: 'A1',
          payToPfinId: '00NMCAP015',
          networkAssocProviderId: '772129110'
        },
        {
          recordEffectiveDate: '02/01/2006',
          recordEndDate: '12/31/2006',
          vbrPayeeId: 39,
          corporateEntityCode: 'NM1',
          pinGroupId: 'RSK',
          pinGroupName: 'MJKNMCAPPIGLET',
          capitationProcessCode: 'CP',
          networkCode: 'MCD',
          taxIdNumber: '999999999',
          capitationCode: 'A1',
          payToPfinId: '00NMCAP015',
          networkAssocProviderId: '772129110'
        },
        {
          recordEffectiveDate: '02/01/2006',
          recordEndDate: '12/31/2006',
          vbrPayeeId: 40,
          corporateEntityCode: 'NM1',
          pinGroupId: 'RSK',
          pinGroupName: 'MJKNMCAPPIGLET',
          capitationProcessCode: 'CP',
          networkCode: 'MCD',
          taxIdNumber: '999999999',
          capitationCode: 'A1',
          payToPfinId: '00NMCAP015',
          networkAssocProviderId: '772129110'
        },
        {
          recordEffectiveDate: '11/01/2006',
          recordEndDate: '11/01/2006',
          vbrPayeeId: 41,
          corporateEntityCode: 'NM1',
          pinGroupId: 'RSK',
          pinGroupName: 'RSK009',
          capitationProcessCode: 'CP',
          networkCode: 'MCD',
          taxIdNumber: '999999999',
          capitationCode: 'A1',
          payToPfinId: '00NMCAP015',
          networkAssocProviderId: '772129110'
        },
        {
          recordEffectiveDate: '11/01/2006',
          recordEndDate: '11/01/2006',
          vbrPayeeId: 42,
          corporateEntityCode: 'NM1',
          pinGroupId: 'RSK',
          pinGroupName: 'RSK009',
          capitationProcessCode: 'CP',
          networkCode: 'MCD',
          taxIdNumber: '999999999',
          capitationCode: 'A1',
          payToPfinId: '00NMCAP015',
          networkAssocProviderId: '772129110'
        },
        {
          recordEffectiveDate: '11/01/2006',
          recordEndDate: '11/01/2006',
          vbrPayeeId: 43,
          corporateEntityCode: 'NM1',
          pinGroupId: 'RSK',
          pinGroupName: 'RSK010',
          capitationProcessCode: 'CP',
          networkCode: 'MCD',
          taxIdNumber: '999999999',
          capitationCode: 'A1',
          payToPfinId: '00NMCAP016',
          networkAssocProviderId: '772129110'
        },
        {
          recordEffectiveDate: '02/01/2006',
          recordEndDate: '12/31/2006',
          vbrPayeeId: 44,
          corporateEntityCode: 'NM1',
          pinGroupId: 'RSK',
          pinGroupName: 'MJKNMCAPPIGLET',
          capitationProcessCode: 'CP',
          networkCode: 'MCD',
          taxIdNumber: '999999999',
          capitationCode: 'A1',
          payToPfinId: '00NMCAP015',
          networkAssocProviderId: '772129110'
        },
        {
          recordEffectiveDate: '02/01/2006',
          recordEndDate: '12/31/2006',
          vbrPayeeId: 45,
          corporateEntityCode: 'NM1',
          pinGroupId: 'RSK',
          pinGroupName: 'MJKNMCAPPIGLET',
          capitationProcessCode: 'CP',
          networkCode: 'MCD',
          taxIdNumber: '999999999',
          capitationCode: 'A1',
          payToPfinId: '00NMCAP015',
          networkAssocProviderId: '772129110'
        },
        {
          recordEffectiveDate: '02/22/2006',
          recordEndDate: '12/31/2006',
          vbrPayeeId: 46,
          corporateEntityCode: 'NM1',
          pinGroupId: 'RSK',
          pinGroupName: 'MJKNMCAPPIGLET',
          capitationProcessCode: 'CP',
          networkCode: 'MCD',
          taxIdNumber: '999999999',
          capitationCode: 'A1',
          payToPfinId: '00NMCAP015',
          networkAssocProviderId: '772129110'
        },
        {
          recordEffectiveDate: '03/01/2006',
          recordEndDate: '11/30/2006',
          vbrPayeeId: 47,
          corporateEntityCode: 'NM1',
          pinGroupId: 'RSK',
          pinGroupName: 'RSK009',
          capitationProcessCode: 'CP',
          networkCode: 'MCD',
          taxIdNumber: '999999999',
          capitationCode: 'A1',
          payToPfinId: '00NMCAP015',
          networkAssocProviderId: '772129110'
        },
        {
          recordEffectiveDate: '02/01/2006',
          recordEndDate: '12/31/2006',
          vbrPayeeId: 48,
          corporateEntityCode: 'NM1',
          pinGroupId: 'RSK',
          pinGroupName: 'RSK009',
          capitationProcessCode: 'CP',
          networkCode: 'MCD',
          taxIdNumber: '999999999',
          capitationCode: 'A1',
          payToPfinId: '00NMCAP015',
          networkAssocProviderId: '772129110'
        },
        {
          recordEffectiveDate: '02/22/2006',
          recordEndDate: '12/31/2006',
          vbrPayeeId: 49,
          corporateEntityCode: 'NM1',
          pinGroupId: 'RSK',
          pinGroupName: 'MJKNMCAPPIGLET',
          capitationProcessCode: 'CP',
          networkCode: 'MCD',
          taxIdNumber: '999999999',
          capitationCode: 'A1',
          payToPfinId: '00NMCAP015',
          networkAssocProviderId: '772129110'
        },
        {
          recordEffectiveDate: '03/01/2006',
          recordEndDate: '11/30/2006',
          vbrPayeeId: 50,
          corporateEntityCode: 'NM1',
          pinGroupId: 'RSK',
          pinGroupName: 'RSK009',
          capitationProcessCode: 'CP',
          networkCode: 'MCD',
          taxIdNumber: '999999999',
          capitationCode: 'A1',
          payToPfinId: '00NMCAP015',
          networkAssocProviderId: '772129110'
        },
        {
          recordEffectiveDate: '06/06/2006',
          recordEndDate: '06/06/2006',
          vbrPayeeId: 51,
          corporateEntityCode: 'NM1',
          pinGroupId: 'RSK',
          pinGroupName: 'RSK009',
          capitationProcessCode: 'CP',
          networkCode: 'MCD',
          taxIdNumber: '999999999',
          capitationCode: 'A1',
          payToPfinId: '00NMCAP015',
          networkAssocProviderId: '772129110'
        }
      ]
    };
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('ngOnInit - should call component.initializeAddPayeeSearchForm()', () => {
    spyOn(component, 'initializeAddPayeeSearchForm');
    component.ngOnInit();
    expect(component.initializeAddPayeeSearchForm).toHaveBeenCalled();
  });

  it('search - component.isViewable should be false', () => {
    component.search();
    expect(component.isViewable).toBeFalsy();
  });

  it('search- component.sharedService.clearToasts should have been called', () => {
    spyOn(component.sharedService, 'clearToasts');
    component.search();
    expect(component.sharedService.clearToasts).toHaveBeenCalled();
  });

  it('retrieveProviderRecords - component.isNoRecordsDisplay should be false', () => {
    const param = { corpEntityCode: 'NM1', pinGroupId: '' };
    component.retrieveProviderRecords(param, 'edit-payee-1');
    expect(component.isNoRecordsDisplay).toBeFalsy();
  });

  it('retrieveProviderRecords - component.payeeErrorCheck should be false', () => {
    const param = { corpEntityCode: 'NM1', pinGroupId: '' };
    component.retrieveProviderRecords(param, 'edit-payee-1');
    expect(component.payeeErrorCheck).toBeFalsy();
  });

  it('savePayeeRecord - component.isEditError should be false', () => {
    const param = { corpEntityCode: 'NM1', pinGroupId: '' };
    component.savePayeeRecord(param, 'select-payee-step-3');
    expect(component.isEditError).toBeFalsy();
  });

  it('updatePayeeRecord - update payee data', () => {
    spyOn(component.modalService, 'close');
    const data = {
      message: 'Records saved successfully.',
      payee: {
        createUserId: 'U398407',
        updateUserId: 'U398407',
        createRecordTimestamp: '2019-07-02T13:27:34.376',
        updateRecordTimestamp: '2019-07-02T13:27:34.376',
        recordEffectiveDate: '02/02/2006',
        recordEndDate: '11/29/2006',
        vbrPayeeId: 1,
        corporateEntityCode: 'NM1',
        pinGroupId: 'RSK',
        pinGroupName: 'RSK009',
        capitationProcessCode: 'CP',
        networkCode: 'MCD',
        taxIdNumber: '999999999',
        capitationCode: 'A1',
        payToPfinId: '00NMCAP015',
        networkAssocProviderId: '772129110'
      }
    };
    component.updatePayeeRecord(data, 'save');
    expect(component.modalService.close).toHaveBeenCalled();
  });

  it('updatePayeeRecord - component.sharedService.handleErrorSuccessWarningInfo should have been called', () => {
    spyOn(component.sharedService, 'handleErrorSuccessWarningInfo');
    const data = {
      message: 'Records saved successfully.',
      payee: {
        createUserId: 'U398407',
        updateUserId: 'U398407',
        createRecordTimestamp: '2019-07-02T13:27:34.376',
        updateRecordTimestamp: '2019-07-02T13:27:34.376',
        recordEffectiveDate: '02/02/2006',
        recordEndDate: '11/29/2006',
        vbrPayeeId: 1,
        corporateEntityCode: 'NM1',
        pinGroupId: 'RSK',
        pinGroupName: 'RSK009',
        capitationProcessCode: 'CP',
        networkCode: 'MCD',
        taxIdNumber: '999999999',
        capitationCode: 'A1',
        payToPfinId: '00NMCAP015',
        networkAssocProviderId: '772129110'
      },
      returnMessage : {
        errors: 'Warning'
      }
    };
    component.updatePayeeRecord(data, 'save');
    expect(component.sharedService.handleErrorSuccessWarningInfo).toHaveBeenCalled();
  });

  it('add - modal should be opened', () => {
    spyOn(component.modalService, 'open');
    component.add('save');
    expect(component.modalService.open).toHaveBeenCalled();
  });

  it('validatePinGroupId - component.isPatternError should be false', () => {
    component.validatePinGroupId('RSK');
    expect(component.isPatternError).toBeFalsy();
  });

  it('validatePinGroupId - component.isPatternError should be true', () => {
    component.validatePinGroupId('#%$');
    expect(component.isPatternError).toBeTruthy();
  });

  it('validateSearchPinGroupId - component.isSearchError should be false', () => {
    component.validateSearchPinGroupId('RSK');
    expect(component.isSearchError).toBeFalsy();
  });

  it('validateSearchPinGroupId - component.isSearchError should be true', () => {
    component.validateSearchPinGroupId('#%$');
    expect(component.isSearchError).toBeTruthy();
  });

  it('editPayee - component.retrieveReqObj.corpEntityCode should be equal to NM1', () => {
    const searchProviderData = {
      recordEffectiveDate: '02/01/2006',
      recordEndDate: '12/31/2006',
      vbrPayeeId: 40,
      corporateEntityCode: 'NM1',
      pinGroupId: 'RSK',
      pinGroupName: 'MJKNMCAPPIGLET',
      capitationProcessCode: 'CP',
      networkCode: 'MCD',
      taxIdNumber: '999999999',
      capitationCode: 'A1',
      payToPfinId: '00NMCAP015',
      networkAssocProviderId: '772129110'
    };
    component.editPayee('save', searchProviderData);
    expect(component.retrieveReqObj.corpEntityCode).toEqual('NM1');
  });

  it('validateVBRDate - validate date - 13/06/2006', () => {
    component.validateVBRDate('13/06/2006', 'isEditEffDateError');
    expect(component.isEditEffDateError).toBeTruthy();
  });

  it('validateVBRDate - validate date - 02/06/2006', () => {
    const date: any = {
      day: 2,
      month: 6,
      year: 2006
    };
    component.validateVBRDate(date, 'isEditEffDateError');
    expect(component.isEditEffDateError).toBeFalsy();
  });

  it('setErrorMessage - component.isEffDateError should be true', () => {
    component.setErrorMessage('isEffDateError', true);
    expect(component.isEffDateError).toBeTruthy();
  });

  it('setErrorMessage - component.isEndDateError should be true', () => {
    component.setErrorMessage('isEndDateError', true);
    expect(component.isEndDateError).toBeTruthy();
  });

  it('setErrorMessage - component.isEditEndDateError should be true', () => {
    component.setErrorMessage('isEditEndDateError', true);
    expect(component.isEditEndDateError).toBeTruthy();
  });

  it('editPayeeReset - component.isEditError should be false', () => {
    component.editPayeeReset();
    expect(component.isEditError).toBeFalsy();
  });

  it('searchProvider - component.retrieveProviderRecords should be called', () => {
    spyOn(component, 'retrieveProviderRecords');
    component.searchProvider();
    expect(component.retrieveProviderRecords).toHaveBeenCalled();
  });

  it('addPayeeSearchResult - modal should be open', () => {
    const data: any = {
      payees: [
        {
          corporateEntityCode: 'NM1',
          pinGroupId: 'RSK',
          pinGroupName: 'RSK009',
          networkCode: 'MCD',
          taxIdNumber: '999999999',
          capitationCode: 'A1',
          payToPfinId: '00NMCAP015',
          payeeAddress: {
            zipCode: '600625317',
            city: 'NORTHBROOK',
            addressLine1: '1885 SHERMER RD',
            addressLine2: '',
            state: 'IL'
          },
          payToPFINPayeeAddress: {
            zipCode: '606781095',
            city: 'CHICAGO',
            addressLine1: '9532 EAGLE WAY',
            addressLine2: '',
            state: 'IL'
          },
          pinGroupEffectiveDate: '01/01/2006',
          pinGroupEndDate: '01/01/2007',
          pfinEffectiveDate: '01/01/2006',
          pfinEndDate: '01/01/2007',
          tinEffectiveDate: '01/01/2006',
          tinEndDate: '01/01/2007',
          networkAssociationEffectiveDate: '01/01/2006',
          networkAssociationEndDate: '01/01/2007',
          networkAssociationID: '772129110',
          capitationTypeCode: 'A1',
          processCode: 'CP',
          networkAssociationName: ' ECHO FIRST CHOICE'
        },
        {
          corporateEntityCode: 'NM1',
          pinGroupId: 'RSK',
          pinGroupName: 'RSK010',
          networkCode: 'MCD',
          taxIdNumber: '999999999',
          capitationCode: 'A1',
          payToPfinId: '00NMCAP016',
          payeeAddress: {
            zipCode: '600625317',
            city: 'NORTHBROOK',
            addressLine1: '1885 SHERMER RD',
            addressLine2: '',
            state: 'IL'
          },
          payToPFINPayeeAddress: {
            zipCode: '606781095',
            city: 'CHICAGO',
            addressLine1: '9532 EAGLE WAY',
            addressLine2: '',
            state: 'IL'
          },
          pinGroupEffectiveDate: '02/02/2005',
          pinGroupEndDate: '05/06/2009',
          pfinEffectiveDate: '02/02/2005',
          pfinEndDate: '05/06/2009',
          tinEffectiveDate: '02/02/2005',
          tinEndDate: '05/06/2009',
          networkAssociationEffectiveDate: '02/02/2005',
          networkAssociationEndDate: '05/06/2009',
          networkAssociationID: '772129110',
          capitationTypeCode: 'A1',
          processCode: 'CP',
          networkAssociationName: ' ECHO FIRST CHOICE New'
        }
      ]
    };
    component.providerList = data.payees;
    spyOn(component.modalService, 'close');
    spyOn(component.modalService, 'open');
    component.addPayeeSearchResult('select-payee-step-1');
    expect(component.modalService.close).toHaveBeenCalled();
  });

  it('should validate cancel step1', () => {
    spyOn(component.modalService, 'close');
    component.cancelStep1('step1');
    expect(component.modalService.close).toHaveBeenCalled();
  });

  it('should validate cancel step2', () => {
    spyOn(component.modalService, 'close');
    component.cancelStep2('step2');
    expect(component.modalService.close).toHaveBeenCalled();
  });

  it('should validate next step2', () => {
    spyOn(component.modalService, 'close');
    component.navigateToAddPayeeDates('step1');
    expect(component.modalService.close).toHaveBeenCalled();
  });

  it('should validate cancel step3', () => {
    spyOn(component.modalService, 'close');
    component.cancelStep3('step2');
    expect(component.modalService.close).toHaveBeenCalled();
  });

  it('should validate modifySearch ', () => {
    spyOn(component.modalService, 'close');
    component.modifySearch('step2');
    expect(component.modalService.close).toHaveBeenCalled();
  });

  it('should validate newSearch', () => {
    spyOn(component.modalService, 'close');
    component.newSearch('step2');
    expect(component.modalService.close).toHaveBeenCalled();
  });

  it('editSaveProvider - component.generateProviderObject should be called', () => {
    spyOn(component, 'generateProviderObject');
    component.editSaveProvider('save');
    expect(component.generateProviderObject).toHaveBeenCalled();
  });

  it('generateProviderObject - component.payee.corporateEntityCode should equal to NM1', () => {
    const dates = {
      VBRPayeeEffectiveDate: '02/02/2006',
      VBRPayeeEndDate: '11/29/2006'
    };
    component.providerInfo = component.payeesList.payees[0];
    component.generateProviderObject(dates);
    expect(component.savePayee.payee.corporateEntityCode).toEqual('NM1');
  });

  it('saveProvider - component.generateProviderObject should be called', () => {
    spyOn(component, 'generateProviderObject');
    component.saveProvider('save');
    expect(component.generateProviderObject).toHaveBeenCalled();
  });

  it('cancelEdit - modal should be closed', () => {
    spyOn(component.modalService, 'close');
    component.cancelEdit('edit');
    expect(component.modalService.close).toHaveBeenCalled();
  });

  it('providerDataOnSuccess - onCurrentRowChange should have been called', () => {
    spyOn(component, 'onCurrentRowChange');
    component.providerDataOnSuccess('data', 'id');
    expect(component.onCurrentRowChange).toHaveBeenCalled();
  });

  it('setUpperCase - component.payeeSearch.pinGroupId should be upperCase', () => {
    component.payeeSearch.pinGroupId = 'se';
    component.setUpperCase();
    expect(component.payeeSearch.pinGroupId).toEqual('SE');
  });

  it('setUpperCase - component.addPayeeSearch.pinGroupId should be upperCase', () => {
    component.addPayeeSearch.pinGroupId = 'se';
    component.setUpperCase();
    expect(component.addPayeeSearch.pinGroupId).toEqual('SE');
  });

  it('toggle - component.isSearchError  to be false', () => {
    component.toggle();
    expect(component.isSearchError).toBeFalsy();
  });

  it('selectProvider - component.modelPayee should be falsy', () => {
    component.selectProvider(component.providerInfo[0]);
    expect(component.modelPayee).toBeFalsy();
  });

  it('onCurrentRowChange - component.currentRow should be currentRow', () => {
    component.onCurrentRowChange('currentRow');
    expect(component.currentRows).toEqual('currentRow');
  });
});
