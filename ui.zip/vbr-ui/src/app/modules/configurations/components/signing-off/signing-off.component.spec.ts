
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SigningOffComponent } from './signing-off.component';

describe('SigningOffComponent', () => {
  let component: SigningOffComponent;
  let fixture: ComponentFixture<SigningOffComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SigningOffComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SigningOffComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
