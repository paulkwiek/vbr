import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-signing-off',
  styleUrls: ['./signing-off.component.scss'],
  templateUrl: './signing-off.component.html'
})
export class SigningOffComponent implements OnInit {
  constructor() {}

  ngOnInit() {}
}
