import { Component, OnInit } from '@angular/core';

@Component({
  // tslint:disable-next-line: component-selector
  selector: 'lfh-view404',
  template: './view404.component.html'
})
export class View404Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
