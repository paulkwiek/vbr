import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { CommonModule, CurrencyPipe } from '@angular/common';

import { RatesComponent } from './rates.component';
import { RatesLandingComponent } from '../../tables/rateslanding/rateslanding';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { CustomDateParserFormatter } from '../../../../shared/modules/ui/components/datepicker/customdateparserformatter';
import { NgbDateParserFormatter } from '@ng-bootstrap/ng-bootstrap';
import { DataTableModule } from '../../../../shared/modules/data-table/index';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ConfigurationService } from '../../services/configuration.service';
import { AppConfigService } from '../../../../app-config.service';
import { SharedModule } from '../../../../shared/shared.module';
import { UIModule } from '../../../../shared/modules/ui/ui.module';
import { Store, StoreModule } from '@ngrx/store';
import { LoadingModule } from '../../../../shared/modules/loading/loading.module';
import {environment} from '../../../../../environments/environment';

describe('RatesComponent', () => {
  let component: RatesComponent;
  let fixture: ComponentFixture<RatesComponent>;
  const data = {
    'returnMessage': null,
    'rateName': {
      'createUserId': 'U402537',
      'updateUserId': 'U402537',
      'createRecordTimestamp': '2019-11-25T08:49:17.004',
      'updateRecordTimestamp': '2019-11-25T08:49:17.004',
      'rowAction': 'NO_ACTION',
      'corporateEntityCode': 'NM1',
      'rateName': 'AQAQAQA',
      'rateConfigTypeName': 'FLATRT',
      'flatRates': [
        {
          'createUserId': 'U402537',
          'updateUserId': 'U402537',
          'createRecordTimestamp': '2019-11-25T08:49:17.005',
          'updateRecordTimestamp': '2019-11-25T08:49:17.007',
          'rowAction': 'NO_ACTION',
          'recordEffectiveDate': '11/01/2019',
          'recordEndDate': '11/30/2019',
          'flatRateId': 555,
          'corporateEntityCode': 'NM1',
          'rateName': 'AQAQAQA',
          'femaleFlatRateAmount': 11.0,
          'maleFlatRateAmount': 11.0,
          'commentText': null,
          'flatRateHistory': [
            {
              'createUserId': 'U402537',
              'updateUserId': 'U402537',
              'createRecordTimestamp': '2019-11-25T08:49:17.007',
              'updateRecordTimestamp': '2019-11-25T08:49:17.007',
              'rowAction': 'NO_ACTION',
              'recordEffectiveDate': '2019-11-01',
              'recordEndDate': '2019-11-30',
              'flatRateHistoryId': 956,
              'corporateEntityCode': 'NM1',
              'rateName': 'AQAQAQA',
              'flatRateId': 555,
              'femaleFlatRateAmount': 11.0,
              'maleFlatRateAmount': 11.0,
              'commentText': null
            }
          ]
        }
      ],
      'paymentArrangementRates': [

      ]
    },
    'message': 'Rate fetched successfully.',
    'errors': null
  };
  AppConfigService.settings = {
    'env': {
      'name': 'DEV2'
    },
    'baseUrls': {
      'BASE_URL': 'https://vbr-arrangementconfig-service-dev2.cfaa.hcsctest.net',
      'BASE_URL_CODE_SERVICE': 'https://vbr-code-service-dev2.cfaa.hcsctest.net',
      'BASE_URL_CALCULATION_SERVICE': 'https://vbr-calculation-service-dev2.cfaa.hcsctest.net',
      'BASE_URL_REPORT': 'https://tableau.test.fyiblue.com/views/'
    },
    'reportUrls': {
      'CAP_SUMMARY_REPORT': 'CapSummaryReport_15735714904500/CapSummaryReport?iframeSizedToWindow=true&:embed=y&:showAppBanner=false&:display_count=no&:showVizHome=no',
      'MEMBERSHIP_ERROR_REPORT': 'MembershipErrorReport_15736417170040/MembershipErrorReport?iframeSizedToWindow=true&:embed=y&:showAppBanner=false&:display_count=no&:showVizHome=no',
      'COMPARISON_REPORT_FOR_APPROVED_FINANCIAL_CALCULATION_DATA': 'ComparisonReportforFinancialCalculationData_15735718388110/ComparisonReportforFinancialcalculationData?iframeSizedToWindow=true&:embed=y&:showAppBanner=false&:display_count=no&:showVizHome=no',
      'COMPARISON_REPORT_FOR_PRELIMINARY_RUN_CALCULATION_DATA': 'ComparisonReportforPreliminaryCalculationData_15735719621730/ComparisonReportforPreliminaryCalculationData?iframeSizedToWindow=true&:embed=y&:showAppBanner=false&:display_count=no&:showVizHome=no',
      'COMPARISON_REPORT_FOR_APPROVED_CALCULATION_DATA': '',
      'RETROACTIVITY_SUMMARY_REPORT': '',
      'NM10931_CAP_DISTRIBUTION_REPORT': 'NM10931-CapDistributionReport_15736400047190/NM10931-CAPDISTRIBUTIONREPORT?iframeSizedToWindow=true&:embed=y&:showAppBanner=false&:display_count=no&:showVizHome=no',
      'NM10940_PRELIMINARY_EFT_REGISTER': 'NM10940-PreliminaryEFTRegisterReport/NM10940-PreliminaryCapEFTRegisterReport?iframeSizedToWindow=true&:embed=y&:showAppBanner=false&:display_count=no&:showVizHome=no',
      'NM10940_FINAL_EFT_REGISTER': 'NM10940-FinalEFTRegisterReport_15736399695060/NM10941-FinalEFTRegisterReport?iframeSizedToWindow=true&:embed=y&:showAppBanner=false&:display_count=no&:showVizHome=no',
      'NM10932_FINAL_OPEN_ITEM_REGISTER': ''
    }
  };

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
        NgbModule,
        DataTableModule,
        RouterTestingModule,
        HttpClientTestingModule,
        SharedModule,
        UIModule,
        LoadingModule,
        StoreModule.forRoot({})
      ],
      declarations: [
        RatesComponent,
        RatesLandingComponent
      ],
      providers: [
        CurrencyPipe,
        {
          provide: NgbDateParserFormatter,
          useClass: CustomDateParserFormatter
        },
        CustomDateParserFormatter,
        ConfigurationService, Store]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RatesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    component.env = environment;
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('ngOnInit - component.initializeRateTable should have been called', () => {
    spyOn(component, 'initializeRateTable');
    component.ngOnInit();
    expect(component.initializeRateTable).toHaveBeenCalled();
  });

  it('ngOnInit - component.getRates should have been called', () => {
    spyOn(component, 'getRates');
    component.ngOnInit();
    expect(component.getRates).toHaveBeenCalled();
  });

  it('initializeRateTable - data should be equal to componnet.rateInformation', () => {
    const data = {
      rateName: '',
      maleFlatRateAmount: null,
      recordEffectiveDate: '',
      recordEndDate: ''

    };
    component.initializeRateTable();
    expect(component.rateInformation).toEqual(data);
  });


  it('save - modal should be closed', () => {
    spyOn(component, 'clearErrorMessage');
    component.rateInformation = data.rateName.flatRates[0];
    component.saveRateInformation('string');
    expect(component.clearErrorMessage).toHaveBeenCalled();
  });


  it('closeModal - modal should be closed', () => {
    spyOn(component.modalService, 'close');
    component.closeModal('create-rate-table');
    expect(component.modalService.close).toHaveBeenCalled();
  });

  it('modalPopUpOpenClose - modalService.open should be called', () => {
    spyOn(component.modalService, 'open');
    component.modalPopUpOpenClose('string', '');
    expect(component.modalService.open).toHaveBeenCalled();
  });

  it('modalPopUpOpenClose - modalService.close should be called', () => {
    spyOn(component.modalService, 'close');
    component.modalPopUpOpenClose('', 'string');
    expect(component.modalService.close).toHaveBeenCalled();
  });

  it('validateRateTableName - configurationService.validateRateTableName should have been called', () => {
    spyOn(component.configurationService, 'validateRateTableName');
    component.validateRateTableName('open', 'close');
    expect(component.configurationService.validateRateTableName).toHaveBeenCalled();
  });

  it('navigate router.navigate should have been called', () => {
    spyOn(component.router, 'navigate');
    component.navigate('rateName');
    expect(component.router.navigate).toHaveBeenCalled();
  });

  it('handleErrorResponse - component.isErrorMsgDisplay should be true', () => {
    const error = {
      'returnMessage': {
        'itemId': null,
        'itemName': null,
        'status': null,
        'errors': [
          {
            'componentName': 'rateName',
            'fieldId': 'maleFlatRateAmount',
            'errorMessageId': 54,
            'errorMsgDescriptionText': 'Rate Amount is greater than or equal to $1000.00 Click on save again to continue',
            'severitylevel': 'E',
            'errorMessageCategoryCode': 'PCF-RTNM'
          },
          {
            'componentName': 'rateName',
            'fieldId': 'rateEffectiveDate',
            'errorMessageId': 31,
            'errorMsgDescriptionText': 'Rate eff date should be the first date of month',
            'severitylevel': 'E',
            'errorMessageCategoryCode': 'PCF-RTNM'
          }
        ],
        'warnings': [

        ],
        'tempList': [

        ]
      }
    };
    component.handleErrorResponse(error);
    expect(component.isErrorMsgDisplay).toBeTruthy();
  });

  it('validateRateName - component.isValidRateName should be true', () => {
    component.validateRateName('R344');
    expect(component.isValidRateName).toBeFalsy();
  });

  it('validateRateName - component.isRateNameDisabled should be false', () => {
    component.validateRateName('E#$%');
    expect(component.isRateNameDisabled).toBeFalsy();
  });

  it('amountValidation- componenent.setErrorMesage should have been called', () => {
    spyOn(component, 'setErrorMessage');
    component.amountValidation('#$#', 'isError');
    expect(component.setErrorMessage).toHaveBeenCalled();
  });
  it('amountValidation- componenent.setErrorMesage should have been called', () => {
    spyOn(component, 'setErrorMessage');
    component.amountValidation(345457688, 'isError');
    expect(component.setErrorMessage).toHaveBeenCalled();
  });
  it('amountValidation- componenent.setErrorMesage should have been called', () => {
    spyOn(component, 'setErrorMessage');
    component.amountValidation(345, 'isError');
    expect(component.setErrorMessage).toHaveBeenCalled();
  });

  it('formatRateAmount - maleFlatRateAmount should be 345 while on focus', () => {
    component.isRateFormatError = false;
    component.isAmountError = false;
    component.rateInformation.maleFlatRateAmount = '$345';
    component.formatRateAmount('focus');
    expect(component.rateInformation.maleFlatRateAmount).toEqual(345);
  });

  it('formatRateAmount - maleFlatRateAmount should be 345 while on focus', () => {
    component.isRateFormatError = false;
    component.isAmountError = false;
    component.rateInformation.maleFlatRateAmount = '345';
    component.formatRateAmount('focusOut');
    expect(component.rateInformation.maleFlatRateAmount).toEqual('$345.00');
  });

  it('checkIfEmpty - component.rateInformation.maleFlatRateAmount should equal 345', () => {
    component.rateInformation.maleFlatRateAmount = '345  ';
    component.checkIfEmpty();
    expect(component.rateInformation.maleFlatRateAmount).toEqual('345');
  });

  it('dateValidation- component.setErrorMessage should have been called', () => {
    spyOn(component, 'setErrorMessage');
    component.dateValidation('12/01/2020', 'errorId');
    expect(component.setErrorMessage).toHaveBeenCalled();
  });

  it('dateValidation- component.setErrorMessage should have been called', () => {
    spyOn(component, 'setErrorMessage');
    const date: any = { year: 2020, month: 6, day: 1 };
    component.dateValidation(date, 'errorId');
    expect(component.setErrorMessage).toHaveBeenCalled();
  });

  it('setUpperCase - component.rateInformation.rateName should be in uppercase', () => {
      component.rateInformation.rateName = 'rateName';
      component.setUpperCase();
      expect(component.rateInformation.rateName).toEqual('RATENAME');
  });
});
