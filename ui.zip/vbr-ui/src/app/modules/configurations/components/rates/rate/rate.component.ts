import { Component, OnInit, DoCheck, OnDestroy, Inject } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ModalService } from '../../../../../shared/services/modal.service';
import {
  RateName,
  GetLinkedArrangement,
  Rate,
  Errors
} from '../../../../../models/configuration.model';
import {
  ReturnMessage
} from '../../../../../models/shared.model';
import { ConfigurationService } from '../../../services/configuration.service';
import { CustomDateParserFormatter } from 'src/app/shared/modules/ui/components/datepicker/customdateparserformatter';
import {
  DATE_PATTERN,
  NUMBER_PATTERN_FOR_RATE,
  AMOUNT_PATTERN_WITH_6_DIGITS_AND_2_DECIMALS,
  RATE_ROLES
} from '../../../../../shared/constants/app.constants';
import { UtilService } from 'src/app/shared/services/util.service';
import { UserCacheService } from '../../../../../shared/services/user-cache.service';
import _ from 'lodash';
import { SharedService } from '../../../../../shared/services/shared.service';
import { LoadingService } from '../../../../../shared/modules/loading/loading.module';
// SSO
import { AuthService } from '../../../../../shared/services/auth.service';
import { environment } from '../../../../../../environments/environment';
@Component({
  selector: 'app-rate',
  templateUrl: './rate.component.html',
  styleUrls: ['./rate.component.scss']
})
export class RateComponent implements OnInit, DoCheck, OnDestroy {
  title: any;
  addRateId: string;
  linkedArrangement: GetLinkedArrangement[];
  rateDetails: RateName;
  rateInformation: Rate;
  rateInformationActual: Rate;
  rateID: string;
  errorMsgList: Errors;
  rateDetailsCheck: boolean;
  unFormattedAmount: any;
  userId: string;
  corporateEntityCode: string;
  // Error variables
  isEffDateError: boolean;
  isEndDateError: boolean;
  isAmountError = false;
  isErrorMsgDisplay: boolean;
  isAddErrorMsgDisplay: boolean;
  isEditErrorMsgDisplay: boolean;
  isRateFormatError = false;
  isEdit: boolean;
  isWarningState = false;
  warningErrorList: Errors;
  rateEffectiveDate: boolean;
  rateEndDate: boolean;
  maleFlatRateAmount: boolean;
  rateEffectiveAndEndDate: boolean;
  returnMessage: ReturnMessage;
  // SS0
  checkRoles: boolean;
  env = environment;
  corporateEntityDescription: string;

  constructor(
    public modalService: ModalService,
    private route: ActivatedRoute,
    public configurationService: ConfigurationService,
    private customDateParserFormatter: CustomDateParserFormatter,
    public utilService: UtilService,
    public userCacheService: UserCacheService,
    public sharedService: SharedService,
    public loadingService: LoadingService,
    public authService: AuthService,
  ) {
    this.addRateId = 'add-arrangements'; // breadcrumbService.addCallbackForRouteRegex('/configurations/rate/:id/:name', this.getId);
    this.sharedService.getCorpEntityCode().subscribe(data => this.corporateEntityCode = data);

    this.sharedService.getCorpEntityDescription().subscribe(data => this.corporateEntityDescription = data);
  }

  /**
   * ngOnInit
   * Life cycle hook after initialization
   */
  ngOnInit() {
    this.rateID = this.route.snapshot.paramMap.get('id');
    this.userId = this.userCacheService.getUserCacheData('USER_ID');
    this.getRateDetailsByRateName();
    // To enable UI components
    this.checkRoles = this.env.SSO_CONFIG.enableSSO ? !this.authService.isAuthorized(RATE_ROLES) : false;
  }

  /**
   * ngDoCheck
   * Life cycle hook on every change
   */
  ngDoCheck() {
    if (this.rateDetails === undefined || _.size(this.rateDetails) === 0) {
      this.rateDetailsCheck = false;
    } else {
      this.rateDetailsCheck = true;
    }
  }

  /* Method : getRateDetailsByRateName
   * This method to get the rate details from service based on the rate name
   */
  getRateDetailsByRateName() {
    this.clearErrorMessage();
    this.loadingService.show();
    this.configurationService.getRatesDetails(this.rateID).subscribe(
      (data) => {
        this.loadingService.hide();
        // on success, call method to update rateDetails data
        this.getRateDetailsDataOnSuccess(data);
      },
      error => {
        this.loadingService.hide();
        this.title = 'Add New Rate';
        // on failure, call method to display error
        this.handleErrorResponse('isErrorMsgDisplay', error);
      }
    );
  }

  /**
   * getRateDetailsDataOnSuccess
   * @param data
   * Function call to update the rateDetails data with data from API
   */
  getRateDetailsDataOnSuccess(data: any) {
    const rateDetails: any = data.rateName;
    this.title = rateDetails.rateName;
    this.rateDetails = rateDetails;
  }

  /** Method : getLinkedArrangements
   * @param - id - Name of the model name
   * This method to get linked arrangement list from service based on the rate name
   */
  getLinkedArrangements(id: string) {
    this.clearErrorMessage();
    this.sharedService.clearToasts();
    this.loadingService.show();
    this.configurationService.getLinkedArrangements(this.rateID).subscribe(
      (data: GetLinkedArrangement[]) => {
        this.loadingService.hide();
        this.linkedArrangement = data;
        this.modalService.open(id);
      },
      error => {
        this.loadingService.hide();
        // on failure, call method to display error
        this.sharedService.handleErrorSuccessWarningInfo('FAILURE', error, 'Rate Errors');
      }
    );
  }
  /* Method : closeModal
   * @param - id - Name of the model name
   * This method to close the model window.
   */
  closeModal(id: string) {
    this.clearErrorMessage();
    this.isWarningState = false;
    this.unFormattedAmount = '';
    this.modalService.close(id);
  }

  /**
  * Method to clear error messages
  */
  clearErrorMessage() {
    this.isErrorMsgDisplay = false;
    this.rateEffectiveDate = false;
    this.rateEndDate = false;
    this.maleFlatRateAmount = false;
    this.rateEffectiveAndEndDate = false;
    this.setErrorMessage('isEffDateError', false);
    this.setErrorMessage('isEndDateError', false);
    this.setErrorMessage('isAmountError', false);
    this.setErrorMessage('isRateFormatError', false);
    this.setErrorMessage('isAddErrorMsgDisplay', false);
    this.setErrorMessage('isEditErrorMsgDisplay', false);
  }
  /**
   * view
   * @param id
   * Method to open the modal for linked arrangement
   */
  view(id: string) {
    if (id === 'view-arrangements') {
      this.getLinkedArrangements(id);
    } else {
      this.modalService.open(id);
    }
  }

  /* Method : isAnyRateInformationChanged
   * This method is used to enable/disable EDIT SAVE button
   */
  isAnyRateInformationChanged() {
    const rateInformation: any = JSON.parse(
      JSON.stringify(this.rateInformation)
    );
    return this.isEdit &&
      JSON.stringify(this.rateInformationActual.recordEndDate) ===
      JSON.stringify(rateInformation.recordEndDate);
  }

  /* Method : saveRateInformation
   * @param : actionMode - Name of the action (ADD / EDIT)
   * This method is used to call the service method to ADD/UPDATE Rate
   */
  saveRateInformation(actionMode: string, modelId: string) {
    this.sharedService.clearToasts();
    this.clearErrorMessage();
    const requestObject = JSON.parse(JSON.stringify(this.generateRateObject(actionMode)));
    requestObject.rate.flatRates[0].recordEffectiveDate = this.customDateParserFormatter.format(requestObject.rate.flatRates[0].recordEffectiveDate);
    requestObject.rate.flatRates[0].recordEndDate = this.customDateParserFormatter.format(requestObject.rate.flatRates[0].recordEndDate);
    this.loadingService.show();
    this.configurationService
      .saveOrUpdateRate(requestObject)
      .subscribe(
        (data: any) => {
          this.loadingService.hide();
          this.modalService.close(modelId);
          this.sharedService.handleErrorSuccessWarningInfo('SUCCESS', data);
          this.getRateDetailsByRateName();
          this.handleWarningResponse(data);
        },
        error => {
          this.loadingService.hide();
          this.rateInformation.maleFlatRateAmount = this.utilService.getFormattedCurrency(
            this.rateInformation.maleFlatRateAmount
          );
          actionMode === 'INSERT'
            ? this.handleErrorResponse('isAddErrorMsgDisplay', error)
            : this.handleErrorResponse('isEditErrorMsgDisplay', error);
        }
      );
  }

  /* Method : generateRateObject
   * @param - actionMode - string to decide save /update
   * This method is used to create request object to save or update the rate information
   */
  generateRateObject(actionMode: string) {
    this.rateInformation.maleFlatRateAmount = Number(this.rateInformation.maleFlatRateAmount.toString().replace(/[^.0-9.-]+/g, ''));
    this.rateInformation.rowAction = actionMode;
    this.rateInformation.femaleFlatRateAmount = this.rateInformation.maleFlatRateAmount;
    const saveRequestObject: RateName = {
      createUserId: this.rateDetails.createUserId,
      updateUserId: this.rateDetails.updateUserId,
      createRecordTimestamp: this.rateDetails.createRecordTimestamp,
      updateRecordTimestamp: this.rateDetails.updateRecordTimestamp,
      rateName: this.rateDetails.rateName,
      rowAction: 'NO_ACTION',
      corporateEntityCode: this.rateDetails.corporateEntityCode,
      rateConfigTypeName: this.rateDetails.rateConfigTypeName,
      flatRates: []
    };
    saveRequestObject.flatRates.push(this.rateInformation);
    const finalSaveObject = {
      rate: saveRequestObject,
      warningState: actionMode === 'INSERT' ? this.isWarningState : true
    };
    return finalSaveObject;
  }

  /**
   * Method: amountValidation
   * @param number:  amount
   * @param errorId: div id to show/hide error message
   * Method to validate amount and show/hide the error message
   */
  amountValidation(amount: any, errorId: string) {
    this.unFormattedAmount = amount;
    if (this.validateNumber(amount)) {
      this.setErrorMessage(errorId, false);
      if (!this.validateAmount(amount)) {
        this.setErrorMessage('isRateFormatError', true);
      } else {
        this.setErrorMessage('isRateFormatError', false);
      }
    } else {
      this.setErrorMessage(errorId, true);
      this.setErrorMessage('isRateFormatError', false);
    }
  }

  /**
   * Method: Format Rate Amount
   * @param action
   * Method to format rate based on focus out and focus in actions
   */
  formatRateAmount(action: string) {
    if ((!this.isAmountError && !this.isRateFormatError) || this.isEdit) {
      this.rateInformation.maleFlatRateAmount = this.utilService.getFormattedAmount(
        action,
        this.rateInformation.maleFlatRateAmount
      );
    }
  }

  /**
   * validateNumber
   * @param data
   * Function to validate if the data is numberic
   */
  validateNumber(data: any) {
    return (
      this.utilService.patterMatch(NUMBER_PATTERN_FOR_RATE, data) && data > 0
    );
  }

  /**
   * checkIfEmpty
   * Method to check if value is empty, else trim the value
   */
  checkIfEmpty() {
    if (
      !this.utilService.isEmptyCheck(this.rateInformation.maleFlatRateAmount)
    ) {
      this.rateInformation.maleFlatRateAmount = this.rateInformation.maleFlatRateAmount.trim();
    }
  }
  /* Method : validateAmount
   * @param number: amount
   * This method is used to do amount validation for the mentioned PATTERN
   */
  validateAmount(amount: any) {
    const formattedAmount = parseFloat(amount);
    return this.utilService.patterMatch(
      AMOUNT_PATTERN_WITH_6_DIGITS_AND_2_DECIMALS,
      formattedAmount
    );
  }

  /* Method : validateDate
   * @param date: Date
   * This method is used to do date validation for the mentioned PATTERN
   */
  validateDate(date: any) {
    return date !== '' && date !== null && date !== undefined
      ? this.utilService.patterMatch(DATE_PATTERN, this.customDateParserFormatter.format(date))
      : false;
  }

  /* Method : dateValidation
   * @param date    - selected date
   * @param errorId - div id to show message
   * Method to validate dates and show/hide the error message
   */
  dateValidation(date: string, errorId: string) {
    !this.validateDate(date)
      ? this.setErrorMessage(errorId, true)
      : this.setErrorMessage(errorId, false);
  }

  /**
   * resetCommentText
   * Method to reset the comment field if there is no change in record end date
   */
  resetCommentText() {
    if (this.isAnyRateInformationChanged()) {
      this.rateInformation.commentText = this.rateInformationActual.commentText;
    }
  }

  /**
   * Method: setErrorMessage
   * @param  string errorId
   * @param boolean trueOrFalse
   * This method is used to show/hide the error message
   */
  setErrorMessage(errorId: string, trueOrFalse: boolean) {
    switch (errorId) {
      case 'isEffDateError':
        this.isEffDateError = trueOrFalse;
        break;
      case 'isEndDateError':
        this.isEndDateError = trueOrFalse;
        break;
      case 'isAmountError':
        this.isAmountError = trueOrFalse;
        break;
      case 'isAddErrorMsgDisplay':
        this.isAddErrorMsgDisplay = trueOrFalse;
        break;
      case 'isEditErrorMsgDisplay':
        this.isEditErrorMsgDisplay = trueOrFalse;
        break;
      case 'isErrorMsgDisplay':
        this.isErrorMsgDisplay = trueOrFalse;
        break;
      case 'isRateFormatError':
        this.isRateFormatError = trueOrFalse;
        break;
    }
  }

  /**
   * Method : editRate
   * @param : id- Model window name
   *          rateInfo - Selected Rate's information
   * Method to retriveve and show the details of the selected rate for EDIT
   */
  editRate(id: string, selectedRateInfo: any) {
    this.isEdit = true;
    this.initializeRateInformation(
      JSON.parse(JSON.stringify(selectedRateInfo))
    );
    this.unFormattedAmount = this.rateInformation.maleFlatRateAmount;
    this.rateInformation.maleFlatRateAmount = this.utilService.getFormattedCurrency(
      this.rateInformation.maleFlatRateAmount
    );
    this.rateInformation.commentText =
      this.rateInformation.commentText === null
        ? ''
        : this.rateInformation.commentText;
    this.rateInformationActual = JSON.parse(
      JSON.stringify(this.rateInformation)
    );
    this.modalService.open(id);
  }
  /**
   * Method : addRate
   * @param : id- Model window name
   * Method to ADD the rate to Rate Table Name
   */
  addRate(id: string) {
    this.isWarningState = false;
    this.initializeRateInformation();
    this.modalService.open(id);
  }
  /**
   * Method : initializeRateInformation
   * Method to initialize the ADD rate Form
   */
  initializeRateInformation(selectedRate?: any) {
    this.rateInformation = {
      createUserId: this.userId,
      updateUserId: this.userId,
      recordEffectiveDate:
        selectedRate === undefined
          ? ''
          : this.customDateParserFormatter.parse(
            selectedRate.recordEffectiveDate
          ),
      recordEndDate:
        selectedRate === undefined
          ? ''
          : this.customDateParserFormatter.parse(selectedRate.recordEndDate),
      createRecordTimestamp:
        selectedRate === undefined ? '' : selectedRate.createRecordTimestamp,
      updateRecordTimestamp:
        selectedRate === undefined ? '' : selectedRate.updateRecordTimestamp,
      corporateEntityCode: this.corporateEntityCode,
      rateName: this.rateDetails.rateName,
      flatRateId: selectedRate === undefined ? null : selectedRate.flatRateId,
      femaleFlatRateAmount:
        selectedRate === undefined ? null : selectedRate.femaleFlatRateAmount,
      maleFlatRateAmount:
        selectedRate === undefined ? null : selectedRate.maleFlatRateAmount,
      commentText: selectedRate === undefined ? '' : selectedRate.commentText
    };
  }

  /**
   * checkRateWarningState
   * @param errorMsgList
   * Method to check the warning state
   */
  checkRateWarningState(errorMsgList: any) {
    errorMsgList.forEach((data: any) => {
      if (data.errorMessageId === 54) {
        this.isWarningState = true;
      }
    });
  }

  /**
   * Method to handle error from API
   * @param: error
   */
  handleErrorResponse(errorId: string, error: any) {
    if (error.returnMessage && error.returnMessage.errors.length > 0) {
      this.returnMessage = error;
      this.setErrorMessage(errorId, true);
      this.checkRateWarningState(error.returnMessage.errors);
      this.rateOutlinedError(error.returnMessage.errors);
    } else {
      console.log('error  == >', JSON.stringify(error));
    }
  }

  /**
   * reaetOutlinedError
   * @param errorFieldList
   * Method to outline elements based on error from API
   */
  rateOutlinedError(errorFieldList: any) {
    errorFieldList.forEach((data: any) => {
      if (data.fieldId === 'rateEffectiveDate') {
        this.rateEffectiveDate = true;
      }
      if (data.fieldId === 'rateEndDate') {
        this.rateEndDate = true;
      }
      if (data.fieldId === 'maleFlatRateAmount') {
        this.maleFlatRateAmount = true;
      }
      if (data.fieldId === 'rateEffectiveAndEndDate') {
        this.rateEffectiveAndEndDate = true;
      }
    });
  }

  /**
   * Method to handle warning from API
   * @param: warning
   */
  handleWarningResponse(warning: any) {
    if (warning && warning.returnMessage.warnings && warning.returnMessage.warnings.length > 0) {
      this.sharedService.handleErrorSuccessWarningInfo('FAILURE', warning, 'Rate Warnings');
    }
  }

  /**
   * validateRateComments
   * Method to check if empty
   */
  validateRateComments() {
    this.rateInformation.commentText = this.rateInformation.commentText.trim();
    return this.utilService.isEmptyCheck(this.rateInformation.commentText);
  }

  /**
   * Life cycle hook after component destroy
   */
  ngOnDestroy() {
    this.sharedService.clearToasts();
  }
}
