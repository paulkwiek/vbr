import { Component, OnInit, OnDestroy, Inject } from '@angular/core';
import { ModalService } from '../../../../shared/services/modal.service';
import { Router } from '@angular/router';
import {
  RateNames,
  RateName,
  Rate,
  Errors
} from '../../../../models/configuration.model';
import { ConfigurationService } from '../../services/configuration.service';
import { UserCacheService } from '../../../../shared/services/user-cache.service';
import { UtilService } from 'src/app/shared/services/util.service';
import { CustomDateParserFormatter } from 'src/app/shared/modules/ui/components/datepicker/customdateparserformatter';
import {
  DATE_PATTERN,
  ALPHA_NUMERIC_PATTERN_WITH_SPACE,
  NUMBER_PATTERN_FOR_RATE,
  AMOUNT_PATTERN_WITH_6_DIGITS_AND_2_DECIMALS,
  RATE_ROLES
} from '../../../../shared/constants/app.constants';
import { SharedService } from '../../../../shared/services/shared.service';
import {
  ReturnMessage
} from '../../../../models/shared.model';
import { LoadingService } from '../../../../shared/modules/loading/loading.module';
// SSO
import { AuthService } from '../../../../shared/services/auth.service';
import {environment} from '../../../../../environments/environment';
@Component({
  selector: 'app-rates',
  templateUrl: './rates.component.html',
  styleUrls: ['./rates.component.scss']
})
export class RatesComponent implements OnInit, OnDestroy {
  env = environment;
  rateNames: RateNames;
  rateInformation: Rate;
  errorMsgList: Errors;
  isErrorMsgDisplay: boolean;
  isValidRateName = false;
  isRateNameDisabled = false;
  isAmountError = false;
  isEffDateError: boolean;
  isEndDateError: boolean;
  isRateFormatError = false;
  isWarningState = false;
  unFormattedAmount: any;
  rateEffectiveDate: boolean;
  rateEndDate: boolean;
  maleFlatRateAmount: boolean;
  rateEffectiveAndEndDate: boolean;
  userId: string;
  corporateEntityCode: string;
  rateConfigType: string;
  returnMessage: ReturnMessage;
  // SS0
  checkRoles: boolean;
  corporateEntityDescription: string;

  constructor(
    public modalService: ModalService,
    public router: Router,
    public configurationService: ConfigurationService,
    public utilService: UtilService,
    private customDateParserFormatter: CustomDateParserFormatter,
    private userCacheService: UserCacheService,
    private sharedService: SharedService,
    public loadingService: LoadingService,
    public authService: AuthService,
  ) {
    this.sharedService.getCorpEntityCode().subscribe(data => this.corporateEntityCode = data);

    this.sharedService.getCorpEntityDescription().subscribe(data => this.corporateEntityDescription = data);
   }

  /**
   * ngOnInit
   * Life cycle hook called on initialization of component
   */
  ngOnInit() {
    this.userId = this.userCacheService.getUserCacheData('USER_ID');
    this.rateConfigType = this.userCacheService.getUserCacheData('RATE_CONFIG_TYPE_NAME');
    this.initializeRateTable();
    this.getRates();
    // To enable UI components
    this.checkRoles = this.env.SSO_CONFIG.enableSSO ? !this.authService.isAuthorized(RATE_ROLES) : false;
  }

  /* Method : initializeRateTable
   * This method to initialize the values to empty
   */
  initializeRateTable(rateName?: string) {
    this.rateInformation = {
      rateName: rateName == undefined ? '' : rateName,
      maleFlatRateAmount: null,
      recordEffectiveDate: '',
      recordEndDate: ''
    };
  }

  /**
   * modalPopUpOpenClose
   * @param close
   * @param open
   * Method to open and close modal based on input
   */
  modalPopUpOpenClose(open?: string, close?: string) {
    if (close !== '') {
      this.modalService.close(close);
    }
    if (open !== '') {
      this.modalService.open(open);
    }
  }

  /**
   * Method: validateRateTableName
   * @param id String
   * Method to open the modal based on validation of rate table name success and id
   */
  validateRateTableName(open: string, close: string) {
    this.loadingService.show();
    // API call to validate rate table name
    this.configurationService
      .validateRateTableName(this.rateInformation.rateName)
      .subscribe(
        (data: any) => {
          this.loadingService.hide();
          // on success, close the current modal and open the modal
          this.closeModal(close);
          this.modalPopUpOpenClose(open, '');
        },
        error => {
          // on failure, call method to display error
          this.handleErrorResponse(error);
        }
      );
  }

  /**
   * Method: navigate
   * @param id
   * Method for page navigation along with id
   */
  navigate(rateName: string) {
    this.router.navigate(['configurations/rates/', rateName]);
  }

  /**
   * Method: closeModal
   * @param id
   * Method to close the modal based on id
   */
  closeModal(id: string) {
    this.isWarningState = false;
    this.unFormattedAmount = '';
    this.initializeRateTable(this.rateInformation.rateName);
    this.clearErrorMessage();
    this.modalService.close(id);
  }

  /* Method : getRates
   * This method to get the list of rates from service
   */
  getRates() {
    // Method to clear error message
    this.clearErrorMessage();
    this.loadingService.show();
    // API service call to get all the rates from DB
    this.configurationService.getRatesFromDB(this.corporateEntityCode).subscribe(
      (data: RateNames) => {
        this.loadingService.hide();
        this.rateNames = data;
      },
      error => {
        // on failure, call method to display error
        this.handleErrorResponse(error);
      }
    );
  }

  /* Method : saveRateInformation
   * @param : modelId - To close model window
   * This method is used to call the service method to CREATE Rate
   */
  saveRateInformation(modelId: string) {
    this.sharedService.clearToasts();
    // Method to clear error message
    this.clearErrorMessage();
    const requestObject = JSON.parse(JSON.stringify(this.generateRateObject()));
    requestObject.rate.flatRates[0].recordEffectiveDate = this.customDateParserFormatter.format(requestObject.rate.flatRates[0].recordEffectiveDate);
    requestObject.rate.flatRates[0].recordEndDate = this.customDateParserFormatter.format(requestObject.rate.flatRates[0].recordEndDate);
    this.loadingService.show();
    // API service call to save rate
    this.configurationService
      .saveOrUpdateRate(requestObject)
      .subscribe(
        (data: any) => {
          this.loadingService.hide();
          // on success, set success message and close the modal
          const getRateName: any = data.rateName;
          this.navigate(getRateName.rateName);
          this.modalPopUpOpenClose('', modelId);
          this.sharedService.handleErrorSuccessWarningInfo('SUCCESS', data);
        },
        error => {
          this.rateInformation.maleFlatRateAmount = this.utilService.getFormattedCurrency(
            this.rateInformation.maleFlatRateAmount
          );
          // on failure, call method to display error
          this.handleErrorResponse(error);
        }
      );
  }

  /* Method : generateRateObject
   * This method is used to create request object to save or update the rate information
   */
  generateRateObject() {
    // Updating RateInformation
    this.rateInformation.createUserId = this.userId;
    this.rateInformation.updateUserId = this.userId;
    this.rateInformation.corporateEntityCode = this.corporateEntityCode;
    this.rateInformation.createRecordTimestamp = null;
    this.rateInformation.updateRecordTimestamp = null;
    this.rateInformation.flatRateId = null;
    this.rateInformation.maleFlatRateAmount = Number(this.rateInformation.maleFlatRateAmount.toString().replace(/[^.0-9.-]+/g, ''));
    this.rateInformation.rowAction = 'INSERT';
    this.rateInformation.femaleFlatRateAmount = this.rateInformation.maleFlatRateAmount;

    const saveRequestObject: RateName = {
      createUserId: this.userId,
      updateUserId: this.userId,
      createRecordTimestamp: '',
      updateRecordTimestamp: '',
      rateName: this.rateInformation.rateName,
      rowAction: 'INSERT',
      corporateEntityCode: this.corporateEntityCode,
      rateConfigTypeName: this.rateConfigType,
      flatRates: []
    };

    saveRequestObject.flatRates.push(this.rateInformation);
    const finalSaveObject = {
      rate: saveRequestObject,
      warningState: this.isWarningState
    };
    return finalSaveObject;
  }

  /**
   * Method to handle error from API
   * @param: error
   */
  handleErrorResponse(error: any) {
    this.loadingService.hide();
    if (error.returnMessage && error.returnMessage.errors.length > 0) {
      this.returnMessage = error;
      this.isErrorMsgDisplay = true;
      this.checkRateWarningState(error.returnMessage.errors);
      this.rateOutlinedError(error.returnMessage.errors);
    } else {
      console.log('error  == >', JSON.stringify(error));
    }
  }

  /**
   * checkRateWarningState
   * @param errorMsgList
   * Method to check warning state
   */
  checkRateWarningState(errorMsgList: any) {
    errorMsgList.forEach((data: any) => {
      if (data.errorMessageId == 54) {
        this.isWarningState = true;
      }
    });
  }

  /**
   * rateOutlinedError
   * @param errorFieldList
   * Method to check the error list and outline in red
   */
  rateOutlinedError(errorFieldList: any) {
    errorFieldList.forEach((data: any) => {
      if (data.fieldId === 'rateEffectiveDate') {
        this.rateEffectiveDate = true;
      }
      if (data.fieldId === 'rateEndDate') {
        this.rateEndDate = true;
      }
      if (data.fieldId === 'maleFlatRateAmount') {
        this.maleFlatRateAmount = true;
      }
      if (data.fieldId === 'rateEffectiveAndEndDate') {
        this.rateEffectiveAndEndDate = true;
      }
    });
  }

  /* Method : validateRateName
   * Args: matchString - rateName
   * This method is used to validate the rate name model and show error message below the field.
   */
  validateRateName(matchString: any) {
    this.isErrorMsgDisplay = false;
    this.rateInformation.rateName = matchString.trim();
    this.isValidRateName = !this.utilService.patterMatch(
      ALPHA_NUMERIC_PATTERN_WITH_SPACE,
      this.rateInformation.rateName
    );
    if (!this.isValidRateName) {
      this.isRateNameDisabled = false;
    }
  }
  /* Method : setUpperCase
   * This method is used to convert the string to upper case
   */
  setUpperCase() {
    this.rateInformation.rateName = this.rateInformation.rateName.toUpperCase();
  }

  /**
   * Method: amountValidation
   * @param number:  amount
   * @param errorId: div id to show/hide error message
   * Method to validate amount and show/hide the error message
   */
  amountValidation(amount: any, errorId: string) {
    this.unFormattedAmount = this.rateInformation.maleFlatRateAmount;
    if (this.validateNumber(amount)) {
      this.setErrorMessage(errorId, false);
      !this.validateAmount(amount) ? this.setErrorMessage('isRateFormatError', true) : this.setErrorMessage('isRateFormatError', false);
    } else {
      this.setErrorMessage(errorId, true);
      this.setErrorMessage('isRateFormatError', false);
    }
  }

  /**
   * Method: Format Rate Amount
   * @param action
   * Method to format rate based on focus out and focus in actions
   */
  formatRateAmount(action: string) {
    if (!this.isAmountError && !this.isRateFormatError) {
      this.rateInformation.maleFlatRateAmount = this.utilService.getFormattedAmount(
        action,
        this.rateInformation.maleFlatRateAmount
      );
    }
  }

  /**
   * validateNumber
   * @param data
   * Function to validate if the data is numberic
   */
  validateNumber(data: any) {
    return (
      this.utilService.patterMatch(NUMBER_PATTERN_FOR_RATE, data) && data > 0
    );
  }

  /**
  * checkIfEmpty
  * Method to check if value is empty, else trim the value
  */
  checkIfEmpty() {
    if (!this.utilService.isEmptyCheck(this.rateInformation.maleFlatRateAmount)) {
      this.rateInformation.maleFlatRateAmount = this.rateInformation.maleFlatRateAmount.trim();
    }
  }

  /* Method : validateAmount
   * @param number: amount
   * This method is used to do amount validation for the mentioned PATTERN
   */
  validateAmount(amount: any) {
    const formattedAmount = parseFloat(amount);
    return this.utilService.patterMatch(
      AMOUNT_PATTERN_WITH_6_DIGITS_AND_2_DECIMALS,
      formattedAmount
    );
  }

  /**
   * Method: setErrorMessage
   * @param  string errorId
   * @param boolean trueOrFalse
   * This method is used to show/hide the error message
   */
  setErrorMessage(errorId: string, trueOrFalse: boolean) {
    switch (errorId) {
      case 'isEffDateError':
        this.isEffDateError = trueOrFalse;
        break;
      case 'isEndDateError':
        this.isEndDateError = trueOrFalse;
        break;
      case 'isAmountError':
        this.isAmountError = trueOrFalse;
        break;
      case 'isRateFormatError':
        this.isRateFormatError = trueOrFalse;
        break;
    }
  }

  /* Method : validateDate
   * @param date: Date
   * This method is used to do date validation for the mentioned PATTERN
   */
  validateDate(date: any) {
    return date !== '' && date !== null && date !== undefined
      ? this.utilService.patterMatch(DATE_PATTERN, this.customDateParserFormatter.format(date))
      : false;
  }

  /* Method : dateValidation
   * @param date    - selected date
   * @param errorId - div id to show message
   * Method to validate dates and show/hide the error message
   */
  dateValidation(date: string, errorId: string) {
    !this.validateDate(date)
      ? this.setErrorMessage(errorId, true)
      : this.setErrorMessage(errorId, false);
  }

  /**
   * Method to clear error messages
   */
  clearErrorMessage() {
    this.isErrorMsgDisplay = false;
    this.isValidRateName = false;
    this.rateEffectiveDate = false;
    this.rateEndDate = false;
    this.maleFlatRateAmount = false;
    this.rateEffectiveAndEndDate = false;
    this.setErrorMessage('isEffDateError', false);
    this.setErrorMessage('isEndDateError', false);
    this.setErrorMessage('isAmountError', false);
    this.setErrorMessage('isRateFormatError', false);
  }

  /**
   * Life cycle hook on compoent destory
   */
  ngOnDestroy() {
    setTimeout(() => {
      this.sharedService.clearToasts();
    }, 10000);
  }
}
