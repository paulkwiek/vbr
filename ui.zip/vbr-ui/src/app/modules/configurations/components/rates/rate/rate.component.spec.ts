import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { TableModule } from '../../../tables/index';
import { UIModule } from '../../../../../shared/modules/ui/ui.module';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { CustomDateParserFormatter } from '../../../../../shared/modules/ui/components/datepicker/customdateparserformatter';
import { NgbDateParserFormatter } from '@ng-bootstrap/ng-bootstrap';
import { CommonModule, CurrencyPipe } from '@angular/common';
import { UserCacheService } from '../../../../../shared/services/user-cache.service';
import { RateComponent } from './rate.component';
import { Store, StoreModule } from '@ngrx/store';
import { LoadingModule } from '../../../../../shared/modules/loading/loading.module';
import {environment} from '../../../../../../environments/environment';

const rateDetailsData = {
  'rateName': {
    'createUserId': 'U402537',
    'updateUserId': 'U402537',
    'createRecordTimestamp': '2019-09-25T15:47:12.985',
    'updateRecordTimestamp': '2019-10-09T12:51:36.184',
    'rowAction': 'NO_ACTION',
    'corporateEntityCode': 'NM1',
    'rateName': '1QQA1',
    'rateConfigTypeName': 'FLATRT',
    'flatRates': [
      {
        'createUserId': 'U402537',
        'updateUserId': 'U402537',
        'createRecordTimestamp': '2019-09-28T14:05:00.259',
        'updateRecordTimestamp': '2019-10-08T12:43:09.91',
        'rowAction': 'NO_ACTION',
        'recordEffectiveDate': '09/01/2024',
        'recordEndDate': '12/31/2024',
        'flatRateId': 183,
        'corporateEntityCode': 'NM1',
        'rateName': '1QQA1',
        'femaleFlatRateAmount': 121.0,
        'maleFlatRateAmount': 121.0,
        'commentText': 'Edited'
      }
    ],
    'paymentArrangementRates': [

    ]
  },
  'message': 'Rate fetched successfully.',
  'errors': null
};
const rateInformationData = {
  'createUserId': 'U402537',
  'updateUserId': 'U402537',
  'createRecordTimestamp': '2019-09-28T14:05:00.259',
  'updateRecordTimestamp': '2019-10-08T12:43:09.91',
  'rowAction': 'NO_ACTION',
  'recordEffectiveDate': '09/01/2024',
  'recordEndDate': '12/31/2024',
  'flatRateId': 183,
  'corporateEntityCode': 'NM1',
  'rateName': '1QQA1',
  'femaleFlatRateAmount': 121.0,
  'maleFlatRateAmount': 121.0,
  'commentText': 'Edited'
};
describe('RateComponent', () => {
  let component: RateComponent;
  let fixture: ComponentFixture<RateComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule, FormsModule, ReactiveFormsModule, TableModule, UIModule, NgbModule, CommonModule,
        LoadingModule,
        StoreModule.forRoot({})],
      declarations: [RateComponent],
      providers: [{
        provide: NgbDateParserFormatter,
        useClass: CustomDateParserFormatter
      },
        CustomDateParserFormatter, CurrencyPipe, UserCacheService, Store]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    component.rateDetails = rateDetailsData.rateName;
    component.rateInformation = rateInformationData;
    component.rateInformationActual = rateInformationData;
    component.userCacheService.setUserCacheData('USER_ID', 'U402537');
    component.userCacheService.setUserCacheData('CORPORATE_ENTITY_CODE', 'NM1');
    component.env = environment;
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('ngDoCheck - rateDetailsCheck should be true', () => {
    component.ngDoCheck();
    expect(component.rateDetailsCheck).toBeTruthy();
  });

  it('getRateDetailsDataOnSuccess - component.title should be equal to 1QQA1', () => {
    component.getRateDetailsDataOnSuccess(rateDetailsData);
    expect(component.title).toEqual('1QQA1');
  });

  it('getLinkedArrangements - component.clearErrorMessage should be called', () => {
    spyOn(component, 'clearErrorMessage');
    component.getLinkedArrangements('id');
    expect(component.clearErrorMessage).toHaveBeenCalled();
  });

  it('closeModal - isRateTableNameSaved to be false', () => {
      spyOn(component.modalService, 'close');
    component.closeModal('id');
    expect(component.modalService.close).toHaveBeenCalled();
  });

  it('view - component.getLinkedArrangements should be called', () => {
    spyOn(component, 'getLinkedArrangements');
    component.view('view-arrangements');
    expect(component.getLinkedArrangements).toHaveBeenCalled();
  });

  it('view - modalService.open should be called', () => {
      spyOn(component.modalService, 'open');
    component.view('id');
    expect(component.modalService.open).toHaveBeenCalled();
  });

 

  it('isAnyRateInformationChanged - return false', () => {
    const value = component.isAnyRateInformationChanged();
    expect(value).toBeFalsy();
  });

  it('isAnyRateInformationChanged - return true', () => {
    component.isEdit = true;
    component.rateInformation.recordEndDate = {
      year: 2024, month: 9, day: 30
    };
    const value = component.isAnyRateInformationChanged();
    expect(value).toBeTruthy();
  });

  it('saveRate - initializeSaveObject should have been called', () => {
    spyOn(component, 'clearErrorMessage');
    component.saveRateInformation('update', 'id');
    expect(component.clearErrorMessage).toHaveBeenCalled();
  });


  it('generateRateObject - should be equal to dataObject', () => {
    component.isWarningState = false;
    component.rateInformation.recordEffectiveDate = { year: 2024, month: 9, day: 1 };
    component.rateInformation.recordEndDate = { year: 2024, month: 12, day: 31 };
    component.rateInformation.flatRateId = null;
    component.rateInformation.commentText = '';
    const dataObject = {
      rate: {
        'createUserId': 'U402537',
        'updateUserId': 'U402537',
        'createRecordTimestamp': '2019-09-25T15:47:12.985',
        'updateRecordTimestamp': '2019-10-09T12:51:36.184',
        'rowAction': 'NO_ACTION',
        'corporateEntityCode': 'NM1',
        'rateName': '1QQA1',
        'rateConfigTypeName': 'FLATRT',
        'flatRates': [{
          'createUserId': 'U402537',
          'updateUserId': 'U402537',
          'createRecordTimestamp': '2019-09-28T14:05:00.259',
          'updateRecordTimestamp': '2019-10-08T12:43:09.91',
          'rowAction': 'INSERT',
          'recordEffectiveDate': '09/01/2024',
          'recordEndDate': '12/31/2024',
          'flatRateId': null,
          'corporateEntityCode': 'NM1',
          'rateName': '1QQA1',
          'femaleFlatRateAmount': 121.0,
          'maleFlatRateAmount': 121.0,
          'commentText': '',
        }]
      },
      warningState: false
    };
    const value = component.generateRateObject('INSERT');
    expect(value).toEqual(dataObject);
  });

  it('amountValidation- componenent.setErrorMesage should have been called', () => {
    spyOn(component, 'setErrorMessage');
    component.amountValidation('#$#', 'isError');
    expect(component.setErrorMessage).toHaveBeenCalled();
  });
  it('amountValidation- componenent.setErrorMesage should have been called', () => {
    spyOn(component, 'setErrorMessage');
    component.amountValidation(345457688, 'isError');
    expect(component.setErrorMessage).toHaveBeenCalled();
  });

  it('formatRateAmount - maleFlatRateAmount should be 345 while on focus', () => {
    component.isRateFormatError = false;
    component.isAmountError = false;
    component.rateInformation.maleFlatRateAmount = '$345';
    component.formatRateAmount('focus');
    expect(component.rateInformation.maleFlatRateAmount).toEqual(345);
  });

  it('formatRateAmount - maleFlatRateAmount should be 345 while on focus', () => {
    component.isRateFormatError = false;
    component.isAmountError = false;
    component.rateInformation.maleFlatRateAmount = '345';
    component.formatRateAmount('focusOut');
    expect(component.rateInformation.maleFlatRateAmount).toEqual('$345.00');
  });

  it('checkIfEmpty - component.rateInformation.maleFlatRateAmount should equal 345', () => {
    component.rateInformation.maleFlatRateAmount = '345  ';
    component.checkIfEmpty();
    expect(component.rateInformation.maleFlatRateAmount).toEqual('345');
  });

  it('dateValidation- component.setErrorMessage should have been called', () => {
    spyOn(component, 'setErrorMessage');
    component.dateValidation('12/01/2020', 'errorId');
    expect(component.setErrorMessage).toHaveBeenCalled();
  });

  it('dateValidation- component.setErrorMessage should have been called', () => {
    spyOn(component, 'setErrorMessage');
    const date: any = { year: 2020, month: 6, day: 1 };
    component.dateValidation(date, 'errorId');
    expect(component.setErrorMessage).toHaveBeenCalled();
  });

  it('resetComments - expect component.rateInformation.commentText should equal Edited', () => {
    component.rateInformationActual.commentText = 'Edited';
    component.resetCommentText();
    expect(component.rateInformation.commentText).toEqual('Edited');
  });

  it('editRate - component.isEdit should be true', () => {
      component.rateInformation = rateInformationData;
    component.editRate('id', rateInformationData);
    expect(component.isEdit).toBeTruthy();
  });

  it('addRate - isWarningState should be false', () => {
      spyOn(component.modalService, 'open');
    component.addRate('id');
    expect(component.modalService.open).toHaveBeenCalled();
    expect(component.isWarningState).toBeFalsy();
  });

  it('initializeRateInformation should equal to dataObject', () => {

    const value = {
      createUserId: 'U402537',
      updateUserId: 'U402537',
      recordEffectiveDate: { year: 2024, month: 9, day: 1 },
      recordEndDate: { year: 2024, month: 12, day: 31 },
      createRecordTimestamp: '2019-09-28T14:05:00.259',
      updateRecordTimestamp: '2019-10-08T12:43:09.91',
      corporateEntityCode: 'NM1',
      rateName: '1QQA1',
      flatRateId: 183,
      femaleFlatRateAmount: 121.0,
      maleFlatRateAmount: 121.0,
      commentText: 'Edited'
    };
    component.initializeRateInformation(rateInformationData);
    component.rateInformation.createUserId = 'U402537';
    component.rateInformation.updateUserId = 'U402537';
    component.rateInformation.corporateEntityCode = 'NM1';
    expect(component.rateInformation).toEqual(value);
  });

  it('handleWarningResponse - component.isWarningMsgDisplay  should be true', () => {
      spyOn(component.sharedService, 'handleErrorSuccessWarningInfo');
    const error = { 'returnMessage' : { 'itemName': 'rateName', 'status': 'SUCCESS', 'errors': [], 'warnings': [{'componentName': 'rateName', 'fieldId': 'paymentArrangementStatus', 'errorMessageId': 217, 'errorMsgDescriptionText': 'Arrangement status were changed due to the global rate edit', 'severitylevel': 'W', 'errorMessageCategoryCode': 'PCF-RTNM', 'validationClass': 'RTNM006CheckPaymentArrangementStatus'}]}, 'rateName': {'createUserId': 'U402537', 'updateUserId': 'U402537', 'createRecordTimestamp': '2019-11-25T08:49:17.004', 'updateRecordTimestamp': '2019-12-03T08:21:26.623', 'rowAction': 'NO_ACTION', 'corporateEntityCode': 'NM1', 'rateName': 'AQAQAQA', 'rateConfigTypeName': 'FLATRT', 'flatRates': [{'createUserId': 'U402537', 'updateUserId': 'U402537', 'createRecordTimestamp': '2019-11-25T08:49:17.005', 'updateRecordTimestamp': '2019-12-03T06:56:19.315', 'rowAction': 'UPDATE', 'recordEffectiveDate': '11/01/2019', 'recordEndDate': '12/31/2019', 'flatRateId': 555, 'corporateEntityCode': 'NM1', 'rateName': 'AQAQAQA', 'femaleFlatRateAmount': 11.0, 'maleFlatRateAmount': 11.0, 'commentText': 'd', 'flatRateHistory': []}], 'paymentArrangementRates': []}, 'message': 'Rate Table successfully updated.'};
    component.handleWarningResponse(error);
    expect(component.sharedService.handleErrorSuccessWarningInfo).toHaveBeenCalled();
  });

  it('validateRateComments should be false', () => {
    component.rateInformation.commentText = 'Edited   ';
    const value = component.validateRateComments();
    expect(value).toBeFalsy();

  });

});
