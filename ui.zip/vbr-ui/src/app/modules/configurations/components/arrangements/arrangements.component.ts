import { Component, OnInit, AfterContentChecked, OnDestroy, ChangeDetectorRef, ViewChildren, QueryList} from '@angular/core';
import { ModalService } from '../../../../shared/services/modal.service';
import { ConfigurationService } from '../../services/configuration.service';
import _ from 'lodash';
import { DataService } from '../../../../shared/services/data.service';
import {
  Message,
  GlobalConfig,
  types,
  ToastContainerDirective,
  ToastService,
  ActiveToast,
} from 'src/app/shared/modules/toast';
import {
  Router,
  RoutesRecognized
} from '@angular/router';
import { Observable } from 'rxjs';
import { UserCacheService } from '../../../../shared/services/user-cache.service';
import { LoadingService } from '../../../../shared/modules/loading/loading.module';
import { SharedService } from 'src/app/shared/services/shared.service';
import { AuthService } from '../../../../shared/services/auth.service';
import { ARRANGEMENT_ROLES } from '../../../../shared/constants/app.constants';
import { environment } from '../../../../../environments/environment';

@Component({
  selector: 'app-arrangements',
  templateUrl: './arrangements.component.html',
  styleUrls: ['./arrangements.component.scss']
})
export class ArrangementsComponent implements OnInit, AfterContentChecked, OnDestroy {
  title = 'Payment Arrangements';
  arrangements: any;
  contentCheck: boolean;
  successMessage: Observable<boolean>;
  toastMessage: any;
  messages: Message[];
  options: GlobalConfig;
  text = '';
  type = types[0];
  message: any;
  inserted: any;
  routeSub: any;
  checkRoles: boolean;
  env = environment;
  @ViewChildren(ToastContainerDirective) inlineContainers: QueryList<
    ToastContainerDirective
  >;
  corporateEntityCode: string;
  corporateEntityDescription: string;

  constructor(
    public modalService: ModalService,
    private configurationService: ConfigurationService,
    private dataService: DataService,
    public toast: ToastService,
    public router: Router, private cdr: ChangeDetectorRef,
    private userCacheService: UserCacheService,
    public loadingService: LoadingService,
    private sharedService: SharedService,
    public authService: AuthService,
  ) {
    this.routeSub = this.router.events.subscribe(event => {
      if (event instanceof RoutesRecognized) {
        if (event.url !== this.router.url) {
          for (const toasty of this.toast.toasts) {
            this.toast.remove(toasty.toastId);
          }
        }
      }
    });

    this.sharedService.getCorpEntityCode().subscribe(data => this.corporateEntityCode = data);

    this.sharedService.getCorpEntityDescription().subscribe(data => this.corporateEntityDescription = data);
    this.getSuccessMessage();
  }

  /**
   * Life cycle event after component initalization
   */
  ngOnInit() {
    this.getArrangements();
    this.checkRoles = this.env.SSO_CONFIG.enableSSO ? !this.authService.isAuthorized(ARRANGEMENT_ROLES) : false;
  }

  /**
   * Life cycle event after content checked
   */
  ngAfterContentChecked() {
    this.cdr.detectChanges();
    if (this.arrangements === undefined || _.size(this.arrangements) === 0) {
      this.contentCheck = false;
    } else {
      this.contentCheck = true;
    }
  }

  /* Method : getSuccessMessage
   * This method to retrieve the success message from data service
   */

  getSuccessMessage() {
    this.toastMessage = this.dataService
      .getSuccessMessage()
      .subscribe(data => {
        if (data && data.isSuccessMessage) {
          this.sharedService.handleErrorSuccessWarningInfo('SUCCESS', data.data);
        }
      });
  }

  /* Method : clearSuccessMessage
   * This method to clear the success message from data service
   */
  clearSuccessMessage() {
    this.dataService.setSuccessMessage({
      isSuccessMessage: false
    });
  }

  /**
   * ngOnDestroy
   * Life cycle hook call on destroy
   */
  ngOnDestroy() {
    if (this.toast.toasts.length > 0) {
      this.toastMessage.unsubscribe();
    }
    this.clearSuccessMessage();
    this.routeSub.unsubscribe();
    this.cdr.detach();
    this.sharedService.clearToasts();
  }

  /* Method : getArragements
   * This method is used to call the service method to get all arrangements from DB
   */
  getArrangements() {
    this.loadingService.show();
    this.configurationService.getAllArrangementsFromDB(this.corporateEntityCode).subscribe(
      (data: any) => {
        this.loadingService.hide();
        this.arrangements = data;
      },
      error => {
        this.loadingService.hide();
        // on failure, call method to display error
        this.sharedService.handleErrorSuccessWarningInfo('FAILURE', error, 'Arrangement Errors');
      }
    );
  }

  /**
   * openModal
   * @param id
   * Method to open the modal
   */
  openModal(id: string) {
    this.modalService.open(id);
  }

  /**
   * closeModal
   * @param id
   * Method to close the modal
   */
  closeModal(id: string) {
    this.modalService.close(id);
  }
}
