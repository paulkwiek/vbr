import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { BrowserModule } from '@angular/platform-browser';
import { CommonModule, CurrencyPipe } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { ArrangementComponent } from './arrangement.component';
import { PipesModule } from '../../../../../shared/pipes/pipes.module';
import { TableModule } from '../../../tables/index';
import { UIModule } from '../../../../../shared/modules/ui/ui.module';
import { DragDropListModule } from '../../../../../shared/modules/dragDropLists/dragDropLists.module';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { CustomDateParserFormatter } from '../../../../../shared/modules/ui/components/datepicker/customdateparserformatter';
import { NgbDateParserFormatter } from '@ng-bootstrap/ng-bootstrap';
import { UtilService } from 'src/app/shared/services/util.service';
import { UserCacheService } from '../../../../../shared/services/user-cache.service';
import { DataTableModule } from '../../../../../shared/modules/data-table/index';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { PaymentArrangement, Provider } from '../../../../../models/configuration.model';
import { Store, StoreModule } from '@ngrx/store';
import { LoadingModule } from '../../../../../shared/modules/loading/loading.module';
import { environment } from '../../../../../../environments/environment';

const arrangementData = {
  'returnMessage': {
    'itemName': 'paymentArrangement',
    'status': 'SUCCESS',
    'errors': [],
    'warnings': [
      {
        'componentName': 'paymentArrangement',
        'fieldId': 'paymentArrangementPayeeEffectiveAndEndDate',
        'errorMessageId': 46,
        'errorMsgDescriptionText': 'Arrangement payee dates must be within VBR payee dates',
        'severitylevel': 'W',
        'errorMessageCategoryCode': 'PCF-PMAM',
        'validationClass': 'PMAM015CheckArrangementPayeeDurationWithVbrPayee'
      }
    ]
  },
  'paymentArrangement': {
    'createUserId': 'U402537',
    'updateUserId': 'VBRETL',
    'createRecordTimestamp': '2019-11-25T09:06:25.319',
    'updateRecordTimestamp': '2019-12-03T08:21:26.711',
    'rowAction': 'NO_ACTION',
    'recordEffectiveDate': '11/01/2019',
    'recordEndDate': '12/31/2019',
    'paymentArrangementId': 1959,
    'corporateEntityCode': 'NM1',
    'paymentArrangementName': 'ARRANGEMENT0103',
    'arrangementFrequencyCode': 'MONT',
    'paymentArrangementTypeCode': 'UNIQUE',
    'paymentArrangementDescription': 'THIS IS AN ARRANGEMENT CREATED TsdHROUGH REGRESSION SUITEfsdfDSFSDFqqaaa1111111',
    'paymentTypeCode': 'FFV-HME',
    'validationStatusCode': 'VA',
    'paymentArrangementStatusDescription': 'Valid',
    'paymentArrangementPayees': [
      {
        'createUserId': 'U402537',
        'updateUserId': 'U402537',
        'createRecordTimestamp': '2019-11-26T11:52:43.528',
        'updateRecordTimestamp': '2019-11-26T11:52:43.53',
        'rowAction': 'NO_ACTION',
        'recordEffectiveDate': '11/01/2019',
        'recordEndDate': '12/31/2019',
        'paymentArrangementPayeeId': 1493,
        'paymentArrangementId': 1959,
        'vbrPayeeId': 412,
        'vbrPayee': {
          'createUserId': 'U402537',
          'updateUserId': 'U402537',
          'createRecordTimestamp': '2019-11-21T12:05:46.192',
          'updateRecordTimestamp': '2019-11-26T12:26:36.447',
          'rowAction': 'NO_ACTION',
          'recordEffectiveDate': '11/01/2019',
          'recordEndDate': '01/31/2020',
          'vbrPayeeId': 412,
          'corporateEntityCode': 'NM1',
          'pinGroupId': 'RF2       ',
          'pinGroupName': 'RF2001',
          'capitationProcessCode': 'CP',
          'networkCode': 'MCD',
          'taxIdNumber': '999999999',
          'capitationCode': 'A1',
          'payToPfinId': '00NMCAB001',
          'networkAssociationID': 772129222
        }
      }
    ],
    'paymentArrangementMemberSubjects': [
      {
        'createUserId': 'U402537',
        'updateUserId': 'U402537',
        'createRecordTimestamp': '2019-11-25T09:06:25.325',
        'updateRecordTimestamp': '2019-11-25T09:06:25.326',
        'rowAction': 'NO_ACTION',
        'paymentArrangementMemberSubjectId': 1656,
        'planStateCode': null,
        'productTypeCode': null,
        'benefitPlanStateCode': null,
        'actionCode': null,
        'benefitPlanNumber': null,
        'lineOfBusinessCode': 'MAPD',
        'accountnumber': null,
        'groupId': null,
        'sectionNumber': null,
        'copayCode': null,
        'captitationEntityCode': null,
        'siteId': null,
        'benefitArrangementNumber': null,
        'memberLocationId': null,
        'networkRiskLevelCode': null,
        'paymentArrangementId': 1959,
        'corporateEntityCode': 'NM1',
        'fundingTypeCode': null,
        'contractId': 'H3251'
      }
    ],
    'retroRuleSetups': [],
    'paymentArrangementHistories': [
      {
        'createUserId': 'VBRETL',
        'updateUserId': 'VBRETL',
        'createRecordTimestamp': '2019-12-02T05:46:23.372',
        'updateRecordTimestamp': '2019-12-02T05:46:23.372',
        'rowAction': 'NO_ACTION',
        'recordEffectiveDate': '2019-11-01',
        'recordEndDate': '2019-12-31',
        'paymentArrangementHistoryId': 2860,
        'paymentArrangementId': 1959,
        'corporateEntityCode': 'NM1',
        'paymentArrangementName': 'ARRANGEMENT0103',
        'arrangementFrequencyCode': 'MONT',
        'paymentArrangementTypeCode': 'UNIQUE',
        'paymentArrangementDescription': 'THIS IS AN ARRANGEMENT CREATED TsdHROUGH REGRESSION SUITEfsdfDSFSDFqqaaa1111111',
        'paymentArrangementContractId': null,
        'paymentTypeCode': 'FFV-HME',
        'validationStatusCode': 'VA'
      },
      {
        'createUserId': 'VBRETL',
        'updateUserId': 'VBRETL',
        'createRecordTimestamp': '2019-12-02T05:46:23.372',
        'updateRecordTimestamp': '2019-12-02T05:46:23.372',
        'rowAction': 'NO_ACTION',
        'recordEffectiveDate': '2019-11-01',
        'recordEndDate': '2019-12-31',
        'paymentArrangementHistoryId': 2859,
        'paymentArrangementId': 1959,
        'corporateEntityCode': 'NM1',
        'paymentArrangementName': 'ARRANGEMENT0103',
        'arrangementFrequencyCode': 'MONT',
        'paymentArrangementTypeCode': 'UNIQUE',
        'paymentArrangementDescription': 'THIS IS AN ARRANGEMENT CREATED TsdHROUGH REGRESSION SUITEfsdfDSFSDFqqaaa1111111',
        'paymentArrangementContractId': null,
        'paymentTypeCode': 'FFV-HME',
        'validationStatusCode': 'IV'
      },
      {
        'createUserId': 'VBRETL',
        'updateUserId': 'VBRETL',
        'createRecordTimestamp': '2019-11-29T10:21:59.162',
        'updateRecordTimestamp': '2019-11-29T10:21:59.162',
        'rowAction': 'NO_ACTION',
        'recordEffectiveDate': '2019-11-01',
        'recordEndDate': '2019-12-31',
        'paymentArrangementHistoryId': 2738,
        'paymentArrangementId': 1959,
        'corporateEntityCode': 'NM1',
        'paymentArrangementName': 'ARRANGEMENT0103',
        'arrangementFrequencyCode': 'MONT',
        'paymentArrangementTypeCode': 'UNIQUE',
        'paymentArrangementDescription': 'THIS IS AN ARRANGEMENT CREATED TsdHROUGH REGRESSION SUITEfsdfDSFSDFqqaaa1111111',
        'paymentArrangementContractId': null,
        'paymentTypeCode': 'FFV-HME',
        'validationStatusCode': 'IV'
      },
      {
        'createUserId': 'VBRETL',
        'updateUserId': 'VBRETL',
        'createRecordTimestamp': '2019-11-29T10:21:59.163',
        'updateRecordTimestamp': '2019-11-29T10:21:59.163',
        'rowAction': 'NO_ACTION',
        'recordEffectiveDate': '2019-11-01',
        'recordEndDate': '2019-12-31',
        'paymentArrangementHistoryId': 2739,
        'paymentArrangementId': 1959,
        'corporateEntityCode': 'NM1',
        'paymentArrangementName': 'ARRANGEMENT0103',
        'arrangementFrequencyCode': 'MONT',
        'paymentArrangementTypeCode': 'UNIQUE',
        'paymentArrangementDescription': 'THIS IS AN ARRANGEMENT CREATED TsdHROUGH REGRESSION SUITEfsdfDSFSDFqqaaa1111111',
        'paymentArrangementContractId': null,
        'paymentTypeCode': 'FFV-HME',
        'validationStatusCode': 'VA'
      },
      {
        'createUserId': 'U402537',
        'updateUserId': 'U402537',
        'createRecordTimestamp': '2019-11-25T09:06:25.319',
        'updateRecordTimestamp': '2019-11-27T13:33:47.877',
        'rowAction': 'NO_ACTION',
        'recordEffectiveDate': '2019-11-01',
        'recordEndDate': '2019-12-31',
        'paymentArrangementHistoryId': 2571,
        'paymentArrangementId': 1959,
        'corporateEntityCode': 'NM1',
        'paymentArrangementName': 'ARRANGEMENT0103',
        'arrangementFrequencyCode': 'MONT',
        'paymentArrangementTypeCode': 'UNIQUE',
        'paymentArrangementDescription': 'THIS IS AN ARRANGEMENT CREATED TsdHROUGH REGRESSION SUITEfsdfDSFSDFqqaaa1111111',
        'paymentArrangementContractId': null,
        'paymentTypeCode': 'FFV-HME',
        'validationStatusCode': 'VA'
      },
      {
        'createUserId': 'U402537',
        'updateUserId': 'U402537',
        'createRecordTimestamp': '2019-11-25T09:06:25.319',
        'updateRecordTimestamp': '2019-11-26T11:52:43.53',
        'rowAction': 'NO_ACTION',
        'recordEffectiveDate': '2019-11-01',
        'recordEndDate': '2019-12-31',
        'paymentArrangementHistoryId': 2546,
        'paymentArrangementId': 1959,
        'corporateEntityCode': 'NM1',
        'paymentArrangementName': 'ARRANGEMENT0103',
        'arrangementFrequencyCode': 'MONT',
        'paymentArrangementTypeCode': 'UNIQUE',
        'paymentArrangementDescription': 'THIS IS AN ARRANGEMENT CREATED TsdHROUGH REGRESSION SUITEfsdf',
        'paymentArrangementContractId': null,
        'paymentTypeCode': 'FFV-HME',
        'validationStatusCode': 'VA'
      },
      {
        'createUserId': 'U402537',
        'updateUserId': 'U402537',
        'createRecordTimestamp': '2019-11-25T09:06:25.319',
        'updateRecordTimestamp': '2019-11-27T10:35:22.927',
        'rowAction': 'NO_ACTION',
        'recordEffectiveDate': '2019-11-01',
        'recordEndDate': '2019-12-31',
        'paymentArrangementHistoryId': 2549,
        'paymentArrangementId': 1959,
        'corporateEntityCode': 'NM1',
        'paymentArrangementName': 'ARRANGEMENT0103',
        'arrangementFrequencyCode': 'MONT',
        'paymentArrangementTypeCode': 'UNIQUE',
        'paymentArrangementDescription': 'THIS IS AN ARRANGEMENT CREATED TsdHROUGH REGRESSION SUITEfsdfDSFSDF',
        'paymentArrangementContractId': null,
        'paymentTypeCode': 'FFV-HME',
        'validationStatusCode': 'VA'
      },
      {
        'createUserId': 'U402537',
        'updateUserId': 'U402537',
        'createRecordTimestamp': '2019-11-25T09:06:25.319',
        'updateRecordTimestamp': '2019-11-27T11:52:36.866',
        'rowAction': 'NO_ACTION',
        'recordEffectiveDate': '2019-11-01',
        'recordEndDate': '2019-12-31',
        'paymentArrangementHistoryId': 2550,
        'paymentArrangementId': 1959,
        'corporateEntityCode': 'NM1',
        'paymentArrangementName': 'ARRANGEMENT0103',
        'arrangementFrequencyCode': 'MONT',
        'paymentArrangementTypeCode': 'UNIQUE',
        'paymentArrangementDescription': 'THIS IS AN ARRANGEMENT CREATED TsdHROUGH REGRESSION SUITEfsdfDSFSDFqq',
        'paymentArrangementContractId': null,
        'paymentTypeCode': 'FFV-HME',
        'validationStatusCode': 'VA'
      },
      {
        'createUserId': 'U402537',
        'updateUserId': 'U402537',
        'createRecordTimestamp': '2019-11-25T09:06:25.319',
        'updateRecordTimestamp': '2019-11-27T12:18:01.405',
        'rowAction': 'NO_ACTION',
        'recordEffectiveDate': '2019-11-01',
        'recordEndDate': '2019-12-31',
        'paymentArrangementHistoryId': 2556,
        'paymentArrangementId': 1959,
        'corporateEntityCode': 'NM1',
        'paymentArrangementName': 'ARRANGEMENT0103',
        'arrangementFrequencyCode': 'MONT',
        'paymentArrangementTypeCode': 'UNIQUE',
        'paymentArrangementDescription': 'THIS IS AN ARRANGEMENT CREATED TsdHROUGH REGRESSION SUITEfsdfDSFSDFqqaaa',
        'paymentArrangementContractId': null,
        'paymentTypeCode': 'FFV-HME',
        'validationStatusCode': 'VA'
      },
      {
        'createUserId': 'U402537',
        'updateUserId': 'U402537',
        'createRecordTimestamp': '2019-11-25T09:06:25.319',
        'updateRecordTimestamp': '2019-11-27T13:04:28.013',
        'rowAction': 'NO_ACTION',
        'recordEffectiveDate': '2019-11-01',
        'recordEndDate': '2019-12-31',
        'paymentArrangementHistoryId': 2568,
        'paymentArrangementId': 1959,
        'corporateEntityCode': 'NM1',
        'paymentArrangementName': 'ARRANGEMENT0103',
        'arrangementFrequencyCode': 'MONT',
        'paymentArrangementTypeCode': 'UNIQUE',
        'paymentArrangementDescription': 'THIS IS AN ARRANGEMENT CREATED TsdHROUGH REGRESSION SUITEfsdfDSFSDFqqaaa1111',
        'paymentArrangementContractId': null,
        'paymentTypeCode': 'FFV-HME',
        'validationStatusCode': 'VA'
      },
      {
        'createUserId': 'U402537',
        'updateUserId': 'U402537',
        'createRecordTimestamp': '2019-11-25T09:06:25.319',
        'updateRecordTimestamp': '2019-11-25T09:06:25.322',
        'rowAction': 'NO_ACTION',
        'recordEffectiveDate': '2019-11-01',
        'recordEndDate': '2019-12-31',
        'paymentArrangementHistoryId': 2529,
        'paymentArrangementId': 1959,
        'corporateEntityCode': 'NM1',
        'paymentArrangementName': 'ARRANGEMENT0103',
        'arrangementFrequencyCode': 'MONT',
        'paymentArrangementTypeCode': 'UNIQUE',
        'paymentArrangementDescription': 'THIS IS AN ARRANGEMENT CREATED THROUGH REGRESSION SUITE',
        'paymentArrangementContractId': null,
        'paymentTypeCode': 'FFV-HME',
        'validationStatusCode': 'VA'
      },
      {
        'createUserId': 'U402537',
        'updateUserId': 'U402537',
        'createRecordTimestamp': '2019-11-25T09:06:25.322',
        'updateRecordTimestamp': '2019-11-25T09:06:25.322',
        'rowAction': 'NO_ACTION',
        'recordEffectiveDate': '2019-01-01',
        'recordEndDate': '2019-12-31',
        'paymentArrangementHistoryId': 2477,
        'paymentArrangementId': 1959,
        'corporateEntityCode': 'NM1',
        'paymentArrangementName': 'ARRANGEMENT0103',
        'arrangementFrequencyCode': 'MONT',
        'paymentArrangementTypeCode': 'UNIQUE',
        'paymentArrangementDescription': 'THIS IS AN ARRANGEMENT CREATED THROUGH REGRESSION SUITE',
        'paymentArrangementContractId': null,
        'paymentTypeCode': 'FFV-HME',
        'validationStatusCode': 'DF'
      }
    ],
    'paymentArrangementRates': [
      {
        'createUserId': 'U402537',
        'updateUserId': 'U402537',
        'createRecordTimestamp': '2019-11-25T16:33:51.244',
        'updateRecordTimestamp': '2019-11-26T11:50:49.513',
        'rowAction': 'NO_ACTION',
        'recordEffectiveDate': '11/01/2019',
        'recordEndDate': '11/01/2019',
        'paymentArrangementRateId': 1646,
        'rateName': 'AQAQAQA',
        'corporateEntityCode': 'NM1',
        'rateConfigTypeName': null,
        'paymentArrangementId': 1959
      },
      {
        'createUserId': 'U402537',
        'updateUserId': 'U402537',
        'createRecordTimestamp': '2019-11-26T11:50:49.505',
        'updateRecordTimestamp': '2019-11-26T11:50:49.512',
        'rowAction': 'NO_ACTION',
        'recordEffectiveDate': '11/01/2019',
        'recordEndDate': '12/31/2019',
        'paymentArrangementRateId': 1664,
        'rateName': 'AQAQAQA',
        'corporateEntityCode': 'NM1',
        'rateConfigTypeName': null,
        'paymentArrangementId': 1959
      }
    ]
  }
};

const editArrDates = {
  arrangPayeeEffectiveDate: '06/01/2020',
  arrangPayeeEndDate: '11/30/2020',
};
const providerInfo = {
  createRecordTimestamp: '2019-09-25T10:27:05.22',
  updateRecordTimestamp: '2019-09-27T06:32:30.045',
  vbrPayeeId: 43,
  corporateEntityCode: 'NM ',
  pinGroupId: 'BSR       ',
  pinGroupName: 'BSR010',
  capitationProcessCode: 'CP',
  networkCode: 'MCD',
  taxIdNumber: '999999999',
  capitationCode: 'A1',
  payToPfinId: '00NMCAP010',
  networkAssocProviderId: '772129111'
};

const lob = { 'codeSetValueItems': [{ 'codeSetName': 'LOB', 'corporateEntityCode': 'NM1', 'codeSetDescription': 'Line of Business', 'codeValueText': 'MAPD', 'codeValueDescription': 'Medicare Advantage Membership Cohort' }] };
const contracts = { 'codeSetValueItems': [{ 'codeSetName': 'MEMCONTRID', 'corporateEntityCode': 'NM1', 'codeSetDescription': 'Member Contract Id', 'codeValueText': 'H3251', 'codeValueDescription': 'H3251' }, { 'codeSetName': 'MEMCONTRID', 'corporateEntityCode': 'NM1', 'codeSetDescription': 'Member Contract Id', 'codeValueText': 'H3822', 'codeValueDescription': 'H3822' }, { 'codeSetName': 'MEMCONTRID', 'corporateEntityCode': 'NM1', 'codeSetDescription': 'Member Contract Id', 'codeValueText': 'H8634', 'codeValueDescription': 'H8634' }] };

describe('ArrangementComponent', () => {
  let component: ArrangementComponent;
  let fixture: ComponentFixture<ArrangementComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        BrowserModule,
        CommonModule,
        FormsModule,
        HttpClientTestingModule,
        NgbModule,
        ReactiveFormsModule,
        DataTableModule,
        RouterTestingModule,
        BrowserAnimationsModule,
        PipesModule,
        TableModule,
        UIModule,
        DragDropListModule,
        LoadingModule,
        StoreModule.forRoot({})
      ],
      declarations: [ArrangementComponent],
      providers: [
        {
          provide: NgbDateParserFormatter,
          useClass: CustomDateParserFormatter
        },
        CustomDateParserFormatter,
        UserCacheService,
        UtilService,
        CurrencyPipe, Store
      ]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ArrangementComponent);
    component = fixture.componentInstance;
    component.env = environment;
    fixture.detectChanges();

    const dataPayment: any = [
      {
        createUserId: 'U398407',
        updateUserId: 'U398407',
        createRecordTimestamp: '2019-07-10T02:39:10',
        updateRecordTimestamp: '2019-07-10T02:39:10',
        paymentTypeCode: 'ACCFND',
        paymentTypeDescription: 'desc'
      },
      {
        createUserId: 'U398407',
        updateUserId: 'U398407',
        createRecordTimestamp: '2019-07-10T02:39:10',
        updateRecordTimestamp: '2019-07-10T02:39:10',
        paymentTypeCode: 'MMCARE',
        paymentTypeDescription: 'desc'
      },
      {
        createUserId: 'U398407',
        updateUserId: 'U398407',
        createRecordTimestamp: '2019-06-28T19:39:04',
        updateRecordTimestamp: '2019-06-28T19:39:04',
        paymentTypeCode: 'PMTYP',
        paymentTypeDescription: 'Payment Type'
      },
      {
        createUserId: 'U398407',
        updateUserId: 'U398407',
        createRecordTimestamp: '2019-07-10T02:39:10',
        updateRecordTimestamp: '2019-07-10T02:39:10',
        paymentTypeCode: 'TYIFND',
        paymentTypeDescription: 'desc'
      }
    ];

    component.arrangement = arrangementData.paymentArrangement;
    component.existingArrangement = JSON.parse(JSON.stringify(arrangementData.paymentArrangement));
    component.providerInfo = providerInfo;

    component.editPayeeArrangDates = editArrDates;
    component.paymentTypes = {
      paymentTypes: dataPayment
    };

    component.userCacheService.setUserCacheData('USER_ID', 'U402537');
    component.userCacheService.setUserCacheData('CORPORATE_ENTITY_CODE', 'NM1');
    component.paymtArrTypeCode = 'UNIQUE';
    component.lineOfBusinessToAddActual = lob.codeSetValueItems;
    component.lineOfBusinessToAdd = component.lineOfBusinessToAddActual;
    component.contractsToAddActual = contracts.codeSetValueItems;
    component.contractsToAdd = component.contractsToAddActual;
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('ngOnInit - initializeArrangementPayeeSearchForm should be called', () => {
    spyOn(component, 'initializeArrangementPayeeSearchForm');
    component.ngOnInit();
    expect(component.initializeArrangementPayeeSearchForm).toHaveBeenCalled();
  });

  it('ngOnInit - initializeArrangDates should be called', () => {
    spyOn(component, 'initializeArrangDates');
    component.ngOnInit();
    expect(component.initializeArrangDates).toHaveBeenCalled();
  });

  it('ngOnInit - initializeVBRDates should be called', () => {
    spyOn(component, 'initializeVBRDates');
    component.ngOnInit();
    expect(component.initializeVBRDates).toHaveBeenCalled();
  });

  it('ngOnInit - getPaymentTypes should be called', () => {
    spyOn(component, 'getPaymentTypes');
    component.ngOnInit();
    expect(component.getPaymentTypes).toHaveBeenCalled();
  });

  it('ngOnInit - component.payeeArrang should be false', () => {
    component.ngOnInit();
    expect(component.payeeArrang).toBeFalsy();
  });

  it('initializeArrangement - initializePaymentArrangement should be called', () => {
    spyOn(component, 'initializePaymentArrangement');
    component.route.snapshot.params = { id: 0 };
    component.initializeArrangement();
    expect(component.initializePaymentArrangement).toHaveBeenCalled();
  });

  it('initializeArrangement - getArrangement should be called', () => {
    spyOn(component, 'getArrangement');
    component.initializeArrangement();
    expect(component.getArrangement).toHaveBeenCalled();
  });

  it('getPaymentTypes - loadingService.show should be called', () => {
    spyOn(component.loadingService, 'show');
    component.getPaymentTypes();
    expect(component.loadingService.show).toHaveBeenCalled();
  });

  it('getArrangement -sharedService.clearToasts should be called', () => {
    spyOn(component.sharedService, 'clearToasts');
    component.getArrangement();
    expect(component.sharedService.clearToasts).toHaveBeenCalled();
  });

  it('initializePaymentArrangement - arrangementData should be equal to component.arrangement', () => {
    const arrangementData: PaymentArrangement = {
      corporateEntityCode: component.userCacheService.getUserCacheData('CORPORATE_ENTITY_CODE'),
      paymentArrangementContractId: null,
      paymentArrangementName: '',
      arrangementFrequencyCode: 'MONT',
      paymentArrangementDescription: '',
      recordEffectiveDate: '',
      recordEndDate: '',
      createUserId: component.userCacheService.getUserCacheData('USER_ID'),
      updateUserId: component.userCacheService.getUserCacheData('USER_ID'),
      createRecordTimestamp: '',
      paymentArrangementId: null,
      validationStatusCode: null,
      rowAction: 'INSERT',
      retroRuleSetups: [],
      paymentArrangementRates: [],
      paymentArrangementHistories: [],
      paymentArrangementMemberSubjects: [],
      paymentArrangementPayees: [],
      paymentArrangementTypeCode: component.paymtArrTypeCode
    };
    component.initializePaymentArrangement();
    expect(component.arrangement).toEqual(arrangementData);
  });

  it('validatePinGroupId - component.isPinGroupError should be false', () => {
    component.validatePinGroupId('RSK');
    expect(component.isPinGroupError).toBeFalsy();
  });

  it('validatePinGroup - component.isPinGroupError should be true', () => {
    component.validatePinGroupId('!#$');
    expect(component.isPinGroupError).toBeTruthy();
  });

  it('pinGroupValidation - should return true', () => {
    const data = component.pinGroupValidation('RSK');
    expect(data).toBeTruthy();
  });

  it('pinGroupValidation should return false', () => {
    const data = component.pinGroupValidation('!#$%');
    expect(data).toBeFalsy();
  });

  it('validateArrangPayeeDate - validate date - 13/06/2006', () => {
    component.validateVBRDate('13/06/2006', 'isEditEffDateError');
    expect(component.isEditEffDateError).toBeTruthy();
  });

  it('validateArrangPayeeDate - validate date - 02/06/2006', () => {
    const date: any = {
      day: 2,
      month: 6,
      year: 2006
    };
    component.validateVBRDate(date, 'isEditEffDateError');
    expect(component.isEditEffDateError).toBeFalsy();
  });

  it('validateArrangPayeeDate - validate date - 13/06/2006', () => {
    component.validateVBRDate('13/06/2006', 'isEffDateError');
    expect(component.isEffDateError).toBeTruthy();
  });

  it('validateArrangPayeeDate - validate date - 13/06/2006', () => {
    component.validateVBRDate('13/06/2006', 'isEndDateError');
    expect(component.isEndDateError).toBeTruthy();
  });

  it('validateArrangPayeeDate - validate date - 13/06/2006', () => {
    component.validateVBRDate('13/06/2006', 'isEditEndDateError');
    expect(component.isEditEndDateError).toBeTruthy();
  });

  it('addPayee - component.initializeArrangementPayeeSearchForm should be called', () => {
    spyOn(component, 'initializeArrangementPayeeSearchForm');
    spyOn(component.modalService, 'open');
    component.addPayee('string');
    expect(component.initializeArrangementPayeeSearchForm).toHaveBeenCalled();
  });

  it('addPayee - modal should be open', () => {
    spyOn(component.modalService, 'open');
    component.addPayee('string');
    expect(component.modalService.open).toHaveBeenCalled();
  });

  it('editArrPayee - modal should be open', () => {
    spyOn(component.modalService, 'open');
    const data: any = {
      'createUserId': 'U402537', 'updateUserId': 'U402537', 'createRecordTimestamp': '2019 - 07 - 15T14: 41: 00', 'updateRecordTimestamp': '2019 - 07 - 15T14: 41: 00', 'recordEffectiveDate': '02 / 02 / 2009', 'recordEndDate': '04 / 01 / 2009', 'paymentArrangementPayeeId': 103, 'vbrPayee': { 'createUserId': 'U402537', 'updateUserId': 'U402537', 'createRecordTimestamp': '2019 - 07 - 15T14: 41: 00', 'updateRecordTimestamp': '2019 - 07 - 15T14: 41: 00', 'recordEffectiveDate': '02 / 02 / 2009', 'recordEndDate': '12 / 31 / 2019', 'vbrPayeeId': 198, 'corporateEntityCode': 'NM', 'pinGroupId': 'KSR', 'pinGroupName': 'KSR009', 'capitationProcessCode': 'CP', 'networkCode': 'MCD', 'taxIdNumber': '999999999', 'capitationCode': 'A1', 'payToPfinId': '00NMCAP017', 'networkAssocProviderId': '772129110' }, 'paymentArrangementRates': []
    };
    const dataString = JSON.stringify(data);
    const record = JSON.parse(dataString);
    component.editArrPayee('edit-arrangement-payee', record, 0);
    expect(component.modalService.open).toHaveBeenCalled();
  });
  it('open - modal should be open', () => {
    spyOn(component.modalService, 'open');
    component.open('string');
    expect(component.modalService.open).toHaveBeenCalled();
  });

  it('close- modal should be closed', () => {
    spyOn(component.modalService, 'close');
    component.close('string');
    expect(component.modalService.close).toHaveBeenCalled();
  });

  it('cancelEdit- component.isEditEffDateError should be false', () => {
    spyOn(component.modalService, 'close');
    component.cancelEdit('edit-arrangement-payee');
    expect(component.isEditEffDateError).toBeFalsy();
  });

  it('cancelEdit - modal should be closed', () => {
    spyOn(component.modalService, 'close');
    component.cancelEdit('string');
    expect(component.modalService.close).toHaveBeenCalled();
  });

  it('saveCustomSetting - component.retroactivityCheck should be true', () => {
    spyOn(component.modalService, 'close');
    component.saveCustomSetting('string');
    expect(component.retroactivityCheck).toBeTruthy();
  });

  it('saveCustomSetting - modal should be closed', () => {
    spyOn(component.modalService, 'close');
    component.saveCustomSetting('string');
    expect(component.modalService.close).toHaveBeenCalled();
  });

  it('getPaymentTypeDescription - component.paymentTypeDescription should be equal to desc', () => {
    component.getPaymentTypeDescription('ACCFND');
    expect(component.paymentTypeDescription).toEqual('desc');
  });

  it('getPaymentTypeDescription - component.paymentTypeDescription should be equal to ""', () => {
    component.getPaymentTypeDescription('des');
    expect(component.paymentTypeDescription).toEqual('');
  });

  it('validateArrangementName - component.ispaymentArrangementNameValid should be true', () => {
    component.arrangement.paymentArrangementName = '';
    component.validateArrangementName();
    expect(component.ispaymentArrangementNameValid).toBeTruthy();
  });

  it('validateArrangementName - component.ispaymentArrangementNameValid should be false', () => {
    component.arrangement.paymentArrangementName = 'a';
    component.validateArrangementName();
    expect(component.ispaymentArrangementNameValid).toBeFalsy();
  });

  it('validateArrangementName - component.isArrangementNameError  should be false', () => {
    component.arrangement.paymentArrangementName = '#$%$%';
    component.validateArrangementName();
    expect(component.isArrangementNameError).toBeTruthy();
  });

  it('validateArrangementName - component.isArrangementNameError should be false', () => {
    component.arrangement.paymentArrangementName = 'a';
    component.validateArrangementName();
    expect(component.isArrangementNameError).toBeFalsy();
  });

  it('arrangementOnSuccess - existingArrangement should be arrangement.paymentArrangementName', () => {
    spyOn(component.sharedService, 'handleErrorSuccessWarningInfo');
    component.arrangementOnSuccess(arrangementData);
    expect(component.arrangement.recordEffectiveDate).toEqual({ year: 2019, month: 11, day: 1 });
  });

  it('arrangementOnSuccess - populateRetrievedLOB should have been called', () => {
    spyOn(component.sharedService, 'handleErrorSuccessWarningInfo');
    spyOn(component, 'populateRetrievedLOB');
    arrangementData.paymentArrangement.paymentArrangementMemberSubjects.length = 1;
    component.arrangementOnSuccess(arrangementData);
    expect(component.populateRetrievedLOB).toHaveBeenCalled();
  });

  it('validateRates - setErrorMessage should have been called', () => {
    spyOn(component, 'setErrorMessage');
    component.arrangement.paymentArrangementRates[0].recordEffectiveDate = '12/56t/5643';
    component.validateRates();
    expect(component.setErrorMessage).toHaveBeenCalled();
  });



  it('disableSave - return true', () => {
    component.arrangement.paymentArrangementName = '$$%';
    const enableDisable = component.disableSave();
    expect(enableDisable).toBeTruthy();
  });

  it('disableSave - return true', () => {
    component.arrangement.paymentArrangementName = 'name';
    component.arrangement.paymentArrangementDescription = '';
    const enableDisable = component.disableSave();
    expect(enableDisable).toBeTruthy();
  });

  it('disableSave - return true', () => {
    component.arrangement.paymentArrangementName = 'name';
    component.arrangement.paymentArrangementDescription = 'desc';
    component.arrangement.recordEffectiveDate = '12/34/3214';
    const enableDisable = component.disableSave();
    expect(enableDisable).toBeTruthy();
  });


  it('disableSave - return true', () => {
    component.arrangement.paymentArrangementName = 'name';
    component.arrangement.paymentArrangementDescription = 'desc';
    component.arrangement.recordEffectiveDate = { year: 2017, month: 7, day: 1 };
    component.arrangement.recordEndDate = '12/34/5465467';
    const enableDisable = component.disableSave();
    expect(enableDisable).toBeTruthy();
  });

  it('open - getRates should be called', () => {
    spyOn(component, 'getRates');
    component.open('add-rates-step1');
    expect(component.getRates).toHaveBeenCalled();
  });

  it('resetEdit- component.isEditEndDateError should be false', () => {
    component.resetEdit('edit-arrangement-payee');
    expect(component.isEditEndDateError).toBeFalsy();
  });

  it('resetEdit- component.editPayeeFormValues.reset should have been called', () => {
    spyOn(component, 'editPayeeFormValues');
    component.resetEdit('edit');
    expect(component.editPayeeFormValues.reset).toHaveBeenCalled();
  });

  it('saveEditArrangPayee - ', () => {
    component.editPayeeArrangDates = {
      arrangPayeeEffectiveDate: { year: 2020, month: 6, day: 1 },
      arrangPayeeEndDate: { year: 2002, month: 11, day: 30 }
    };
    component.arrangement = arrangementData.paymentArrangement;
    component.selectectPayee = 0;
    component.saveEditArrangPayee();
    expect(component.arrangement.paymentArrangementPayees[0].recordEffectiveDate).toEqual('06/01/2020');
  });

  it('saveEditArrangPayee - ', () => {
    component.editPayeeArrangDates = {
      arrangPayeeEffectiveDate: { year: 2020, month: 6, day: 1 },
      arrangPayeeEndDate: { year: 2002, month: 11, day: 30 }
    };
    component.arrangement = arrangementData.paymentArrangement;
    component.selectectPayee = 0;
    component.saveEditArrangPayee();
    expect(component.arrangement.paymentArrangementPayees[0].createUserId).toEqual('U402537');
  });

  it('saveEdit - component.validateArrangementPayee should be called', () => {
    spyOn(component, 'validateArrangementPayee');
    component.saveEdit('edit-arrangement-payee');
    expect(component.validateArrangementPayee).toHaveBeenCalled();
  });
  it('saveEdit - component.modalService.close should be called', () => {
    spyOn(component.modalService, 'close');
    component.saveEdit('edit');
    expect(component.modalService.close).toHaveBeenCalled();
  });

  it('generateArrangementPayeeObj - paymentArrangementPayeeReq should equal to data', () => {
    component.editPayeeArrangDates = {
      arrangPayeeEffectiveDate: { year: 2020, month: 6, day: 1 },
      arrangPayeeEndDate: { year: 2020, month: 11, day: 30 }
    };
    const data = {
      validateArrangementPayee: {
        recordEffectiveDate: '06/01/2020',
        recordEndDate: '11/30/2020',
        createUserId: component.userCacheService.getUserCacheData('USER_ID'),
        updateUserId: component.userCacheService.getUserCacheData('USER_ID'),
        rowAction: 'NO_ACTION',
        paymentArrangementPayeeId: 1493,
        vbrPayee: {
          createUserId: 'U402537',
          updateUserId: 'U402537',
          createRecordTimestamp: '2019-09-25T10:27:05.22',
          updateRecordTimestamp: '2019-09-27T06:32:30.045',
          rowAction: 'NO_ACTION',
          recordEffectiveDate: '01/01/2020',
          recordEndDate: '12/31/2020',
          vbrPayeeId: 44,
          corporateEntityCode: 'NM ',
          pinGroupId: 'BSR       ',
          pinGroupName: 'BSR011',
          capitationProcessCode: 'CP',
          networkCode: 'MCD',
          taxIdNumber: '999999999',
          capitationCode: 'A1',
          payToPfinId: '00NMCAP010',
          networkAssocProviderId: '772129111'
        },

      }
    };
    component.selectectPayee = 0;
    const value = component.generateArrangementPayeeObj();
    expect(value.validateArrangementPayee.paymentArrangementPayeeId).toEqual(data.validateArrangementPayee.paymentArrangementPayeeId);
  });

  it('validateArrangementPayee - ', () => {
    spyOn(component.loadingService, 'show');
    component.selectectPayee = 0;
    component.validateArrangementPayee('edit-arrangement-payee');
    expect(component.loadingService.show).toHaveBeenCalled();
  });

  it('searchProvider - if payeetype = vbr, searchExisitingPayeeRecords should have been called', () => {
    component.selectVbrPayee = '';
    component.payeeArrangementSearch.payeeType = 'vbr';
    component.searchProvider('string');
    expect(component.selectVbrPayee).toEqual('');
  });

  it('searchProvider - if payeetype !== vbr, retrieveProviderRecords should have been called', () => {
    spyOn(component, 'retrieveProviderRecords');
    component.payeeArrangementSearch.payeeType = 're';
    component.searchProvider('string');
    expect(component.retrieveProviderRecords).toHaveBeenCalled();
  });

  it('retrieveProviderRecords - component.loadingService.show should have been called', () => {
    spyOn(component.loadingService, 'show');
    component.retrieveProviderRecords({ reqParam: 'data' });
    expect(component.loadingService.show).toHaveBeenCalled();
  });

  it('getRates - component.loadingService.show should be called', () => {
    spyOn(component.loadingService, 'show');
    component.getRates('string');
    expect(component.loadingService.show).toHaveBeenCalled();
  });

  it('handleErrorResponse - component.isNoRecordsDisplay should be true', () => {
    const error = { 'errors': [{ 'errorMessageId': 10000, 'errorMsgDescriptionText': 'Data could not be saved to the table. Please try again.', 'severitylevel': 'E', 'errorMessageCategoryCode': 'ERR' }] };
    component.handleErrorResponse(error);
    expect(component.isNoRecordsDisplay).toBeTruthy();
  });

  it('providerSearchResult - component.modelPopUpOpenClose should be called', () => {
    spyOn(component, 'modelPopUpOpenClose');
    component.providerSearchResult();
    expect(component.modelPopUpOpenClose).toHaveBeenCalled();
  });


  it('navigateToAddVBRDates - if id is edit-payee, then componnet.errorPremierCheck should be false', () => {
    spyOn(component.modalService, 'close');
    component.navigateToAddVBRDates('edit-payee');
    expect(component.errorPremierCheck).toBeFalsy();
  });

  it('selectProvider - if payeeType = premier, then component.setErrorMessage should be called', () => {
    spyOn(component.loadingService, 'show');
    component.selectProvider({ data: 'edit' }, 'premier');
    expect(component.loadingService.show).toHaveBeenCalled();
  });

  it('selectProvider - if payeeType !== premier, then component.modelVbr should be true', () => {
    component.selectProvider({ data: 'edit' }, 'data');
    expect(component.modelvbr).toBeTruthy();
  });

  it('modelPopUpOpenClose - modalService.close should have been called', () => {
    spyOn(component.modalService, 'close');
    component.modelPopUpOpenClose('edi-payee', '');
    expect(component.modalService.close).toHaveBeenCalled();
  });

  it('modelPopUpOpenClose - modalService.open should have been called', () => {
    spyOn(component.modalService, 'open');
    component.modelPopUpOpenClose('', 'edit-payee');
    expect(component.modalService.open).toHaveBeenCalled();
  });

  it('cancelStep1 - modalService.close should have been called', () => {
    spyOn(component.modalService, 'close');
    component.cancelStep1('string');
    expect(component.modalService.close).toHaveBeenCalled();
  });

  it('cancelStep2 - modalService.close should have been called', () => {
    spyOn(component.modalService, 'close');
    component.cancelStep2('string');
    expect(component.isNoRecordsDisplay).toBeFalsy();
  });


  it('modifySearch - component.modelvber should be false ', () => {
    spyOn(component.modalService, 'close');
    spyOn(component.modalService, 'open');
    component.modifySearch('edit-payee');
    expect(component.modelvbr).toBeFalsy();
  });

  it('newSearch - modalService.open should have been called', () => {
    spyOn(component.modalService, 'close');
    spyOn(component.modalService, 'open');
    component.newSearch('string');
    expect(component.modalService.open).toHaveBeenCalled();
  });

  it('cancelStep3 - component.modalService.close should have been called', () => {
    spyOn(component.modalService, 'close');
    component.cancelStep3('string');
    expect(component.modalService.close).toHaveBeenCalled();
  });

  it('addArrangementPayee - component.vbrPayeeEffDate should be equla to component.providerInfo.vbrEffDate', () => {
    spyOn(component, 'validatePayeeRecord');
    component.addPayeeVBRDates = {
      VBRPayeeEffectiveDate: '',
      VBRPayeeEndDate: '11/30/2020'
    };
    component.addArrangementPayee();
    expect(component.vbrPayeeEffDate).toEqual(component.providerInfo.vbrEffDate);
  });

  it('addArrangementPayee - component.vbrPayeeEndDate should be equla to component.providerInfo.vbrEndDate', () => {
    spyOn(component, 'validatePayeeRecord');
    component.addPayeeVBRDates = {
      VBRPayeeEffectiveDate: '06/01/2020',
      VBRPayeeEndDate: ''
    };
    component.addArrangementPayee();
    expect(component.vbrPayeeEndDate).toEqual(component.providerInfo.vbrEndDate);
  });

  it('saveProvider - component.addArrangementPayee should be have been called', () => {
    spyOn(component, 'validatePayeeRecord');
    component.addPayeeVBRDates = {
      VBRPayeeEffectiveDate: '06/01/2020',
      VBRPayeeEndDate: '11/30/2020'
    };
    component.selectVbrPayee = 'vbr_payee_1';
    component.saveProvider('id', 'string');
    expect(component.validatePayeeRecord).toHaveBeenCalled();
  });

  it('ValidatePayeeRecord - component.loadingService.show should have been called', () => {
    spyOn(component.loadingService, 'show');
    const request = {
      reqParam: {
        vbrPayee: {
          data: 'data'
        }
      }
    };
    component.validatePayeeRecord(request, 'id', 'vbr');
    expect(component.loadingService.show).toHaveBeenCalled();
  });

  it('formatRateDate - component.arrangement.paymentArrangementRates[0] should be equal to 11/01/2019', () => {
    component.arrangement = arrangementData.paymentArrangement;
    component.arrangement.paymentArrangementRates[0].recordEffectiveDate = { year: 2019, month: 11, day: 1 };
    component.formatRateDate('format');
    expect(component.arrangement.paymentArrangementRates[0].recordEffectiveDate).toEqual('11/01/2019');
  });

  it('formatRateDate - component.arrangement.paymentArrangementRates[0] should be equal to {year:2019, month:11, day:1}', () => {
    component.arrangement.paymentArrangementRates[0].recordEffectiveDate = '11/01/2019';
    component.formatRateDate('update');
    expect(component.arrangement.paymentArrangementRates[0].recordEffectiveDate).toEqual({ year: 2019, month: 11, day: 1 });
  });

  it('saveArrangementRecord - component.updatePaymentArrangementRatesAction should have been called', () => {
    component.arrangement.paymentArrangementName = 'ERR';
    component.arrangement.paymentArrangementDescription = 'data';
    spyOn(component, 'updatePaymentArrangementRatesAction');
    component.saveArrangementRecord('save');
    expect(component.updatePaymentArrangementRatesAction).toHaveBeenCalled();
  });

  it('saveArrangementRecord - value is no - component.formatRateDate should be called', () => {
    spyOn(component, 'formatRateDate');
    component.saveArrangementRecord('no');
    expect(component.formatRateDate).toHaveBeenCalled();
  });

  it('saveArrangementRecord - value is update - component.formatRateDate should be called', () => {
    component.saveArrangementRecord('update');
    expect(component.arrangement.overwriteCancelArrangement).toBeFalsy();
  });


  it('updatePaymentArrangementRatesAction - component.paymentArrangementRates[0].rowAction should be update', () => {
    component.arrangement.paymentArrangementRates[0].recordEffectiveDate = '12/09/2019';
    component.arrangement.paymentArrangementRates[0].recordEndDate = '12/11/2019';
    component.updatePaymentArrangementRatesAction();
    expect(component.arrangement.paymentArrangementRates[0].rowAction).toEqual('UPDATE');
  });

  it('updatePaymentArrangmentPayeesAction - component.arrangement.paymentArrangementPayees[0].rowAction should be update', () => {
    component.arrangement.paymentArrangementPayees[0].recordEffectiveDate = '12/09/2019';
    component.arrangement.paymentArrangementPayees[0].recordEndDate = '12/11/2019';
    component.updatePaymentArrangmentPayeesAction();
    expect(component.arrangement.paymentArrangementPayees[0].rowAction).toEqual('UPDATE');
  });

  it('validateVBRDate - component.setErrorMesage should have been called', () => {
    spyOn(component, 'setErrorMessage');
    const date: any = { year: 2020, month: 6, day: 1 };
    component.validateVBRDate(date, 'errorId');
    expect(component.setErrorMessage).toHaveBeenCalled();
  });

  it('validateVBRDate - component.setErrorMesage should have been called', () => {
    spyOn(component, 'setErrorMessage');
    const date = '12/01/2020';
    component.validateVBRDate(date, 'errorId');
    expect(component.setErrorMessage).toHaveBeenCalled();
  });

  it('validatePaymentArrangementDescription - component.isArrangementPaymentDescriptionValid should be false', () => {
    component.arrangement.paymentArrangementDescription = 'data    ';
    component.validatePaymentArrangementDescription();
    expect(component.isArrangementPaymentDescriptionValid).toBeFalsy();
  });

  it('validatePaymentArrangementDescription - component.isArrangementPaymentDescriptionValid should be true', () => {
    component.arrangement.paymentArrangementDescription = '';
    component.validatePaymentArrangementDescription();
    expect(component.isArrangementPaymentDescriptionValid).toBeTruthy();
  });

  it('setFrequency - isCheckedFrequencyMonth should be true if frequency is month', () => {
    component.setFrequency('month');
    expect(component.isCheckedFrequencyMonth).toBeTruthy();
  });

  it('setFrequency - isCheckedFrequencyMonth should be false if frequency is date', () => {
    component.setFrequency('date');
    expect(component.isCheckedFrequencyMonth).toBeFalsy();
  });

  it('cancelArrangement - component.router.navigateByUrl is called', () => {
    spyOn(component.router, 'navigateByUrl');
    component.cancelArrangement();
    expect(component.router.navigateByUrl).toHaveBeenCalled();
  });

  it('checkForLineOfBusiness - if lineOfBusinessCheck is true, component.populateMemberSubjectForSave should have been called', () => {
    component.contractLOBCheck = true;
    spyOn(component, 'populateMemberSubjectForSave');
    component.checkForContractsAndLOB();
    expect(component.populateMemberSubjectForSave).toHaveBeenCalled();
  });

  it('checkForContractsAndLOB - contractLOBAction  should be NO_ACTION', () => {
    component.contractsAdded = [{
      codeValueText: 'H3251',
      codeValueDescription: 'H3251',
      corporateEntityCode: 'NM1',
      codeSetName: 'MEMCONTRID',
      codeSetDescription: 'Member Contract Id'
    }];
    component.lineOfBusinessAdded = [{
      codeSetDescription: 'Line of Business',
      codeSetName: 'LOB',
      codeValueDescription: 'Medicare Advantage Membership Cohort',
      codeValueText: 'MAPD',
      corporateEntityCode: 'NM1'
    }];
    component.checkForContractsAndLOB();
    expect(component.contractLOBAction).toEqual('NO_ACTION');
  });

  it('checkForContractsAndLOB - contractLOBAction  should be NO_ACTION', () => {
    component.contractLOBs = [{
      cid: 'H3252',
      cidCode: 'H3252',
      lname: 'Medicare Advantage Membership Cohort',
      lnameCode: 'MAPD',
      corporateEntityCode: 'NM1'
    }];
    component.checkForContractsAndLOB();
    expect(component.contractLOBAction).toEqual('UPDATE');
  });

  it('populateRetrievedLOB - membersubjectPresent  should be true', () => {
    component.populateRetrievedLOB(arrangementData.paymentArrangement.paymentArrangementMemberSubjects);
    expect(component.membersubjectPresent).toBeTruthy();
  });

  it('populateMemberSubjectForSave  data should be equal to value', () => {
    const data = [{
      'createUserId': 'U402537',
      'updateUserId': 'U402537',
      'createRecordTimestamp': '2019-11-25T09:06:25.325',
      'updateRecordTimestamp': '2019-11-25T09:06:25.326',
      'rowAction': 'NO_ACTION',
      'paymentArrangementMemberSubjectId': 1656,
      'planStateCode': null,
      'productTypeCode': null,
      'benefitPlanStateCode': null,
      'actionCode': null,
      'benefitPlanNumber': null,
      'lineOfBusinessCode': 'MAPD',
      'accountnumber': null,
      'groupId': null,
      'sectionNumber': null,
      'copayCode': null,
      'captitationEntityCode': null,
      'siteId': null,
      'benefitArrangementNumber': null,
      'memberLocationId': null,
      'networkRiskLevelCode': null,
      'paymentArrangementId': 1959,
      'corporateEntityCode': 'NM1',
      'fundingTypeCode': null,
      'contractId': 'H3251'
    }];
    component.populateMemberSubjectForSave();
    expect(component.arrangement.paymentArrangementMemberSubjects).toEqual(data);
  });
  it('addAllContractsAndLOB - removedLineOfBusiness should be equal to []', () => {
    component.lineOfBusinessToAdd = ['member', 'lop'];
    component.addAllContractsAndLOB();
    expect(component.clearContractLobsAdded).toEqual([]);
  });

  it('onCurrentRowChange - component.currentRows should equal to 3', () => {
    component.onCurrentRowChange(3);
    expect(component.currentRows).toEqual(3);
  });

  it('selectRate -component.isDisableRateNxtBtn should be false', () => {
    const rate = {
      createUserId: 'U1',
      updateUserId: 'U2',
      rowAction: 'NO_ACTION',
      recordEffectiveDate: '06/01/2019',
      recordEndDate: '11/30/2019',
      paymentArrangementRateId: 475,
      rateName: 'RATE1',
      corporateEntityCode: 'NM ',
      rateConfigTypeName: null,
      paymentArrangementId: 507
    };
    component.selectRate(rate);
    expect(component.isDisableRateNxtBtn).toBeFalsy();
  });

  it('assignRateDates - component.initializeRateObject should have been called', () => {
    spyOn(component.modalService, 'close');
    spyOn(component, 'initializeRateObject');
    component.assignRateDates('id');
    expect(component.initializeRateObject).toHaveBeenCalled();
  });

  it('getRateDetailsByRateName - component.loadingService.show should have been called', () => {
    spyOn(component.loadingService, 'show');
    component.getRateDetailsByRateName();
    expect(component.loadingService.show).toHaveBeenCalled();
  });

  it('initializeRateObject- data should be equal to component.paymentArrangementRAte', () => {
    const data = {
      paymentArrangementRateId: null,
      rateName: '',
      rateConfigTypeName: '',
      paymentArrangementId: null,
      corporateEntityCode: '',
      recordEffectiveDate: '',
      recordEndDate: '',
      createUserId: component.userCacheService.getUserCacheData('USER_ID'),
      updateUserId: component.userCacheService.getUserCacheData('USER_ID'),
      rowAction: 'INSERT'
    };
    component.initializeRateObject();
    expect(component.paymentArrangementRate).toEqual(data);
  });



  it('validateArrangementRate - component.loadingService.show should be called', () => {
    spyOn(component.loadingService, 'show');
    component.paymentArrangementRate.recordEffectiveDate = { year: 2019, month: 7, day: 1 };
    component.paymentArrangementRate.recordEndDate = { year: 2019, month: 7, day: 31 };
    component.validateArrangementRate('id');
    expect(component.loadingService.show).toHaveBeenCalled();
  });

  it('saveRate- component.modalService.close should have been called', () => {
    spyOn(component.modalService, 'close');
    component.saveRate('id');
    expect(component.modalService.close).toHaveBeenCalled();
  });

  it('viewRates - component.checkAndRemoveToast should have been called', () => {
    spyOn(component, 'checkAndRemoveToast');
    component.viewRates('1QQA1', 'id');
    expect(component.checkAndRemoveToast).toHaveBeenCalled();
  });

  it('editRates - component.modalService.open should have been called', () => {
    spyOn(component.modalService, 'open');
    component.editRates('1QQA1', 'id');
    expect(component.modalService.open).toHaveBeenCalled();
  });

  it('setUpperCase - component.arrangement.paymentArrangementName should be "ARRNAME"', () => {
    component.arrangement.paymentArrangementName = 'arrname';
    component.setUpperCase();
    expect(component.arrangement.paymentArrangementName).toEqual('ARRNAME');
  });

  it('setUpperCase - component.payeeArrangementSearch.pinGroupId  should be "RE1"', () => {
    component.payeeArrangementSearch.pinGroupId = 're1';
    component.setUpperCase();
    expect(component.payeeArrangementSearch.pinGroupId).toEqual('RE1');
  });

  it('validateRates - arrangement.validateDate should have been called', () => {
    spyOn(component, 'validateDate');
    component.validateRates();
    expect(component.validateDate).toHaveBeenCalled();
  });

  it('outlinedError - paymentArrangementPayeeEffectiveAndEndDate', () => {
    const warnings = [
      {
        'componentName': 'paymentArrangement',
        'fieldId': 'paymentArrangementPayeeEffectiveAndEndDate',
        'errorMessageId': 46,
        'errorMsgDescriptionText': 'Arrangement payee dates must be within VBR payee dates',
        'severitylevel': 'W',
        'errorMessageCategoryCode': 'PCF-PMAM',
        'validationClass': 'PMAM015CheckArrangementPayeeDurationWithVbrPayee'
      }
    ];
    component.outlinedError(warnings);
    expect(component.isEffDateEndDate).toBeTruthy();
  });

  it('saveDefaultSetting - component.retroactivityCheck should be true', () => {
    spyOn(component.modalService, 'close');
    component.marked = true;
    component.saveDefaultSetting('save');
    expect(component.retroactivityCheck).toBeTruthy();
  });

  it('removeAllContractsAndLOB - should return', () => {
    component.lineOfBusinessAdded = [];
    component.contractsAdded = [];
  });

  it('arrangemntStatus - component.isSaveArrangementError to be false', () => {
    const error = [
      {
        errorId: '275',
        errorMsgDescriptionText: 'error'
      }
    ];
    component.arrangemntStatus(error);
    expect(component.isArrangementNameError).toBeFalsy();
  });

  it('openConfirmModal - component.checkAndRemoveToast should have been called', () => {
    spyOn(component, 'checkAndRemoveToast');
    component.openConfirmModal(true, 'id');
    expect(component.checkAndRemoveToast).toHaveBeenCalled();
  });

  it('clearContractLobsAdded - component.clearDragDropSections should have been called', () => {
    spyOn(component, 'clearDragDropSections');
    component.membersubjectPresent = false;
    component.clearContractLobsAdded();
    expect(component.clearDragDropSections).toHaveBeenCalled();
  });
  it('outlinedError - paymentArrangementEffectiveDate', () => {
    const warnings = [
      {
        'componentName': 'paymentArrangement',
        'fieldId': 'paymentArrangementEffectiveDate',
        'errorMessageId': 46,
        'errorMsgDescriptionText': 'Arrangement payee dates must be within VBR payee dates',
        'severitylevel': 'W',
        'errorMessageCategoryCode': 'PCF-PMAM',
        'validationClass': 'PMAM015CheckArrangementPayeeDurationWithVbrPayee'
      }
    ];
    component.outlinedError(warnings);
    expect(component.isEffDate).toBeTruthy();
  });

  it('outlinedError - paymentArrangementEndDate', () => {
    const warnings = [
      {
        'componentName': 'paymentArrangement',
        'fieldId': 'paymentArrangementEndDate',
        'errorMessageId': 46,
        'errorMsgDescriptionText': 'Arrangement payee dates must be within VBR payee dates',
        'severitylevel': 'W',
        'errorMessageCategoryCode': 'PCF-PMAM',
        'validationClass': 'PMAM015CheckArrangementPayeeDurationWithVbrPayee'
      }
    ];
    component.outlinedError(warnings);
    expect(component.isEndDate).toBeTruthy();
  });

  it('outlinedError - paymentArrangementEffectiveAndEndDate', () => {
    const warnings = [
      {
        'componentName': 'paymentArrangement',
        'fieldId': 'paymentArrangementEffectiveAndEndDate',
        'errorMessageId': 46,
        'errorMsgDescriptionText': 'Arrangement payee dates must be within VBR payee dates',
        'severitylevel': 'W',
        'errorMessageCategoryCode': 'PCF-PMAM',
        'validationClass': 'PMAM015CheckArrangementPayeeDurationWithVbrPayee'
      }
    ];
    component.outlinedError(warnings);
    expect(component.isdurationEffDateEndDate).toBeTruthy();
  });

  it('outlinedError - paymentArrangementPaymentType', () => {
    const warnings = [
      {
        'componentName': 'paymentArrangement',
        'fieldId': 'paymentArrangementPaymentType',
        'errorMessageId': 46,
        'errorMsgDescriptionText': 'Arrangement payee dates must be within VBR payee dates',
        'severitylevel': 'W',
        'errorMessageCategoryCode': 'PCF-PMAM',
        'validationClass': 'PMAM015CheckArrangementPayeeDurationWithVbrPayee'
      }
    ];
    component.outlinedError(warnings);
    expect(component.isPaymtOutlinedError).toBeTruthy();
  });

  it('outlinedError - paymentArrangementFrequencyCode', () => {
    const warnings = [
      {
        'componentName': 'paymentArrangement',
        'fieldId': 'paymentArrangementFrequencyCode',
        'errorMessageId': 46,
        'errorMsgDescriptionText': 'Arrangement payee dates must be within VBR payee dates',
        'severitylevel': 'W',
        'errorMessageCategoryCode': 'PCF-PMAM',
        'validationClass': 'PMAM015CheckArrangementPayeeDurationWithVbrPayee'
      }
    ];
    component.outlinedError(warnings);
    expect(component.isFrequencyOutlinedError).toBeTruthy();
  });

  it('outlinedError - paymentArrangementDescription', () => {
    const warnings = [
      {
        'componentName': 'paymentArrangement',
        'fieldId': 'paymentArrangementDescription',
        'errorMessageId': 46,
        'errorMsgDescriptionText': 'Arrangement payee dates must be within VBR payee dates',
        'severitylevel': 'W',
        'errorMessageCategoryCode': 'PCF-PMAM',
        'validationClass': 'PMAM015CheckArrangementPayeeDurationWithVbrPayee'
      }
    ];
    component.outlinedError(warnings);
    expect(component.isDescOutlinedError).toBeTruthy();
  });

  it('outlinedError - paymentArrangementName', () => {
    const warnings = [
      {
        'componentName': 'paymentArrangement',
        'fieldId': 'paymentArrangementName',
        'errorMessageId': 46,
        'errorMsgDescriptionText': 'Arrangement payee dates must be within VBR payee dates',
        'severitylevel': 'W',
        'errorMessageCategoryCode': 'PCF-PMAM',
        'validationClass': 'PMAM015CheckArrangementPayeeDurationWithVbrPayee'
      }
    ];
    component.outlinedError(warnings);
    expect(component.isNameOutlinedError).toBeTruthy();
  });

  it('outlinedError - paymentArrangementMemberSubject', () => {
    const warnings = [
      {
        'componentName': 'paymentArrangement',
        'fieldId': 'paymentArrangementMemberSubject',
        'errorMessageId': 46,
        'errorMsgDescriptionText': 'Arrangement payee dates must be within VBR payee dates',
        'severitylevel': 'W',
        'errorMessageCategoryCode': 'PCF-PMAM',
        'validationClass': 'PMAM015CheckArrangementPayeeDurationWithVbrPayee'
      }
    ];
    component.outlinedError(warnings);
    expect(component.isSubOutlinedError).toBeTruthy();
  });

  it('outlinedError - paymentArrangementPayee', () => {
    const warnings = [
      {
        'componentName': 'paymentArrangement',
        'fieldId': 'paymentArrangementPayee',
        'errorMessageId': 46,
        'errorMsgDescriptionText': 'Arrangement payee dates must be within VBR payee dates',
        'severitylevel': 'W',
        'errorMessageCategoryCode': 'PCF-PMAM',
        'validationClass': 'PMAM015CheckArrangementPayeeDurationWithVbrPayee'
      }
    ];
    component.outlinedError(warnings);
    expect(component.isPayeeOutlinedError).toBeTruthy();
  });

  it('outlinedError - paymentArrangementRate', () => {
    const warnings = [
      {
        'componentName': 'paymentArrangement',
        'fieldId': 'paymentArrangementRate',
        'errorMessageId': 46,
        'errorMsgDescriptionText': 'Arrangement payee dates must be within VBR payee dates',
        'severitylevel': 'W',
        'errorMessageCategoryCode': 'PCF-PMAM',
        'validationClass': 'PMAM015CheckArrangementPayeeDurationWithVbrPayee'
      }
    ];
    component.outlinedError(warnings);
    expect(component.isRateOutlinedError).toBeTruthy();
  });

  it('saveDefaultSetting - component.retroactivityCheck should be true', () => {
    spyOn(component.modalService, 'close');
    component.marked = true;
    component.saveDefaultSetting('save');
    expect(component.retroactivityCheck).toBeTruthy();
  });

  it('saveDefaultSetting - component.retroactivityCheck should be false', () => {
    spyOn(component.modalService, 'close');
    component.marked = false;
    component.saveDefaultSetting('save');
    expect(component.retroactivityCheck).toBeFalsy();
  });

  it('removeAllContractsAndLOB - should return', () => {
    component.lineOfBusinessAdded = [];
    component.contractsAdded = [];
  });

  it('arrangemntStatus - component.isSaveArrangementError to be false', () => {
    const error = [
      {
        errorMessageId: '275',
        errorMsgDescriptionText: 'error'
      }
    ];
    component.arrangemntStatus(error);
    expect(component.isArrangementNameError).toBeFalsy();
  });

  it('openConfirmModal - component.checkAndRemoveToast should have been called', () => {
    spyOn(component, 'checkAndRemoveToast');
    component.openConfirmModal(true, 'id');
    expect(component.checkAndRemoveToast).toHaveBeenCalled();
  });

  it('clearContractLobsAdded - component.clearDragDropSections should have been called', () => {
    spyOn(component, 'clearDragDropSections');
    component.membersubjectPresent = false;
    component.clearContractLobsAdded();
    expect(component.clearDragDropSections).toHaveBeenCalled();
  });

  it('clearContractLobsAdded - component.setDragDropEditState should have been called', () => {
    spyOn(component, 'setDragDropEditState');
    component.membersubjectPresent = true;
    component.clearContractLobsAdded();
    expect(component.setDragDropEditState).toHaveBeenCalled();
  });

  it('clearDragDropSections - component.contractsAdded should equal []', () => {
    spyOn(component, 'clearDragDropSections');
    component.clearDragDropSections();
    expect(component.contractsAdded).toEqual([]);
  });

  it('ngAfterContentChecked - arrangementCheck should be false', () => {
    component.ngAfterContentChecked();
    expect(component.arrangementCheck).toBeFalsy();
  });

  it('ngAfterContentChecked - arrangementCheck should be true;', () => {
    component.arrangement = arrangementData.paymentArrangement;
    component.ngAfterContentChecked();
    expect(component.arrangementCheck).toBeTruthy();
  });

  it('arrangementOnSuccess - componenet.sharedService.handleWarnings should have been called', () => {
    spyOn(component.sharedService, 'handleWarnings');
    component.arrangementOnSuccess(arrangementData);
    expect(component.sharedService.handleWarnings).toHaveBeenCalled();
  });

  it('setErrorMessage - component.isRateEffDateError should be false', () => {
    spyOn(component.sharedService, 'handleWarnings');
    component.arrangementOnSuccess(arrangementData);
    expect(component.sharedService.handleWarnings).toHaveBeenCalled();
  });

  it('arrangementOnSuccess - componenet.sharedService.handleWarnings should have been called', () => {
    spyOn(component.sharedService, 'handleWarnings');
    spyOn(component, 'getPaymentTypeDescription');
    component.arrangementOnSuccess(arrangementData);
    expect(component.getPaymentTypeDescription).toHaveBeenCalled();
  });

  it('setErrorMessage - component.isRateEffDateError should be false', () => {
    component.setErrorMessage('isRateEffDateError', false);
    expect(component.isRateEffDateError).toBeFalsy();
  });

  it('setErrorMessage - component.isRateEndDateError should be false', () => {
    component.setErrorMessage('isRateEndDateError', false);
    expect(component.isRateEndDateError).toBeFalsy();
  });

  it('setErrorMessage - component.isDurationEffDateError should be false', () => {
    component.setErrorMessage('isDurationEffDateError', false);
    expect(component.isDurationEffDateError).toBeFalsy();
  });

  it('setErrorMessage - component.isDurationEndDateError should be false', () => {
    component.setErrorMessage('isDurationEndDateError', false);
    expect(component.isDurationEndDateError).toBeFalsy();
  });

  it('getcodeValue - loadingService.show should have been called', () => {
    spyOn(component.loadingService, 'show');
    component.getcodeValue('UNIQUE');
    expect(component.loadingService.show).toHaveBeenCalled();
  });

  it('isArrangementDataChanged - rowAction should be NO_ACTION', () => {
    component.arrangement.paymentArrangementName = 'ARRANGEMENT0103';
    component.arrangement.paymentArrangementDescription = 'THIS IS AN ARRANGEMENT CREATED TsdHROUGH REGRESSION SUITEfsdfDSFSDFqqaaa1111111';
    component.arrangement.arrangementFrequencyCode = 'MONT';
    component.arrangement.paymentArrangementTypeCode = 'UNIQUE';
    component.arrangement.recordEffectiveDate = { year: 2019, month: 11, day: 1 };
    component.arrangement.recordEndDate = { year: 2019, month: 12, day: 31 };
    const data = component.isArrangementDataChanged();
    expect(data).toEqual('NO_ACTION');
  });

  it('removeAllContractsAndLOB - component.lineOfBusinessToAdd equal component.lineOfBusinessAdded', () => {
    component.contractsAdded = [{
      codeValueText: 'H3251',
      codeValueDescription: 'H3251',
      corporateEntityCode: 'NM1',
      codeSetName: 'MEMCONTRID',
      codeSetDescription: 'Member Contract Id'
    }];
    component.lineOfBusinessAdded = [{
      codeSetDescription: 'Line of Business',
      codeSetName: 'LOB',
      codeValueDescription: 'Medicare Advantage Membership Cohort',
      codeValueText: 'MAPD',
      corporateEntityCode: 'NM1'
    }];
    component.removeAllContractsAndLOB();
    expect(component.lineOfBusinessToAdd).toEqual([{
      codeSetDescription: 'Line of Business',
      codeSetName: 'LOB',
      codeValueDescription: 'Medicare Advantage Membership Cohort',
      codeValueText: 'MAPD',
      corporateEntityCode: 'NM1'
    }]);
  });

  it('removeAllContractsAndLOB - component.contractsToAdd equal component.contractsAdded', () => {
    component.contractsAdded = [{
      codeValueText: 'H3251',
      codeValueDescription: 'H3251',
      corporateEntityCode: 'NM1',
      codeSetName: 'MEMCONTRID',
      codeSetDescription: 'Member Contract Id'
    }];
    component.lineOfBusinessAdded = [{
      codeSetDescription: 'Line of Business',
      codeSetName: 'LOB',
      codeValueDescription: 'Medicare Advantage Membership Cohort',
      codeValueText: 'MAPD',
      corporateEntityCode: 'NM1'
    }];
    component.removeAllContractsAndLOB();
    expect(component.contractsToAdd).toEqual([{
      codeValueText: 'H3251',
      codeValueDescription: 'H3251',
      corporateEntityCode: 'NM1',
      codeSetName: 'MEMCONTRID',
      codeSetDescription: 'Member Contract Id'
    }]);
  });

  it('addLineOfBusiness - component.addLineOfBusiness', () => {
    component.addLineOfBusiness({
      codeSetDescription: 'Line of Business',
      codeSetName: 'LOB',
      codeValueDescription: 'Medicare Advantage Membership Cohort',
      codeValueText: 'MAPD',
      corporateEntityCode: 'NM1'
    }, 'click', component.lineOfBusinessToAdd);

    expect(component.lineOfBusinessToAdd).toEqual([{
      codeSetDescription: 'Line of Business',
      codeSetName: 'LOB',
      codeValueDescription: 'Medicare Advantage Membership Cohort',
      codeValueText: 'MAPD',
      corporateEntityCode: 'NM1'
    }]);
  });

  it('addContracts - component.contractsToAdd to equal component.contractsAdded', () => {
    component.addContracts({
      codeValueText: 'H3251',
      codeValueDescription: 'H3251',
      corporateEntityCode: 'NM1',
      codeSetName: 'MEMCONTRID',
      codeSetDescription: 'Member Contract Id'
    }, 'click', component.contractsToAdd);

    expect(component.contractsToAdd).toEqual([{
      codeValueText: 'H3251',
      codeValueDescription: 'H3251',
      corporateEntityCode: 'NM1',
      codeSetName: 'MEMCONTRID',
      codeSetDescription: 'Member Contract Id'
    }]);
  });

  it('removeLineOfBusiness - component.lineOfBusinessToAdd to equal component.lineOfBusinessAdded', () => {
    component.removeLineOfBusiness({
      codeSetDescription: 'Line of Business',
      codeSetName: 'LOB',
      codeValueDescription: 'Medicare Advantage Membership Cohort',
      codeValueText: 'MAPD',
      corporateEntityCode: 'NM1'
    }, 'click', component.lineOfBusinessAdded);

    expect(component.lineOfBusinessAdded).toEqual([{
      codeSetDescription: 'Line of Business',
      codeSetName: 'LOB',
      codeValueDescription: 'Medicare Advantage Membership Cohort',
      codeValueText: 'MAPD',
      corporateEntityCode: 'NM1'
    }]);
  });

  it('removeContracts - component.contractsToAdd to equal component.contractsAdded', () => {
    component.removeContracts({
      codeValueText: 'H3251',
      codeValueDescription: 'H3251',
      corporateEntityCode: 'NM1',
      codeSetName: 'MEMCONTRID',
      codeSetDescription: 'Member Contract Id'
    }, 'click', component.contractsAdded);

    expect(component.contractsAdded).toEqual([{
      codeValueText: 'H3251',
      codeValueDescription: 'H3251',
      corporateEntityCode: 'NM1',
      codeSetName: 'MEMCONTRID',
      codeSetDescription: 'Member Contract Id'
    }]);
  });

  it('validateArrangementRate - loadingService.show should have been called', () => {
    spyOn(component.loadingService, 'show');
    component.validateArrangementRate('id');
    expect(component.loadingService.show).toHaveBeenCalled();
  });

  it('checkAndRemoveToast - component.toast.remove should have been called', () => {
    spyOn(component.toast, 'remove');
    component.inserted = {
      toastId: '123'
    };
    component.checkAndRemoveToast();
    expect(component.toast.remove).toHaveBeenCalled();
  });

  it('openConfirmModal - modalService should be open', () => {
    spyOn(component.modalService, 'open');
    component.openConfirmModal(false, 'error');
    expect(component.modalService.open).toHaveBeenCalled();
  });
});
