import {
  Component,
  OnInit,
  ViewChild,
  OnDestroy,
  ChangeDetectorRef,
  AfterContentChecked,
  ViewChildren,
  QueryList
} from '@angular/core';
import {
  ActivatedRoute,
  Router,
  RoutesRecognized
} from '@angular/router';
import { ModalService } from '../../../../../shared/services/modal.service';
import {
  animate,
  state,
  style,
  transition,
  trigger
} from '@angular/animations';
import { Subject } from 'rxjs';
import {
  PaymentArrangement,
  ArrangmentDates,
  SaveArrangement,
  PaymentTypes
} from '../../../../../models/configuration.model';
import { CustomDateParserFormatter } from 'src/app/shared/modules/ui/components/datepicker/customdateparserformatter';
import { ConfigurationService } from '../../../services/configuration.service';
import { UtilService } from 'src/app/shared/services/util.service';
import { UserCacheService } from '../../../../../shared/services/user-cache.service';
import {
  ArrangementPayee,
  Provider,
  Providers,
  VBRDates,
  Errors,
  RateNames,
  RateName,
  PaymentArrangementRate,
  PaymentArrangementPayee
} from '../../../../../models/configuration.model';
import {
  ALPHA_NUMERIC_PATTERN,
  ALPHA_NUMERIC_PATTERN_WITH_SPACE,
  DATE_PATTERN,
  ARRANGEMENT_ROLES,
  PAYMENT_ARRANGEMENT_TYPE_CODE,
  PAYMENT_ARRANGEMENT_FREQUENCY,
  SUBJECT_MEMBER_CONTRACT_ID,
  SUBJECT_MEMBER_LOB
} from '../../../../../shared/constants/app.constants';
import _ from 'lodash';
import {
  GlobalConfig,
  ToastContainerDirective,
  ToastService,
} from 'src/app/shared/modules/toast';
import { DataService } from 'src/app/shared/services/data.service';
import { SharedService } from '../../../../../shared/services/shared.service';
import { LoadingService } from '../../../../../shared/modules/loading/loading.module';
import { AuthService } from '../../../../../shared/services/auth.service';
import {
  ReturnMessage
} from '../../../../../models/shared.model';
import { environment } from '../../../../../../environments/environment';
export enum VisibilityState {
  Visible = 'visible',
  Hidden = 'hidden'
}

export enum Direction {
  None = 'None',
  Up = 'Up',
  Down = 'Down'
}
@Component({
  selector: 'app-arrangement',
  templateUrl: './arrangement.component.html',
  styleUrls: ['./arrangement.component.scss'],
  animations: [
    trigger('scrollAnimation', [
      state(
        VisibilityState.Visible,
        style({
          transform: 'translateY(0px)'
        })
      ),
      state(
        VisibilityState.Hidden,
        style({
          transform: 'translateY(0px)'
        })
      ),
      transition(
        `${VisibilityState.Visible} => ${VisibilityState.Hidden}`,
        animate('250ms')
      ),
      transition(
        `${VisibilityState.Hidden} => ${VisibilityState.Visible}`,
        animate('250ms')
      )
    ])
  ]
})
export class ArrangementComponent
  implements OnDestroy, OnInit, AfterContentChecked {

  @ViewChild('step1Form') step1FormValues: any;
  @ViewChild('editPayeeForm') editPayeeFormValues: any;
  @ViewChildren(ToastContainerDirective) inlineContainers: QueryList<
    ToastContainerDirective
  >;
  private destroy$: Subject<boolean> = new Subject<boolean>();
  payeeArrangementSearch: ArrangementPayee;
  paymentArrangementRate: PaymentArrangementRate;
  rateRows: RateName;
  providerInfo: Provider;
  addPayeeVBRDates: VBRDates;
  paymentTypes: PaymentTypes;
  isContainerVisible = VisibilityState.Visible;
  providerList: Providers;
  arrangement: PaymentArrangement;
  editPayeeArrangDates: ArrangmentDates;
  noRecordMsg: Error;
  rateNames: RateNames;
  saveArrangement: SaveArrangement;
  saveArrangementErrorList: Errors;
  rateDetails: RateName;
  paymentArrangementPayeeObj: PaymentArrangementPayee;
  options: GlobalConfig;
  isRateDateError: boolean;
  isRateEffDateError: boolean;
  isRateEndDateError: boolean;
  selectectPayee: number;
  isEffDateError: boolean;
  isEndDateError: boolean;
  selectVbrPayee: any;
  selectPremierPayee: any;
  slideHeader2InAtPosition = 30;
  arrangementId = 0;
  retroactivityCheck: boolean;
  marked: boolean;
  retroCheck: boolean;
  isCheckedFrequencyDate: boolean;
  isCheckedFrequencyMonth: boolean;
  activityType: any;
  retroFrequency: any;
  modelpremier: any;
  modelvbr: any;
  model4: any;
  modelrate: any;
  modelratetable2: any;
  modelratetable3: any;
  save: any;
  cancel: any;
  editCustomSettingForm: any;
  retro_months: any;
  isPinGroupError: boolean;
  payeeID: number;
  isEditEffDateError: boolean;
  isEditEndDateError: boolean;
  payeeArrang: boolean;
  payeeType;
  totalRecords = 0;
  isNoRecordsDisplay: boolean;
  isSaveArrangementError;
  vbrPayeeEffDate: any;
  vbrPayeeEndDate: any;
  currentRows: any;
  pinGroupName: any;
  rowData: any;
  lineOfBusinessToAdd = [];
  lineOfBusinessAdded = [];
  arngmtFrequency = [];
  contractsToAdd = [];
  contractsAdded = [];
  contractLOBs = [];
  contractLOBCheck: boolean;
  isDurationEffDateError: boolean;
  isDurationEndDateError: boolean;
  name: any;
  arrangementObj: any = {};
  arrangementPayeeObj: any = {};
  isDisableRateNxtBtn = true;
  selectedRateName: string;
  paymentTypeDescription: string;
  isArrangementNameError: boolean;
  isPayeeOutlinedError: boolean;
  isRateOutlinedError: boolean;
  isFrequencyOutlinedError: boolean;
  isdurationEffDateEndDate: boolean;
  isDescOutlinedError: boolean;
  isNameOutlinedError: boolean;
  isSubOutlinedError: boolean;
  isPaymtOutlinedError: boolean;
  isDurationEndDate: boolean;
  isDurationEffDate: boolean;
  arrangementNameTitle: string;
  arrangementDescription: string;
  isArrangementPaymentDescriptionValid: boolean;
  ispaymentArrangementNameValid: boolean;
  existingArrangement: any;
  isPayeeError: boolean;
  isErrorDates: boolean;
  isArrangementPayeeError: boolean;
  inserted: any;
  errorPremierCheck: boolean;
  lname: any;
  cid: any;
  membersubjectPresent = false;
  routeSub: any;
  arrangementCheck: boolean;
  contractsToAddActual = [];
  lineOfBusinessToAddActual = [];
  contractLOBAction: string;
  isSuccessMessage: boolean;
  isWarningORDraft: string;
  checkRoles: boolean;
  arrangementWarnings: any;
  returnMessage: ReturnMessage;
  isEffDate: boolean;
  isEndDate: boolean;
  isEffDateEndDate: boolean;
  env = environment;
  paymtArrTypeCode: string;
  corporateEntityCode: string;
  corporateEntityDescription: string;
  constructor(
    public route: ActivatedRoute,
    public router: Router,
    public modalService: ModalService,
    public customDateParserFormatter: CustomDateParserFormatter,
    public configurationService: ConfigurationService,
    public utilService: UtilService,
    public userCacheService: UserCacheService,
    private cdr: ChangeDetectorRef,
    public toast: ToastService,
    private dataService: DataService,
    public sharedService: SharedService,
    public loadingService: LoadingService,
    public authService: AuthService,
  ) {
    this.options = this.toast.toastConfig;
    this.routeSub = this.router.events.subscribe(event => {
      if (event instanceof RoutesRecognized) {
        if (event.url !== this.router.url) {
          for (const toasty of this.toast.toasts) {
            this.toast.remove(toasty.toastId);
          }
        }
      }
    });

    this.sharedService.getCorpEntityCode().subscribe(data => this.corporateEntityCode = data);

    this.sharedService.getCorpEntityDescription().subscribe(data => this.corporateEntityDescription = data);
  }

  /**
   * ngOnDestroy
   * Life cycle hook to destory or unsubscribe the events and variables
   */
  ngOnDestroy() {
    this.destroy$.next(true);
    this.destroy$.unsubscribe();
    this.routeSub.unsubscribe();
    this.sharedService.clearToasts();
  }

  /**
   * ngOnInit
   * Life Cycle hook that initializes on init
   */
  ngOnInit() {
    this.initializeArrangementPayeeSearchForm();
    this.initializeArrangDates();
    this.initializeVBRDates();
    this.getPaymentTypes();
    this.payeeArrang = false;
    this.getcodeValue(SUBJECT_MEMBER_LOB);
    this.getcodeValue(SUBJECT_MEMBER_CONTRACT_ID);
    this.getcodeValue(PAYMENT_ARRANGEMENT_FREQUENCY);
    this.errorPremierCheck = false;
    // To enable UI components
    this.checkRoles = this.env.SSO_CONFIG.enableSSO ? !this.authService.isAuthorized(ARRANGEMENT_ROLES) : false;
  }

  /**
   * ngAfterContentChecked
   * Life Cycle event on after the content is checked
   */
  ngAfterContentChecked(): void {
    this.cdr.detectChanges();
    if (this.arrangement !== undefined) {
      if (this.arrangement.paymentArrangementId > 0) {
        this.arrangementCheck = true;
      } else {
        this.arrangementCheck = false;
      }
    } else {
      this.arrangementCheck = false;
    }
  }
  /* Method : initalizeArrangement
   * This method is used to decide the mode (NEW / EXISTING) of arrangement
   */
  initializeArrangement() {
    this.arrangementId = parseInt(this.route.snapshot.paramMap.get('id'));
    this.arrangementId !== 0
      ? this.getArrangement()
      : this.initializePaymentArrangement();
  }

  /* Method : setUpperCase
   * This method is used to convert the string to upper case
   */
  setUpperCase() {
    this.arrangement.paymentArrangementName = this.arrangement.paymentArrangementName.toUpperCase();
    this.payeeArrangementSearch.pinGroupId = this.payeeArrangementSearch.pinGroupId.toUpperCase();
  }
  /* Method : getPaymentTypes
   * This method is used to call the service method to get the payment types
   */
  getPaymentTypes() {
    this.loadingService.show();
    // API call to get all the arrangement payment types
    this.configurationService.getArrangementPaymentTypes(this.corporateEntityCode).subscribe(
      (data: PaymentTypes) => {
        this.loadingService.hide();
        // On success, data is given to paymentTypes
        this.paymentTypes = data;
        this.getcodeValue(PAYMENT_ARRANGEMENT_TYPE_CODE);
      },
      error => {
        this.loadingService.hide();
        // On failure, error is displayed
        this.sharedService.handleErrorSuccessWarningInfo('FAILURE', error, 'Arrangement Error');
      }
    );
  }
  /* Method : getcodeValue
   * @param : codeName: string
   * This method is used to get the code values.
   */
  getcodeValue(codeName: string) {
    this.loadingService.show();
    this.sharedService.getCodeValues(codeName).subscribe((data: any) => {

      this.loadingService.hide();

      if (codeName == PAYMENT_ARRANGEMENT_TYPE_CODE) {
        this.paymtArrTypeCode = data.codeSetValueItems[0].codeValueText;
        this.initializeArrangement();
      } else if (codeName == PAYMENT_ARRANGEMENT_FREQUENCY) {
        this.arngmtFrequency = data.codeSetValueItems;
      } else if (codeName == SUBJECT_MEMBER_LOB) {
        this.setMemberSubjectElementType(data, 'Line of Business');
      } else if (codeName == SUBJECT_MEMBER_CONTRACT_ID) {
        this.setMemberSubjectElementType(data, 'Contract');
      }

    },
      error => {
        this.loadingService.hide();
        this.sharedService.handleErrorSuccessWarningInfo('FAILURE', error, 'Arrangement Error');
      });
  }

  setMemberSubjectElementType(data: any, type: any) {
    if (type == 'Contract') {

      data.codeSetValueItems.forEach((dataElement: any) => {
        this.contractsToAddActual.push(dataElement);
      });
      this.contractsToAdd = this.contractsToAddActual;
      this.contractsToAdd.forEach((element) => {
        element.type = type;
      });
    } else {
      data.codeSetValueItems.forEach((dataElement: any) => {
        this.lineOfBusinessToAddActual.push(dataElement);
      });
      this.lineOfBusinessToAdd = this.lineOfBusinessToAddActual;
      this.lineOfBusinessToAdd.forEach((element) => {
        element.type = type;
      });
    }

  }

  /* Method : getArrangement
   * This method is used to call the service method to get the arrangement records
   */
  getArrangement() {
    this.sharedService.clearToasts();
    this.loadingService.show();
    // API call to get the arrangement from DB using arrangement Id
    this.configurationService
      .getArrangementFromDB(this.arrangementId)
      .subscribe(
        (data: any) => {
          this.loadingService.hide();
          // On success, arrangementOnSuccess method is called with data
          this.arrangementOnSuccess(data);
        },
        error => {
          // On failure, error is displayed
          this.returnMessage = error;
          this.handleErrorResponse(error);
        }
      );
  }

  /**
   * arrangementOnSuccess
   * @param data
   * Method to handle the success response after API call
   */
  arrangementOnSuccess(data: any) {
    // on success, call method to display warnings
    if (data.returnMessage.warnings.length > 0) {
      this.sharedService.handleWarnings('WARNINGS', data, 'Arrangement Warnings');
      this.outlinedError(data.returnMessage.warnings);
    }
    this.arrangement = data.paymentArrangement;
    this.isWarningORDraft = data.paymentArrangement.validationStatusCode;

    this.arrangementNameTitle = this.arrangement.paymentArrangementName;

    this.arrangement.recordEffectiveDate = this.customDateParserFormatter.parse(
      data.paymentArrangement.recordEffectiveDate
    );
    this.arrangement.recordEndDate = this.customDateParserFormatter.parse(
      data.paymentArrangement.recordEndDate
    );

    this.arrangement.paymentArrangementRates.forEach(element => {
      element.recordEffectiveDate = this.customDateParserFormatter.parse(
        element.recordEffectiveDate
      );
      element.recordEndDate = this.customDateParserFormatter.parse(
        element.recordEndDate
      );
    });
    if (
      data.paymentArrangement.paymentArrangementMemberSubjects.length > 0
    ) {
      this.populateRetrievedLOB(
        data.paymentArrangement.paymentArrangementMemberSubjects
      );
    }
    this.getPaymentTypeDescription(this.arrangement.paymentTypeCode);
    this.existingArrangement = JSON.parse(JSON.stringify(this.arrangement));
  }
  /**
   * Method to initialize Payment Arrangement
   */
  initializePaymentArrangement() {
    this.arrangement = {
      corporateEntityCode: this.corporateEntityCode,
      paymentArrangementContractId: null,
      paymentArrangementName: '',
      arrangementFrequencyCode: 'MONT',
      paymentArrangementDescription: '',
      recordEffectiveDate: '',
      recordEndDate: '',
      createUserId: this.userCacheService.getUserCacheData('USER_ID'),
      updateUserId: this.userCacheService.getUserCacheData('USER_ID'),
      createRecordTimestamp: '',
      paymentArrangementId: null,
      validationStatusCode: null,
      rowAction: 'INSERT',
      retroRuleSetups: [],
      paymentArrangementRates: [],
      paymentArrangementHistories: [],
      paymentArrangementMemberSubjects: [],
      paymentArrangementPayees: [],
      paymentArrangementTypeCode: this.paymtArrTypeCode
    };
    this.arrangementNameTitle = 'New Payment Arrangement';
  }

  /**
   * getPaymentTypesDescription
   * @param paymentTypeCode
   * Method to update payment Type Description based on paymentTypeCode
   */
  getPaymentTypeDescription(paymentTypeCode: string) {
    const data: any = this.paymentTypes.paymentTypes.find(
      paymentType => paymentType.paymentTypeCode === paymentTypeCode
    );
    this.paymentTypeDescription = data ? data.paymentTypeDescription : '';
  }

  /* Method : initializeVBRDates
   * This method is used to initialize the values to empty
   */
  initializeVBRDates() {
    this.addPayeeVBRDates = { VBRPayeeEffectiveDate: '', VBRPayeeEndDate: '' };
  }
  // Non-MVP
  // ngAfterViewInit() {
  //   const content = document.querySelector('app-retroactivities > div');
  //   const scroll$ = fromEvent(content, 'scroll').pipe(
  //     throttleTime(10),
  //     map(() => content.scrollTop),
  //     pairwise(),
  //     map(
  //       ([y1, y2]): Direction => {
  //         return y2 < y1
  //           ? Direction.Up
  //           : y2 > this.slideHeader2InAtPosition
  //             ? Direction.Down
  //             : Direction.None;
  //       }
  //     ),
  //     distinctUntilChanged(),
  //     takeUntil(this.destroy$)
  //   );

  //   scroll$.subscribe(dir => {
  //     if (dir === Direction.Down) {
  //       this.isContainerVisible = VisibilityState.Hidden;
  //     } else {
  //       this.isContainerVisible = VisibilityState.Visible;
  //     }
  //   });
  // }
  // Non-MVP

  /**
   * initializeArrangDates
   * Method to initializeArrangement Dates to empty
   */
  initializeArrangDates() {
    this.editPayeeArrangDates = {
      arrangPayeeEffectiveDate: '',
      arrangPayeeEndDate: ''
    };
  }

  /* Method : validateArrangementName
   * Args: matchString - Payment Arrangement Name
   * This method is used to validate the Payment Arrangement Name model and show error message below the field.
   */
  validateArrangementName() {
    this.arrangement.paymentArrangementName = this.arrangement.paymentArrangementName.trim();
    this.ispaymentArrangementNameValid = false;
    this.isArrangementNameError = false;
    if (
      this.utilService.isEmptyCheck(this.arrangement.paymentArrangementName)
    ) {
      this.ispaymentArrangementNameValid = true;
    } else if (!this.validatePaymentArrangementName()) {
      this.isArrangementNameError = true;
    }
  }
  /**
   * validatePaymentArrangementName
   * Function to check the value with pattern and return true or false
   */
  validatePaymentArrangementName() {
    return this.utilService.patterMatch(
      ALPHA_NUMERIC_PATTERN_WITH_SPACE,
      this.arrangement.paymentArrangementName
    );
  }

  /* Method : validatePinGroupId
   * Args: matchString - Pin group Id
   * This method is used to validate the pin group id Add Payee search model and show error message below the field.
   */
  validatePinGroupId(matchString: any) {
    this.isPinGroupError = !this.pinGroupValidation(matchString);
  }
  /* Method : pinGroupValidation
   * Args: matchString - Pin group Id
   * This method is used to validate the pin group id with the pattern
   */
  pinGroupValidation(matchString: any) {
    return this.utilService.patterMatch(ALPHA_NUMERIC_PATTERN, matchString);
  }

  /* Method : setErrorMessage
   * This method is used to show/hide the error message
   */
  setErrorMessage(errorId: string, trueOrFalse: boolean) {
    switch (errorId) {
      case 'isRateEffDateError':
        this.isRateEffDateError = trueOrFalse;
        break;
      case 'isRateEndDateError':
        this.isRateEndDateError = trueOrFalse;
        break;
      case 'isRateDateError':
        this.isRateDateError = trueOrFalse;
        break;
      case 'isEffDateError':
        this.isEffDateError = trueOrFalse;
        break;
      case 'isEndDateError':
        this.isEndDateError = trueOrFalse;
        break;
      case 'isEditEffDateError':
        this.isEditEffDateError = trueOrFalse;
        break;
      case 'isEditEndDateError':
        this.isEditEndDateError = trueOrFalse;
        break;
      case 'isDurationEffDateError':
        this.isDurationEffDateError = trueOrFalse;
        break;
      case 'isDurationEndDateError':
        this.isDurationEndDateError = trueOrFalse;
        break;
    }
  }




  /* Method : validateDate
   * This method is used to do date validation
   */
  validateDate(date: any) {
    return date !== '' && date !== null && date !== undefined && this.utilService.patterMatch(
      DATE_PATTERN,
      this.customDateParserFormatter.format(date)
    );
  }
  /* Method : validateRates
   * This method is used validate the dates for rates
   */
  validateRates() {
    let isError = false;
    if (this.arrangement.paymentArrangementRates) {
      const rateLenth = this.arrangement.paymentArrangementRates.length;
      for (let i = 0; i < rateLenth; i++) {
        if (
          this.validateDate(
            this.arrangement.paymentArrangementRates[i].recordEffectiveDate
          ) === false ||
          this.validateDate(
            this.arrangement.paymentArrangementRates[i].recordEndDate
          ) === false
        ) {
          isError = true;
          this.setErrorMessage('isRateDateError', true);
          break;
        } else {
          isError = false;
          this.setErrorMessage('isRateDateError', false);
        }
      }
    }
    return isError;
  }

  /**
   * disableSave
   * Method to check validations and return value to disable/enable the save button
   */
  disableSave() {
    return this.arrangement.paymentArrangementName.trim() === '' ||
      this.utilService.isEmptyCheck(this.arrangement.paymentArrangementName) ||
      !this.validatePaymentArrangementName() ||
      this.arrangement.paymentArrangementDescription.trim() === '' ||
      this.utilService.isEmptyCheck(
        this.arrangement.paymentArrangementDescription
      ) ||
      !this.validateDate(this.arrangement.recordEffectiveDate) ||
      !this.validateDate(this.arrangement.recordEndDate) ||
      !this.arrangement.arrangementFrequencyCode ||
      !this.arrangement.paymentTypeCode ||
      (this.arrangement.paymentArrangementId &&
        JSON.stringify(this.arrangement) ===
        JSON.stringify(this.existingArrangement)) ||
      this.validateRates() ||
      this.arrangement.paymentArrangementPayees && !this.arrangement.paymentArrangementPayees.every(value => (!this.utilService.isEmptyCheck(value.recordEffectiveDate) && !this.utilService.isEmptyCheck(value.recordEndDate))) || this.checkRoles;
  }

  /**
   * addPayee
   * @param id
   * Method call on addPayee
   */
  addPayee(id: string) {
    this.sharedService.clearToasts();
    this.initializeVBRDates();
    this.initializeArrangementPayeeSearchForm();
    this.isNoRecordsDisplay = false;
    this.noRecordMsg = null;
    this.isPayeeError = false;
    this.modalService.open(id);
  }

  /**
   * editArrPayee
   * @param id
   * @param editArrPayeeRecord
   * @param selectectPayee
   * Method to edit arrangement payee
   */
  editArrPayee(id: string, editArrPayeeRecord: any, selectectPayee: any) {
    this.selectectPayee = selectectPayee;
    this.arrangementObj = editArrPayeeRecord;
    this.arrangementPayeeObj = editArrPayeeRecord.vbrPayee;

    this.editPayeeArrangDates.arrangPayeeEffectiveDate = this.customDateParserFormatter.parse(
      editArrPayeeRecord.recordEffectiveDate
    );
    this.editPayeeArrangDates.arrangPayeeEndDate = this.customDateParserFormatter.parse(
      editArrPayeeRecord.recordEndDate
    );
    this.payeeID = editArrPayeeRecord.paymentArrangementPayeeId;
    this.isArrangementPayeeError = false;
    this.checkAndRemoveToast();
    this.modalService.open(id);
  }

  /**
   * open
   * @param id
   * Method to open the modal
   */
  open(id: string) {
    this.checkAndRemoveToast();
    this.isErrorDates = false;
    if (id === 'add-rates-step1') {
      this.getRates(id);
    } else {
      this.modalService.open(id);
    }
  }

  /**
   * close
   * @param id
   * Method to close the modal
   */
  close(id: string) {
    this.modalService.close(id);

  }

  /**
   * cancelEdit
   * @param id
   * Method to cancel the edit payee modal
   */
  cancelEdit(id: string) {
    this.clearOutlinedError();
    if (id === 'edit-arrangement-payee') {
      this.isEditEffDateError = false;
      this.isEditEndDateError = false;
    }
    this.modalService.close(id);
  }

 /**
  * saveCustomSetting
  * @param id
  */
  saveCustomSetting(id: string) {
    this.retroactivityCheck = true;
    this.modalService.close(id);
  }

  /**
   * resetEdit
   * @param id
   * Method to reset the values for edit payee
   */
  resetEdit(id: string) {
    if (id === 'edit-arrangement-payee') {
      this.editPayeeArrangDates.arrangPayeeEffectiveDate = this.customDateParserFormatter.parse(
        this.arrangementObj.recordEffectiveDate
      );
      this.editPayeeArrangDates.arrangPayeeEndDate = this.customDateParserFormatter.parse(
        this.arrangementObj.recordEndDate
      );
      this.isEditEffDateError = false;
      this.isEditEndDateError = false;
    } else {
      this.editPayeeFormValues.reset();
    }
  }

  /**
   * saveEditArrangPayee
   * Method to create object for save edit arrangement payee
   */
  saveEditArrangPayee() {
    this.arrangement.paymentArrangementPayees[
      this.selectectPayee
    ].recordEffectiveDate = this.customDateParserFormatter.format(
      this.editPayeeArrangDates.arrangPayeeEffectiveDate
    );
    this.arrangement.paymentArrangementPayees[
      this.selectectPayee
    ].recordEndDate = this.customDateParserFormatter.format(
      this.editPayeeArrangDates.arrangPayeeEndDate
    );
    this.arrangement.paymentArrangementPayees[
      this.selectectPayee
    ].createUserId = this.userCacheService.getUserCacheData('USER_ID');
    this.arrangement.paymentArrangementPayees[
      this.selectectPayee
    ].updateUserId = this.userCacheService.getUserCacheData('USER_ID');
    this.arrangement.paymentArrangementPayees[
      this.selectectPayee
    ].rowAction = this.arrangement.paymentArrangementId ? 'UPDATE' : 'INSERT';
  }

  /**
   * saveEdit
   * @param id
   * Method to redirect or close the modal
   */
  saveEdit(id: string) {
    if (id === 'edit-arrangement-payee') {
      this.validateArrangementPayee(id);
    } else {
      this.modalService.close(id);
    }
  }

  /**
   * Method: generateArrangementPayeeObj
   * Method to generate arrangement payee object
   */
  generateArrangementPayeeObj() {
    let paymentArrangementPayeeReq: any;
    this.paymentArrangementPayeeObj = {
      recordEffectiveDate: this.customDateParserFormatter.format(
        this.editPayeeArrangDates.arrangPayeeEffectiveDate
      ),
      recordEndDate: this.customDateParserFormatter.format(
        this.editPayeeArrangDates.arrangPayeeEndDate
      ),
      createUserId: this.userCacheService.getUserCacheData('USER_ID'),
      updateUserId: this.userCacheService.getUserCacheData('USER_ID'),
      rowAction: 'NO_ACTION',
      paymentArrangementPayeeId: this.arrangement.paymentArrangementPayees[
        this.selectectPayee
      ].paymentArrangementPayeeId,
      vbrPayee: this.arrangement.paymentArrangementPayees[this.selectectPayee]
        .vbrPayee
    };
    paymentArrangementPayeeReq = {
      validateArrangementPayee: this.paymentArrangementPayeeObj
    };
    return paymentArrangementPayeeReq;
  }

  /**
   * @param id
   * Method: validateArrangementPayee
   * Method to validate arrangement Payee dates
   */
  validateArrangementPayee(id: string) {
    this.loadingService.show();
    // Service call for 'validateArrangementPayee' API
    this.configurationService
      .validateArrangementPayee(this.generateArrangementPayeeObj())
      .subscribe(
        // On success, return Sucess message
        (data: any) => {
          this.loadingService.hide();
          this.saveEditArrangPayee();
          this.modalService.close(id);
        },
        error => {
          this.returnMessage = error;
          this.clearOutlinedError();
          this.outlinedError(error.returnMessage.errors);
          this.isArrangementPayeeError = true;
          this.loadingService.hide();
          // On failure, error is displayed
        }
      );
  }

  /**
   * searchProvider
   * @param id
   * Method to search Provider based on payee type
   */
  searchProvider(id: string) {
    this.errorPremierCheck = false;
    this.totalRecords = 0;
    if (!this.isPinGroupError) {
      this.payeeType = this.payeeArrangementSearch.payeeType;
      // If payeeType is 'vbr' i.e. search existing vbr payee, searchExisitingPayeeRecords method is called
      if (this.payeeType === 'vbr') {
        this.selectVbrPayee = '';
        this.searchExistingPayeeRecords();
        // if payeeType is other than 'vbr', add new payee method is called
      } else {
        // Method call for retieving records from premier provider
        this.selectPremierPayee = '';
        this.retrieveProviderRecords(this.payeeArrangementSearch);
      }
    }
  }

  /**
   * searchExistingPayeeRecords
   * Method to get the payee records and display in UI
   */

  searchExistingPayeeRecords() {
    this.loadingService.show();
    this.configurationService.searchExistingPayees(this.payeeArrangementSearch).subscribe((data: any) => {
      this.loadingService.hide();
      const displayArray: any = [];
      data.forEach((element: any) => {
        // On success, display the records
        element.vbrPayee.vbrEffDate = element.vbrPayee.recordEffectiveDate;
        element.vbrPayee.vbrEndDate = element.vbrPayee.recordEndDate;
        displayArray.push(element.vbrPayee);
      });
      this.providerList = displayArray;
      this.rowData = this.providerList;
      this.onCurrentRowChange(this.providerList);
      this.pinGroupName = 'pinGroupName';
      // Method call for modal close and Open
      this.modelPopUpOpenClose(
        'select-payee-step-1',
        'select-payee-step-2-vbr'
      );
    },
      error => {
        // On failure, error is displayed
        this.returnMessage = error;
        this.handleErrorResponse(error);
      }
    );
  }

  /* Method : retrieveProviderRecords
   * This method is used to call the service method to retrieve the provider records
   */
  retrieveProviderRecords(reqParam: any) {
    const requestParam: ArrangementPayee[] = [];
    requestParam.push(reqParam);
    this.loadingService.show();
    this.configurationService.getProviderPayees(requestParam).subscribe(
      (data: any) => {
        this.loadingService.hide();
        this.providerList = data.payees;
        if (reqParam.payeeType === 'premier_provider') {
          this.providerSearchResult();
        }

        this.rowData = this.providerList;
        this.onCurrentRowChange(this.providerList);
        this.pinGroupName = 'pinGroupName';
      },
      error => {
        this.returnMessage = error;
        this.handleErrorResponse(error);
      }
    );
  }

  /* Method : getRates
   * This method to get the list of rates from service
   */
  getRates(id: string) {
    this.rateNames = null;
    this.isDisableRateNxtBtn = true;
    this.loadingService.show();
    this.configurationService.getRatesFromDB(this.corporateEntityCode).subscribe(
      (data: RateNames) => {
        this.loadingService.hide();
        this.rateNames = data;
        this.checkAndRemoveToast();
        this.modalService.open(id);
      },
      error => {
        // on failure, call method to display error
        this.returnMessage = error;
        this.handleErrorResponse(error);
      }
    );
  }

  /**
   * Method to handle error from API
   * @param: error
   */
  handleErrorResponse(error: any) {
    this.loadingService.hide();
    this.noRecordMsg = error;
    this.isNoRecordsDisplay = true;
  }

  /**
   * providerSearchResult
   * Method to close or open modal
   */
  providerSearchResult() {
    this.modelPopUpOpenClose(
      'select-payee-step-1',
      'select-payee-step-2-premier'
    );
  }

  /**
  * Method to open/close Modal on click of Nxt
  * @param id
  */
  navigateToAddVBRDates(id: string) {
    this.initializeVBRDates();
    this.modelpremier = false;
    this.errorPremierCheck = false;
    this.modalService.close(id);
    this.modalService.open('select-payee-step-3');

  }
  /**
   * Method to select unique provider data
   * @param provider
   * @param payeeType
   */
  selectProvider(provider: object, payeeType: string) {
    this.errorPremierCheck = false;
    this.modelpremier = false;
    this.providerInfo = {};
    if (payeeType === 'premier') {
      this.modelpremier = true;
      this.loadingService.show();
      this.configurationService.validateUniquePayee(this.configurationService.buildRequestToValidateUniquePayee(provider)).subscribe((_data: any) => {
        this.loadingService.hide();
        if (this.modelpremier) {
          this.setErrorMessage('isEffDateError', false);
          this.setErrorMessage('isEndDateError', false);
        }
      },
        error => {
          this.loadingService.hide();
          this.errorPremierCheck = true;
          this.modelpremier = false;
          this.returnMessage = error;
        });
    } else {
      this.modelvbr = true;
    }
    this.providerInfo = provider;
  }

  /**
   * modelPopUpOpenClose
   * @param close
   * @param open
   * Method to open or close model pop up
   */
  modelPopUpOpenClose(close?: string, open?: string) {
    this.checkAndRemoveToast();
    if (close !== '') {
      this.modalService.close(close);
    }
    if (open !== '') {
      this.modalService.open(open);
    }
  }

  /**
   * cancelStep1
   * @param modalId
   * Method to cancel step 1 of payee
   */
  cancelStep1(modalId: string) {
    this.modalService.close(modalId);
    this.isNoRecordsDisplay = false;
  }

  /**
   * cancelStep2
   * @param modalId
   * Method to cancel step 2 of payee
   */
  cancelStep2(modalId: string) {
    this.initializeArrangementPayeeSearchForm();
    this.modalService.close(modalId);
    this.isNoRecordsDisplay = false;
  }

  /**
   * modifySearch
   * @param modalId
   * Method to modify the search
   */
  modifySearch(modalId: string) {
    this.modelvbr = false;
    this.modelpremier = false;
    this.modalService.close(modalId);
    this.modalService.open('select-payee-step-1');
  }

  /**
   * newSearch
   * @param id
   * Method to search new
   */
  newSearch(id: string) {
    this.initializeArrangementPayeeSearchForm();
    this.modalService.close(id);
    this.modalService.open('select-payee-step-1');
  }

  /**
   * cancelStep3
   * @param id
   * Method to cancel step 3 of payee
   */
  cancelStep3(id: string) {
    this.isRateEffDateError = false;
    this.isRateEndDateError = false;
    this.modalService.close(id);
    this.clearOutlinedError();
  }

  /* Method : saveProvider
   * This method is used to add the payee record in Arrangement Screen
   */
  saveProvider(id: string, payeeType: string) {
    const payee = this.addArrangementPayee();
    this.validatePayeeRecord(payee, id, payeeType);
  }

  /* Method : validatePayeeRecord
   * This method is used to validate the VBR Payee Effective Date and VBR Payee End Date in the Step 3
   */
  validatePayeeRecord(reqParam: any, id: string, payeeType: string) {
    this.sharedService.clearToasts();
    this.isPayeeError = false;
    const requestObject = {
      payee: reqParam.vbrPayee
    };
    this.loadingService.show();
    this.configurationService.savePayeesToDB(requestObject).subscribe(
      (data: any) => {
        this.loadingService.hide();
        if (payeeType === 'premier') {
          reqParam.vbrPayee.rowAction = 'INSERT';
          this.modelPopUpOpenClose('select-payee-step-3', '');
        } else {
          this.modelPopUpOpenClose(id, '');
        }
        this.arrangement.paymentArrangementPayees.push(reqParam);
      },
      error => {
        this.loadingService.hide();
        this.returnMessage = error;
        this.clearOutlinedError();
        this.outlinedError(error.returnMessage.errors);
        this.isPayeeError = true;
      }
    );
  }

  /* Method : outlinedError
   * This method is for red lines for Effective date and End date.
   */
  outlinedError(errorFieldList: any) {
    errorFieldList.forEach((data: any) => {
      if ((data.fieldId === 'paymentArrangementEffectiveDate') || (data.fieldId === 'paymentArrangementRateEffectiveDate') || (data.fieldId === 'vbrPayeeEffectiveDate') || (data.fieldId === 'paymentArrangementPayeeEffectiveDate')) {
        this.isEffDate = true;
      }
      if ((data.fieldId === 'paymentArrangementEndDate') || (data.fieldId === 'paymentArrangementRateEndDate') || (data.fieldId === 'vbrPayeeEndDate') || (data.fieldId === 'paymentArrangementPayeeEndDate')) {
        this.isEndDate = true;
      }
      if ((data.fieldId === 'paymentArrangementRateEffectiveAndEndDate') || (data.fieldId === 'vbrPayeeEffectiveAndEndDate') || (data.fieldId === 'paymentArrangementPayeeEffectiveAndEndDate') || data.fieldId === 'vbrPayeeProviderEffectiveAndEndDates') {
        this.isEffDateEndDate = true;
      }
      if ((data.fieldId === 'paymentArrangementEffectiveAndEndDate') || (data.fieldId === 'paymentArrangementRateEffectiveDate') || (data.fieldId === 'paymentArrangementPayeeEffectiveDate') || (data.fieldId === 'paymentArrangementPayeeEffectiveAndEndDate') || (data.fieldId === 'paymentArrangementRateEffectiveAndEndDate')) {
        this.isdurationEffDateEndDate = true;
      }
      if (data.fieldId === 'paymentArrangementPaymentType') {
        this.isPaymtOutlinedError = true;
      }
      if (data.fieldId === 'paymentArrangementFrequencyCode') {
        this.isFrequencyOutlinedError = true;
      }
      if (data.fieldId === 'paymentArrangementDescription') {
        this.isDescOutlinedError = true;
      }
      if (data.fieldId === 'paymentArrangementName') {
        this.isNameOutlinedError = true;
      }
      if (data.fieldId === 'paymentArrangementMemberSubject') {
        this.isSubOutlinedError = true;
      }
      if ((data.fieldId === 'paymentArrangementPayeeEffectiveDate') || (data.fieldId === 'paymentArrangementPayee') || (data.fieldId === 'paymentArrangementPayeeEffectiveAndEndDate') || (data.fieldId === 'vbrPayeeEffectiveDate') || (data.fieldId === 'paymentArrangementPayeeEndDate')) {
        this.isPayeeOutlinedError = true;
      }
      if ((data.fieldId === 'paymentArrangementRate') || (data.fieldId === 'paymentArrangementRateEffectiveAndEndDate') || (data.fieldId === 'paymentArrangementRateEndDate') || (data.fieldId === 'paymentArrangementRateEffectiveDate')) {
        this.isRateOutlinedError = true;
      }
      if ((data.fieldId === 'paymentArrangementEffectiveDate')) {
        this.isDurationEffDate = true;
      }
      if ((data.fieldId === 'paymentArrangementEndDate')) {
        this.isDurationEndDate = true;
      }
    });
  }

  /* Method : clearOutlinedError
   * This method is for clear red lines for Effective date and End date.
   */
  clearOutlinedError() {
    this.isEffDate = false;
    this.isEndDate = false;
    this.isEffDateEndDate = false;
  }

  /* Method : clearOutlinedWarning
   * This method is for clear red lines for Arrangement save main form contains Payee, Rate, Subject, Name, Description
   * Frequency, Payment Type and duration.
   */
  clearOutlinedWarning() {
    this.isdurationEffDateEndDate = false;
    this.isPaymtOutlinedError = false;
    this.isFrequencyOutlinedError = false;
    this.isDescOutlinedError = false;
    this.isNameOutlinedError = false;
    this.isSubOutlinedError = false;
    this.isPayeeOutlinedError = false;
    this.isRateOutlinedError = false;
    this.isDurationEndDate = false;
    this.isDurationEffDate = false;
  }

  /**
   * addArrangementPayee
   * Method to create the request object of add arrangement payee
   */
  addArrangementPayee() {
    this.vbrPayeeEffDate = this.customDateParserFormatter.format(
      this.addPayeeVBRDates.VBRPayeeEffectiveDate
    );
    this.vbrPayeeEndDate = this.customDateParserFormatter.format(
      this.addPayeeVBRDates.VBRPayeeEndDate
    );
    if (this.vbrPayeeEffDate === '') {
      this.vbrPayeeEffDate = this.providerInfo.vbrEffDate;
    }
    if (this.vbrPayeeEndDate === '') {
      this.vbrPayeeEndDate = this.providerInfo.vbrEndDate;
    }

    const requestObject = {
      providerData: this.providerInfo,
      userId: this.userCacheService.getUserCacheData('USER_ID'),
      createRecordTimestamp: this.providerInfo.createRecordTimestamp ? this.providerInfo.createRecordTimestamp : null,
      updateRecordTimestamp: this.providerInfo.updateRecordTimestamp ? this.providerInfo.updateRecordTimestamp : null,
      recordEffectiveDate: this.vbrPayeeEffDate,
      recordEndDate: this.vbrPayeeEndDate
    };

    const payee: any = {
      vbrPayee: this.configurationService.buildRequestToSavePayee(requestObject)
    };

    payee.vbrPayee.rowAction = 'NO_ACTION';
    payee.vbrPayee.vbrPayeeId = this.providerInfo.vbrPayeeId;

    return payee;
  }

  /**
   * formatRateDate
   * @param action
   * Method to format the rate date
   */
  formatRateDate(action: string) {
    if (this.arrangement.paymentArrangementRates.length > 0) {
      for (
        let i = 0;
        i < this.arrangement.paymentArrangementRates.length;
        i++
      ) {
        this.arrangement.paymentArrangementRates[i].recordEffectiveDate =
          action === 'format'
            ? this.customDateParserFormatter.format(
              this.arrangement.paymentArrangementRates[i].recordEffectiveDate
            )
            : this.customDateParserFormatter.parse(
              this.arrangement.paymentArrangementRates[i].recordEffectiveDate
            );
        this.arrangement.paymentArrangementRates[i].recordEndDate =
          action === 'format'
            ? this.customDateParserFormatter.format(
              this.arrangement.paymentArrangementRates[i].recordEndDate
            )
            : this.customDateParserFormatter.parse(
              this.arrangement.paymentArrangementRates[i].recordEndDate
            );
      }
    }
  }

  /* Method : updatePaymentArrangementRatesAction
 * This method is used to update the row action as 'UPDATE' for rates, if any change in rates
 */
  updatePaymentArrangementRatesAction() {
    if (this.arrangement && this.existingArrangement && this.arrangement.paymentArrangementRates && this.existingArrangement.paymentArrangementRates) {
      const paymentArrangementRatesLength = this.arrangement.paymentArrangementRates.length;
      const existingpaymentArrangementRatesLength = this.existingArrangement.paymentArrangementRates.length;
      for (let i = 0; i < paymentArrangementRatesLength; i++) {
        if (i < existingpaymentArrangementRatesLength) {
          if (JSON.stringify(this.arrangement.paymentArrangementRates[i].recordEffectiveDate) != JSON.stringify(this.existingArrangement.paymentArrangementRates[i].recordEffectiveDate) ||
            JSON.stringify(this.arrangement.paymentArrangementRates[i].recordEndDate) != JSON.stringify(this.existingArrangement.paymentArrangementRates[i].recordEndDate)) {
            this.arrangement.paymentArrangementRates[i].rowAction = 'UPDATE';
          }
        }
      }
    }
  }

  /**
   * updatePaymentArrangementPayeesAction
   * Method to update payment arrangement payees row action
   */
  updatePaymentArrangmentPayeesAction() {
    if (this.arrangement && this.existingArrangement && this.arrangement.paymentArrangementPayees && this.existingArrangement.paymentArrangementPayees) {
      const paymentArrangementPayeesLength = this.arrangement.paymentArrangementPayees.length;
      const existingPaymentArrangementPayeesLength = this.existingArrangement.paymentArrangementPayees.length;
      for (let i = 0; i < paymentArrangementPayeesLength; i++) {
        if (i < existingPaymentArrangementPayeesLength) {
          if (JSON.stringify(this.arrangement.paymentArrangementPayees[i].recordEffectiveDate) !== JSON.stringify(this.existingArrangement.paymentArrangementPayees[i].recordEffectiveDate) || JSON.stringify(this.arrangement.paymentArrangementPayees[i].recordEndDate) !== JSON.stringify(this.existingArrangement.paymentArrangementPayees[i].recordEndDate)) {
            this.arrangement.paymentArrangementPayees[i].rowAction = 'UPDATE';
          }
        } else if (existingPaymentArrangementPayeesLength >= 0) {
          this.arrangement.paymentArrangementPayees[i].rowAction = 'INSERT';
        }
      }

    }
  }

  /* Method : updateArrangementRowAction
   * This method is used to check update the ROWACTION for Arrangement
   */
  updateArrangementRowAction() {
    if (this.arrangement.paymentArrangementId !== null) {
      this.arrangement.rowAction = this.isArrangementDataChanged();
    } else {
      this.arrangement.rowAction = 'INSERT';
    }
  }
  /* Method : isArrangementDataChanged
   * This method is used to check any primary data is changed in Arrangement
   */
  isArrangementDataChanged() {
    return ((this.existingArrangement.paymentArrangementName != this.arrangement.paymentArrangementName) ||
      (this.existingArrangement.paymentArrangementDescription != this.arrangement.paymentArrangementDescription) ||
      (this.existingArrangement.arrangementFrequencyCode != this.arrangement.arrangementFrequencyCode) ||
      (this.existingArrangement.paymentArrangementTypeCode != this.arrangement.paymentArrangementTypeCode) ||
      (this.customDateParserFormatter.format(this.existingArrangement.recordEffectiveDate) != this.arrangement.recordEffectiveDate) ||
      (this.customDateParserFormatter.format(this.existingArrangement.recordEndDate) != this.arrangement.recordEndDate)
    )
      ? 'UPDATE'
      : 'NO_ACTION';
  }

  /* Method : saveArrangement
   * This method is used to save the arrangement record in DB
   */
  saveArrangementRecord(value: string) {
    this.clearOutlinedWarning();
    this.arrangement.recordEffectiveDate = this.customDateParserFormatter.format(
      this.arrangement.recordEffectiveDate
    );
    this.arrangement.recordEndDate = this.customDateParserFormatter.format(
      this.arrangement.recordEndDate
    );
    this.arrangement.createUserId = this.userCacheService.getUserCacheData(
      'USER_ID'
    );
    this.arrangement.updateUserId = this.userCacheService.getUserCacheData(
      'USER_ID'
    );
    this.arrangement.corporateEntityCode = this.corporateEntityCode;

    this.updatePaymentArrangementRatesAction();
    this.updatePaymentArrangmentPayeesAction();

    this.formatRateDate('format');
    if (value === 'save') {
      this.arrangement.overwriteCancelArrangement = false;
      this.arrangement.overwriteSaveArrangement = false;

    } else if (value === 'no') {
      this.formatRateDate('parse');
      this.arrangement.recordEffectiveDate = this.customDateParserFormatter.parse(
        this.arrangement.recordEffectiveDate
      );
      this.arrangement.recordEndDate = this.customDateParserFormatter.parse(
        this.arrangement.recordEndDate
      );
      this.modalService.close('confirm-modal-arrangement');
      this.outlinedError(this.arrangementWarnings.returnMessage.warnings);
      this.sharedService.handleWarnings('WARNINGS', this.arrangementWarnings, 'Arrangement Warnings');
      return false;

    } else {
      this.arrangement.overwriteCancelArrangement = false;
      this.arrangement.overwriteSaveArrangement = true;
    }

    this.saveArrangement = {
      arrangement: this.arrangement
    };
    this.updateArrangementRowAction();
      this.loadingService.show();
      this.sharedService.clearToasts();
      this.configurationService
        .saveArrangementToDB(this.saveArrangement)
        .subscribe(
          (data: any) => {
            this.loadingService.hide();
            this.modalService.close('confirm-modal-arrangement');
            this.dataService.setSuccessMessage({
              data: data,
              isSuccessMessage: true
            });
            this.router.navigateByUrl('configurations/arrangements');
          },
          error => {
            this.loadingService.hide();
            this.formatRateDate('parse');
            this.arrangement.recordEffectiveDate = this.customDateParserFormatter.parse(
              this.arrangement.recordEffectiveDate
            );
            this.arrangement.recordEndDate = this.customDateParserFormatter.parse(
              this.arrangement.recordEndDate
            );
            this.saveArrangementErrorList = error.returnMessage.errors;
            this.isSaveArrangementError = true;
            this.outlinedError(error.returnMessage.errors);
            this.arrangemntStatus(error.returnMessage.errors);
            this.openConfirmModal(this.isSaveArrangementError, error);
          }
        );
  }

  /* Method : arrangemntStatus
     * This method is used to filter the arrangemnt Status array coming from saveArrangementRecord method
     */
  arrangemntStatus(arr) {
    const errorID = ['275', '276', '277', '278', '279', '280', '281', '282', '283'];
    for (const error of arr) {
      errorID.forEach((val) => {
        if (val == error.errorMessageId) {
          this.isSaveArrangementError = false;
          this.arrangementDescription = error.errorMsgDescriptionText;
          return false;
        }
      }
      );
    }
  }

  /* Method : validateVBRDate
   * This method is used to validate VBR date and show/hide the error message
   */
  validateVBRDate(date: string, errorId: string) {
    this.clearOutlinedError();
    if (!this.validateDate(date)) {
      this.setErrorMessage(errorId, true);
    } else {
      this.setErrorMessage(errorId, false);
    }
  }
  /**
   * Method: validatePaymentArrangementDescription
   * Function to validate the payment arrangement description
   */
  validatePaymentArrangementDescription() {
    this.arrangement.paymentArrangementDescription = this.arrangement.paymentArrangementDescription.trim();
    this.isArrangementPaymentDescriptionValid = this.utilService.isEmptyCheck(
      this.arrangement.paymentArrangementDescription
    );
  }

  /**
   * saveDefaultSetting
   * @param id
   */
  saveDefaultSetting(id: string) {
    if (this.marked) {
      this.retroactivityCheck = true;
      this.marked = false;
    } else {
      this.retroactivityCheck = false;
      this.marked = false;
    }
    this.modalService.close(id);
  }

  /**
   * toggleVisibility
   * @param e
   */
  toggleVisibility(e) {
    this.marked = e.target.checked;
  }

  /**
   * setFrequency
   * @param frequency
   */
  setFrequency(frequency: string) {
    if (frequency === 'month') {
      this.isCheckedFrequencyMonth = true;
      this.isCheckedFrequencyDate = false;
    } else if (frequency === 'date') {
      this.isCheckedFrequencyDate = true;
      this.isCheckedFrequencyMonth = false;
    } else {
      return;
    }
  }
  /* Method : initializeArrangementPayeeSearchForm
   * This method is used to set the default values for the search fields
   */
  initializeArrangementPayeeSearchForm() {
    this.modelvbr = false;
    this.modelpremier = false;
    this.payeeArrangementSearch = {
      payeeType: '',
      corpEntityCode: this.corporateEntityCode,
      pinGroupId: ''
    };
  }

  /* Method : cancelArrangement
   * This method is used to route to arrangements screen when cancel is clicked
   */
  cancelArrangement() {
    this.router.navigateByUrl('configurations/arrangements');
  }


  /* Method : checkForContractsAndLOB
   * This method is to set the contract and lob set by the user
   */
  checkForContractsAndLOB() {
    const addContractLOBObject = {
      cid: '',
      cidCode: '',
      lname: '',
      lnameCode: '',
      corporateEntityCode: ''
    };
    for (const l in this.lineOfBusinessAdded) {
      if (this.lineOfBusinessAdded) {
        for (const c in this.contractsAdded) {
          if (this.contractsAdded) {
            addContractLOBObject.cid = this.contractsAdded[c].codeValueDescription;
            addContractLOBObject.cidCode = this.contractsAdded[c].codeValueText;
            }
        }
        addContractLOBObject.lname = this.lineOfBusinessAdded[l].codeValueDescription;
        addContractLOBObject.lnameCode = this.lineOfBusinessAdded[l].codeValueText;
        addContractLOBObject.corporateEntityCode = this.corporateEntityCode;
        if (this.contractLOBs.length > 0) {
          this.contractLOBs.pop();
          this.contractLOBs.push(addContractLOBObject);
        } else {
          this.contractLOBs.push(addContractLOBObject);
        }
        if (this.existingArrangement != null && this.existingArrangement != undefined) {
          this.existingArrangement.paymentArrangementMemberSubjects.forEach((element) => {
            this.contractLOBs.forEach((data) => {
              if (data.lnameCode === element.lineOfBusinessCode && data.cidCode === element.contractId) {
                this.contractLOBAction = 'NO_ACTION';
              } else {
                this.contractLOBAction = 'UPDATE';
              }
            });
          });
        }
      }
    }

    if (_.size(this.contractLOBs) === 0 || this.contractLOBs === undefined) {
      this.contractLOBCheck = false;
    } else {
      this.contractLOBCheck = true;
    }

    if (this.contractLOBCheck) {
      this.membersubjectPresent = true;
      this.populateMemberSubjectForSave();
    }
  }

  /**
   * populateMemberSubjectForSave
   * Method to populate member subject
   */
  populateMemberSubjectForSave() {
    const subject: any = {
      contractId: '',
      lineOfBusinessCode: '',
      paymentArrangementMemberSubjectId: null,
      paymentArrangementId: null,
      corporateEntityCode: '',
      rowAction: '',
      createUserId: this.userCacheService.getUserCacheData('USER_ID'),
      updateUserId: this.userCacheService.getUserCacheData('USER_ID'),
      createRecordTimestamp: null,
      updateRecordTimestamp: null
    };
    const memberSubject: any = [];

    this.contractLOBs.forEach((data) => {
      subject.contractId = data.cid;
      subject.lineOfBusinessCode = data.lnameCode;
      subject.corporateEntityCode = data.corporateEntityCode;
      if (this.contractLOBAction === 'UPDATE') {
        subject.rowAction = 'UPDATE';
        subject.paymentArrangementId = this.arrangement.paymentArrangementId;
        subject.paymentArrangementMemberSubjectId = this.arrangement.paymentArrangementMemberSubjects[0].paymentArrangementMemberSubjectId;
        subject.createUserId = this.arrangement.paymentArrangementMemberSubjects[0].createUserId;
        subject.updateUserId = this.arrangement.paymentArrangementMemberSubjects[0].updateUserId;
        subject.createRecordTimestamp = this.arrangement.paymentArrangementMemberSubjects[0].createRecordTimestamp;
        subject.updateRecordTimestamp = this.arrangement.paymentArrangementMemberSubjects[0].updateRecordTimestamp;
      } else if (this.contractLOBAction === 'NO_ACTION') {
        subject.rowAction = 'NO_ACTION';
        subject.paymentArrangementId = this.arrangement.paymentArrangementId;
        subject.paymentArrangementMemberSubjectId = this.arrangement.paymentArrangementMemberSubjects[0].paymentArrangementMemberSubjectId;
      } else {
        subject.rowAction = 'INSERT';
        if (this.arrangement.paymentArrangementId != null && this.arrangement.paymentArrangementId > 0) {
          subject.paymentArrangementId = this.arrangement.paymentArrangementId;
        }
      }
      memberSubject.push(subject);
    });

    this.arrangement.paymentArrangementMemberSubjects = memberSubject;
  }

  /**
   * onCurrentRowChange
   * @param currentRow
   * Method to change current row
   */
  onCurrentRowChange(currentRow: any) {
    this.currentRows = currentRow;
  }

  addAllContractsAndLOB() {
    let removedLineOfBusiness = [];
    let removedContracts = [];
    if (
      _.size(this.lineOfBusinessToAdd) === 0 &&
      _.size(this.contractsToAdd) === 0
    ) {
      return;
    } else {
      if (_.size(this.lineOfBusinessToAdd) > 0) {
        removedLineOfBusiness = _.remove(this.lineOfBusinessToAdd);
        this.lineOfBusinessAdded = _.concat(
          this.lineOfBusinessAdded,
          removedLineOfBusiness
        );
      }
      if (_.size(this.contractsToAdd) > 0) {
        removedContracts = _.remove(this.contractsToAdd);
        this.contractsAdded = _.concat(this.contractsAdded, removedContracts);
      }
    }
  }

  /**
   * removeAllContractsAndLOB
   * Method to remove all contracts and LOB
   */
  removeAllContractsAndLOB() {
    let removedLineOfBusiness = [];
    let removedContracts = [];
    if (
      _.size(this.lineOfBusinessAdded) === 0 &&
      _.size(this.contractsAdded) === 0
    ) {
      return;
    } else {
      if (_.size(this.lineOfBusinessAdded) > 0) {
        removedLineOfBusiness = this.lineOfBusinessAdded.splice(
          0,
          this.lineOfBusinessAdded.length
        );
        this.lineOfBusinessToAdd = _.concat(
          this.lineOfBusinessToAdd,
          removedLineOfBusiness
        );
      }
      if (_.size(this.contractsAdded) > 0) {
        removedContracts = this.contractsAdded.splice(
          0,
          _.size(this.contractsAdded)
        );
        this.contractsToAdd = _.concat(this.contractsToAdd, removedContracts);
      }
    }
  }

  /**
   * addLineOfBusiness
   * @param item
   * @param evntType
   * @param list
   * Method to add line of business
   */
  addLineOfBusiness(item: any, evntType: string, list: any[]) {
    if (evntType === 'click') {
      this.lineOfBusinessToAdd.splice(
        this.lineOfBusinessToAdd.indexOf(item),
        1
      );
      this.lineOfBusinessAdded.push(item);
    }
  }

  /**
   * addContracts
   * @param item
   * @param evntType
   * @param list
   * Method to add contracts
   */
  addContracts(item: any, evntType: string, list: any[]) {
    if (evntType === 'click') {
      this.contractsToAdd.splice(this.contractsToAdd.indexOf(item), 1);
      this.contractsAdded.push(item);
    }
  }

  /**
   * removeLineOfBusiness
   * @param item
   * @param evntType
   * @param list
   * Method to remove Line of Business
   */
  removeLineOfBusiness(item: any, evntType: string, list: any[]) {
    if (evntType === 'click') {
      this.lineOfBusinessAdded.splice(
        this.lineOfBusinessAdded.indexOf(item),
        1
      );
      this.lineOfBusinessToAdd.push(item);
    }
  }

  /**
   * removeContracts
   * @param item
   * @param evntType
   * @param list
   * Method to remove Contracts
   */
  removeContracts(item: any, evntType: string, list: any[]) {
    if (evntType === 'click') {
      this.contractsAdded.splice(this.contractsAdded.indexOf(item), 1);
      this.contractsToAdd.push(item);
    }
  }

  /**
   * removeItem
   * @param item
   * @param list
   * Method to remove any item
   */
  public removeItem(item: any, list: any[]): void {
    list.splice(list.indexOf(item), 1);
  }
  /* Method : selectRate
   * @param : selectedRate- selected rate object
   * This method is used to get the selected rate details  from rateList.
   */
  selectRate(selectedRate: any) {
    this.isDisableRateNxtBtn = false;
    this.selectedRateName = selectedRate.rateName;
  }
  /* Method : assignRateDates
   * @param : selectedRate- selected rate object
   * This method is used to get the selected rate details  from rateList.
   */
  assignRateDates(id: string) {
    this.initializeRateObject();
    this.getRateDetailsByRateName();
    this.modelPopUpOpenClose(id, 'add-rates-step2');
  }
  /* Method : getRateDetailsByRateName
   * This method to get the rate details from service based on the rate name
   */
  getRateDetailsByRateName() {
    this.clearOutlinedError();
    this.loadingService.show();
    this.configurationService.getRatesDetails(this.selectedRateName).subscribe(
      (data: any) => {
        this.loadingService.hide();
        this.rateDetails = data;
        this.paymentArrangementRate.rateName = data.rateName.rateName;
        this.paymentArrangementRate.rateConfigTypeName =
          data.rateName.rateConfigTypeName;
        this.paymentArrangementRate.corporateEntityCode =
          data.rateName.corporateEntityCode;
      },
      error => {
        this.loadingService.hide();
      }
    );
  }
  /* Method : initializeRateObject
   * This method is used to initialize the rate object after fetching the rate details of the rate name
   */
  initializeRateObject() {
    this.paymentArrangementRate = {
      paymentArrangementRateId: null,
      rateName: '',
      rateConfigTypeName: '',
      paymentArrangementId: null,
      corporateEntityCode: '',
      recordEffectiveDate: '',
      recordEndDate: '',
      createUserId: this.userCacheService.getUserCacheData('USER_ID'),
      updateUserId: this.userCacheService.getUserCacheData('USER_ID'),
      rowAction: 'INSERT'
    };
  }

  /* Method : validateArrangementRate
   * @Param : id
   * This method is used to Validate the arrangement rate/ Global rate dates.
   */
  validateArrangementRate(id: string) {
    this.paymentArrangementRate.recordEffectiveDate = this.customDateParserFormatter.format(this.paymentArrangementRate.recordEffectiveDate);
    this.paymentArrangementRate.recordEndDate = this.customDateParserFormatter.format(this.paymentArrangementRate.recordEndDate);
    const arrangementRateValidationRequest = { paymentArrangementRate: this.paymentArrangementRate };
    this.loadingService.show();
    this.configurationService
      .validateArrangementRate(arrangementRateValidationRequest)
      .subscribe(
        (data: any) => {
          this.loadingService.hide();
          this.paymentArrangementRate.recordEffectiveDate = this.customDateParserFormatter.parse(this.paymentArrangementRate.recordEffectiveDate);
          this.paymentArrangementRate.recordEndDate = this.customDateParserFormatter.parse(this.paymentArrangementRate.recordEndDate);
          this.saveRate(id);
        },
        (error: any) => {
          this.loadingService.hide();
          this.paymentArrangementRate.recordEffectiveDate = this.customDateParserFormatter.parse(this.paymentArrangementRate.recordEffectiveDate);
          this.paymentArrangementRate.recordEndDate = this.customDateParserFormatter.parse(this.paymentArrangementRate.recordEndDate);
          this.returnMessage = error;
          this.clearOutlinedError();
          this.outlinedError(error.returnMessage.errors);
          this.isErrorDates = true;
        }
      );
  }

  /* Method : saveRate
   * @Param : id
   * This method is used to save the rate in the rate object and show in the Arrangement home screen
   */
  saveRate(id: string) {
    this.modalService.close(id);
    this.arrangement.paymentArrangementRates.push(this.paymentArrangementRate);
  }
  /* Method : viewRates
   * @Param : rateName- Name of the Rate Table
   *          id - Model window name
   * This method is used to save the rate in the rate object and show in the Arrangement home screen
   */
  viewRates(rateName: any, id: string) {
    this.checkAndRemoveToast();
    this.loadingService.show();
    this.configurationService.getRatesDetails(rateName).subscribe(
      (data: any) => {
        this.loadingService.hide();
        this.modalService.open(id);
        this.rateRows = data.rateName;
      },
      error => {
        this.loadingService.hide();
      }
    );
  }

  /**
   * editRates
   * @param rateName
   * @param id
   * Method to edit rates
   */
  editRates(rateName: any, id: string) {
    this.modalService.open(id);
    this.rateRows = rateName;
  }

  /**
   * checkAndRemoveToast
   * Method to remove toast
   */
  checkAndRemoveToast() {
    if (this.inserted !== undefined) {
      this.toast.remove(this.inserted.toastId);
    }
  }

  /**
   * openConfirmModal
   * @param isError
   * @param error
   * Method to open confirm modal
   */
  openConfirmModal(isError: boolean, error: any) {
    this.checkAndRemoveToast();
    if (isError) {
      this.modalService.close('confirm-modal-arrangement');
      this.sharedService.handleErrorSuccessWarningInfo('FAILURE', error, 'Arrangement Error');
      this.isSuccessMessage = false;
    } else {
      this.isSuccessMessage = true;
      this.arrangementWarnings = error;
      this.modalService.open('confirm-modal-arrangement');
    }
  }

  /* Method : populateRetrievedLOB
   * This method is to populate contract and lob items retrieved from service
   */
  populateRetrievedLOB(memberSubject: any) {
    const subject: any = {};
    memberSubject.forEach(element => {
      if ((element.lineOfBusinessCode != null) && (element.contractId != null) && (element.corporateEntityCode != null)) {
        this.lineOfBusinessToAddActual.forEach((data) => {
          if (data.codeValueText === element.lineOfBusinessCode) {
            subject.lname = data.codeValueDescription;
          }
        });
        this.contractsToAddActual.forEach((data) => {
          if (data.codeValueText === element.contractId) {
            subject.cid = data.codeValueDescription;
          }
        });
        subject.corporateEntityCode = element.corporateEntityCode;
        this.contractLOBs.push(subject);
      }
      this.setDragDropEditState();
    });

    if (this.contractLOBs.length > 0) {
      this.membersubjectPresent = true;
    }
  }

  /* Method : clearContractLobsAdded
   * This method is to handle cancel in member subject modal
   */
  clearContractLobsAdded() {
    if (!this.membersubjectPresent) {
      this.clearDragDropSections();
    } else {
      this.clearDragDropSections();
      this.setDragDropEditState();
    }
  }

  /* Method : clearDragDropSections
   * This method to clear the drag and drop sections
   */
  clearDragDropSections() {
    this.contractsToAdd = _.concat(this.contractsToAdd, this.contractsAdded);
    this.lineOfBusinessToAdd = _.concat(this.lineOfBusinessToAdd, this.lineOfBusinessAdded);
    this.lineOfBusinessAdded = [];
    this.contractsAdded = [];
  }

  /* Method : setDragDropEditState
   * This method to set the drag and drop sections when a member subject is already set
   */
  setDragDropEditState() {
    this.lineOfBusinessToAdd.forEach((element) => {
      if (this.contractLOBs.length > 0) {
        if (this.contractLOBs[0].lname === element.codeValueDescription) {
          this.lineOfBusinessToAdd.splice(
            this.lineOfBusinessToAdd.indexOf(element),
            1
          );
          this.lineOfBusinessAdded.push(element);
        }
      }
    });

    this.contractsToAdd.forEach((element) => {
      if (this.contractLOBs.length > 0) {
        if (this.contractLOBs[0].cid === element.codeValueDescription) {
          this.contractsToAdd.splice(
            this.contractsToAdd.indexOf(element),
            1
          );
          this.contractsAdded.push(element);
        }
      }
    });
  }
}
