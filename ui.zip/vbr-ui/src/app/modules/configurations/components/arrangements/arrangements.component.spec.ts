import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ArrangementsComponent } from './arrangements.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { RouterTestingModule } from '@angular/router/testing';
import { TableModule } from '../../tables/index';
import { Store, StoreModule } from '@ngrx/store';
import { LoadingModule } from '../../../../shared/modules/loading/loading.module';
import {environment} from '../../../../../environments/environment';

describe('ArrangementsComponent', () => {
  let component: ArrangementsComponent;
  let fixture: ComponentFixture<ArrangementsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ArrangementsComponent],
      imports: [BrowserAnimationsModule, RouterTestingModule, TableModule,
        LoadingModule,
        StoreModule.forRoot({})],
        providers: [Store]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ArrangementsComponent);
    component = fixture.componentInstance;
    component.env = environment;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('ngOnInit - getArrangement() should be called', () => {
    spyOn(component, 'getArrangements');
    component.ngOnInit();
    expect(component.getArrangements).toHaveBeenCalled();
  });

  it('ngAfterContentChecked - component.contentCheck should be false', () => {
    component.ngAfterContentChecked();
    expect(component.contentCheck).toBeFalsy();
  });

  it('ngAfterContentChecked component.contentCheck should be true', () => {
    component.arrangements = {
      payToPfinID: 'BSR',
      paymentArrangementName: 'NewArrangement',
      status: 'IN'
    };
    component.ngAfterContentChecked();
    expect(component.contentCheck).toBeTruthy();
  });

  it('getArrangements - component.loadingService.show should have been called', () => {
    spyOn(component.loadingService, 'show');
    component.getArrangements();
    expect(component.loadingService.show).toHaveBeenCalled();
  });

  it('openModal - modalService.open should have been called', () => {
      spyOn(component.modalService, 'open');
      component.openModal('id');
      expect(component.modalService.open).toHaveBeenCalled();
  });

  it('closeModal - modalService.close should have been called', () => {
      spyOn(component.modalService, 'close');
      component.closeModal('id');
      expect(component.modalService.close).toHaveBeenCalled();
  });
});
