import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { RetroActivitySettingsComponent } from './retroactivity_settings.component';
import { UIModule } from '../../../../shared/modules/ui/ui.module';
import { TableModule } from '../../tables/index';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { CustomDateParserFormatter } from '../../../../shared/modules/ui/components/datepicker/customdateparserformatter';
import { NgbDateParserFormatter } from '@ng-bootstrap/ng-bootstrap';
import { RouterTestingModule } from '@angular/router/testing';

describe('RetroActivitySettingsComponent', () => {
  let component: RetroActivitySettingsComponent;
  let fixture: ComponentFixture<RetroActivitySettingsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [UIModule, TableModule, FormsModule, CommonModule, NgbModule, RouterTestingModule],
      declarations: [RetroActivitySettingsComponent],
      providers: [{
        provide: NgbDateParserFormatter,
        useClass: CustomDateParserFormatter
      },
      CustomDateParserFormatter]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RetroActivitySettingsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
