import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ModalService } from '../../../../shared/services/modal.service';
@Component({
  selector: 'app-retroactivity-settings',
  templateUrl: './retroactivity_settings.component.html',
  styleUrls: ['./retroactivity_settings.component.scss']
})
export class RetroActivitySettingsComponent implements OnInit {
  constructor(
    private route: ActivatedRoute,
    private modalService: ModalService
  ) {}
  arrangement = {
    name: null,
    payees: []
  };
  id = 0;
  bodyText: string;
  months: any;
  isCheckedFrequencyDate: boolean;
  isCheckedFrequencyMonth: boolean;
  retroactivity_settings: any;
  activityRetroType: any;
  retroFrequency: any;
  paymentRetroType: any;

  ngOnInit() {
    const id = this.route.snapshot.paramMap.get('id');
    // tslint:disable-next-line: radix
    this.id = parseInt(id);
  }

  cancel(id: string) {
    this.modalService.close(id);
  }

  save(id: string) {
    this.modalService.close(id);
  }

  setFrequency(frequency: string) {
    if (frequency === 'month') {
      this.isCheckedFrequencyMonth = true;
      this.isCheckedFrequencyDate = false;
    } else if (frequency === 'date') {
      this.isCheckedFrequencyDate = true;
      this.isCheckedFrequencyMonth = false;
    } else {
      return;
    }
  }
}
