import { Component, OnInit, OnDestroy, Inject } from '@angular/core';
import { ModalService } from '../../../../shared/services/modal.service';
import { UtilService } from 'src/app/shared/services/util.service';
import { UserCacheService } from '../../../../shared/services/user-cache.service';
import { ConfigurationService } from '../../services/configuration.service';
import {
  ALPHA_NUMERIC_PATTERN,
  PAYMENTTYPE_ROLES
} from '../../../../shared/constants/app.constants';
import {
  Payment,
  PaymentTypes,
  Errors
} from '../../../../models/configuration.model';
import { SharedService } from 'src/app/shared/services/shared.service';
// SSO
import { AuthService } from '../../../../shared/services/auth.service';
import { LoadingService } from '../../../../shared/modules/loading/loading.module';
import { ReturnMessage } from 'src/app/models/shared.model';
import { environment } from '../../../../../environments/environment';

@Component({
  selector: 'app-paymenttypes',
  templateUrl: './paymenttypes.component.html',
  styleUrls: ['./paymenttypes.component.scss']
})
export class PaymentTypesComponent implements OnInit, OnDestroy {
  corporateEntityCode: string;
  isPaymentTypeDesc: boolean;
  isValidPaymentType: boolean;
  paymentTypes: PaymentTypes;
  paymentType: Payment;
  modeldescription: any;
  isErrorMsgDisplay: boolean;
  isPaymentTypeAlreadyExists: boolean;
  paymentTypeSuccessMessage: string;  
  returnMessage:ReturnMessage;
  checkRoles: boolean;
  isSearchError: boolean;
  paymentTypeActualInformaiton: Payment;
  env = environment;
  isEdit: boolean;

  constructor(
    public modalService: ModalService,
    public utilService: UtilService,
    private userCacheService: UserCacheService,
    private configurationService: ConfigurationService,
    public authService: AuthService,
    public sharedService: SharedService,
    public loadingService: LoadingService
  ) { 
    this.sharedService.getCorpEntityCode().subscribe(data => this.corporateEntityCode = data);
  }

  /**
   * Lifecycle hook on page load
   */
  ngOnInit() {
    this.initializePaymentTypes();
    this.getPaymentTypes();
    
    // To enable UI components
    this.checkRoles = this.env.SSO_CONFIG.enableSSO ? !this.authService.isAuthorized(PAYMENTTYPE_ROLES) : false;
  }

  /* Method : initializePaymentTypes
   * This method to initialize the values to empty
   */
  initializePaymentTypes() {
    this.paymentType = { paymentTypeCode: '', paymentTypeDescription: '' };
  }
  /* Method : setUpperCase
   * This method is used to convert the string to upper case
   */
  setUpperCase() {
    this.paymentType.paymentTypeCode = this.paymentType.paymentTypeCode.toUpperCase();
  }

  /**
   * Method : close
   * @param id
   * Method to close the modal and reset the error and form
   */
  close(id: string) {
    this.clearErrorMessage();
    this.initializePaymentTypes();
    this.modalService.close(id);
    if (id === 'edit-paymenttype') {
      this.isEdit = false;
      this.getPaymentTypes();
    }
    this.isPaymentTypeAlreadyExists = false;
  }

  /* Method : getPaymentTypes
   * This method is used to call the service method to get the payment types
   */
  getPaymentTypes() {
    this.loadingService.show();
    this.configurationService.getArrangementPaymentTypes(this.corporateEntityCode).subscribe(
      (data: PaymentTypes) => {
        this.loadingService.hide();
        this.paymentTypes = data;
        this.isSearchError = false;
      },
      error => {
        this.loadingService.hide();
        this.handleErrorResponse(error);
      }
    );
  }
  /**
   * Method : Save
   * @param id and action
   * Method to save the added/updated payment type and payment description
   * On Success, message is shown as record added successfully on paymentType parent page after modal is closed
   * On Failure, message is shown as value already exists in database on modal with data populated
   */

  saveOrUpdatePaymentType(id: string, action: string) {
    this.sharedService.clearToasts();
    this.clearErrorMessage();
    this.loadingService.show();
    this.configurationService
      .saveOrUpdatePaymentType(this.generateRequestObject(action))
      .subscribe(
        (data: any) => {
          this.loadingService.hide();
          this.isPaymentTypeAlreadyExists = false;
          this.handleSuccessResponse(data);
          this.modalService.close(id);
          this.getPaymentTypes();
          this.initializePaymentTypes();
        },
        error => {
          this.loadingService.hide();
          this.handleErrorResponse(error);
        }
      );
  }
  /**
   * Method: HandleSuccessResponse
   * @param data
   * Method to get the message from success response and populate in payment type page
   */
  handleSuccessResponse(data: any) {
    if (data && data.message) {
      this.sharedService.handleErrorSuccessWarningInfo('SUCCESS', data);
    }
  }

  /**
   * Method to handle error from API
   * @param: error
   */
  handleErrorResponse(error: any) {
    if (error.returnMessage && error.returnMessage.errors && error.returnMessage.errors.length > 0) {
      this.returnMessage = error;
      this.isErrorMsgDisplay = true;
      this.rateOutlinedError(error.returnMessage.errors);
    } else {
      console.log('error  == >', JSON.stringify(error));
    }
  }

  /**
   * rateOutlinedError
   * @param errorFieldList
   * Method to check the error list and outline in red
   */
  rateOutlinedError(errorFieldList: any) {
    errorFieldList.forEach((data: any) => {
      if (data.fieldId === 'paymentTypeName') {
        this.isPaymentTypeAlreadyExists = true;
      }
      if (data.fieldId === 'paymentTypeDescription') {
        this.isPaymentTypeDesc = true;
      }
    });
  }

  /**
   * Method: GenerateRequestObject
   * @param: action
   * Method to create the request for add/update Payment Service based on action and return the value to Save Method
   */
  generateRequestObject(action: string) {
    const userId = this.userCacheService.getUserCacheData('USER_ID');
    const addOrUpdatePaymentTypeRequestObject = {
      paymentType: {
        createUserId: userId,
        updateUserId: userId,
        createRecordTimestamp: this.paymentType.createRecordTimestamp
          ? this.paymentType.createRecordTimestamp
          : '',
        updateRecordTimestamp: this.paymentType.updateRecordTimestamp
          ? this.paymentType.updateRecordTimestamp
          : '',
        paymentTypeCode: this.paymentType.paymentTypeCode,
        paymentTypeDescription: this.paymentType.paymentTypeDescription,
        rowAction: action,
        corporateEntityCode: this.corporateEntityCode
      }
    };
    return addOrUpdatePaymentTypeRequestObject;
  }

  /**
   * Method: editPaymentType
   * @param id and paymentType
   * Method to update the selected payment type
   */
  editPaymentType(id: string, paymentType: any) {
    this.isEdit = true;
    this.paymentTypeActualInformaiton = JSON.parse(JSON.stringify(paymentType));
    this.paymentType = paymentType;
    this.modalService.open(id);
  }

  /* Method : validatePaymentType
   * Args: matchString - payment type
   * This method is used to validate the payment type and show error message below the field.
   */
  validatePaymentType(matchString: any) {
    this.isValidPaymentType = !this.utilService.patterMatch(
      ALPHA_NUMERIC_PATTERN,
      matchString
    );
  }

  /**
   * Method to clear error messages
   */
  clearErrorMessage() {
    this.isErrorMsgDisplay = false;
    this.isValidPaymentType = false;
    this.isPaymentTypeDesc = false;
    this.isPaymentTypeAlreadyExists = false;
  }

  /**
   * Life cycle hook after component destroy
   */
  ngOnDestroy() {
    this.sharedService.clearToasts();
  }
}
