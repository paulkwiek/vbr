import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { CommonModule, CurrencyPipe } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';

import { PaymentTypesComponent } from './paymenttypes.component';
import { UIModule } from '../../../../shared/modules/ui/ui.module';
import { TableModule } from '../../tables/index';
import { Store, StoreModule } from '@ngrx/store';
import { LoadingModule } from '../../../../shared/modules/loading/loading.module';
import {environment} from '../../../../../environments/environment';

describe('PaymenttypesComponent', () => {
  let component: PaymentTypesComponent;
  let fixture: ComponentFixture<PaymentTypesComponent>;

  const paymentTypesData = {
    paymentTypes: [
      {
        corporateEntityCode: 'NM1',
        paymentTypeCategoryCode: 'CA1',
        createUserId: 'U402537',
        updateUserId: 'U402537',
        createRecordTimestamp: '2019-08-19T13:58:00',
        updateRecordTimestamp: '2019-08-20T08:11:09',
        rowAction: null,
        paymentTypeCode: '09876',
        paymentTypeDescription: '09876'
      },
      {
        corporateEntityCode: 'NM1',
        paymentTypeCategoryCode: 'CA1',
        createUserId: 'U402537',
        updateUserId: 'U402537',
        createRecordTimestamp: '2019-08-20T08:22:55',
        updateRecordTimestamp: '2019-08-20T09:58:58',
        rowAction: null,
        paymentTypeCode: '098760',
        paymentTypeDescription: '098763'
      },
      {
        corporateEntityCode: 'NM1',
        paymentTypeCategoryCode: 'CA1',
        createUserId: 'U402537',
        updateUserId: 'U402537',
        createRecordTimestamp: '2019-08-20T08:17:01',
        updateRecordTimestamp: '2019-08-20T08:17:01',
        rowAction: null,
        paymentTypeCode: '0987612',
        paymentTypeDescription: '09876'
      }
    ]
  };

  const addSuccessPaymentTypeData = {
    message: 'Records saved successfully.',
    paymentType: {
      createUserId: 'U402537',
      updateUserId: 'U402537',
      createRecordTimestamp: '2019-08-20T14:58:51.977',
      updateRecordTimestamp: '2019-08-20T14:58:51.977',
      rowAction: 'INSERT',
      paymentTypeCode: 'PaymentArT',
      paymentTypeDescription: 'Payment Arrangement Type Description35'
    }
  };
  const paymentType = {
    paymentTypeCode: '',
    paymentTypeDescription: '',
    createRecordTimestamp: '',
    updateRecordTimestamp: ''
  };

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        CommonModule,
        FormsModule,
        HttpClientModule,
        UIModule,
        TableModule,
        LoadingModule,
        StoreModule.forRoot({})
      ],
      declarations: [PaymentTypesComponent],
      providers: [CurrencyPipe, Store]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PaymentTypesComponent);
    component = fixture.componentInstance; 
    fixture.detectChanges();
    component.env = environment;
    component.paymentTypes = paymentTypesData;
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('close - component.modalService.close shoudld be called', () => {
    spyOn(component.modalService, 'close');
    component.close('string');
    expect(component.modalService.close).toHaveBeenCalled();
  });

  it('close - if id is edit-paymenttype, component.paymentTypes should be equal to paymentTypesData', () => {
    spyOn(component.modalService, 'close');
    component.close('edit-paymenttype');
    expect(component.paymentTypes).toEqual(paymentTypesData);
  });

  it('getPaymentTypes - component.paymentTypes shoudld be equal to  paymentTypesData', () => {
    component.getPaymentTypes();
    expect(component.paymentTypes).toEqual(paymentTypesData);
  });

  it('saveOrUpdatePaymentType - component.sharedService.clearToasts should have been called', () => {
    spyOn(component.sharedService,'clearToasts');
    component.paymentType = paymentType;
    component.saveOrUpdatePaymentType('string', 'INSERT');
    expect(component.sharedService.clearToasts).toHaveBeenCalled();
  });

  it('validatePaymentType - component.isValidPaymentType should be false', () => {
    component.validatePaymentType('Type45');
    expect(component.isValidPaymentType).toBeFalsy();
  });

  it('validatePaymentType - component.isValidPaymentType should be true', () => {
    component.validatePaymentType('Typ3$%');
    expect(component.isValidPaymentType).toBeTruthy();
  });

  it('handleErrorResponse - component.isErrorMsgDisplay should be true', () => {
    const error = { 'errors': [{ 'errorMessageId': 10000, 'errorMsgDescriptionText': 'Data could not be saved to the table. Please try again.', 'severitylevel': 'E', 'errorMessageCategoryCode': 'ERR' }] };
    component.handleErrorResponse(error);
    expect(component.isErrorMsgDisplay).toBeTruthy();
  });
  it('editPaymentType - modalService.open should have been called', () => {
      spyOn(component.modalService,'open');
    const paymenttype = {
      createUserId: 'U402537',
      updateUserId: 'U402537',
      createRecordTimestamp: '2019-08-19T13:58:00',
      updateRecordTimestamp: '2019-08-20T08:11:09',
      rowAction: null,
      paymentTypeCode: '09876',
      paymentTypeDescription: '09876'
    };
    component.editPaymentType('DESC', paymenttype);
    expect(component.modalService.open).toHaveBeenCalled();
  });

  it('setUpperCase - component.payment.paymentTypeCode should be in uppercase',()=>{
      component.paymentType.paymentTypeCode ='dec';
      component.setUpperCase();
      expect(component.paymentType.paymentTypeCode).toEqual('DEC');
  });

  it('refreshPaymentTypes - component.loadingService.show should have been called',()=>{
      spyOn(component.loadingService,'show');
      component.refreshPaymentTypes();
      expect(component.loadingService.show).toHaveBeenCalled();
  });

  it('handleSuccessResponse - component.sharedService.handleErrorSuccessWarningInfo should have been called',()=>{
      spyOn(component.sharedService,'handleErrorSuccessWarningInfo');
      let data ={
          response:'SUCCESS',
          message :"Success"
      };
      component.handleSuccessResponse(data);
      expect(component.sharedService.handleErrorSuccessWarningInfo).toHaveBeenCalled();
  });
});
