import { NgModule } from '@angular/core';
import { CommonModule, CurrencyPipe } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';

import { ConfigurationsRoutingModule } from './configurations-routing.module';
import { TableModule } from './tables';
import { ArrangementsComponent } from './components/arrangements/arrangements.component';
import { ArrangementComponent } from './components/arrangements/arrangement/arrangement.component';
import { PayeesComponent } from './components/payees/payees.component';
import { SigningOffComponent } from './components/signing-off/signing-off.component';
import { View404Component } from './components/view404/view404.component';
import { RatesComponent } from './components/rates/rates.component';
import { PaymentTypesComponent } from './components/paymenttypes/paymenttypes.component';
import { RateComponent } from './components/rates/rate/rate.component';
import { RetroActivitySettingsComponent } from './components/retroactivity_settings/retroactivity_settings.component';
import { SharedModule } from 'src/app/shared/shared.module';
import { PipesModule } from 'src/app/shared/pipes/pipes.module';
@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ConfigurationsRoutingModule,
    NgbModule,
    TableModule,
    SharedModule,
    PipesModule
  ],
  declarations: [
    ArrangementsComponent,
    ArrangementComponent,
    PayeesComponent,
    SigningOffComponent,
    View404Component,
    RatesComponent,
    PaymentTypesComponent,
    RateComponent,
    RetroActivitySettingsComponent
  ],
  providers: [SharedModule, PipesModule, CurrencyPipe]

})
export class ConfigurationsModule {}
