import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';

import { ArrangementsComponent } from './components/arrangements/arrangements.component';
import { ArrangementComponent } from './components/arrangements/arrangement/arrangement.component';
import { PayeesComponent } from './components/payees/payees.component';
import { RatesComponent } from './components/rates/rates.component';
import { PaymentTypesComponent } from './components/paymenttypes/paymenttypes.component';
import { RateComponent } from './components/rates/rate/rate.component';
import { RetroActivitySettingsComponent } from './components/retroactivity_settings/retroactivity_settings.component';

const routes: Routes = [
  {
    path: 'arrangements',
    component: ArrangementsComponent,
    data: {
      breadcrumb: 'Payment Arrangements'
    }
  },
  {
    path: 'arrangements/:id',
    component: ArrangementComponent,
    data: {
      breadcrumb: 'Arrangement'
    }
  },
  { path: 'payees', component: PayeesComponent },
  {
    path: 'rates',
    component: RatesComponent
  },
  { path: 'rates/:id', component: RateComponent },
  { path: 'paymenttypes', component: PaymentTypesComponent },
  { path: 'retroactivities', component: RetroActivitySettingsComponent }
];

@NgModule({
  imports: [CommonModule, RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ConfigurationsRoutingModule {}
