import { NgModule } from '@angular/core';
import { CommonModule, CurrencyPipe } from '@angular/common';
import { PipesModule } from 'src/app/shared/pipes/pipes.module';
import { ReportsRoutingModule } from './reports-routing.module';
import { TableauReportComponent } from './components/tableau/tableau-report.component';
import { TableauReportNavigationComponent } from './components/tableau/tableau-report-navigation/tableau-report-navigation.component';

@NgModule({
  imports: [
    CommonModule,
    ReportsRoutingModule
  ],
  declarations: [
    TableauReportComponent,
    TableauReportNavigationComponent
  ],
  providers: [
    PipesModule,
    TableauReportComponent
  ],
  exports: [
    TableauReportNavigationComponent
  ]
})
export class ReportsModule {}
