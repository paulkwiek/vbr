import { Component, ViewChild, AfterViewInit, ElementRef, ChangeDetectionStrategy } from '@angular/core';
import { Observable } from 'rxjs';
import { Store, State } from '@ngrx/store';
import { AppState } from '../../../../store/app.state';
import { ReportsService } from '../../services/reports.service';
import { UserCacheService } from '../../../../shared/services/user-cache.service';

declare var tableau: any;
@Component({
  selector: 'app-reporting',
  templateUrl: './tableau-report.component.html',
  styleUrls: ['./tableau-report.component.scss']
})
export class TableauReportComponent implements AfterViewInit {
  selectedReportId: Observable<any>;
  selectedReportName: Observable<any>;
  reportVizualizer: any;
  presentReportName: string;
  containerDiv: any;
  header: string;
  @ViewChild('vizContainer') vizContainer: ElementRef<any>;
  constructor(
    private store: Store<AppState>,
    private state: State<AppState>,
    private reportsService: ReportsService,
    private userCacheService: UserCacheService,
  ) {
    this.selectedReportId = this.store.select(
      state => state.reports.selectedReportId
    );
    this.selectedReportName = this.store.select(
      state => state.reports.selectedReportName
    );
  }
  /**
   * Method: ngAfterViewInit
   * Initilize the  report container
   */
  ngAfterViewInit() {
    this.containerDiv = this.vizContainer.nativeElement;
  }
  /**
  * Method: getReport
  * @param reportName :id attribute of report
  * if any report is available call getReportInfo method to update the header information
  * set the selected report as present record to avoid the getReport method call
  * Invoke initVizualizer to load the report
  */
  getReport(reportName: string) {
    if (reportName !== '' && reportName !== '0' && this.presentReportName !== reportName && reportName !== null && reportName !== undefined) {
      this.presentReportName = reportName;
      this.initVizualizer(this.reportsService.getReportUrl(reportName));
     // this.checkReportStatus(reportName);
    }
  }

  /* checkReportStatus(reportName: any ) {
    let repName  = this.reportsService.getReportUrl(reportName);
    if (reportName == 'CAP_SUMMARY_REPORT') {
      repName = repName + 'aaaaa';
    }

    this.reportsService.checkStatusCode(repName).subscribe(
      (data: any) => {
        console.log('AAAAAA', data);
        console.log(JSON.stringify(data));
      },
      error => {
        console.log('BBBBBBBBBBBBB', error);
        console.log(JSON.stringify(error));
      }
    );
  } */

  /**
  * Method: initVizualizer
  * @param reportUrl:URL for the report
  * Method to load the report in container
  */
  initVizualizer(reportUrl: string) {
    const options = { hideTabs: true, width: '150%', height: '900px', onFirstInteractive: function () {} };
    if (this.reportVizualizer) {
      this.reportVizualizer.dispose();
    }
    this.reportVizualizer = new tableau.Viz(this.containerDiv, reportUrl, options);
  }

}
