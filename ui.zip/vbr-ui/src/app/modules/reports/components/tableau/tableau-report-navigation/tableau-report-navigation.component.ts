import {
  Component,
  OnInit,
  Output,
  Input,
  EventEmitter,
  ViewChild
} from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { of, Observable } from 'rxjs';
import { Store } from '@ngrx/store';
import { AppState } from '../../../../../store/app.state';
import { ReportChangedAction } from 'src/app/store/reports/reports.actions';
import { Report } from '../../../../../models/configuration.model';
import { TableauReportComponent } from '../tableau-report.component';
import { ReportsService } from '../../../../reports/services/reports.service';
@Component({
  selector: 'app-reporting-navigation',
  templateUrl: './tableau-report-navigation.component.html',
  styleUrls: ['./tableau-report-navigation.component.scss']
})
export class TableauReportNavigationComponent implements OnInit {
  isCollapsed = false;
  selectedReportId: Observable<string>;
  reports: any;
  @Output() reportSelected = new EventEmitter<Report>();
  constructor(
    private route: ActivatedRoute,
    private store: Store<AppState>,
    private router: Router,
    private reportsService: ReportsService,
    private reporting: TableauReportComponent
  ) {
    this.getReportDetails();
    this.selectedReportId = this.store.select(
      state => state.reports.selectedReportId
    );
  }
  ngOnInit() {
    const id = this.route.snapshot.paramMap.get('id');
  }
  /**
   * Method: getReportDetails
   * This method is used to get the list of report details
   */
  getReportDetails() {
    this.reportsService.getReportDetails().subscribe(
      (data: any) => {
        this.reports = data;
      },
      error => {
      }
    );
  }
  onChangeReport(report: object) {
    this.router.navigate(['/reports/tableau-report']);
    this.store.dispatch(new ReportChangedAction(report));
  }
}
