import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';

import { TableauReportComponent } from './components/tableau/tableau-report.component';

const routes: Routes = [

  { path: 'tableau-report', component: TableauReportComponent }

];

@NgModule({
  imports: [CommonModule, RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ReportsRoutingModule {}
