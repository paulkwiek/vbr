import { Injectable } from '@angular/core';
import { resourceEndPoints } from '../../../shared/constants/app.constants';
import { HttpdataService } from '../../../shared/services/httpdata.service';
import { AppConfigService } from '../../../app-config.service';



@Injectable({
  providedIn: 'root'
})
export class ReportsService {

  protected BASE_URL = AppConfigService.settings.baseUrls.BASE_URL;

  protected BASE_URL_REPORT = AppConfigService.settings.baseUrls.BASE_URL_REPORT;
  protected REPORT_URL = AppConfigService.settings.reportUrls;

  constructor(private http: HttpdataService) { }

  /**
   * getReportUrl - Method used to retrive the selected report's report URL
   * @param reportName - selected report name
   */
  getReportUrl(reportName: string) {
    let selectReportURl: string;
    switch (reportName) {
      case 'CAP_SUMMARY_REPORT':
        selectReportURl = this.BASE_URL_REPORT + this.REPORT_URL.CAP_SUMMARY_REPORT;
        break;
      case 'MEMBERSHIP_ERROR_REPORT':
        selectReportURl = this.BASE_URL_REPORT + this.REPORT_URL.MEMBERSHIP_ERROR_REPORT;
        break;
      case 'COMPARISON_REPORT_FOR_APPROVED_FINANCIAL_CALCULATION_DATA':
        selectReportURl = this.BASE_URL_REPORT + this.REPORT_URL.COMPARISON_REPORT_FOR_APPROVED_FINANCIAL_CALCULATION_DATA;
        break;
      case 'COMPARISON_REPORT_FOR_PRELIMINARY_RUN_CALCULATION_DATA':
        selectReportURl = this.BASE_URL_REPORT + this.REPORT_URL.COMPARISON_REPORT_FOR_PRELIMINARY_RUN_CALCULATION_DATA;
        break;
      case 'COMPARISON_REPORT_FOR_APPROVED_CALCULATION_DATA':
        selectReportURl = this.BASE_URL_REPORT + this.REPORT_URL.COMPARISON_REPORT_FOR_APPROVED_CALCULATION_DATA;
        break;
      case 'RETROACTIVITY_SUMMARY_REPORT':
        selectReportURl = this.BASE_URL_REPORT + this.REPORT_URL.RETROACTIVITY_SUMMARY_REPORT;
        break;
      case 'NM10931_CAP_DISTRIBUTION_REPORT':
        selectReportURl = this.BASE_URL_REPORT + this.REPORT_URL.NM10931_CAP_DISTRIBUTION_REPORT;
        break;
      case 'NM10940_PRELIMINARY_EFT_REGISTER':
        selectReportURl = this.BASE_URL_REPORT + this.REPORT_URL.NM10940_PRELIMINARY_EFT_REGISTER;
        break;
      case 'NM10940_FINAL_EFT_REGISTER':
        selectReportURl = this.BASE_URL_REPORT + this.REPORT_URL.NM10940_FINAL_EFT_REGISTER;
        break;
      case 'NM10932_FINAL_OPEN_ITEM_REGISTER':
        selectReportURl = this.BASE_URL_REPORT + this.REPORT_URL.NM10932_FINAL_OPEN_ITEM_REGISTER;
        break;

    }
    return selectReportURl;
  }
  getReportDetails() {
    return this.http.get('assets/mocks/data/report-info.json');
  }
  // checkStatusCode(reportURL:string){
  //   return this.http.get(reportURL);
  // }

}


