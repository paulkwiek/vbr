export interface CodeSetValueItems {
    codeSetValueItems: CodeSetValueItem[];
  }

  export interface CodeSetValueItem {
    codeSetDescription: string;
    codeSetName: string;
    codeValueDescription: string;
    codeValueText: string;
    corporateEntityCode: string;
  }

  export interface  ReturnMessage {
    itemName: string;
    status: string;
    errors: Error[];
    warnings: Warnings[];
   }

  export interface Errors {
    errors: Error[];
  }

  export interface Error {
    componentName: string;
    fieldId: string;
    errorMessageId: string;
    errorMsgDescriptionText: string;
    severitylevel: string;
    errorMessageCategoryCode: string;
    validationClass: string;
  }

  export interface Warnings {
    errors: Warning[];
  }

  export interface Warning {
    componentName: string;
    fieldId: string;
    errorMessageId: string;
    errorMsgDescriptionText: string;
    severitylevel: string;
    errorMessageCategoryCode: string;
    validationClass: string;
}
