export interface SaveArrangement {
  arrangement: PaymentArrangement;
}

export interface PaymentArrangement {
  corporateEntityCode?: string;
  paymentArrangementContractId?: string;
  paymentArrangementName?: string;
  arrangementFrequencyCode?: string;
  paymentArrangementTypeCode?: string;
  paymentArrangementDescription?: string;
  recordEffectiveDate?: any;
  recordEndDate?: any;
  createUserId?: string;
  updateUserId?: string;
  createRecordTimestamp?: any;
  paymentArrangementId?: any;
  paymentTypeCode?: string;
  validationStatusCode?: string;
  rowAction?: string;
  overwriteSaveArrangement?: boolean;
  overwriteCancelArrangement?: boolean;
  retroRuleSetups?: any;
  paymentArrangementStatusDescription?: string;
  updateRecordTimestamp?: string;
  paymentArrangementHistories?: PaymentArrangementHistory[];
  paymentArrangementRates?: PaymentArrangementRate[];
  paymentArrangementMemberSubjects?: PaymentArrangementMemberSubject[];
  paymentArrangementPayees?: PaymentArrangementPayee[];

}
export interface PaymentArrangementHistory {
  arrangementFrequencyCode?: string;
  corporateEntityCode?: string;
  createRecordTimestamp?: string;
  createUserId?: string;
  paymentArrangementContractId?: any;
  paymentArrangementDescription?: string;
  paymentArrangementHistoryId?: number;
  paymentArrangementId?: number;
  paymentArrangementName?: string;
  paymentArrangementTypeCode?: string;
  paymentTypeCode?: string;
  recordEffectiveDate?: any;
  recordEndDate?: any;
  rowAction?: string;
  updateRecordTimestamp?: string;
  updateUserId?: string;
  validationStatusCode?: string;
}

export interface PaymentArrangementMemberSubject {
  paymentArrangementMemberSubjectId: any;
  paymentArrangementId: any;
  lineOfBusinessCode: string;
  contractId: string;
  createUserId: any;
  updateUserId: any;
  corporateEntityCode: string;
  rowAction: string;
  updateRecordTimestamp: any;
  createRecordTimestamp: any;
  accountnumber?: any;
  actionCode?: any;
  benefitArrangementNumber?: any;
  benefitPlanNumber?: any;
  benefitPlanStateCode?: any;
  captitationEntityCode?: any;
  copayCode?: any;
  fundingTypeCode?: any;
  groupId?: any;
  memberLocationId?: any;
  networkRiskLevelCode?: any;
  planStateCode?: any;
  productTypeCode?: any;
  sectionNumber?: any;
  siteId?: any;
}

export interface PaymentArrangementPayee {
  createUserId: string;
  updateUserId: string;
  recordEffectiveDate: string;
  recordEndDate: string;
  paymentArrangementPayeeId: number;
  vbrPayee: Payee;
  rowAction: string;
  createRecordTimestamp?: string;
  paymentArrangementId?: number;
  updateRecordTimestamp?: string;
  vbrPayeeId?: number;
}

export interface PaymentArrangementRate {
  paymentArrangementRateId: number;
  rateName: any;
  rateConfigTypeName: string;
  paymentArrangementId: any;
  corporateEntityCode: string;
  recordEffectiveDate: any;
  recordEndDate: any;
  createUserId: string;
  updateUserId: string;
  rowAction: string;
  createRecordTimestamp?: string;
  updateRecordTimestamp?: string;
}

export interface Payees {
  payees: Payee[];
}
export interface Payee {
  recordEffectiveDate?: string;
  recordEndDate?: string;
  vbrPayeeId?: number;
  corporateEntityCode?: string;
  pinGroupId?: string;
  pinGroupName?: string;
  capitationProcessCode?: string;
  networkCode?: string;
  capitationCode?: string;
  payToPfinId?: string;
  networkAssocProviderId?: any;
  networkAssociationID?: any;
  taxIdNumber?: string;
  createUserId?: string;
  updateUserId?: string;
  createRecordTimestamp?: any;
  updateRecordTimestamp?: any;
  rowAction?: string;
  payToPfinName?: string;
  networkAssociationEffectiveDate?: string;
  networkAssociationEndDate?: string;
  pfinEffectiveDate?: string;
  pfinEndDate?: string;
  pinGroupEffectiveDate?: string;
  pinGroupEndDate?: string;
  pingroupCapitationEffectiveDate?: string;
  pingroupCapitationEndDate?: string;
  tinEffectiveDate?: string;
  tinEndDate?: string;
}

export interface SavePayee {
  payee: Payee;
}

export interface ArrangementPayee {
  payeeType: string;
  corpEntityCode: string;
  pinGroupId: string;
}

export interface PayeeSearch {
  corpEntityCode?: string;
  pinGroupId?: string;
  networkAssociationID?: string;
  networkCode?: string;
  taxIdNumber?: string;
  payToPFIN?: string;
  capitationTypeCode?: string;
  processCode?: string;
  vbrPayeeId?: number;
  pinGroupName?: string;

}

export interface PayeeRetrieveSearch {
  corpEntityCode: string;
  networkAssociationID: string;
  networkCode: string;
  pinGroupId: string;
  payToPFIN: string;
  capitationTypeCode: string;
  processCode: string;
}

export interface CorporateEntity {
  name: string;
  abbrev: string;
}

export interface Providers {
  providers: Provider[];
}

export interface Provider {
  pinGroupEffectiveDate?: string;
  pinGroupEndDate?: string;
  pfinEffectiveDate?: string;
  pfinEndDate?: string;
  tinEffectiveDate?: string;
  tinEndDate?: string;
  networkAssociationEffectiveDate?: string;
  networkAssociationEndDate?: string;
  payToPfinId?: string;
  payToPfinName?: string;
  networkAssociationID?: string;
  payeeAddress?: PayeeAddress;
  capitationTypeCode?: string;
  capitationCode?: string;
  taxIdNumber?: string;
  processCode?: string;
  payToPFINPayeeAddress?: PayToPFINPayeeAddress;
  corporateEntityCode?: string;
  networkAssociationName?: string;
  pinGroupName?: string;
  pinGroupId?: string;
  networkCode?: string;
  vbrEndDate?: string;
  vbrEffDate?: string;
  vbrPayeeId?: number;
  tinAddress?: PayeeAddress;
  createRecordTimestamp?: any;
  updateRecordTimestamp?: any;
  pingroupCapitationEffectiveDate?: string;
  pingroupCapitationEndDate?: string;
}

export interface PayeeAddress {
  zipCode: string;
  city: string;
  addressLine1: string;
  addressLine2: string;
  state: string;
}

export interface PayToPFINPayeeAddress {
  zipCode: string;
  city: string;
  addressLine1: string;
  addressLine2: string;
  state: string;
}

export interface Errors {
  errors: Error[];
}

export interface Error {
  errorMessageId: string;
  description: string;
  severitylevel: string;
}

export interface VBRDates {
  VBRPayeeEffectiveDate: any;
  VBRPayeeEndDate: any;
}

export interface ArrangmentDates {
  arrangPayeeEffectiveDate: any;
  arrangPayeeEndDate: any;
}

export interface PaymentTypes {
  paymentTypes: Payment[];
}

export interface Payment {
  paymentTypeCode: string;
  paymentTypeDescription: string;
  createRecordTimestamp?: string;
  updateRecordTimestamp?: string;
}

export interface RateNames {
  rateNames: RateName[];
}

export interface RateName {
  createUserId?: string;
  updateUserId?: string;
  corporateEntityCode?: string;
  rateName?: string;
  rowAction?: string;
  rateConfigTypeName?: string;
  createRecordTimestamp?: string;
  updateRecordTimestamp?: string;
  flatRates?: Rate[];
}

export interface Rate {
  createUserId?: string;
  updateUserId?: string;
  recordEffectiveDate?: any;
  recordEndDate?: any;
  corporateEntityCode?: string;
  rateName?: string;
  femaleFlatRateAmount?: number;
  maleFlatRateAmount?: any;
  rowAction?: string;
  createRecordTimestamp?: string;
  updateRecordTimestamp?: string;
  flatRateId?: number;
  commentText?: string;
}

export interface GetLinkedArrangements {
  getLinkedArrangements: GetLinkedArrangement[];
}

export interface GetLinkedArrangement {
  paymentArrangementId: number;
  pinGroupName: string;
  pinGroupId: string;
  recordEffectiveDate: string;
  recordEndDate: string;
}

export interface Report {
  id: number;
  name: string;
  header: string;
}
