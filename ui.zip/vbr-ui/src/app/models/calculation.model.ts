export interface SaveCalculationRun {
  calculationRunName: string;
  corporateEntityCode: string;
  runTypeCode: string;
  runNameStatusCode: string;
  rowAction: string;
  createUserId: string;
  updateUserId: string;
  calculationGroupings: Codes[];
}
export interface Codes {
  calculationGroupingLevelCode: string;
  calculationRunName: string;
  calculationGroupingLevelValueText: string;
  selectedIndicator: string;
  createUserId: string;
  updateUserId: string;
  createRecordTimestamp: string;
  updateRecordTimestamp: string;
  rowAction: string;
}
export interface CalculationRunNames {
  calculationRunName: CalculationRunName[];
}
export interface CalculationRunName {
  createUserId: string;
  updateUserId: string;
  createRecordTimestamp: string;
  updateRecordTimestamp: string;
  rowAction: string;
  calculationRunName: string;
  corporateEntityCode: string;
  runTypeCode: string;
  runNameStatusCode: string;
  calculationGroupings: [];
  calculationRequests: [];
}
export interface ReviewCalculationRunNames {
  reviewCalculationRunNames: ReviewCalculationRunName[];
}
export interface ReviewCalculationRunName {
  createUserId: string;
  updateUserId: string;
  createRecordTimestamp: string;
  updateRecordTimestamp: string;
  rowAction: string;
  calculationRunName: string;
  corporateEntityCode: string;
  calculationRequestId: number;
  calculationRequestName: string;
  processPeriodDate: string;
  requestSubmittedTimestamp: string;
  requestSubmittedUserId: string;
  requestCommentText: string;
  calculationRequestStatusCode: string;
  parentCalculationRunName: any;
  calculationErrorLogs: [];
  calculationHistoryStatusList: [];
  calculationMemberDetailList: [];
  approvedCalculationMemberDetailList: [];
  calculationArrangementsList: [];
  calculationGroupingsDTOList: [];
}
export interface CalculationRunTypes {
  providers: CalculationRunType[];
}
export interface CalculationRunType {
  id: number;
  name: string;
}
export interface RunItems {
  id: number;
  type: string;
  label: string;
  columns: Array<ItemTypes>;
}

export interface ItemTypes {
  itemType: ItemType[];
}

export interface ItemType {
  id: number;
  name: string;
}

export interface ReviewStatus {
  calculationRunName: string;
  calculationRequestId: number;
  calculationRequestStatusCode: string;
  approvedBy: string;
  requestedTime: string;
  errorsOccuredDuringRun: any;
  processingTimeInMinutes?: any;
  calculationRequestStatusDescription?: string;
}

export interface Error {
  id: number;
  message: string;
}

export interface Errors {
  errors: Error[];
}
export interface List {
  type: string;
  name: string;
}
export interface ReviewStatusItems {
  reviewStatus: ReviewStatus[];
}

export interface Tab {
  id: string;
  aria: string;
  name: string;
  type: string;
  list: List[];
  date_modified: string;
}

export interface IndividualReviewCalculation {
  individualSummaryReviewCalculation: SummaryReviewCalculation;
  individualPayeeReviewCalculations: PayeeReviewCalcalations[];
  calculationReviewMonth: string;
}

export interface SummaryReviewCalculation {
  currentMembers: number;
  retroMembers: number;
  currentReimbursementAmount: number;
  retroReimbursementAmount: number;
  totalReimbursementAmount: number;
}

export interface PayeeReviewCalcalations {
  currentMembers: number;
  retroMembers: number;
  currentReimbursementAmount: number;
  retroReimbursementAmount: number;
  totalReimbursementAmount: number;
  payeeId: number;
  manualAdjustmentAmount: number;
  currentPMPM: number;
  overallPMPM: number;
}

export interface ComparePriorReviewCalculationResults {
  comparePriorPayeeDTO: ComparePriorPayeeResults;
  comparePriorSummaryDTO: ComparePriorSummaryResults;

}

export interface ComparePriorPayeeResults {
  currentComparePriorPayeeCalculation: PayeeReviewCalcalations[];
  payeeAbsoluteVarianceDTO: PayeeVariance[];
  payeePercentageVarianceDTO: PayeeVariance[];
  previousComparePriorPayeeCalculation: PayeeReviewCalcalations[];
}

export interface PayeeVariance {
  currentMembersVariance: number;
  currentPMPMVariance: number;
  currentReimbursementAmountVariance: number;
  manualReimbursementAmountVariance: number;
  overAllPMPMVariance: number;
  payeeId: string;
  retroMembersVariance: number;
  retroReimbursementAmountVariance: number;
  totalReimbursementAmountVariance: number;
}

export interface ComparePriorSummaryResults {
  absVariance: SummaryVariance;
  comparePriorCurrentSummaryReviewCalculation: SummaryReviewCalculation;
  comparePriorPreviousSummaryReviewCalculation: SummaryReviewCalculation;
  percentageVariance: SummaryVariance;
}

// tslint:disable-next-line: no-empty-interface
export interface SummaryCalculationResult {}

export interface SummaryVariance {
  currentMembersVariance: number;
  currentReimbursementAmountVariance: number;
  retroMembersVariance: number;
  retroReimbursementAmountVariance: number;
  totalReimbursementAmountVariance: number;
}
// export interface LineofBusiness {
//   calculationGroupingLevelCode: string,
//   calculationRunName: string,
//   calculationGroupingLevelValueText: string,
//   selectedIndicator: string,
//   createUserId: string,
//   updateUserId: string,
//   createRecordTimestamp:string,
//   updateRecordTimestamp:string,
//   rowAction:string
// }
