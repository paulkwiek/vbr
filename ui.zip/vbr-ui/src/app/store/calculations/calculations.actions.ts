import { Action } from '@ngrx/store';

export const CalculationActionsTypes = {
  TAB_CHANGED_ACTION: '[Calculations] -Tab changed-'
};

export class TabChangedAction implements Action {
  type = CalculationActionsTypes.TAB_CHANGED_ACTION;
  constructor(public payload: any) {}
}

export type CalculationActions = TabChangedAction;
