import { CalculationsTabState } from './calculations.state';
import {
  CalculationActions,
  CalculationActionsTypes
} from './calculations.actions';

export const appInitialState: CalculationsTabState = {
  selectedTab: 'nm-preliminary-1'
};

export function CalculationReducer(
  state = appInitialState,
  action: CalculationActions
): CalculationsTabState {
  switch (action.type) {
    case CalculationActionsTypes.TAB_CHANGED_ACTION: {
      return Object.assign(state, {
        ...state,
        selectedTab: action.payload
      });
    }

    default: {
      return state;
    }
  }
}
