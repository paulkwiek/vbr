export interface CalculationsTabState {
  selectedTab: string;
}
