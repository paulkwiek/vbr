import { CalculationsTabState } from './calculations/calculations.state';
import { ReportState } from './reports/reports.state';
import { CorporateEntityState } from './corporate-entity/corporate-entity.state';

// Newly added for SSO
import { AuthState } from 'hcsc-lib-sso';
import { createSelector } from '@ngrx/store';
import { getAuthorizationStates, getDecodedToken } from 'hcsc-lib-sso';

export interface AppState {
  calculations: CalculationsTabState;
  reports: ReportState;
  // Newly added for SSO
  authState: AuthState;
  corpEntity: CorporateEntityState;
}

 // Newly added for SSO
export const getAuthState = (state: AppState) => state.authState;

export const getAuthenticationState = createSelector(
  getAuthState,
  getAuthorizationStates
);

export const getAuthUserState = createSelector(
  getAuthState,
  getDecodedToken
);
