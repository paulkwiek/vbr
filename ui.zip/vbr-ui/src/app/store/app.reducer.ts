import { ActionReducerMap, createSelector } from '@ngrx/store';
import { AppState } from './app.state';
import { CalculationReducer } from './calculations/calculations.reducer';
import { ReportsReducer } from './reports/reports.reducer';
import { CorporateEntityReducer } from './corporate-entity/corporate-entity.reducer';
import { reducer } from 'hcsc-lib-sso';

export const reducers: ActionReducerMap<AppState> = {
  calculations: CalculationReducer,
  reports: ReportsReducer,
  corpEntity: CorporateEntityReducer,

  // Newly Added for SSO
  authState: reducer
};

// Newly Added for SSO
export function ssoMetaReducers() {
  return [];
}
