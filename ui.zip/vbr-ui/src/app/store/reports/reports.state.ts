export interface ReportState {
  selectedReportId: string;
  selectedReportName: string;
}
