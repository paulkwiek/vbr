import { Action } from '@ngrx/store';

export const ReportActionsTypes = {
  REPORT_CHANGED_ACTION: 'Reports Changed to ---'
};

export class ReportChangedAction implements Action {
  type = ReportActionsTypes.REPORT_CHANGED_ACTION;
  constructor(public payload: any) {}
}

export type ReportActions = ReportChangedAction;
