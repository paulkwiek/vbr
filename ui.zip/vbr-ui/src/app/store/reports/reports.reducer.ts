import { ReportState } from './reports.state';
import { ReportActions, ReportActionsTypes } from './reports.actions';

export const appInitialState: ReportState = {
  selectedReportId: '',
  selectedReportName: ''
};

export function ReportsReducer(
  state = appInitialState,
  action: ReportActions
): ReportState {
  switch (action.type) {
    case ReportActionsTypes.REPORT_CHANGED_ACTION: {
      return Object.assign(state, {
        ...state,
        selectedReportId: action.payload.id,
        selectedReportName: action.payload.name
      });
    }

    default: {
      return state;
    }
  }
}
