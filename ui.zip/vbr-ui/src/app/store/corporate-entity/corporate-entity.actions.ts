import { Action } from '@ngrx/store';

export const corporateEntityActionTypes = {
    SET_CORPORATE_ENTITY_CODE : '[Corporate Entity] Code Set Action',
    SET_CORPORATE_ENTITY_DESCRIPTION : '[Corporate Entity] Description Set Action',
    SET_CORPORATE_ENTITY_CODE_LIST : '[Corporate Entity] List Set Action'
};

export class SetCorporateEntityCodeAction implements Action {
    readonly type = corporateEntityActionTypes.SET_CORPORATE_ENTITY_CODE;
    constructor(public payload: any) {}
}

export class SetCorporateEntityDescriptionAction implements Action {
    readonly type = corporateEntityActionTypes.SET_CORPORATE_ENTITY_DESCRIPTION;
    constructor(public payload: any) {}
}


export class SetCorporateEntityListAction implements Action {
    readonly type = corporateEntityActionTypes.SET_CORPORATE_ENTITY_CODE_LIST;
    constructor(public payload: any) { }
}
