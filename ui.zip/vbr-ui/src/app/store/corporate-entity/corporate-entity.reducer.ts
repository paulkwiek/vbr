import { corporateEntityActionTypes, SetCorporateEntityCodeAction } from './corporate-entity.actions';
import { CorporateEntityState } from './corporate-entity.state';

export const initialGlobalState: CorporateEntityState = {
    selectedCorporateEntityCode: '',
    selectedCorporateEntityDescription: '',
    corporateEntityList: ''
};

export function CorporateEntityReducer(state = initialGlobalState, action: SetCorporateEntityCodeAction): CorporateEntityState {

    switch (action.type) {
        case corporateEntityActionTypes.SET_CORPORATE_ENTITY_CODE: {
            return Object.assign(state, { ...state, selectedCorporateEntityCode: action.payload });
        }
        case corporateEntityActionTypes.SET_CORPORATE_ENTITY_DESCRIPTION: {
            return Object.assign(state, { ...state, selectedCorporateEntityDescription: action.payload });
        }
        case corporateEntityActionTypes.SET_CORPORATE_ENTITY_CODE_LIST: {
            return Object.assign(state, { ...state, corporateEntityList: action.payload });
        }
        default: return state;

    }
}
