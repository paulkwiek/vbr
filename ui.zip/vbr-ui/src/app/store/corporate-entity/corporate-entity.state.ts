export interface CorporateEntityState {
    selectedCorporateEntityCode: any;
    selectedCorporateEntityDescription: any;
    corporateEntityList: any;
}
