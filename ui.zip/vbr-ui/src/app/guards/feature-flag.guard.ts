import { Injectable, Inject } from '@angular/core';
import { CanActivate, CanActivateChild, ActivatedRouteSnapshot, UrlSegment, Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class FeatureFlagGuard implements CanActivate, CanActivateChild {

  constructor(@Inject('env') private env: any, private router: Router) { }

  canActivate(route: ActivatedRouteSnapshot): Promise<boolean> {
    return this.evaluateRoles(route.url);
  }

  canActivateChild(childRoute: ActivatedRouteSnapshot): Promise<boolean> {
    return this.evaluateRoles(childRoute.url);
  }

  evaluateRoles(urlParams: UrlSegment[]): Promise<boolean> {
    const path = urlParams[0] && urlParams[0].path ? urlParams[0].path : '/';
    switch (path) {
      case 'configurations':
        if (this.env.FEATURE_FLAGS.configurations) {
          return Promise.resolve(true);
        } else {
          this.router.navigate([]);
          return Promise.resolve(false);
        }
      case 'calculations':
        if (this.env.FEATURE_FLAGS.calculations) {
          return Promise.resolve(true);
        } else {
          this.router.navigate([]);
          return Promise.resolve(false);
        }
        case 'reports':
          if (this.env.FEATURE_FLAGS.reports) {
            return Promise.resolve(true);
          } else {
            this.router.navigate([]);
            return Promise.resolve(false);
          }
      default:
        return Promise.resolve(true);
    }
  }
}
