import { Injectable, Inject } from '@angular/core';
import { CanActivate, Router, CanActivateChild } from '@angular/router';
import { Store } from '@ngrx/store';
import { map, take, filter } from 'rxjs/operators';

import { AppState, AuthState, getAuthState, AuthorizationState } from 'hcsc-lib-sso';
import { ALL_ROLES } from '../shared/constants/app.constants';


@Injectable({
  providedIn: 'root'
})
export class AppRouterGuard implements CanActivate, CanActivateChild {
  private user: AuthState;

  constructor(public store: Store<AppState>, private router: Router, @Inject('env') private env: any) {

  }

  canActivate(): Promise<boolean> {
    return this.env.SSO_CONFIG.enableSSO ? this.evaluateRoles() : new Promise(resolve => { resolve(true); });
  }

  canActivateChild(): Promise<boolean> {
    return this.evaluateRoles();
  }

  evaluateRoles(): Promise<boolean> {
    return new Promise(resolve => {
      this.store.select(getAuthState).pipe(
        filter(_ => _ != null
          && _.data != null
          && _.data.decodedToken != null
          && _.data.decodedToken.hcsc_private_claims != null
          && _.data.decodedToken.hcsc_private_claims.permissions != null),
        take(1),
        map(_ => {
          this.user = _;

          const activated = this.user.data.decodedToken.hcsc_private_claims.permissions.findIndex((permission) => {
            return ALL_ROLES.findIndex(
              (role) => permission.toLocaleLowerCase() === role.toLocaleLowerCase()
            ) !== -1;
          }) !== -1;

          if (!activated && this.user != null && this.user.data.authorizationStatus === AuthorizationState.IS_AUTHORIZED) {
            this.router.navigate(['/unauthorized']);
            resolve(false);
          } else if (activated) {
            resolve(true);
          }
        })).subscribe();
    });
  }

}
