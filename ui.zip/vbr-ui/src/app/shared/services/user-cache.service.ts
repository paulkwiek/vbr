import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class UserCacheService {

  private userCacheMap: any;

  constructor() {
    this.userCacheMap = {};
  }

  /**
   * This function checks local storage for any offloaded data for this cache
   */
  loadFromLocalStorage() {
    const localUserCache: any = localStorage.getItem('localUserCache');
    if (localUserCache != undefined && localStorage !== null) {
      this.userCacheMap = JSON.parse(localUserCache);
      localStorage.removeItem(localUserCache);
    }
  }

  /**
   * This function is used to prevent the cache on page refresh
   */
  backupToLocalStorage() {
    localStorage.setItem('localUserCache', JSON.stringify(this.userCacheMap));
  }

  /**
   * This function is used to get the specific data from cache based on the value
   * @param key {String}
   */
  getUserCacheData(key: string) {
    return this.userCacheMap[key];
  }

  /**
   * This function is used to set data from cache based on the key value
   * @param key {String} - The map key
   * @param data {any} - The data to save
   */
  setUserCacheData(key: string, data: any) {
    this.userCacheMap[key] = data;
  }

  /**
   * This function is used to erase the specific data from cache based on the value
   * @param key {String} - The map key should we erase
   */
  eraseUserCacheData(key: string) {
    this.userCacheMap[key] = undefined;
  }
}
