import { Injectable } from '@angular/core';
import { Workbook } from 'exceljs';
import * as fs from 'file-saver';
// import * as logoFile from './carlogo.js';
// import { DatePipe } from '../../node_modules/@angular/common';
@Injectable({
  providedIn: 'root'
})
export class ExcelService {
  /**
   * Method - generateWorkBook
   * This method is used to create excel workbook
   */
  generateWorkBook() {
    return new Workbook();
  }
  /**
   * Method - generateWorkSheet
   * Param  - workbook
   *        - Worksheet Name
   * This method is used to create worksheet in the specified workbook
   */
  generateWorkSheet(workbook: any, worksheetName: string, ) {
    return workbook.addWorksheet(worksheetName);
  }
  /**
  * Method - generateExcel
  * @param:- workbook
  *        - Worksheet Name
  *        - title (Showing processing period)
  *        - header -Column headers
  *        - data Rows
  *        - mergeCell - cells range to merge
  *        - columnWidth - specifies the column width
  * This method is used to do
  */

  generateExcel(workbook: any, worksheetName: string, title: string, header: any, data: any, mergeCell: string, columnWidth: any) {
    const worksheet = workbook.getWorksheet(worksheetName);
    // Add Title Row and applying style
    const titleRow = worksheet.addRow([title]);
    titleRow.eachCell((cell, number) => {
      cell.border = { right: { style: 'thin' } };
      cell.alignment = { vertical: 'middle', horizontal: 'center' };
    });
    this.mergeCells(worksheet, mergeCell);

    // Add Header Row and applying style
    const headerRow = worksheet.addRow(header);
    headerRow.eachCell((cell, number) => {
      cell.border = { top: { style: 'thin' }, left: { style: 'thin' }, bottom: { style: 'thin' }, right: { style: 'thin' } };
    });
    headerRow.font = { bold: true };

    // Add Data and Conditional Formatting
    data.forEach(d => {
      const row = worksheet.addRow(d);
      row.eachCell((cell, number) => {
        cell.border = { top: { style: 'thin' }, left: { style: 'thin' }, bottom: { style: 'thin' }, right: { style: 'thin' } };
      });
    });

    this.setColumnWidth(worksheet, columnWidth);
    return workbook;
  }
  /**
   * Method - mergeCells
   * @param:- workbook
   *        - mergeCell - cells range to merge
   * This method is used to do merge the cells based on the Range
   */
  mergeCells(worksheet: any, mergeCell: any) {
    if (mergeCell != '') {
      worksheet.mergeCells(mergeCell);
    }
  }
  /**
   * Method - mergeCells
   * @param:- workbook
   *        - columnWidth - specifies the column width
   * This method is used to do
   */
  setColumnWidth(worksheet: any, columnWidth: any) {
    if (columnWidth != '') {
      const columnWidthLength = columnWidth.length;
      if (columnWidthLength > 0) {
        for (let i = 0; i < columnWidthLength; i++) {
          worksheet.getColumn(i + 1).width = columnWidth[i];
        }
      }
    }
  }
  /**
   * Method - downloadFile
   * @param:- workbook
   *        - workBookName - specifies file name to download
   * This method is used to download the excel File
   */
  downloadFile(workbook: any, workBookName: string) {
    // Generate Excel File with given name
    workbook.xlsx.writeBuffer().then((data) => {
      const blob = new Blob([data], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
      fs.saveAs(blob, workBookName + '.xlsx');
    });
  }
}
