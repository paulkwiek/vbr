import { HTTP_INTERCEPTORS } from '@angular/common/http';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { ActivatedRouteSnapshot } from '@angular/router';
import { InjectionToken, NO_ERRORS_SCHEMA } from '@angular/core';
import { getTestBed, inject, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { JwtHelperService } from '@auth0/angular-jwt';
import { Store, StoreModule } from '@ngrx/store';

import * as fromRoot from '../../reducers';
import { AuthenticateSuccess } from '../../actions/auth-user.actions';
import { AuthUser, HCSCRoles, SCPRoles, RoleTypes } from '../../models/auth-user.model';
import { AuthService } from './auth.service';

export class MockComponent {

}

const externalUrlProvider = new InjectionToken('externalUrlRedirectResolver');

const routes = [{
    path: 'externalLogout',
    component: MockComponent,
    resolve: {
        url: externalUrlProvider
    },
    data: {
        externalUrl: 'http://www.google.com'
    }
}];

describe('AuthServiceService', () => {
    let injector: TestBed;
    let service: AuthService;
    let httpMock: HttpTestingController;
    let store: Store<fromRoot.State>;
    const jwtService = new JwtHelperService(null);

    beforeEach(() => {
        TestBed.configureTestingModule({
            imports: [
                HttpClientTestingModule,
                RouterTestingModule.withRoutes(routes),
                StoreModule.forRoot({
                    ...fromRoot.reducers
                })
            ],
            providers: [
                AuthService,
                { provide: JwtHelperService, useValue: jwtService },
                { provide: HTTP_INTERCEPTORS, multi: true },
                {
                    provide: externalUrlProvider,
                    useValue: (route: ActivatedRouteSnapshot) => {
                        const externalUrl = route.data['externalUrl'];
                    },
                }
            ],
            schemas: [NO_ERRORS_SCHEMA]
        });
        injector = getTestBed();
        service = injector.get(AuthService);
        httpMock = injector.get(HttpTestingController);
        store = TestBed.get(Store);
    });

    afterEach(() => {
        httpMock.verify();
    });

    it('should be created', inject([AuthService], (service: AuthService) => {
        expect(service).toBeTruthy();
    }));

    it('should execute authenticateUser and return user', inject([AuthService], (service: AuthService) => {
        const expected: AuthUser = { uuid: '123' };
        spyOn(jwtService, 'decodeToken').and.returnValue(expected);
        const username = 'sam';
        const password = 'mypassword';

        service.authenticateSmSession().subscribe(result => {
            expect(result).toEqual(expected);
        });

        const req = httpMock.expectOne(service.SM_SESSION_API_PATH);
        expect(req.request.method).toBe('POST');
        req.flush(expected);

    }));

    it('should execute call with 401', inject([AuthService], (service: AuthService) => {
        const username = 'sam';
        const password = 'mypassword';

        spyOn(service, 'clearAppStateAndLogout');
        service.authenticateSmSession().subscribe({
            error(actualError) { }
        });

        const req = httpMock.expectOne(service.SM_SESSION_API_PATH);
        req.flush('[Unauthorized] Token Expired', { status: 401, statusText: 'Unauthorized' });

        httpMock.verify();
        expect(service.clearAppStateAndLogout).toHaveBeenCalled();

    }));

    it('should execute isAuthenticated with true', inject([AuthService], (service: AuthService) => {
        store.dispatch(new AuthenticateSuccess({}));
        const result = service.isAuthenticated();
        expect(result).toBe(true);
    }));

    it('should execute isAuthorized with true', inject([AuthService], (service: AuthService) => {
        store.dispatch(new AuthenticateSuccess({ roles: ['mock-admin'] }));
        const result = service.isAuthorized(['mock-admin']);
        expect(result).toBe(true);
    }));

    it('should execute isHcsc with true', inject([AuthService], (service: AuthService) => {
        store.dispatch(new AuthenticateSuccess({ roles: HCSCRoles }));
        const result = service.isHcscRole();
        expect(result).toBe(true);
    }));

    it('should execute isScp with true', inject([AuthService], (service: AuthService) => {
        store.dispatch(new AuthenticateSuccess({ roles: SCPRoles }));
        const result = service.isScpRole();
        expect(result).toBe(true);
    }));

    it('should execute isOnlyAcctMgmtRole with true', inject([AuthService], (service: AuthService) => {
        store.dispatch(new AuthenticateSuccess({ roles: [RoleTypes.HCSC_ACCT_MGNT] }));
        const result = service.isOnlyAcctMgmtRole();
        expect(result).toBe(true);
    }));

    it('should execute isOnlyAcctMgmtRole with false', inject([AuthService], (service: AuthService) => {
        store.dispatch(new AuthenticateSuccess({ roles: HCSCRoles}));
        const result = service.isOnlyAcctMgmtRole();
        expect(result).toBe(false);
    }));

    // it('should execute getUserPrefixes with value', inject([AuthService], (service: AuthService) => {
    //     const mockPrefixes = ['AAA', 'BBB'];
    //     store.dispatch(new AuthenticateSuccess({ prefixes: mockPrefixes }));
    //     const result = service.getUserPrefixes();
    //     expect(result).toBe(mockPrefixes);
    // }));

    it('should execute refreshToken and return jwt', inject([AuthService], (service: AuthService) => {
        const expected: AuthUser = { uuid: '123' };
        spyOn(jwtService, 'decodeToken').and.returnValue(expected);

        service.refreshToken().subscribe(result => {
            expect(result).toEqual(expected);
        });

        const req = httpMock.expectOne(service.REFRESH_API_PATH);
        expect(req.request.method).toBe('POST');
        req.flush(expected);
    }));

    it('should execute logout', inject([AuthService], (service: AuthService) => {
        service.clearAppStateAndLogout();
    }));

    it('should execute ngDestroy', inject([AuthService], (service: AuthService) => {
        service.ngOnDestroy();
    }));

    it('should execute start timer', inject([AuthService], (service: AuthService) => {
        service.startExpirationTimer(new Date(), 30);
    }));

    it('should execute refreshToken', inject([AuthService], (service: AuthService) => {
        service.refreshToken();
    }));

});
