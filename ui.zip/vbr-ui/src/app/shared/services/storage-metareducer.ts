import { ActionReducer, Action } from '@ngrx/store';
import _ from 'lodash';
import { LocalStorageService } from './localstorage.service';

// tslint:disable-next-line: max-line-length
export function storageMetaReducer<S, A extends Action = Action>(
  saveKeys: string[],
  localStorageKey: string,
  storageService: LocalStorageService
) {
  let onInit = true; // after load/refresh…
  return function(reducer: ActionReducer<S, A>) {
    return function(state: S, action: A): S {
      // get to the nextState.
      const nextState = reducer(state, action);
      // init the application state.
      if (onInit) {
        onInit = false;
        const savedState = storageService.getSavedState(localStorageKey);
        return _.merge(nextState, savedState);
      }

      // save the next state to the application storage.
      const stateToSave = _.pick(nextState, saveKeys);
      storageService.setSavedState(stateToSave, localStorageKey);

      return nextState;
    };
  };
}
