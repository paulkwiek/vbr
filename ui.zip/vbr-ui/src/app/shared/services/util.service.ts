import { Injectable } from '@angular/core';
import { CurrencyPipe } from '@angular/common';
import { format } from 'url';
import { CustomDateParserFormatter } from '../../shared/modules/ui/components/datepicker/customdateparserformatter';
import {
  ALPHA_NUMERIC_PATTERN,
  DATE_PATTERN,
  PAYEES_ROLES,
  AMOUNT_PATTERN_WITH_6_DIGITS_AND_2_DECIMALS,
  NUMBER_PATTERN_FOR_RATE
} from '../../shared/constants/app.constants';

@Injectable({
  providedIn: 'root'
})
export class UtilService {
  constructor(private currencyPipe: CurrencyPipe, private customDateParserFormatter: CustomDateParserFormatter) { }

  /* function:ngbDatepPickerFormatter()
   * date : Date - MM/DD/YYYY
   * Method to convert the date into ngbDatepPicker format
   **/
  ngbDatepPickerFormatter(date: any) {
    const dateArr = date.split('/');
    // tslint:disable-next-line: radix
    return {
      // tslint:disable-next-line: radix
      year: parseInt(dateArr[2]),
      // tslint:disable-next-line: radix
      month: parseInt(dateArr[0]),
      // tslint:disable-next-line: radix
      day: parseInt(dateArr[1])
    };
  }

  /* function:patterMatch()
   * args : patternToMatch - Pattern to Match; toBeMatch - String to match
   * Method is used to check the patten is matching or not
   **/
  patterMatch(patternToMatch: any, toBeMatch: any) {
    if (toBeMatch == '') {
      return true;
    } else {
      return patternToMatch.test(toBeMatch);
    }
  }

  /**
   * Method: getFormattedDate
   * @param timeStamp
   * Method to get date from timestamp for display
   * Specifically created for Rate
   */
  getFormattedDate(timeStamp: string) {
    const date: any = new Date(timeStamp);
    return (
      String(date.getMonth() + 1).padStart(2, '0') +
      '/' +
      String(date.getDate()).padStart(2, '0') +
      '/' +
      date.getFullYear()
    );
  }

  /**
   * Method: getFormattedTime
   * @param timeStamp
   * Method to get time from timestamp for display
   * Specifically created for Rate
   */
  getFormattedTime(timeStamp: string) {
    const time: string = new Date(timeStamp).toLocaleTimeString();
    const timeSplit: any = time.split(':');
    const secondsSplit: any = timeSplit[2].split(' ');
    return timeSplit[0] + '.' + timeSplit[1] + ' ' + secondsSplit[1];
  }

  /**
   * Method: getFormattedAmount
   * @param action, amount
   * Method to format the amount based on focus in and out actions
   */

  getFormattedAmount(action: string, amount: any) {
    let formattedAmount =
      amount !== null && amount !== undefined
        ? amount.toString().indexOf('$') > -1
          ? this.getUnFormattedAmount(amount)
          : amount
        : null;
    if (action === 'focusOut' && amount !== null && amount !== undefined) {
      formattedAmount = this.getFormattedCurrency(formattedAmount);
    }
    return formattedAmount;
  }

  getUnFormattedAmount(amount: any) {
    return Number(amount.replace(/[^.0-9.-]+/g, ''));
  }

  /**
   * Method : getFormattedCurrency
   * @param amount
   * Method to format US currency without decimals
   */

  getFormattedCurrency(amount: any) {
    return this.currencyPipe.transform(amount, 'USD', true, '1.2-2');
  }
  /**
   * isEmptyCheck
   * @param value
   * Check and return true if the value is empty else false
   */
  isEmptyCheck(value: string) {
    return (value === '' || value === undefined || value === null);
  }


  /**
   * getDataFromCode
   * @param code
   * @param data
   * Mehtod to get the data from passing code
   */
  getDataFromCode(code: string, data: any) {
    const value: any = data.codeSetValueItems.find(
      (codeValue: any) => codeValue.codeValueText === code
    );
    return value;
  }

  /* Method : validateEffEndDates
   * This method is used to do validate effective and end dates range fields
   */
  validateEffEndDates(effectiveDate, endDate) {
    return (!this.validateDate(effectiveDate) || !this.validateDate(endDate));
  }

  /* Method : validateDate
   * This method is used to do date validation
   */
  validateDate(date: any) {
    return ((date !== '' && date !== null && date !== undefined)
      ? (this.patterMatch(DATE_PATTERN, this.customDateParserFormatter.format(date)))
      : false);
  }

   /* Method : validateAmount
   * @param number: amount
   * This method is used to do amount validation for the mentioned PATTERN
   */
  validateAmount(amount: any) {
    const formattedAmount = parseFloat(amount);
    return !(this.patterMatch(
      AMOUNT_PATTERN_WITH_6_DIGITS_AND_2_DECIMALS,
      formattedAmount
    ));
  }

  /**
   * validateNumber
   * @param data
   * Function to validate if the data is numberic
   */
  validateNumber(data: any) {
    return !(
      this.patterMatch(NUMBER_PATTERN_FOR_RATE, data) && data > 0
    );
  }
}
