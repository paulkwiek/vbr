import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';

export interface Results {
  adjustment: boolean;
  line_of_business: boolean;
  product_type: boolean;
  payment_type: boolean;
}

const initialResults: Results = {
  adjustment: true,
  line_of_business: true,
  product_type: true,
  payment_type: true
};

@Injectable()
export class ResultsService {
  private readonly _resultChanges = new BehaviorSubject<Results>(
    initialResults
  );
  readonly results = this._resultChanges.asObservable();
  updateDropdowns(condition: boolean) {
    const results = { ...this._resultChanges.value };
    this._resultChanges.next(results);
  }
}
