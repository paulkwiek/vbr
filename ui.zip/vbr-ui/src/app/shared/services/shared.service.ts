import { Injectable } from '@angular/core';
import { resourceEndPoints } from '../../shared/constants/app.constants';
import { HttpdataService } from '../../shared/services/httpdata.service';
import { AppConfigService } from '../../app-config.service';
import { UserCacheService } from '../../shared/services/user-cache.service';
import { Message } from '../modules/toast/toast-constants';
import { GlobalConfig } from '../modules/toast/toast-config';
import { ToastService } from '../modules/toast/toast.service';
import { cloneDeep } from 'lodash';
import { LoadingService } from 'src/app/shared/modules/loading/loading.module';
import { Store } from '@ngrx/store';
import { AppState } from '../../store/app.state';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class SharedService {
  messages: Message[];
  options: GlobalConfig;
  text = '';
  private lastInserted: number[] = [];
  protected BASE_URL = AppConfigService.settings.baseUrls.BASE_URL;
  protected BASE_URL_CODE_SERVICE = AppConfigService.settings.baseUrls.BASE_URL_CODE_SERVICE;
  protected BASE_URL_REPORT = AppConfigService.settings.baseUrls.BASE_URL_REPORT;
  corporateEntityCode: string;
  selectedCorporateEntityList: Observable<any>;
  selectedCorporateEntityDescription: Observable<any>;
  selectedCorporateEntity: Observable<any>;

  constructor(private http: HttpdataService, private userCacheService: UserCacheService, public toast: ToastService, private loadingService: LoadingService, private store: Store<AppState>) {
    this.options = this.toast.toastConfig;
    this.getCorpEntityCode().subscribe(data => this.corporateEntityCode = data);
  }

  /**
   * getCodeValues
   * @param param
   * Method to get code set values from code set table API
   */
  getCodeValues(param: string) {
    return this.http.get(this.BASE_URL_CODE_SERVICE + resourceEndPoints.GET_CODE + '/' + this.corporateEntityCode + '/' + param);
  }


  /**
  * getEntityCorpValues
  * @param param
  * Method to get corporate entity code set values from code set table API
  */
  getEntityCorpValues() {
    return this.http.get(this.BASE_URL_CODE_SERVICE + resourceEndPoints.RETRIEVE_CORP_ENTITY_CODE);
  }

  /* Method : openToast
  * This method is used design the sucess and error messages from the backed reponse.
  */
  openToast(messageType: string, message: string, title?: string) {
    this.options.imageClass = this.options.iconClasses[messageType] + '-image';

    const opt = cloneDeep(this.options);
    this.toast.toasts.push(this.toast.show(
      message,
      title,
      opt,
      this.options.iconClasses[messageType]
    ));
  }



  /* Method : handleErrorSuccessWarningInfo
  * This method is to handle toast type and its class
  */
  handleErrorSuccessWarningInfo(messageType: string, response: any, heading?: string) {
    let messageList;
    if (messageType == 'SUCCESS') {
      this.openToast('success', response.message);
      this.options.timeOut = 10000;
      this.options.extendedTimeOut = 5000;
      this.options.disableTimeOut = false;
    } else if (messageType == 'FAILURE') {
      this.options.disableTimeOut = true;
      this.toast.toastConfig.easeTime = 0;
      this.options.positionClass = 'toast-top-right';
      if (response.returnMessage && response.returnMessage.errors) {
        messageList = this.generateMessage(response.returnMessage.errors);
        messageList += this.generateMessage(response.returnMessage.warnings);
      } else {
        messageList = this.generateMessage(response.errors);
        messageList += this.generateMessage(response.warnings);
      }
      this.openToast('info', messageList, heading);
    }
  }

  /* Method : handleWarnings
    * This method is to handle warnings
    */
  handleWarnings(messageType: string, response: any, heading?: string) {
    let messageList;

    if (messageType == 'WARNINGS') {
      this.options.disableTimeOut = true;
      if (response.returnMessage && response.returnMessage.warnings) {
        messageList = this.generateMessage(response.returnMessage.warnings);
      }
      this.openToast('info', messageList, heading);
    }
  }
  /* Method : generateMessage
   * This method is to construct the error and warning message with bullet points
   */
  generateMessage(errors: any) {
    let errorText = '';
    for (const error in errors) {
      errorText +=
        '<br/>' +
        '<li>' +
        errors[error].errorMsgDescriptionText +
        '</li>';
    }
    return errorText;

  }

  /* Method : clearToasts
   * This method is to clear toasts
   */
  clearToasts() {
    this.toast.clear();
  }

  /* Method : selectedCorpEntityDescription
   * This method is to retrieve corporate entity description in app component
   */
  selectedCorpEntityDescription(list: any, selectedCode: any) {
    let description: any;
    list.forEach(element => {
      if (selectedCode == element.corporateEntityCode) {
        description = element.corporateEntityDescription;
      }
    });
    return description;
  }

  /* Method : getCorpEntityCode
   * This method is to retrieve corporate entity code
   */
  getCorpEntityCode() {
    return this.store.select(
      state => state.corpEntity.selectedCorporateEntityCode
    );
  }

  /* Method : getCorpEntityDescription
   * This method is to retrieve corporate entity description
   */
  getCorpEntityDescription() {
    return this.store.select(
      state => state.corpEntity.selectedCorporateEntityDescription
    );
  }

  /* Method : getCorpEntityList
   * This method is to retrieve corporate entity list
   */
  getCorpEntityList() {
    return this.store.select(
      state => state.corpEntity.corporateEntityList
    );
  }
}
