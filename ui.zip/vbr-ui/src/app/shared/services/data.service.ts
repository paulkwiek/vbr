import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class DataService {

  private userData: any = null;
  private successData: any = null;
  private processingMonth: any = null;

  private userDataChanged = new BehaviorSubject<any>(this.userData);
  private successDataChanged = new BehaviorSubject<any>(this.successData);
  public userDataInstance = this.userDataChanged.asObservable();
  public successDataInstance = this.successDataChanged.asObservable();
  private processingMonthData = new BehaviorSubject<any>(this.processingMonth);

  constructor() { }

  setUserData(data: any) {
    this.userDataChanged.next(data);
  }

  /* Method : setSuccessMessage
     * This method to set the success message used in rate component
     */
  setSuccessMessage(data: any) {
    this.successDataChanged.next(data);
  }

  /* Method : getSuccessMessage
     * This method to return the success message used in rate component
     */
  getSuccessMessage() {
    return this.successDataInstance;
  }

  /* Method : getProcessingMonth
     * This method to get the processing month value
     */
    getProcessingMonth(data: any) {
      this.processingMonthData.next(data);
    }

    /* Method : setProcessingMonth
       * This method to return the processing month value
       */
      setProcessingMonth() {
      return this.processingMonthData;
    }
}
