import { Injectable, OnDestroy } from '@angular/core';

// SSO
import getValue from 'object-getvalue';
import {
  DecodedToken,
  AppState,
  getAuthUserState
} from 'hcsc-lib-sso';
import { Subscription } from 'rxjs';
import { Store } from '@ngrx/store';

@Injectable({ providedIn: 'root' })
export class AuthService implements OnDestroy {
  // SSO
  user: DecodedToken;
  user$: Subscription;

  constructor(public store: Store<AppState>) { }

  public isAuthorized(requiredPermissions: string[]): boolean {

    this.user$ = this.store.select(getAuthUserState).subscribe(user => {
      this.user = user;
    });
    const permissions = getValue(this, 'user.hcsc_private_claims.permissions');
    if (!permissions) {
      return false;
    }
    return (
      this.user.hcsc_private_claims.permissions.find(permission => {
        return (
          requiredPermissions.find(
            permissionName => permission === permissionName
          ) != null
        );
      }) != null
    );
  }

  public getCorpCode() {
    this.user$ = this.store.select(getAuthUserState).subscribe(user => {
      this.user = user;
    });
    const corpCode = getValue(this, 'user.hcsc_private_claims.corpcode');

    return corpCode;
  }

  ngOnDestroy() {
    this.user$.unsubscribe();
  }

}
