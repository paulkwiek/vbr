import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';

import { UIModule } from './modules/ui/ui.module';
import { DragDropListModule } from './modules/dragDropLists/dragDropLists.module';
import { DataTableModule } from './modules/data-table';
import { LoadingModule } from './modules/loading/loading.module';
import { PopOverModule } from './modules/popover/popover.module';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {
  ToastModule,
  ToastContainerModule,
  ToastNoAnimationModule
} from './modules/toast';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    NgbModule,
    UIModule,
    DataTableModule,
    DragDropListModule,
    LoadingModule,
    PopOverModule,
    ToastNoAnimationModule,
    ToastModule.forRoot(),
    ToastContainerModule
    // NumberPipe
    // ArraySortPipe,
    // SearchPipe
  ],
  declarations: [],
  providers: [
    UIModule,
    DragDropListModule,
    LoadingModule,
    DataTableModule,
    PopOverModule
  ],
  exports: [
    CommonModule,
    FormsModule,
    NgbModule,
    UIModule,
    DragDropListModule,
    DataTableModule,
    LoadingModule,
    PopOverModule,
    ToastNoAnimationModule,
    ToastModule,
    ToastContainerModule
    // ArraySortPipe,
    // SearchPipe
  ]
})
export class SharedModule {}
