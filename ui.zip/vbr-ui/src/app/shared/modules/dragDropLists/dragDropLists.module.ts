import { NgModule } from '@angular/core';

import { CommonModule } from '@angular/common';
import {
  DraggableDirective,
  HandleDirective,
  ListDirective,
  NoDragDirective
} from './directives/index';
import { State } from './services/index';

@NgModule({
  imports: [CommonModule],
  exports: [
    DraggableDirective,
    HandleDirective,
    ListDirective,
    NoDragDirective
  ],
  entryComponents: [],
  declarations: [
    DraggableDirective,
    HandleDirective,
    ListDirective,
    NoDragDirective
  ],
  providers: [State]
})
export class DragDropListModule {}
