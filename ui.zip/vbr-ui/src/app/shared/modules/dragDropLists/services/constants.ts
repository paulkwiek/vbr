export const MIME_TYPE = 'application/x-dnd';
export const EDGE_MIME_TYPE = 'application/json';
export const MSIE_MIME_TYPE = 'Text';

export const ALL_EFFECTS: Effects[] = ['move', 'copy', 'link'];

export type Effects = 'move' | 'copy' | 'link';
