import { Injectable } from '@angular/core';
import { StateConfig } from './index';
import { ALL_EFFECTS } from './constants';
@Injectable()
export class State {
  public dragState: StateConfig = {
    isDragging: false,
    itemType: undefined,
    dropEffect: 'none',
    effectAllowed: ALL_EFFECTS[0]
  };

  public filterEffects(effects: string[], effectAllowed: string) {
    if (effectAllowed === 'all') {
      return effects;
    }
    return effects.filter(effect => {
      return effectAllowed.toLowerCase().indexOf(effect) !== -1;
    });
  }
}
