import { Effects } from '../services';
export interface DraggableConfig {
  draggable: boolean;
  effectAllowed: Effects;
}

export interface StateConfig {
  isDragging: boolean;
  itemType: string;
  dropEffect: string;
  effectAllowed: Effects;
}
