import {
  Directive,
  Input,
  OnDestroy,
  OnInit,
  Output,
  ElementRef,
  HostListener,
  EventEmitter
} from '@angular/core';
import {
  State,
  ListSettings,
  StateConfig,
  ALL_EFFECTS,
  MIME_TYPE,
  EDGE_MIME_TYPE,
  MSIE_MIME_TYPE
} from '../services';
import { Subject } from 'rxjs';

export const dropAccepted: Subject<any> = new Subject();

@Directive({
  selector: '[appList]'
})
export class ListDirective implements OnInit, OnDestroy {
  @Input('appList') public option: ListSettings = {
    disabled: false,
    effectAllowed: 'move',
    allowedTypes: undefined
  };
  // tslint:disable-next-line: no-input-rename
  @Input('Model') public Model: any[];
  @Input() public set Placeholder(placeholder: Element) {
    this.placeholder = placeholder;
    placeholder.remove();
  }
  // tslint:disable-next-line: no-output-rename
  @Output('DragOver') public DragOver: EventEmitter<any> = new EventEmitter();
  // tslint:disable-next-line: no-output-rename
  @Output('Drop') public Drop: EventEmitter<any> = new EventEmitter();
  // tslint:disable-next-line: no-output-rename
  @Output('Inserted') public Inserted: EventEmitter<any> = new EventEmitter();
  private dragState: StateConfig;
  private nativeElement: HTMLElement;
  private listSettings: {} = {};
  private placeholder: Element;

  constructor(
    private element: ElementRef,
    // tslint:disable-next-line: no-shadowed-variable
    private state: State
  ) {
    this.dragState = state.dragState;
    this.nativeElement = element.nativeElement;
    this.placeholder = this.getPlaceholderElement();
  }

  public ngOnInit(): void {}

  public ngOnDestroy(): void {}

  @HostListener('dragenter', ['$event'])
  public handleDragEnter(event: DragEvent): boolean {
    event = event['originalEvent'] || event;
    const mimeType: string = this.getMimeType(event.dataTransfer.types);
    if (!mimeType || !this.isDropAllowed(this.getItemType(mimeType))) {
      return true;
    }

    event.preventDefault();
    return false;
  }

  @HostListener('dragover', ['$event'])
  public handleDragOver(event: DragEvent): boolean {
    event = event['originalEvent'] || event;
    const mimeType: string = this.getMimeType(event.dataTransfer.types);
    const itemType: string = this.getItemType(mimeType);
    if (!mimeType || !this.isDropAllowed(itemType)) {
      return true;
    }
    if (this.placeholder.parentNode !== this.nativeElement) {
      this.nativeElement.appendChild(this.placeholder);
    }

    if (event.target !== this.nativeElement) {
      let listItemNode: Node = event.target as Node;
      while (
        listItemNode.parentNode !== this.nativeElement &&
        listItemNode.parentNode
      ) {
        listItemNode = listItemNode.parentNode;
      }

      if (
        listItemNode.parentNode === this.nativeElement &&
        listItemNode !== this.placeholder
      ) {
        let isFirstHalf: boolean;

        const rect: ClientRect = (listItemNode as Element).getBoundingClientRect();
        if (this.option && this.option.horizontal) {
          isFirstHalf = event.clientX < rect.left + rect.width / 2;
        } else {
          isFirstHalf = event.clientY < rect.top + rect.height / 2;
        }
        this.nativeElement.insertBefore(
          this.placeholder,
          isFirstHalf ? listItemNode : listItemNode.nextSibling
        );
      }
    }

    const ignoreDataTransfer: boolean = mimeType === MSIE_MIME_TYPE;
    const dropEffect: string = this.getDropEffect(event, ignoreDataTransfer);
    if (dropEffect === 'none') {
      return this.stopDragOver();
    }
    event.preventDefault();
    if (!ignoreDataTransfer) {
      event.dataTransfer.dropEffect = dropEffect;
    }

    this.nativeElement.classList.add('Dragover');
    event.stopPropagation();
    return false;
  }

  @HostListener('drop', ['$event'])
  public handleDrop(event: DragEvent): boolean {
    event = event['originalEvent'] || event;
    const mimeType: string = this.getMimeType(event.dataTransfer.types);
    let itemType: string = this.getItemType(mimeType);
    if (!mimeType || !this.isDropAllowed(itemType)) {
      return true;
    }

    event.preventDefault();

    let data: any;
    try {
      data = JSON.parse(event.dataTransfer.getData(mimeType));
    } catch (e) {
      return this.stopDragOver();
    }

    if (mimeType === MSIE_MIME_TYPE || mimeType === EDGE_MIME_TYPE) {
      itemType = data.type || undefined;
      data = data.item;
      if (!this.isDropAllowed(itemType)) {
        return this.stopDragOver();
      }
    }

    const ignoreDataTransfer: boolean = mimeType === MSIE_MIME_TYPE;
    const dropEffect: string = this.getDropEffect(event, ignoreDataTransfer);
    if (dropEffect === 'none') {
      return this.stopDragOver();
    }

    const index: number = this.getPlaceholderIndex();
    const offset: number =
      this.nativeElement.children.length - 1 - this.Model.length;
    if (this.Drop) {
      this.invokeCallback(this.Drop, event, dropEffect, itemType, index, data);
      if (!data) {
        return this.stopDragOver();
      }
    }

    this.dragState.dropEffect = dropEffect;
    if (!ignoreDataTransfer) {
      event.dataTransfer.dropEffect = dropEffect;
    }

    if (data !== true) {
      let insertionPoint: number = index - offset;
      if (insertionPoint < 0) {
        insertionPoint = 0;
      }
      this.Model.splice(insertionPoint, 0, data);
    }
    this.invokeCallback(
      this.Inserted,
      event,
      dropEffect,
      itemType,
      index,
      data
    );

    dropAccepted.next({ item: data, list: this.Model });
    this.stopDragOver();
    event.stopPropagation();
    return false;
  }

  @HostListener('dragleave', ['$event'])
  public handleDragLeave(event: DragEvent): void {
    event = event['originalEvent'] || event;

    const newTarget: Element = document.elementFromPoint(
      event.clientX,
      event.clientY
    );
    if (this.nativeElement.contains(newTarget) && !event['_PhShown']) {
      event['_PhShown'] = true;
    } else {
      this.stopDragOver();
    }
  }

  private getPlaceholderElement(): Element {
    let placeholder: Element;
    if (this.nativeElement.children) {
      for (let i = 1; i < this.nativeElement.children.length; i++) {
        const child: Element = this.nativeElement.children.item(i);
        if (child.classList.contains('Placeholder')) {
          placeholder = child;
        }
      }
    }
    const placeholderDefault: Element = document.createElement('li');
    placeholderDefault.classList.add('Placeholder');
    return placeholder || placeholderDefault;
  }

  private getMimeType(types: any): string {
    if (!types) {
      return MSIE_MIME_TYPE;
    }
    for (let i = 0; i < types.length; i++) {
      if (
        types[i] === MSIE_MIME_TYPE ||
        types[i] === EDGE_MIME_TYPE ||
        types[i].substr(0, MIME_TYPE.length) === MIME_TYPE
      ) {
        return types[i];
      }
    }
    return null;
  }

  private getItemType(mimeType: string): string {
    if (this.dragState.isDragging) {
      return this.dragState.itemType || undefined;
    }
    if (mimeType === MSIE_MIME_TYPE || mimeType === EDGE_MIME_TYPE) {
      return null;
    }
    return (mimeType && mimeType.substr(MIME_TYPE.length + 1)) || undefined;
  }
  private isDropAllowed(itemType: string): boolean {
    if (this.option) {
      if (this.option.disabled) {
        return false;
      }
      if (this.option.max && this.Model.length === this.option.max) {
        return false;
      }
      if (!this.option.externalSources && !this.dragState.isDragging) {
        return false;
      }
      if (!this.option.allowedTypes || itemType === null) {
        return true;
      }
    }
    return itemType && this.option.allowedTypes.indexOf(itemType) !== -1;
  }

  private getDropEffect(event: DragEvent, ignoreDataTransfer: boolean): string {
    let effects: string[] = Object.assign([], ALL_EFFECTS);
    if (!ignoreDataTransfer) {
      effects = this.state.filterEffects(
        effects,
        event.dataTransfer.effectAllowed
      );
    }
    if (this.dragState.isDragging) {
      effects = this.state.filterEffects(effects, this.dragState.effectAllowed);
    }
    if (this.option && this.option.effectAllowed) {
      effects = this.state.filterEffects(effects, this.option.effectAllowed);
    }
    // MacOS automatically filters dataTransfer.effectAllowed depending on the modifier keys,
    // therefore the following modifier keys will only affect other operating systems.
    if (!effects.length) {
      return 'none';
    } else if (event.ctrlKey && effects.indexOf('copy') !== -1) {
      return 'copy';
    } else if (event.altKey && effects.indexOf('link') !== -1) {
      return 'link';
    } else {
      return effects[0];
    }
  }

  private stopDragOver(): boolean {
    this.placeholder.remove();
    this.nativeElement.classList.remove('Dragover');
    return true;
  }
  private invokeCallback(
    eventEmitter: EventEmitter<any>,
    event: DragEvent,
    dropEffect: string,
    itemType: string,
    index?: number,
    item?: any
  ): boolean {
    eventEmitter.emit({
      dropEffect: dropEffect,
      event: event,
      external: !this.dragState.isDragging,
      index: index !== undefined ? index : this.getPlaceholderIndex(),
      item: item || undefined,
      type: itemType
    });
    return true;
  }
  private getPlaceholderIndex(): number {
    for (let i = 0; i < this.nativeElement.children.length; i++) {
      if (this.nativeElement.children[i].classList.contains('Dragging')) {
        this.nativeElement.children[i].remove();
        break;
      }
    }
    return Array.prototype.indexOf.call(
      this.nativeElement.children,
      this.placeholder
    );
  }
}
