import {
  Directive,
  Input,
  Output,
  ElementRef,
  HostListener,
  EventEmitter
} from '@angular/core';
import { State, DraggableConfig, StateConfig } from '../services';
@Directive({
  selector: '[appHandle]'
})
export class HandleDirective {
  private dragState: StateConfig;
  private nativeElement: HTMLElement;
  private draggableString = 'draggable';
  constructor(private element: ElementRef, private state: State) {
    this.dragState = state.dragState;
    this.nativeElement = element.nativeElement;
    this.nativeElement.setAttribute(this.draggableString, 'true');
  }

  @HostListener('dragstart', ['$event'])
  public handleDragStart(event: DragEvent): void {
    event = event['originalEvent'] || event;
    event['_Handle'] = true;
  }

  @HostListener('dragend', ['$event'])
  public handleDragEnd(event: DragEvent): void {
    event = event['originalEvent'] || event;

    if (!event['_Handle']) {
      event.stopPropagation();
    }
  }
}
