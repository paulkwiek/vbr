import {
  Directive,
  Input,
  Output,
  OnDestroy,
  OnInit,
  ElementRef,
  HostListener,
  EventEmitter
} from '@angular/core';
import { State } from '../services';
import {
  DraggableConfig,
  StateConfig,
  ALL_EFFECTS,
  MIME_TYPE,
  EDGE_MIME_TYPE,
  MSIE_MIME_TYPE
} from '../services/index';
import { dropAccepted } from './list';
import { Subscription } from 'rxjs';
@Directive({
  selector: '[appDraggable]'
})
export class DraggableDirective implements OnInit, OnDestroy {
  // tslint:disable-next-line: no-input-rename
  @Input('appDraggable') public option: DraggableConfig = <DraggableConfig>{
    draggable: true
  };
  // tslint:disable-next-line: no-input-rename
  @Input('Type') public Type: string;
  // tslint:disable-next-line: no-input-rename
  @Input('Object') public Object: HTMLElement;
  @Input('DragDisabled') public set disableDrag(disable: string | boolean) {
    if (disable !== undefined) {
      this.nativeElement.setAttribute(
        this.draggableString,
        (!disable).toString()
      );
    }
  }
  // tslint:disable-next-line: no-output-rename
  @Output('DragStart') public DragStart: EventEmitter<any> = new EventEmitter();
  // tslint:disable-next-line: no-output-rename
  @Output('DragEnd') public DragEnd: EventEmitter<any> = new EventEmitter();
  // tslint:disable-next-line: no-output-rename
  @Output('Copied') public Copied: EventEmitter<any> = new EventEmitter();
  // tslint:disable-next-line: no-output-rename
  @Output('Linked') public Linked: EventEmitter<any> = new EventEmitter();
  // tslint:disable-next-line: no-output-rename
  @Output('Moved') public Moved: EventEmitter<any> = new EventEmitter();
  // tslint:disable-next-line: no-output-rename
  @Output('Canceled') public Canceled: EventEmitter<any> = new EventEmitter();
  // tslint:disable-next-line: no-output-rename
  @Output('Selected') public Selected: EventEmitter<any> = new EventEmitter();

  private dragState: StateConfig;
  private dropSubscription: Subscription;
  private nativeElement: HTMLElement;
  private draggableString = 'draggable';
  numOfClicks = 0;
  constructor(private element: ElementRef, private state: State) {
    this.dragState = state.dragState;
    this.nativeElement = element.nativeElement;
    this.nativeElement.setAttribute(this.draggableString, 'true');

    // this.nativeElement.onselectstart = function(): void {
    //   if (this.dragDrop) {
    //     this.dragDrop();
    //   }
    // };
  }

  public ngOnInit(): void {
    this.dropSubscription = dropAccepted.subscribe(({ item, list }) => {
      if (JSON.stringify(this.Object) === JSON.stringify(item)) {
        const cb: object = {
          copy: 'Copied',
          link: 'Linked',
          move: 'Moved',
          none: 'Canceled'
        };
        if (this.dragState) {
          (this[cb[this.dragState.effectAllowed]] as EventEmitter<any>).emit();
        }
        this.DragEnd.emit();
      }
    });
  }

  public ngOnDestroy(): void {
    this.dropSubscription.unsubscribe();
  }

  @HostListener('dragstart', ['$event'])
  public handleDragStart(event: DragEvent): void {
    if (this.nativeElement.getAttribute(this.draggableString) === 'false') {
      return;
    }
    this.dragState.isDragging = true;
    this.dragState.itemType = this.Type;
    this.dragState.dropEffect = 'none';
    if (!this.option) {
      this.option = <DraggableConfig>{ draggable: true };
    }
    this.dragState.effectAllowed = this.option.effectAllowed || ALL_EFFECTS[0];
    event.dataTransfer.effectAllowed = this.dragState.effectAllowed;
    const mimeType: string =
      MIME_TYPE +
      (this.dragState.itemType ? '-' + this.dragState.itemType : '');
    try {
      event.dataTransfer.setData(mimeType, JSON.stringify(this.Object));
    } catch (e) {
      const data: string = JSON.stringify({
        item: this.Object,
        type: this.dragState.itemType
      });
      try {
        event.dataTransfer.setData(EDGE_MIME_TYPE, data);
      } catch (e) {
        const effectsAllowed: string[] = this.state.filterEffects(
          ALL_EFFECTS,
          this.dragState.effectAllowed
        );
        event.dataTransfer.effectAllowed = effectsAllowed[0];
        event.dataTransfer.setData(MSIE_MIME_TYPE, data);
      }
    }

    this.nativeElement.classList.add('Dragging');
    if (this.nativeElement.classList.contains('right-item-style')) {
      this.nativeElement.classList.add('selectedRightItem');
    }
    setTimeout(() => {
      if (this.dragState.effectAllowed === 'move') {
        this.nativeElement.style.display = 'none';
      }
    }, 0);

    if ((<any>event)._Handle && event.dataTransfer.setDragImage) {
      event.dataTransfer.setDragImage(this.nativeElement, 0, 0);
    }

    this.DragStart.emit();
    event.stopPropagation();
  }

  @HostListener('dragend', ['$event'])
  public handleDragEnd(event: DragEvent): void {
    // Clean up
    this.dragState.isDragging = false;
    this.nativeElement.classList.remove('Dragging');
    this.nativeElement.style.removeProperty('display');
    event.stopPropagation();
    setTimeout(() => this.nativeElement.classList.remove('DraggingSource'), 0);
  }

  @HostListener('click', ['$event'])
  public handleClick(event: Event): void {
    if (this.nativeElement.classList.contains('right-item-style')) {
      this.nativeElement.classList.add('selectedRightItem');
      this.numOfClicks++;
    }
    if (this.nativeElement.classList.contains('left-item-style')) {
      this.nativeElement.classList.add('selectedLeftItem');
      this.numOfClicks++;
    }
    if (this.nativeElement.hasAttribute('Selected')) {
      return;
    }
    if (this.numOfClicks > 1) {
      this.nativeElement.classList.remove('selectedRightItem');
      this.nativeElement.classList.remove('selectedLeftItem');
      this.numOfClicks = 0;
    }

    event = event['originalEvent'] || event;

    this.Selected.emit();

    event.stopPropagation();
  }

  private findElementWithAttribute(
    element: HTMLElement,
    attr: string
  ): HTMLElement {
    if (element.hasAttribute(attr)) {
      return element;
    }
    if (element.parentElement === null) {
      return;
    }
    return this.findElementWithAttribute(element.parentElement, attr);
  }
}
