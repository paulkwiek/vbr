import { NgModule, ModuleWithProviders } from '@angular/core';
import { LoadingService } from './loading.service';
import { LoadingComponent } from './loading.component';

export * from './loading.service';
export * from './loading.component';

@NgModule({
  imports: [],
  declarations: [LoadingComponent],
  exports: [LoadingComponent],
  providers: [LoadingService]
})
export class LoadingModule {
  static forRoot(): ModuleWithProviders {
    return {
      ngModule: LoadingModule,
      providers: [LoadingService]
    };
  }
}
