import { CommonModule } from '@angular/common';
import { ModuleWithProviders, NgModule } from '@angular/core';

import { ToastComponent } from './toast.component';
import {
  DefaultNoComponentGlobalConfig,
  GlobalConfig,
  TOAST_CONFIG
} from './toast-config';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';

export const DefaultGlobalConfig: GlobalConfig = {
  ...DefaultNoComponentGlobalConfig,
  toastComponent: ToastComponent
};

@NgModule({
  imports: [CommonModule, NgbModule],
  declarations: [ToastComponent],
  exports: [ToastComponent],
  entryComponents: [ToastComponent]
})
export class ToastModule {
  static forRoot(config: Partial<GlobalConfig> = {}): ModuleWithProviders {
    return {
      ngModule: ToastModule,
      providers: [
        {
          provide: TOAST_CONFIG,
          useValue: {
            default: DefaultGlobalConfig,
            config
          }
        }
      ]
    };
  }
}

@NgModule({
  imports: [CommonModule]
})
export class ToastComponentlessModule {
  static forRoot(config: Partial<GlobalConfig> = {}): ModuleWithProviders {
    return {
      ngModule: ToastModule,
      providers: [
        {
          provide: TOAST_CONFIG,
          useValue: {
            default: DefaultNoComponentGlobalConfig,
            config
          }
        }
      ]
    };
  }
}
