import { Injector, InjectFlags } from '@angular/core';
import { Observable, Subject } from 'rxjs';
import { OverlayRef } from './overlay/overlay-ref';
import { ToastPackage } from './toast-config';

export class ToastRef<T> {
  componentInstance: T;
  private duplicatesCount = 0;
  private _afterClosed = new Subject<any>();
  private _activate = new Subject<any>();
  private _manualClose = new Subject<any>();
  private _resetTimeout = new Subject<any>();
  private _countDuplicate = new Subject<number>();

  constructor(private _overlayRef: OverlayRef) {}

  manualClose() {
    this._manualClose.next();
    this._manualClose.complete();
  }

  manualClosed(): Observable<any> {
    return this._manualClose.asObservable();
  }

  timeoutReset(): Observable<any> {
    return this._resetTimeout.asObservable();
  }

  countDuplicate(): Observable<number> {
    return this._countDuplicate.asObservable();
  }

  close(): void {
    this._overlayRef.detach();
    this._afterClosed.next();
    this._manualClose.next();
    this._afterClosed.complete();
    this._manualClose.complete();
    this._activate.complete();
    this._resetTimeout.complete();
    this._countDuplicate.complete();
  }

  afterClosed(): Observable<any> {
    return this._afterClosed.asObservable();
  }

  isInactive() {
    return this._activate.isStopped;
  }

  activate() {
    this._activate.next();
    this._activate.complete();
  }

  afterActivate(): Observable<any> {
    return this._activate.asObservable();
  }

  /** Reset the toast timouts and count duplicates */
  onDuplicate(resetTimeout: boolean, countDuplicate: boolean) {
    if (resetTimeout) {
      this._resetTimeout.next();
    }
    if (countDuplicate) {
      this._countDuplicate.next(++this.duplicatesCount);
    }
  }
}

export class ToastInjector implements Injector {
  constructor(
    private _toastPackage: ToastPackage,
    private _parentInjector: Injector
  ) {}

  get<T>(token: any, notFoundValue?: T, flags?: InjectFlags): T | ToastPackage {
    if (token === ToastPackage) {
      return this._toastPackage;
    }
    return this._parentInjector.get<T>(token, notFoundValue, flags);
  }
}
