import { InjectionToken } from '@angular/core';
import { SafeHtml } from '@angular/platform-browser';

import { Observable, Subject } from 'rxjs';

import { ComponentType } from './portal/portal';
import { ToastRef } from './toast-injector';

export type ProgressAnimationType = 'increasing' | 'decreasing';

export interface IndividualConfig {
  disableTimeOut: boolean;
  timeOut: number;
  closeButton: boolean;
  extendedTimeOut: number;
  progressBar: boolean;
  progressAnimation: ProgressAnimationType;
  enableHtml: boolean;
  toastClass: string;
  positionClass: string;
  messageClass: string;
  easing: string;
  easeTime: string | number;
  tapToDismiss: boolean;
  toastComponent?: ComponentType<any>;
  onActivateTick: boolean;

  imageClass: string;
}

export interface ToastIconClasses {
  error: string;
  info: string;
  success: string;
  warning: string;
}

export interface ToastImageClass {
  error: string;
  info: string;
  success: string;
  warning: string;
}

export interface GlobalConfig extends IndividualConfig {
  maxOpened: number;
  autoDismiss: boolean;
  iconClasses: Partial<ToastIconClasses>;
  newestOnTop: boolean;
  preventDuplicates: boolean;
  countDuplicates: boolean;
  resetTimeoutOnDuplicate: boolean;
  imageClasses: Partial<ToastImageClass>;
  imageClass: string;
}

export class ToastPackage {
  private _onTap = new Subject<any>();
  private _onAction = new Subject<any>();

  constructor(
    public toastId: number,
    public config: IndividualConfig,
    public message: string,
    public title: string | undefined,
    public toastType: string,
    public image: string,
    public toastRef: ToastRef<any>
  ) {
    this.toastRef.afterClosed().subscribe(() => {
      this._onAction.complete();
      this._onTap.complete();
    });
  }

  triggerTap() {
    this._onTap.next();
    if (this.config.tapToDismiss) {
      this._onTap.complete();
    }
  }

  onTap(): Observable<any> {
    return this._onTap.asObservable();
  }

  triggerAction(action?: any) {
    this._onAction.next(action);
  }

  onAction(): Observable<any> {
    return this._onAction.asObservable();
  }
}

// tslint:disable-next-line: no-empty-interface
export interface GlobalToastConfig extends GlobalConfig {}
// tslint:disable-next-line: no-empty-interface
export interface IndividualToastConfig extends IndividualConfig {}
// tslint:disable-next-line: no-empty-interface
export interface ToastConfig extends IndividualConfig {}

export const DefaultNoComponentGlobalConfig: GlobalConfig = {
  maxOpened: 0,
  autoDismiss: false,
  newestOnTop: true,
  preventDuplicates: false,
  countDuplicates: false,
  resetTimeoutOnDuplicate: false,
  iconClasses: {
    error: 'toast-error',
    info: 'toast-info',
    success: 'toast-success',
    warning: 'toast-warning'
  },

  // Individual
  closeButton: false,
  disableTimeOut: false,
  timeOut: 5000,
  extendedTimeOut: 1000,
  enableHtml: false,
  progressBar: false,
  toastClass: 'ng-toast',
  positionClass: 'toast-top-right',
  messageClass: 'toast-message',
  easing: 'ease-in',
  easeTime: 300,
  tapToDismiss: true,
  onActivateTick: false,
  progressAnimation: 'decreasing',
  imageClasses: {
    success: 'toast-image-sucess',
    error: 'toast-image-error',
    info: 'toast-image-info',
    warning: 'toast-image-warning'
  },
  imageClass: 'success'
};

export interface ToastToken {
  default: GlobalConfig;
  config: Partial<GlobalConfig>;
}

export const TOAST_CONFIG = new InjectionToken<ToastToken>('ToastConfig');
