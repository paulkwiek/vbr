import {
  ComponentRef,
  Inject,
  Injectable,
  Injector,
  NgZone,
  SecurityContext
} from '@angular/core';
import { DomSanitizer, SafeHtml } from '@angular/platform-browser';

import { Observable } from 'rxjs';

import { Overlay } from './overlay/overlay';
import { ComponentPortal } from './portal/portal';
import { ToastInjector, ToastRef } from './toast-injector';
import { ToastContainerDirective } from './toast.directive';
import {
  GlobalConfig,
  IndividualConfig,
  ToastPackage,
  ToastToken,
  TOAST_CONFIG
} from './toast-config';
import _ from 'lodash';

export interface ActiveToast<C> {
  toastId: number;
  message: string;
  portal: ComponentRef<C>;
  toastRef: ToastRef<C>;
  onShown: Observable<any>;
  onHidden: Observable<any>;
  onTap: Observable<any>;
  onAction: Observable<any>;

  image: string;
}

@Injectable({ providedIn: 'root' })
export class ToastService {
  toastConfig: GlobalConfig;
  currentlyActive = 0;
  toasts: ActiveToast<any>[] = [];
  overlayContainer: ToastContainerDirective;
  previousToastMessage: string | undefined;
  private index = 0;

  constructor(
    @Inject(TOAST_CONFIG) token: ToastToken,
    private overlay: Overlay,
    private _injector: Injector,
    private sanitizer: DomSanitizer,
    private ngZone: NgZone
  ) {
    this.toastConfig = {
      ...token.default,
      ...token.config
    };
    if (token.config.iconClasses) {
      this.toastConfig.iconClasses = {
        ...token.default.iconClasses,
        ...token.config.iconClasses
      };
    }
    if (token.config.imageClasses) {
      this.toastConfig.imageClasses = {
        ...token.default.imageClasses,
        ...token.default.imageClasses
      };
    }
  }

  show(
    message?: string,
    title?: string,
    override: Partial<IndividualConfig> = {},
    type = '',
    image = ''
  ) {
    return this._preBuildNotification(
      type,
      message,
      title,
      image,
      this.applyConfig(override)
    );
  }

  success(message?: string,  title?: string, override: Partial<IndividualConfig> = {}) {
    const type = this.toastConfig.iconClasses.success || '';
    const image = this.toastConfig.imageClasses.success || '';
    return this._preBuildNotification(
      type,
      message,
      title,
      image,
      this.applyConfig(override)
    );
  }

  error(message?: string,  title?: string, override: Partial<IndividualConfig> = {}) {
    const type = this.toastConfig.iconClasses.error || '';
    const image = this.toastConfig.imageClasses.error || '';
    return this._preBuildNotification(
      type,
      message,
      title,
      image,
      this.applyConfig(override)
    );
  }

  info(message?: string,  title?: string, override: Partial<IndividualConfig> = {}) {
    const type = this.toastConfig.iconClasses.info || '';
    const image = this.toastConfig.imageClasses.info || '';
    return this._preBuildNotification(
      type,
      message,
      title,
      image,
      this.applyConfig(override)
    );
  }

  warning(message?: string,  title?: string, override: Partial<IndividualConfig> = {}) {
    const type = this.toastConfig.iconClasses.warning || '';
    const image = this.toastConfig.imageClasses.warning || '';
    return this._preBuildNotification(
      type,
      message,
      title,
      image,
      this.applyConfig(override)
    );
  }

  clear(toastId?: number) {
    for (const toast of this.toasts) {
      if (toastId !== undefined) {
        if (toast.toastId === toastId) {
          toast.toastRef.manualClose();
          return;
        }
      } else {
        toast.toastRef.manualClose();
      }
    }
  }

  remove(toastId: number) {
    const found = this._findToast(toastId);
    if (!found) {
      return false;
    }
    found.activeToast.toastRef.close();
    this.toasts.splice(found.index, 1);
    this.currentlyActive = this.currentlyActive - 1;
    if (!this.toastConfig.maxOpened || !this.toasts.length) {
      return false;
    }
    if (
      this.currentlyActive < this.toastConfig.maxOpened &&
      this.toasts[this.currentlyActive]
    ) {
      const p = this.toasts[this.currentlyActive].toastRef;
      if (!p.isInactive()) {
        this.currentlyActive = this.currentlyActive + 1;
        p.activate();
      }
    }
    return true;
  }

  findDuplicate(
    message: string,
    resetOnDuplicate: boolean,
    countDuplicates: boolean
  ) {
    for (let i = 0; i < this.toasts.length; i++) {
      const toast = this.toasts[i];
      if (toast.message === message) {
        toast.toastRef.onDuplicate(resetOnDuplicate, countDuplicates);
        return toast;
      }
    }
    return null;
  }

  private applyConfig(override: Partial<IndividualConfig> = {}): GlobalConfig {
    return { ...this.toastConfig, ...override };
  }

  private _findToast(
    toastId: number
  ): { index: number; activeToast: ActiveToast<any> } | null {
    for (let i = 0; i < this.toasts.length; i++) {
      if (this.toasts[i].toastId === toastId) {
        return { index: i, activeToast: this.toasts[i] };
      }
    }
    return null;
  }

  private _preBuildNotification(
    toastType: string,
    message: string | undefined,
    title: string | undefined,
    image: string,
    config: GlobalConfig
  ): ActiveToast<any> | null {
    if (config.onActivateTick) {
      return this.ngZone.run(() =>
        this._buildNotification(toastType, message, title, image, config)
      );
    }
    return this._buildNotification(toastType, message, title, image, config);
  }

  private _buildNotification(
    toastType: string,
    message: string | undefined,
    title: string | undefined,
    image: string,
    config: GlobalConfig
  ): ActiveToast<any> | null {
    if (!config.toastComponent) {
      throw new Error('toastComponent required');
    }

    const duplicate = this.findDuplicate(
      message,
      this.toastConfig.resetTimeoutOnDuplicate && config.timeOut > 0,
      this.toastConfig.countDuplicates
    );
    if (message && this.toastConfig.preventDuplicates && duplicate !== null) {
      return duplicate;
    }

    this.previousToastMessage = message;
    let keepInactive = false;
    if (
      this.toastConfig.maxOpened &&
      this.currentlyActive >= this.toastConfig.maxOpened
    ) {
      keepInactive = true;
      if (this.toastConfig.autoDismiss) {
        this.clear(this.toasts[0].toastId);
      }
    }
    const overlayRef = this.overlay.create(
      config.positionClass,
      this.overlayContainer
    );
    this.index = this.index + 1;
    let sanitizedMessage: string = message;
    if (message && config.enableHtml) {
      sanitizedMessage = this.sanitizer.sanitize(SecurityContext.HTML, message);
    }

    const toastRef = new ToastRef(overlayRef);
    const toastPackage = new ToastPackage(
      this.index,
      config,
      sanitizedMessage,
      title,
      toastType,
      image,
      toastRef
    );
    const toastInjector = new ToastInjector(toastPackage, this._injector);
    const component = new ComponentPortal(config.toastComponent, toastInjector);
    const portal = overlayRef.attach(component, this.toastConfig.newestOnTop);
    toastRef.componentInstance = (<any>portal)._component;
    const ins: ActiveToast<any> = {
      toastId: this.index,
      message: message || '',
      image: image || '',
      toastRef,
      onShown: toastRef.afterActivate(),
      onHidden: toastRef.afterClosed(),
      onTap: toastPackage.onTap(),
      onAction: toastPackage.onAction(),
      portal
    };
    const toastMessage = ins.message;
    if (!keepInactive) {
      setTimeout(() => {
        ins.toastRef.activate();
        this.currentlyActive = this.currentlyActive + 1;
      });
    }
    if (_.size(this.toasts) === 0) {
      this.toasts.push(ins);
    } else {
      _.forEach(this.toasts, function(value) {
        value.message += ' ' + toastMessage;
      });
    }
    return ins;
  }
  isEmptyObject(obj) {
    return obj && Object.keys(obj).length === 0;
  }
}
