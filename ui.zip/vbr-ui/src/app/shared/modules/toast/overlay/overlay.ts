import { DOCUMENT } from '@angular/common';
import {
  ApplicationRef,
  ComponentFactoryResolver,
  Inject,
  Injectable
} from '@angular/core';

import { DomPortalHost } from '../portal/dom-portal-host';
import { ToastContainerDirective } from '../toast.directive';
import { OverlayContainer } from './overlay-container';
import { OverlayRef } from './overlay-ref';

@Injectable({ providedIn: 'root' })
export class Overlay {
  private _paneElements: Map<
    ToastContainerDirective,
    { string?: HTMLElement }
  > = new Map();

  constructor(
    private _overlayContainer: OverlayContainer,
    private _componentFactoryResolver: ComponentFactoryResolver,
    private _appRef: ApplicationRef,
    @Inject(DOCUMENT) private _document: any
  ) {}

  create(
    positionClass?: string,
    overlayContainer?: ToastContainerDirective
  ): OverlayRef {
    return this._createOverlayRef(
      this.getPaneElement(positionClass, overlayContainer)
    );
  }

  getPaneElement(
    positionClass: string = '',
    overlayContainer?: ToastContainerDirective
  ): HTMLElement {
    if (!this._paneElements.get(overlayContainer)) {
      this._paneElements.set(overlayContainer, {});
    }

    if (!this._paneElements.get(overlayContainer)[positionClass]) {
      this._paneElements.get(overlayContainer)[
        positionClass
      ] = this._createPaneElement(positionClass, overlayContainer);
    }

    return this._paneElements.get(overlayContainer)[positionClass];
  }

  private _createPaneElement(
    positionClass: string,
    overlayContainer?: ToastContainerDirective
  ): HTMLElement {
    const pane = this._document.createElement('div');

    pane.id = 'toast-container';
    pane.classList.add(positionClass);
    pane.classList.add('toast-container');

    if (!overlayContainer) {
      this._overlayContainer.getContainerElement().appendChild(pane);
    } else {
      overlayContainer.getContainerElement().appendChild(pane);
    }

    return pane;
  }

  private _createPortalHost(pane: HTMLElement): DomPortalHost {
    return new DomPortalHost(
      pane,
      this._componentFactoryResolver,
      this._appRef
    );
  }

  private _createOverlayRef(pane: HTMLElement): OverlayRef {
    return new OverlayRef(this._createPortalHost(pane));
  }
}
