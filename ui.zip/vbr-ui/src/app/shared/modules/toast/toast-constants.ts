export interface Message {
  text?: string;
  type?: string;
}

export const types = ['success', 'error', 'info', 'warning'];
