import { ComponentRef, Injector, ViewContainerRef } from '@angular/core';

export interface ComponentType<T> {
  new (...args: any[]): T;
}
export class ComponentPortal<T> {
  private _attachedHost?: BasePortalHost;
  component: ComponentType<T>;

  viewContainerRef: ViewContainerRef;

  injector: Injector;

  constructor(component: ComponentType<T>, injector: Injector) {
    this.component = component;
    this.injector = injector;
  }

  attach(host: BasePortalHost, newestOnTop: boolean) {
    this._attachedHost = host;
    return host.attach(this, newestOnTop);
  }

  detach() {
    const host = this._attachedHost;
    if (host) {
      this._attachedHost = undefined;
      return host.detach();
    }
  }

  get isAttached(): boolean {
    return this._attachedHost != null;
  }

  setAttachedHost(host?: BasePortalHost) {
    this._attachedHost = host;
  }
}

export abstract class BasePortalHost {
  private _attachedPortal?: ComponentPortal<any>;

  private _disposeFn?: () => void;

  attach(portal: ComponentPortal<any>, newestOnTop: boolean) {
    this._attachedPortal = portal;
    return this.attachComponentPortal(portal, newestOnTop);
  }

  abstract attachComponentPortal<T>(
    portal: ComponentPortal<T>,
    newestOnTop: boolean
  ): ComponentRef<T>;

  detach() {
    if (this._attachedPortal) {
      this._attachedPortal.setAttachedHost();
    }

    this._attachedPortal = undefined;
    if (this._disposeFn) {
      this._disposeFn();
      this._disposeFn = undefined;
    }
  }

  setDisposeFn(fn: () => void) {
    this._disposeFn = fn;
  }
}
