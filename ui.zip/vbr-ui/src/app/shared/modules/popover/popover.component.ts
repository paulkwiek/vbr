import {
  AfterViewInit,
  ChangeDetectorRef,
  Component,
  ElementRef,
  EventEmitter,
  Input,
  OnDestroy,
  Renderer2,
  ViewChild
} from '@angular/core';
import { PopOverDirective } from './popover.directive';
import { PopOverLocation } from './popover.location';

@Component({
  selector: 'app-popover',
  templateUrl: 'popover.component.html',
  styleUrls: ['popover.component.scss']
})
export class PopOverComponent implements AfterViewInit, OnDestroy {
  @Input() public content: string;
  @Input() public location: PopOverLocation = PopOverLocation.Top;
  @Input() public title: string;
  @Input() public parentClass: string;
  @Input() public animation = true;
  @Input() public closeOnClickOutside = false;
  @Input() public closeOnMouseOutside = false;
  @Input() public size: 'small' | 'medium-small' | 'medium' | 'large' | 'auto' =
    'small';

  @ViewChild('popoverDiv') public popoverDiv: ElementRef;

  public popover: PopOverDirective;
  public onCloseFromOutside = new EventEmitter();
  public top = -10000;
  public left = -10000;
  public isIn = false;
  public displayType = 'none';
  public effectiveLocation: string;
  public opacity = 0;
  public transitionEnabled = false;

  public windowWidth = window.innerWidth;
  public windowHeight = window.innerHeight;

  public listenClickFunc: any;
  public listenMouseFunc: any;
  public listenTouchFunc: any;

  public onDocumentMouseDown = (event: any) => {
    const element = this.element.nativeElement;
    if (!element || !this.popover) {
      return;
    }
    if (
      element.contains(event.target) ||
      this.popover.getElement().contains(event.target)
    ) {
      return;
    }
    this.onCloseFromOutside.emit(undefined);
  }

  constructor(
    protected element: ElementRef,
    protected cdr: ChangeDetectorRef,
    protected renderer: Renderer2
  ) {}

  public ngAfterViewInit(): void {
    if (this.closeOnClickOutside) {
      this.listenClickFunc = this.renderer.listen(
        'document',
        'mousedown',
        (event: any) => this.onDocumentMouseDown(event)
      );
    }
    if (this.closeOnMouseOutside) {
      this.listenMouseFunc = this.renderer.listen(
        'document',
        'mouseover',
        (event: any) => this.onDocumentMouseDown(event)
      );
    }
    this.listenTouchFunc = this.renderer.listen(
      'document',
      'touchstart',
      (event: any) => this.onDocumentMouseDown(event)
    );

    this.show();
    this.cdr.detectChanges();
  }

  public ngOnDestroy(): void {
    if (this.closeOnClickOutside && this.listenClickFunc) {
      this.listenClickFunc();
    }
    if (this.closeOnMouseOutside && this.listenMouseFunc) {
      this.listenMouseFunc();
    }
    if (!!this.listenTouchFunc) {
      this.listenTouchFunc();
    }
  }

  public updatePosition(): void {
    if (this.opacity) {
      const p = this.positionElements(
        this.popover.getElement(),
        this.popoverDiv.nativeElement,
        this.location
      );
      this.top = p.top;
      this.left = p.left;
    }
  }

  public show(): void {
    if (!this.popover || !this.popover.getElement()) {
      return;
    }

    const p = this.positionElements(
      this.popover.getElement(),
      this.popoverDiv.nativeElement,
      this.location
    );
    this.displayType = 'block';
    this.top = p.top;
    this.left = p.left;
    this.isIn = true;
    this.transitionEnabled = true;
    this.opacity = 1;
    if (this.size === 'small') {
      this.left = -245.5;
    }
    if (this.size === 'large') {
      this.left = -545.5;
    }
    if (this.size === 'medium-small') {
      this.left = -405.5;
    }
  }

  public hide(): void {
    this.top = -10000;
    this.left = -10000;
    this.isIn = true;
    this.popover.hide();
  }

  public hideFromPopover(): void {
    this.top = -10000;
    this.left = -10000;
    this.isIn = true;
    this.transitionEnabled = false;
    this.opacity = 0;
  }

  protected positionElements(
    hostEl: HTMLElement,
    targetEl: HTMLElement,
    positionStr: PopOverLocation,
    appendToBody: boolean = false
  ): { top: number; left: number } {
    const positionStrParts = (positionStr as string).split(' ');
    let pos0 = positionStrParts[0];
    const pos1 = positionStrParts[1] || 'center';
    const hostElPos = appendToBody
      ? this.offset(hostEl)
      : this.position(hostEl);
    const targetElWidth = targetEl.offsetWidth;
    const targetElHeight = targetEl.offsetHeight;

    this.effectiveLocation = pos0 = this.getEffectiveLocation(
      pos0,
      hostEl,
      targetEl
    );

    const shiftWidth: any = {
      center: function(): number {
        return hostElPos.left + hostElPos.width / 2 - targetElWidth / 2;
      },
      left: function(): number {
        return hostElPos.left;
      },
      right: function(): number {
        return hostElPos.left + hostElPos.width;
      },
      topOrBottomRight: function(): number {
        return hostElPos.left + hostElPos.width / 2;
      },
      topOrBottomLeft: function(): number {
        return hostElPos.left - targetElWidth + hostElPos.width / 2;
      }
    };

    const shiftHeight: any = {
      center: function(): number {
        return hostElPos.top + hostElPos.height / 2 - targetElHeight / 2;
      },
      top: function(): number {
        return hostElPos.top;
      },
      bottom: function(): number {
        return hostElPos.top + hostElPos.height;
      }
    };

    let targetElPos: { top: number; left: number };
    switch (pos0) {
      case PopOverLocation.Right:
        targetElPos = {
          top: shiftHeight[pos1](),
          left: shiftWidth[pos0]()
        };
        break;

      case PopOverLocation.Left:
        targetElPos = {
          top: shiftHeight[pos1](),
          left: hostElPos.left - targetElWidth
        };
        break;

      case PopOverLocation.Bottom:
        targetElPos = {
          top: shiftHeight[pos0](),
          left: shiftWidth[pos1]()
        };
        break;
      case PopOverLocation.TopLeft:
        targetElPos = {
          top: hostElPos.top - targetElHeight,
          left: shiftWidth['topOrBottomLeft']()
        };
        break;
      case PopOverLocation.TopRight:
        targetElPos = {
          top: hostElPos.top - targetElHeight,
          left: shiftWidth['topOrBottomRight']()
        };
        break;
      case PopOverLocation.BottomLeft:
        targetElPos = {
          top: shiftHeight[PopOverLocation.Bottom](),
          left: shiftWidth['topOrBottomLeft']()
        };
        break;
      case PopOverLocation.BottomRight:
        targetElPos = {
          top: shiftHeight[PopOverLocation.Bottom](),
          left: shiftWidth['topOrBottomRight']()
        };
        break;

      default:
        targetElPos = {
          top: hostElPos.top - targetElHeight,
          left: shiftWidth[pos1]()
        };
        break;
    }

    return targetElPos;
  }

  protected position(
    nativeEl: HTMLElement
  ): { width: number; height: number; top: number; left: number } {
    let offsetParentBCR = { top: 0, left: 0 };
    const elBCR = this.offset(nativeEl);
    const offsetParentEl = this.parentOffsetEl(nativeEl);
    if (offsetParentEl !== window.document) {
      offsetParentBCR = this.offset(offsetParentEl);
      offsetParentBCR.top +=
        offsetParentEl.clientTop - offsetParentEl.scrollTop;
      offsetParentBCR.left +=
        offsetParentEl.clientLeft - offsetParentEl.scrollLeft;
    }

    const boundingClientRect = nativeEl.getBoundingClientRect();
    return {
      width: boundingClientRect.width || nativeEl.offsetWidth,
      height: boundingClientRect.height || nativeEl.offsetHeight,
      top: elBCR.top - offsetParentBCR.top,
      left: elBCR.left - offsetParentBCR.left
    };
  }

  protected offset(
    nativeEl: any
  ): { width: number; height: number; top: number; left: number } {
    const boundingClientRect = nativeEl.getBoundingClientRect();
    return {
      width: boundingClientRect.width || nativeEl.offsetWidth,
      height: boundingClientRect.height || nativeEl.offsetHeight,
      top:
        boundingClientRect.top +
        (window.pageYOffset || window.document.documentElement.scrollTop),
      left:
        boundingClientRect.left +
        (window.pageXOffset || window.document.documentElement.scrollLeft)
    };
  }

  protected getStyle(nativeEl: HTMLElement, cssProp: string): string {
    if ((nativeEl as any).currentStyle) {
      return (nativeEl as any).currentStyle[cssProp];
    }

    if (window.getComputedStyle) {
      return (window.getComputedStyle as any)(nativeEl)[cssProp];
    }
    return (nativeEl.style as any)[cssProp];
  }

  protected isStaticPositioned(nativeEl: HTMLElement): boolean {
    return (this.getStyle(nativeEl, 'position') || 'static') === 'static';
  }

  protected parentOffsetEl(nativeEl: HTMLElement): any {
    let offsetParent: any = nativeEl.offsetParent || window.document;
    while (
      offsetParent &&
      offsetParent !== window.document &&
      this.isStaticPositioned(offsetParent)
    ) {
      offsetParent = offsetParent.offsetParent;
    }
    return offsetParent || window.document;
  }

  protected getEffectiveLocation(
    location: string,
    hostElement: HTMLElement,
    targetElement: HTMLElement
  ): string {
    const hostElBoundingRect = hostElement.getBoundingClientRect();

    const desiredLocation = location || PopOverLocation.Top;

    if (desiredLocation === PopOverLocation.Top) {
      const isTopOverflow =
        hostElBoundingRect.top - targetElement.offsetHeight < 0;
      const isRightOverflow =
        hostElBoundingRect.left +
          hostElBoundingRect.width / 2 +
          targetElement.offsetWidth / 2 >
        this.windowWidth;
      const isLeftOverflow =
        hostElBoundingRect.left +
          hostElBoundingRect.width / 2 -
          targetElement.offsetWidth / 2 <
        0;

      if (isTopOverflow) {
        return PopOverLocation.Bottom;
      } else if (isRightOverflow) {
        return PopOverLocation.TopLeft;
      } else if (isLeftOverflow) {
        return PopOverLocation.TopRight;
      }
    }
    if (desiredLocation === PopOverLocation.Bottom) {
      const isRightOverflow =
        hostElBoundingRect.left +
          hostElBoundingRect.width / 2 +
          targetElement.offsetWidth / 2 >
        this.windowWidth;
      const isLeftOverflow =
        hostElBoundingRect.left +
          hostElBoundingRect.width / 2 -
          targetElement.offsetWidth / 2 <
        0;
      const isBottomOverflow =
        hostElBoundingRect.bottom + targetElement.offsetHeight >
        this.windowHeight;

      if (isBottomOverflow) {
        return PopOverLocation.Top;
      } else if (isRightOverflow) {
        return PopOverLocation.BottomLeft;
      } else if (isLeftOverflow) {
        return PopOverLocation.BottomRight;
      }
    }
    if (desiredLocation === PopOverLocation.Left) {
      const isTopOverflow =
        hostElBoundingRect.top +
          hostElBoundingRect.height / 2 -
          targetElement.offsetHeight / 2 <
        0;
      const isLeftOverflow =
        hostElBoundingRect.left - targetElement.offsetWidth < 0;
      const isBottomOverflow =
        hostElBoundingRect.top +
          hostElBoundingRect.height / 2 +
          targetElement.offsetHeight / 2 >
        this.windowHeight;

      if (isLeftOverflow) {
        return PopOverLocation.Right;
      } else if (isTopOverflow) {
        return PopOverLocation.BottomLeft;
      } else if (isBottomOverflow) {
        return PopOverLocation.TopLeft;
      }
    }
    if (desiredLocation === PopOverLocation.Right) {
      const isTopOverflow =
        hostElBoundingRect.top +
          hostElBoundingRect.height / 2 -
          targetElement.offsetHeight / 2 <
        0;
      const isRightOverflow =
        hostElBoundingRect.right + targetElement.offsetWidth > this.windowWidth;
      const isBottomOverflow =
        hostElBoundingRect.top +
          hostElBoundingRect.height / 2 +
          targetElement.offsetHeight / 2 >
        this.windowHeight;

      if (isRightOverflow) {
        return PopOverLocation.Left;
      } else if (isTopOverflow) {
        return PopOverLocation.BottomRight;
      } else if (isBottomOverflow) {
        return PopOverLocation.TopRight;
      }
    }
    if (desiredLocation === PopOverLocation.TopRight) {
      const isTopOverflow =
        hostElBoundingRect.top - targetElement.offsetHeight < 0;
      const isRightOverflow =
        hostElBoundingRect.right + targetElement.offsetWidth > this.windowWidth;

      if (isTopOverflow && isRightOverflow) {
        return PopOverLocation.BottomLeft;
      } else if (isTopOverflow) {
        return PopOverLocation.BottomRight;
      } else if (isRightOverflow) {
        return PopOverLocation.TopLeft;
      }
    }
    if (desiredLocation === PopOverLocation.TopLeft) {
      const isTopOverflow =
        hostElBoundingRect.top - targetElement.offsetHeight < 0;
      const isLeftOverflow =
        hostElBoundingRect.left - targetElement.offsetWidth < 0;

      if (isTopOverflow && isLeftOverflow) {
        return PopOverLocation.BottomRight;
      } else if (isTopOverflow) {
        return PopOverLocation.BottomLeft;
      } else if (isLeftOverflow) {
        return PopOverLocation.TopRight;
      }
    }
    if (desiredLocation === PopOverLocation.BottomRight) {
      const isBottomOverflow =
        hostElBoundingRect.bottom + targetElement.offsetHeight >
        this.windowHeight;
      const isRightOverflow =
        hostElBoundingRect.right + targetElement.offsetWidth > this.windowWidth;

      if (isBottomOverflow && isRightOverflow) {
        return PopOverLocation.TopLeft;
      } else if (isBottomOverflow) {
        return PopOverLocation.TopRight;
      } else if (isRightOverflow) {
        return PopOverLocation.BottomLeft;
      }
    }
    if (desiredLocation === PopOverLocation.BottomLeft) {
      const isBottomOverflow =
        hostElBoundingRect.bottom + targetElement.offsetHeight >
        this.windowHeight;
      const isLeftOverflow =
        hostElBoundingRect.left - targetElement.offsetWidth < 0;

      if (isBottomOverflow && isLeftOverflow) {
        return PopOverLocation.TopRight;
      } else if (isBottomOverflow) {
        return PopOverLocation.TopLeft;
      } else if (isLeftOverflow) {
        return PopOverLocation.BottomRight;
      }
    }

    return desiredLocation;
  }
}
