import { PopOverDirective } from './popover.directive';
import { PopOverComponent } from './popover.component';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

@NgModule({
  declarations: [PopOverDirective, PopOverComponent],
  imports: [CommonModule],
  exports: [PopOverComponent, PopOverDirective],
  entryComponents: [PopOverComponent]
})
export class PopOverModule {}
