/**
 * This is a continuation of ngx-popover
 * @Reference {github} https://github.com/pleerock/ngx-popover
 */

import {
  ComponentFactoryResolver,
  ComponentRef,
  Directive,
  EventEmitter,
  HostListener,
  Input,
  OnChanges,
  Output,
  SimpleChange,
  ViewContainerRef
} from '@angular/core';
import { PopOverComponent } from './popover.component';
import { PopOverLocation } from './popover.location';

@Directive({
  // tslint:disable-next-line: directive-selector
  selector: '[popover]',
  exportAs: 'popover'
})
export class PopOverDirective implements OnChanges {
  protected popoverComponent = PopOverComponent;
  protected popover: ComponentRef<PopOverComponent>;
  protected visible: boolean;

  constructor(
    protected viewContainerRef: ViewContainerRef,
    protected resolver: ComponentFactoryResolver
  ) {}

  @Input('popover') public content: string | PopOverComponent;
  @Input() public popoverSize:
    | 'small'
    | 'medium-small'
    | 'medium'
    | 'large'
    | 'auto';
  @Input() public popoverDisabled: boolean;
  @Input() public popoverAnimation: boolean;
  @Input() public popoverLocation: PopOverLocation;
  @Input() public popoverTitle: string;
  @Input() public popoverOnHover = true;
  @Input() public popoverCloseOnClickOutside: boolean;
  @Input() public popoverCloseOnMouseOutside: boolean;
  @Input() public popoverDismissTimeout = 0;
  // tslint:disable-next-line: no-output-on-prefix
  @Output() public onShown = new EventEmitter<PopOverDirective>();
  // tslint:disable-next-line: no-output-on-prefix
  @Output() public onHidden = new EventEmitter<PopOverDirective>();

  @HostListener('click', ['$event'])
  public showOrHideOnClick(evt: Event): void {
    if (this.popoverOnHover) {
      return;
    }
    if (this.popoverDisabled) {
      return;
    }
    evt.stopImmediatePropagation();
    this.toggle();
  }

  @HostListener('touchend', ['$event'])
  public showOrHideOnTouch(evt: Event): void {
    evt.stopImmediatePropagation();
    if (!this.popoverOnHover) {
      return;
    }
    if (this.popoverDisabled) {
      return;
    }
    this.toggle();
  }

  @HostListener('focusin')
  @HostListener('mouseenter')
  public showOnHover(): void {
    if (!this.popoverOnHover) {
      return;
    }
    if (this.popoverDisabled) {
      return;
    }
    this.show();
  }

  @HostListener('focusout')
  @HostListener('mouseleave')
  public hideOnHover(): void {
    if (this.popoverCloseOnMouseOutside) {
      return;
    }
    if (!this.popoverOnHover) {
      return;
    }
    if (this.popoverDisabled) {
      return;
    }
    this.hide();
  }

  public ngOnChanges(changes: { [propertyName: string]: SimpleChange }): void {
    if (changes['popoverDisabled']) {
      if (changes['popoverDisabled'].currentValue) {
        this.hide();
      }
    }
  }

  public toggle(): void {
    if (!this.visible) {
      this.show();
    } else {
      this.hide();
    }
  }

  public show(): void {
    if (this.visible) {
      return;
    }

    this.visible = true;
    if (typeof this.content === 'string') {
      const factory = this.resolver.resolveComponentFactory(
        this.popoverComponent
      );
      if (!this.visible) {
        return;
      }

      this.popover = this.viewContainerRef.createComponent(factory);
      const popover = this.popover.instance as PopOverComponent;
      popover.popover = this;
      popover.content = this.content as string;
      if (this.popoverLocation !== undefined) {
        popover.location = this.popoverLocation;
      }
      if (this.popoverAnimation !== undefined) {
        popover.animation = this.popoverAnimation;
      }
      if (this.popoverTitle !== undefined) {
        popover.title = this.popoverTitle;
      }
      if (this.popoverCloseOnClickOutside !== undefined) {
        popover.closeOnClickOutside = this.popoverCloseOnClickOutside;
      }
      if (this.popoverCloseOnMouseOutside !== undefined) {
        popover.closeOnMouseOutside = this.popoverCloseOnMouseOutside;
      }
      if (this.popoverSize) {
        popover.size = this.popoverSize;
      }

      popover.onCloseFromOutside.subscribe(() => this.hide());
      if (this.popoverDismissTimeout > 0) {
        setTimeout(() => this.hide(), this.popoverDismissTimeout);
      }
    } else {
      const popover = this.content as PopOverComponent;
      popover.popover = this;
      if (this.popoverLocation !== undefined) {
        popover.location = this.popoverLocation;
      }
      if (this.popoverAnimation !== undefined) {
        popover.animation = this.popoverAnimation;
      }
      if (this.popoverTitle !== undefined) {
        popover.title = this.popoverTitle;
      }
      if (this.popoverCloseOnClickOutside !== undefined) {
        popover.closeOnClickOutside = this.popoverCloseOnClickOutside;
      }
      if (this.popoverCloseOnMouseOutside !== undefined) {
        popover.closeOnMouseOutside = this.popoverCloseOnMouseOutside;
      }
      if (this.popoverSize) {
        popover.size = this.popoverSize;
      }

      popover.onCloseFromOutside.subscribe(() => this.hide());
      if (this.popoverDismissTimeout > 0) {
        setTimeout(() => this.hide(), this.popoverDismissTimeout);
      }
      popover.show();
    }

    this.onShown.emit(this);
  }

  public hide(): void {
    if (!this.visible) {
      return;
    }

    this.visible = false;
    if (this.popover) {
      this.popover.destroy();
    }

    if (this.content instanceof PopOverComponent) {
      (this.content as PopOverComponent).hideFromPopover();
    }

    this.onHidden.emit(this);
  }

  public getElement(): HTMLElement {
    return this.viewContainerRef.element.nativeElement;
  }
}
