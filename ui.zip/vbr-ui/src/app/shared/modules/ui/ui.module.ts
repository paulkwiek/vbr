import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { ModalComponent } from './components/modal/modal.component';
import { InputComponent } from './components/input/input.component';
import { PanelComponent } from './components/panel/panel.component';
import { PayeeBlockComponent } from './components/payee-block/payee-block.component';
import { SectionComponent } from './components/section/section.component';
import { SimpletextComponent } from './components/simpletext/simpletext.component';
import { PlaintextComponent } from './components/plaintext/plaintext.component';
import { NgbDateParserFormatter } from '@ng-bootstrap/ng-bootstrap';
import { CustomDateParserFormatter } from './components/datepicker/customdateparserformatter';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { PinBlockComponent } from './components/pin-block/pin-block.component';
import { EditPayeeBlockComponent } from './components/edit-payee-block/edit-payee-block.component';
import { PaginationComponent } from './components/pagination/pagination.component';
import { PipesModule } from '../../pipes/pipes.module';
import { ErrorComponent } from './components/error/error.component';

@NgModule({
  declarations: [
    ModalComponent,
    InputComponent,
    PanelComponent,
    PayeeBlockComponent,
    PlaintextComponent,
    SectionComponent,
    SimpletextComponent,
    PinBlockComponent,
    EditPayeeBlockComponent,
    PaginationComponent,
    ErrorComponent
  ],
  imports: [
    CommonModule,
    HttpClientModule,
    ReactiveFormsModule,
    FormsModule,
    PipesModule
  ],
  exports: [
    ModalComponent,
    InputComponent,
    PanelComponent,
    PayeeBlockComponent,
    PlaintextComponent,
    SectionComponent,
    SimpletextComponent,
    PinBlockComponent,
    EditPayeeBlockComponent,
    PaginationComponent,
    ErrorComponent
  ],
  providers: [
    { provide: NgbDateParserFormatter, useClass: CustomDateParserFormatter },
    CustomDateParserFormatter
  ],
  bootstrap: [
    ModalComponent,
    InputComponent,
    PanelComponent,
    PayeeBlockComponent,
    PlaintextComponent,
    SectionComponent,
    SimpletextComponent,
    PinBlockComponent,
    EditPayeeBlockComponent,
    PaginationComponent,
    ErrorComponent
  ]
})
export class UIModule {}
