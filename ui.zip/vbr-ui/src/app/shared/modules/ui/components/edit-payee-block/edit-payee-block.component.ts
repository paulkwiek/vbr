import { Component, OnInit, Input } from '@angular/core';
@Component({
  selector: 'app-edit-payee-block',
  templateUrl: './edit-payee-block.component.html',
  styleUrls: ['./edit-payee-block.component.scss']
})
export class EditPayeeBlockComponent implements OnInit {
  @Input() provider: any;
  @Input() payeeArrang: boolean;
  editCheck: boolean;

  constructor() {}

  ngOnInit() {
    if (this.payeeArrang === true) {
      this.editCheck = true;
    } else {
      this.editCheck = false;
    }
  }
}
