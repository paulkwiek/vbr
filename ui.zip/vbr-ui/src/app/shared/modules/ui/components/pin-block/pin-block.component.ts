import { Component, OnInit, Input, OnChanges } from '@angular/core';
import { PayeesComponent } from '../../../../../modules/configurations/components/payees/payees.component';
import { Provider } from '../../../../../models/configuration.model';

@Component({
  selector: 'app-pin-block',
  templateUrl: './pin-block.component.html',
  styleUrls: ['./pin-block.component.scss']
})
export class PinBlockComponent implements OnInit, OnChanges {
  // @Input() payee: any;
  @Input() payeeType: string;
  payeeCheck: boolean;
  @Input() provider: Provider;

  constructor() {}

  ngOnInit() {}

  ngOnChanges() {
    // console.log(this.payeeType);
    if (this.payeeType === 'premier_provider') {
      this.payeeCheck = true;
    } else {
      this.payeeCheck = false;
    }
    // console.log(this.payeeCheck);
    // console.log(this.provider);
  }
}
