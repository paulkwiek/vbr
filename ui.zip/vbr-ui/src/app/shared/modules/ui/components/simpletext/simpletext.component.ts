import { Component, OnInit, Input } from '@angular/core';
import { ModalService } from 'src/app/shared/services/modal.service';

@Component({
  selector: 'app-simpletext',
  templateUrl: './simpletext.component.html',
  styleUrls: ['./simpletext.component.scss']
})
export class SimpletextComponent implements OnInit {
  @Input() title: string;
  @Input() name: string;
  @Input() value: string;
  @Input() modalvalue: string;
  @Input() checkRoles: boolean;

  constructor(private modalService: ModalService) {}

  ngOnInit() {}
  create(id: string) {
    this.modalService.open(id);
  }
}
