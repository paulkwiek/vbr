import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-plaintext',
  templateUrl: './plaintext.component.html',
  styleUrls: ['./plaintext.component.scss']
})
export class PlaintextComponent implements OnInit {
  @Input() label: string;
  @Input() name: string;
  @Input() value: string;
  @Input() line1: string;
  @Input() line2: string;
  @Input() class: string;
  @Input() required: boolean;

  constructor() {}

  ngOnInit() {
    // console.log('plaintext component :: class=',this.class);
  }
}
