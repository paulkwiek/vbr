import {
  Component,
  OnInit,
  Input,
  Output,
  EventEmitter,
  DoCheck
} from '@angular/core';
import _ from 'lodash';

@Component({
  selector: 'app-pagination',
  templateUrl: './pagination.component.html',
  styleUrls: ['./pagination.component.scss']
})
export class PaginationComponent implements OnInit, DoCheck {
  @Input() rowData: any;
  @Input() sortField: any;
  @Input() sorter: boolean;
  currentRows: any;
  pageSize = 25;
  pagesCount: number;
  currentPage = 0;
  startPage = 0;
  endPage = this.pageSize;
  updatePage = 1;
  @Output() currentRowChange: EventEmitter<any> = new EventEmitter<any>();

  constructor() { }

  ngOnInit() {
    this.updatePage = this.currentPage + 1;
    if (this.rowData) {
      if (this.rowData.length < this.pageSize) {
        this.startPage = 0;
        this.endPage = this.rowData.length;
      }
      this.generatePages(0);
    }
  }
  ngDoCheck() {
    if (this.rowData) {
      this.ngOnInit();
    }
  }
  generatePages(index) {
    if (this.rowData.length) {
      this.pagesCount = Math.floor(this.rowData.length / this.pageSize) + 1;
      this.currentPage = index;
      this.startPage = index * this.pageSize;
      this.endPage = this.startPage + this.pageSize;
      if (this.endPage > this.rowData.length) {
        this.endPage = this.rowData.length;
      }
      this.currentRows = [];
      // tslint:disable-next-line: no-shadowed-variable
      this.rowData.filter((row: any, index: number) => {
        if (index >= this.startPage && index < this.endPage) {
          this.currentRows.push(row);
        }
      });
      this.sendCurrentRow(this.currentRows);
      this.updatePage = this.currentPage + 1;
    }
  }
  sendCurrentRow(currentRows: any) {
    currentRows = this.currentRows;
    this.currentRowChange.emit(currentRows);
  }
  gotoPage(index) {
    this.generatePages(index);
    this.currentPage = index;
    this.updatePage = this.currentPage + 1;
  }
  changeRowNumber(event) {
    if (this.pageSize === event.target.value) {
      return false;
    }
    this.pageSize = +event.target.value;
    this.gotoPage(0);
  }
  onCurrentPageChange(val) {
    val = Number(val) - 1;
    this.gotoPage(val);
  }
  onChange(val) {
    if (val.includes('A-Z')) {
      this.rowData.sort((a, b) => {
        if (a[this.sortField] < b[this.sortField]) {
          return -1;
        } else {
          return 1;
        }
      });
    }
    if (val.includes('Z-A')) {
      this.rowData.sort((a, b) => {
        if (a[this.sortField] > b[this.sortField]) {
          return -1;
        } else {
          return 1;
        }
      });
    }
    this.generatePages(this.currentPage);
  }
}
