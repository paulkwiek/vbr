import { Component, OnInit, Input } from '@angular/core';
import { ArrangementComponent } from 'src/app/modules/configurations/components/arrangements/arrangement/arrangement.component';

@Component({
  selector: 'app-payee-block',
  templateUrl: './payee-block.component.html',
  styleUrls: ['./payee-block.component.scss']
})
export class PayeeBlockComponent implements OnInit {
  @Input() payee: any;
  @Input() index: number;

  constructor(private arrangementsComponent: ArrangementComponent) {}

  ngOnInit() {}
  edit(id: string, editArrPayeeRecord: any) {
    this.arrangementsComponent.editArrPayee(id, editArrPayeeRecord, this.index);
  }
}
