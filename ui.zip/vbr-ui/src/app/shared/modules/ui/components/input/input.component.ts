import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-input',
  templateUrl: './input.component.html'
})
export class InputComponent implements OnInit {
  @Input() type: string;
  @Input() name: string;
  @Input() label: string;
  @Input() value: string;

  constructor() {}

  ngOnInit() {}
}
