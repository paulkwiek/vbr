import { Component, Inject, forwardRef } from '@angular/core';
import { DataTableComponent } from '../table/table';

@Component({
  selector: 'app-data-table-header',
  templateUrl: './header.html',
  // tslint:disable-next-line: use-host-property-decorator
  host: {
    '(document:click)': '_closeSelector()'
  }
})
export class DataTableHeaderComponent {
  columnSelectorOpen = false;

  _closeSelector() {
    this.columnSelectorOpen = false;
  }

  constructor(
    @Inject(forwardRef(() => DataTableComponent))
    public dataTable: DataTableComponent
  ) {}
}
