import {
  Component,
  Input,
  Inject,
  forwardRef,
  Output,
  EventEmitter,
  OnDestroy
} from '@angular/core';
import { DataTableComponent } from '../table/table';

@Component({
  // tslint:disable-next-line: component-selector
  selector: '[dataTableRow]',
  templateUrl: './row.html',
  styleUrls: ['./row.scss']
})
export class DataTableRowComponent implements OnDestroy {
  get selected() {
    return this._selected;
  }

  set selected(selected) {
    this._selected = selected;
    this.selectedChange.emit(selected);
  }

  get displayIndex(): number {
    if (this.dataTable.pagination) {
      return this.dataTable.displayParams.offset + this.index + 1;
    } else {
      return this.index + 1;
    }
  }

  constructor(
    @Inject(forwardRef(() => DataTableComponent))
    public dataTable: DataTableComponent
  ) {}
  @Input() dataitem: any;
  @Input() index: number;
  expanded: boolean;
  @Input() findIndex: number;

  private _selected: boolean;

  @Output() selectedChange = new EventEmitter();

  _this = this;

  getTooltip() {
    if (this.dataTable.rowTooltip) {
      return this.dataTable.rowTooltip(this.dataitem, this, this.index);
    }
    return '';
  }

  ngOnDestroy() {
    this.selected = false;
  }
}
