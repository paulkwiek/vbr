import { Directive, Input, ContentChild, OnInit, Output } from '@angular/core';
import { DataTableRowComponent } from '../row/row';
import { CellCallback } from '../types';

@Directive({
  // tslint:disable-next-line: directive-selector
  selector: 'app-data-table-column'
})
export class DataTableColumnDirective implements OnInit {
  // init:
  @Input() header: string;
  @Input() sortable = false;
  @Input() resizable = false;
  @Input() property: string;
  @Input() styleClass: string;
  @Input() cellColors: CellCallback;

  @Input() width: number | string;
  @Input() visible = true;
  @Input() link: boolean;
  @Input() findVar: number;
  @Input() index: number;
  @Output() findIndex: number;

  @ContentChild('dataTableCell') cellTemplate;
  @ContentChild('dataTableHeader') headerTemplate;

  private styleClassObject = {};

  getCellColor(row: DataTableRowComponent, index: number) {
    if (this.cellColors !== undefined) {
      return (<CellCallback>this.cellColors)(row.dataitem, row, this, index);
    }
  }

  ngOnInit() {
    this._initCellClass();
    // if (this.findVar !== undefined) {
    //   this.findIndex = this.findVar;
    // }
  }

  private _initCellClass() {
    if (!this.styleClass && this.property) {
      if (/^[a-zA-Z0-9_]+$/.test(this.property)) {
        this.styleClass = 'column-' + this.property;
      } else {
        this.styleClass =
          'column-' + this.property.replace(/[^a-zA-Z0-9_]/g, '');
      }
    }
    if (this.styleClass != null) {
      this.styleClassObject = {
        [this.styleClass]: true
      };
    }
  }
}
