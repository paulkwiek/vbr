import { DataTableRowComponent } from './row/row';
import { DataTableColumnDirective } from './column/column';

export type RowCallback = (
  dataitem: any,
  row: DataTableRowComponent,
  index: number
) => string;

export type CellCallback = (
  dataitem: any,
  row: DataTableRowComponent,
  column: DataTableColumnDirective,
  index: number
) => string;

export interface DataTableTranslations {
  indexColumn: string;
  selectColumn: string;
  expandColumn: string;
  paginationLimit: string;
  paginationRange: string;
}

export let defaultTranslations = <DataTableTranslations>{
  indexColumn: 'index',
  selectColumn: 'select',
  expandColumn: 'expand',
  paginationLimit: 'Show',
  paginationRange: 'Results'
};

export interface DataTableParams {
  offset?: number;
  limit?: number;
  sortBy?: string;
  sortAsc?: boolean;
}
