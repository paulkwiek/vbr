import { NgModule, Pipe } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { DataTableHeaderComponent } from './components/header/header';
import { DataTableColumnDirective } from './components/column/column';
import { DataTableComponent } from './components/table/table';
import { DataTableRowComponent } from './components/row/row';
import { DataTablePaginationComponent } from './components/pagination/pagination';

import { PixelConverter } from './utils/px';
import { Hide } from './utils/hide';
import { MinPipe } from './utils/min';
import { PipesModule } from '../../pipes/pipes.module';

export * from './components/types';
export * from './tools/data-table-resource';
export * from './tools/data-table-resource-customized';

export {
  DataTableComponent,
  DataTableColumnDirective,
  DataTableRowComponent,
  DataTablePaginationComponent,
  DataTableHeaderComponent
};
export const DATA_TABLE_DIRECTIVES = [
  DataTableComponent,
  DataTableColumnDirective
];

@NgModule({
  imports: [CommonModule, FormsModule, PipesModule],
  declarations: [
    DataTableComponent,
    DataTableColumnDirective,
    DataTableRowComponent,
    DataTablePaginationComponent,
    DataTableHeaderComponent,
    PixelConverter,
    Hide,
    MinPipe
  ],
  providers: [],
  exports: [DataTableComponent, DataTableColumnDirective, DataTableRowComponent]
})
export class DataTableModule {}
