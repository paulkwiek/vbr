import { DataTableParams } from '../components/types';
import _ from 'lodash';

export class DataTableResource<T> {
  constructor(private dataitems: T[]) {}

  query(
    params: DataTableParams,
    filter?: (dataitem: T, index: number, dataitems: T[]) => boolean
  ): Promise<T[]> {
    let result: T[] = [];
    let resultasc;
    let resultdesc;
    if (filter) {
      result = this.dataitems.filter(filter);
    } else {
      result = this.dataitems.slice();
    }

    if (params.sortBy) {
      if (params.sortBy !== 'pinGroupId') {
        result.sort((a, b) => {
          if (
            typeof a[params.sortBy] === 'string' ||
            typeof b[params.sortBy] === 'string'
          ) {
            if (
              this.dataRepresentation(a[params.sortBy]) <
              this.dataRepresentation(b[params.sortBy])
            ) {
              return -1;
            } else if (
              this.dataRepresentation(a[params.sortBy]) >
              this.dataRepresentation(b[params.sortBy])
            ) {
              return 1;
            }
            return 0;
          } else {
            return a[params.sortBy] - b[params.sortBy];
          }
        });
      } else if (params.sortBy === 'pinGroupId') {
          if (params.sortAsc) {
            resultasc = _.orderBy(result, [params.sortBy], ['asc']);
          }
          if (!params.sortAsc) {
            resultdesc = _.orderBy(result, [params.sortBy], ['desc']);
          }
        }


      if (params.sortAsc === false) {
        result.reverse();
      }
    }
    if ((!(result.length <= params.limit)) && params.offset !== undefined) {
      if (params.limit === undefined) {
        result = result.slice(params.offset, result.length);
      } else {
        result = result.slice(params.offset, params.offset + params.limit);
      }
    }
    if (params.sortBy === 'pinGroupId') {
      if (params.sortAsc) {
        result = resultasc;
      } else {
        result = resultdesc;
      }
    }
    return new Promise((resolve, reject) => {
      setTimeout(() => resolve(result));
    });
  }

  count(): Promise<number> {
    return new Promise((resolve, reject) => {
      setTimeout(() => resolve(this.dataitems.length));
    });
  }
  dataRepresentation = data => {
    let data_split;
    let parts;
    if (data !== null) {
      if (data.includes('$')) {
        data_split = data
          .split('$')
          .join('')
          .split(',')
          .join('')
          .split('.')
          .join('');
        data_split = data_split / 100;
        return `${data_split}`;
      } else if (data.includes('/')) {
        parts = data.split('/');
        return `${parts[2]}/${parts[1]}/${parts[0]}`;
      } else {
        data = data
          .split(' ')
          .join('')
          .toLowerCase();
        return data;
      }
    }
  }
}
