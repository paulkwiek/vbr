import { DataTableParams } from '../components/types';

export class DataTableResourceCustomized<T> {
  constructor(private dataitems: T[]) {}
  prevResult: T[] = [];
  isRates = false;
  isFirstEndDateSort = true;

  /* Method : sortDateAscend
   * This method ascends parted date values in ascending order
   * returns number
   */
  sortDateAscend(a: any, b: any, params: any): number {
    if (
      this.dataRepresentation(a[params.sortBy]) <
      this.dataRepresentation(b[params.sortBy])
    ) {
      return -1;
    }
    if (
      this.dataRepresentation(a[params.sortBy]) >
      this.dataRepresentation(b[params.sortBy])
    ) {
      return 1;
    }
    return 0;
  }

  query(
    params: DataTableParams,
    filter?: (dataitem: T, index: number, dataitems: T[]) => boolean
  ): Promise<T[]> {
    let result: T[] = [];

    if (filter) {
      result = this.dataitems.filter(filter);
    } else {
      result = this.dataitems.slice();
    }

    if ((result.length > 0) && (result[0].hasOwnProperty('rateName'))) {
      this.isRates = true;
    }

    if (params.sortBy) {
      if (params.sortBy === 'recordEndDate' && this.isRates) {
        if (this.isFirstEndDateSort) {
          this.prevResult = result;
        }
        this.prevResult.sort((a, b) => {
          if (a['recordEffectiveDate'] === b['recordEffectiveDate']) {
            return this.sortDateAscend(a, b, params);
          }
        });
        result = this.prevResult;
      } else {

          result.sort((a, b) => {
            this.isFirstEndDateSort = false;
            if (
              typeof a[params.sortBy] === 'string' ||
              typeof b[params.sortBy] === 'string' ||
              typeof a[params.sortBy] === 'object' ||
              typeof b[params.sortBy] === 'object'
            ) {
              return this.sortDateAscend(a, b, params);
            } else {
              return a[params.sortBy] - b[params.sortBy];
            }
          });
      }

      if (
        ((params.sortAsc === false && (!this.isRates || this.isRates && params.sortBy !== 'recordEndDate')))
      ) {
        result.reverse();
      } else if (
        params.sortAsc === false &&
        params.sortBy === 'recordEndDate' &&
        this.isRates
      ) {
        this.prevResult.sort((a, b) => {
          if (a['recordEffectiveDate'] === b['recordEffectiveDate']) {
            if (
              this.dataRepresentation(a[params.sortBy]) <
              this.dataRepresentation(b[params.sortBy])
            ) {
              return 1;
            } else if (
              this.dataRepresentation(a[params.sortBy]) >
              this.dataRepresentation(b[params.sortBy])
            ) {
              return -1;
            }
            return 0;
          }
          result = this.prevResult;
        });
      }
      this.prevResult = result;
    }
    if (params.offset !== undefined) {
      if (params.limit === undefined) {
        result = result.slice(params.offset, result.length);
      } else {
        result = result.slice(params.offset, params.offset + params.limit);
      }
    }


    return new Promise((resolve, reject) => {
     // this.dataitems = result;
      setTimeout(() => resolve(result));
    });
  }

  count(): Promise<number> {
    return new Promise((resolve, reject) => {
      setTimeout(() => resolve(this.dataitems.length));
    });
  }
  dataRepresentation = data => {
    let data_split;
    let parts;
    if (data !== null) {
      if (data.includes('$')) {
        data_split = data
          .split('$')
          .join('')
          .split(',')
          .join('')
          .split('.')
          .join('');
        data_split = data_split / 100;
        return `${data_split}`;
      } else if (data.includes('/')) {
        parts = data.split('/');
        return `${parts[2]}/${parts[1]}/${parts[0]}`;
      } else {
        data = data
          .split(' ')
          .join('')
          .toLowerCase();
        return data;
      }
    }
  }
}
