export const SERVER_API_URL = 'http://localhost:8086/';
export const ALPHA_NUMERIC_PATTERN = /^[a-zA-Z0-9]+$/;
export const ALPHA_NUMERIC_PATTERN_WITH_SPACE = /^[a-zA-Z0-9 ]+$/;
export const CALCULATION_RUN_NAME_PATTERN = /^[A-Za-z0-9](?:[\w' -]{0,18}[A-Za-z0-9])?$/;
export const DATE_PATTERN = /^\d{1,2}\/\d{1,2}\/\d{4}$/;
export const AMOUNT_PATTERN = /^\-?[0-9]+(?:\.[0-9]{1,2})?$/;
export const NUMBER_PATTERN_FOR_RATE = /^[0-9]{1,9}([.][0-9]{0,2})?$/;
export const AMOUNT_PATTERN_WITH_6_DIGITS_AND_2_DECIMALS = /^(?!\.0?$)\d{0,6}(\.\d{0,2})?$/;
// Code Set value starts
export const PAYMENT_ARRANGEMENT_TYPE_CODE = 'ARNGMTTYPE';
export const PAYMENT_ARRANGEMENT_FREQUENCY = 'ARNGMTFREQ';
export const SUBJECT_MEMBER_CONTRACT_ID = 'MEMCONTRID';
export const SUBJECT_MEMBER_LOB = 'LOB';

// Code Set value ends
export const TABS = [
  {
    id: 'nm-preliminary-1',
    aria: 'nm-preliminary-1',
    name: 'NM-Preliminary 1',
    type: 'Preliminary',
    list: [
      {
        type: 'Line Of Business',
        name: 'Medicare Advantage - Daily'
      },
      { type: 'Payment Types', name: 'HME 2' }
    ],
    date_modified: ''
  },
  {
    id: 'calculation-run-1',
    aria: 'calculation-run-1',
    name: 'Calculation-Run 1',
    type: 'Calculation-Run',
    list: [
      { type: 'Payees', name: 'HME 2 Specialist Inc' },
      { type: 'Product Types', name: 'MAHMO1' }
    ],
    date_modified: ''
  },
  {
    id: 'approval-run-1',
    aria: 'approval-run-1',
    name: 'Approval Run 1',
    type: 'Approval Run',
    list: [
      { type: 'Product Types', name: 'MAHMO2' },
      {
        type: 'Line Of Business',
        name: 'Retail'
      }
    ],
    date_modified: ''
  }
];
export const INSERT_ACTION = 'INSERT';

export const resourceEndPoints = {
  // Search Payee From DB
  SEARCH_PAYEE: '/payee/searchPayee',
  // RETRIEVE Payee From Premier Provider API
  RETRIEVE_PAYEE: '/payee/retrievePayee',
  // RETRIEVE Payee list
  RETRIEVE_PAYEE_LIST: '/payee/retrievePayees',
  // SAVE Payee To DB
  SAVE_PAYEE: '/payee/savePayee',
  // GET ARRANGEMENTS
  GET_ARRANGEMENTS: '/paymentarrangement/getArrangements',
  // GET ARRANGEMENT
  GET_ARRANGEMENT: '/paymentarrangement/getArrangement',
  // SAVE ARRANGEMENT to DB
  SAVE_ARRANGEMENT: '/paymentarrangement/saveArrangement',
  // RETRIEVE PAYMENT TYPES
  RETRIEVE_PAYMENT_TYPES: '/paymentType/getAllPaymentTypes',
  // RETRIEVE RATES
  RETRIEVE_RATES: '/rates/retrieveRates',
  // RATES DETAILS
  GET_RATE_DETAILS: '/rates/retrieveRate',
  // GET LINKED ARRANGEMENTS
  GET_LINKED_ARRANGEMENTS: '/rates/getLinkedArrangements',
  // SAVE or UPDATE RATES
  SAVE_OR_UPDATE_RATE: '/rates/saveRate',
  // SAVE or UPDATE PAYMENT TYPES - INSERT
  SAVE_OR_UPDATE_PAYMENT_TYPE: '/paymentType/savePaymentType',
  // VALIDATE RATE TABLE NAME
  VALIDATE_RATE_TABLE_NAME: '/rates/validateRateName',
  // VALIDATE ARRANGEMENT RATE
  VALIDATE_ARRANGEMEMT_RATE: '/paymentarrangement/validateArrangementRate',
  // SAVE CALCULATION RUN
  SAVE_CALCULATION_RUN: '/calculationRun/saveCalculationRun',
  // VALIDATE_ARRANGEMEMT_PAYEE
  VALIDATE_ARRANGEMEMT_PAYEE: '/paymentarrangement/validateArrangementPayee',
  // RETRIEVE CALCULATION RUN
  RETRIEVE_CALCULATION_RUN: '/calculationRun/retrieveCalculationRunNames',
  // RETRIEVE LINE OF BUSINESS
  RETRIEVE_LINE_OF_BUSINESS: '/calculationRun/getCodeValueItems',
  // RETRIEVE LINE OF CALCULATION STATUS
  RETRIEVE_LINE_OF_CALCULATION_STATUS: '/calculationRequestStatus/getAllStatus',
  // SAVE CALCULATION REQUEST
  SAVE_CALCULATION_REQUEST: '/calculationRequest/createCalculationRequest',
  // REVIEW CALCULATION RUN NAME
  REVIEW_CALCULATION_RUN_NAME: '/reviewCalculationResult/getReviewCalculationRunName',
  // VALIDATE UNIQUE PAYEE
  VALIDATE_UNIQUE_PAYEE: '/payee/validateUniquePayee',
  // GET CODE FROM CODE SERVICE
  GET_CODE: '/codes/getCodes',
  // GETTING PROCESSING MONTH
  PROCESSING_MONTH: '/calculationRequestStatus/getProcessingMonth',
  // DELETE CALCULATION RUN
  DELETE_CALCULATION_RUN: '/calculationRun/deleteCalculationRun',
  // SEARCH EXISTING PAYEES
  SEARCH_EXISTING_PAYEES: '/paymentarrangement/searchPayee',
  // REVIEW CALCULATION RUN NAME
  REVIEW_CALC_RESULT_INDIVIDUAL: '/reviewCalculationResult/individual',
  // REVIEW CALCULATION RESULT COMPARE PRIOR
  REVIEW_CALC_RESULT_COMPARE_PRIOR: '/reviewCalculationResult/comparePrior',
  // CALCULATION APPROVAL STATUS
  CALC_APPROVAL_STATUS: '/calculationApproval/calculationApprovalStatus',
  // OPERATIONAL APPROVAL SUBMIT
  SUBMIT_OPERATIONAL_APPROVAL: '/calculationApproval/operationalApproval',
  // FINANCE APPROVAL SUBMIT
  SUBMIT_FINANCE_APPROVAL: '/financeRequest/calculationRequest/createFinanceRequest',
  // RETRIEVE ENTITY CORP CODE
  RETRIEVE_CORP_ENTITY_CODE: '/corporateEntity/getCorporateEntityCodes'

};
// SSO user roles STARTS

// ALL ROLES
export const ALL_ROLES = ['CALC_APPROVAL_NM', 'REPORTING_NM', 'ADMIN_ALL',
  'CALC_FINANCE_APPROVAL_NM', 'FINANCE_APPROVAL_NM',
  'INQUIRY_ALL', 'UPDATE_NM', 'UPDATE_TX',
  'CALCULATION_APPROVAL_TX'];

// PAYMENT TYPE SUCCESS ROLES
export const PAYMENTTYPE_ROLES = ['UPDATE_NM', 'CALC_APPROVAL_NM'];

// RATES SUCCESS ROLES
export const RATE_ROLES = PAYMENTTYPE_ROLES;

// PAYEES SUCCESS ROLES
export const PAYEES_ROLES = PAYMENTTYPE_ROLES;

// ARRANGEMENT SUCCESS ROLES
export const ARRANGEMENT_ROLES = PAYMENTTYPE_ROLES;

// CALCULATION RUN SUCCESS ROLES
export const CALCULATION_RUN_ROLES = ['UPDATE_NM', 'CALC_APPROVAL_NM', 'CALC_FINANCE_APPROVAL_NM'];

// CALCULATION OPERATIONAL APPROVAL SUCCESS ROLES
export const CALC_OP_APPROVAL_ROLES = ['CALC_APPROVAL_NM', 'CALC_FINANCE_APPROVAL_NM'];

// CALCULATION FINANCE APPROVAL SUCCESS ROLES
export const CALC_FIN_APPROVAL_ROLES = ['FINANCE_APPROVAL_NM', 'CALC_FINANCE_APPROVAL_NM'];

// SSO ENDS
