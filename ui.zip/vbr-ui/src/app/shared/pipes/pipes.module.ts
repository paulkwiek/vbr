import { NgModule } from '@angular/core';
import { NumberPipe } from './number.pipe';
import { SearchPipe } from './search.pipe';
import { ArraySortPipe, ArrayFilterPipe } from './array.pipe';
import { RateFilterPipe } from './rate-filter.pipe';
import { PaymentTypeFilterPipe } from './payment-type-filter.pipe';
import { DescriptionPipe } from './description-filter.pipe';
import { SafePipe } from './safe.pipe';

@NgModule({
  declarations: [
    NumberPipe,
    ArraySortPipe,
    SearchPipe,
    ArrayFilterPipe,
    RateFilterPipe,
    PaymentTypeFilterPipe,
    DescriptionPipe,
    SafePipe
  ],
  providers: [],
  exports: [
    NumberPipe,
    ArraySortPipe,
    SearchPipe,
    RateFilterPipe,
    PaymentTypeFilterPipe,
    DescriptionPipe,
    SafePipe
  ]
})
export class PipesModule {}
