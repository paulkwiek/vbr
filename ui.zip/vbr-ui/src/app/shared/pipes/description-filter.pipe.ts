import { Pipe, PipeTransform } from '@angular/core';
@Pipe({
  name: 'descriptionFilter'
})
export class DescriptionPipe implements PipeTransform {
  transform(value: any, args?: any): any {
    if (!args) {
      return value;
    }
    return value.filter(val => {
      const rVal = val.paymentTypeDescription
        .toLocaleLowerCase()
        .includes(args.toLocaleLowerCase());
      return rVal;
    });
  }
}
