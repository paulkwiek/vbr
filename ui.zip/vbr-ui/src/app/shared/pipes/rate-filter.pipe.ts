import { Pipe, PipeTransform } from '@angular/core';
@Pipe({
  name: 'rateFilter'
})
export class RateFilterPipe implements PipeTransform {
  transform(value: any, args?: any): any {
    if (!args) {
      return value;
    }
    return value.filter(val => {
      const rVal = val.rateName.toLocaleLowerCase().includes(args.toLocaleLowerCase());
      return rVal;
    });
  }
}
