import { Pipe, PipeTransform } from '@angular/core';
@Pipe({
  name: 'customSearchFilter',
  pure: false
})
export class SearchPipe implements PipeTransform {
  transform(value: any, args?: any): any {
    let rVal: any;
    if (!args || args.searchParam === undefined) {
      return value;
    }
    return value.filter(val => {
      if (args.searchKey === 'calculationRunName') {
        rVal = val.calculationRunName;
      } else {
        rVal = val.codeValueDescription;
      }
      return rVal
        .toLocaleLowerCase()
        .includes(args.searchParam.toLocaleLowerCase());
    });
  }
}
