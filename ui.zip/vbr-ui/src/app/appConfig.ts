export interface AppConfig {
    env: {
        name: string;
    };
    baseUrls: {
        BASE_URL: string;
        BASE_URL_CODE_SERVICE: string;
        BASE_URL_CALCULATION_SERVICE: string;
        BASE_URL_REPORT: string;
        SSO_BASE_URL: string;
    };
    reportUrls: {
        CAP_SUMMARY_REPORT: string;
        MEMBERSHIP_ERROR_REPORT: string;
        COMPARISON_REPORT_FOR_APPROVED_FINANCIAL_CALCULATION_DATA: string;
        COMPARISON_REPORT_FOR_PRELIMINARY_RUN_CALCULATION_DATA: string;
        COMPARISON_REPORT_FOR_APPROVED_CALCULATION_DATA: string;
        RETROACTIVITY_SUMMARY_REPORT: string;
        NM10931_CAP_DISTRIBUTION_REPORT: string;
        NM10940_PRELIMINARY_EFT_REGISTER: string;
        NM10940_FINAL_EFT_REGISTER: string;
        NM10932_FINAL_OPEN_ITEM_REGISTER: string;
    };
}
