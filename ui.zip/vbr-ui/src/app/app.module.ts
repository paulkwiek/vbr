import { BrowserModule } from '@angular/platform-browser';
import { NgModule, APP_INITIALIZER } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ConfigurationsModule } from './modules/configurations/configurations.module';
import { ReportsModule } from './modules/reports/reports.module';
import { CalculationsModule } from './modules/calculations/calculations.module';
import { PipesModule } from './shared/pipes/pipes.module';
import {
  StoreModule,
  META_REDUCERS,
  MetaReducer,
  ActionReducerMap
} from '@ngrx/store';
import { reducers } from './store/app.reducer';
import { StoreDevtoolsModule } from '@ngrx/store-devtools';
import { ROOT_STORAGE_KEYS, ROOT_LOCAL_STORAGE_KEY } from './app.tokens';
import { LocalStorageService } from './shared/services/localstorage.service';
import { storageMetaReducer } from './shared/services/storage-metareducer';
import { EffectsModule } from '@ngrx/effects';
import { NgrxRouterStoreModule } from './router/ngrx-router-module';
import { environment } from '../environments/environment';
import { storeFreeze } from 'ngrx-store-freeze';
import { AppConfigService } from './app-config.service';
import { RouterModule, Router } from '@angular/router';

// SSO Integration
import { storeLogger } from 'ngrx-store-logger';
import { ActionReducer } from '@ngrx/store';
import { HTTP_INTERCEPTORS } from '@angular/common/http';

// SSO Integration
import {
  reducers as ssoReducers,
  ApiAuthRequestInterceptor,
  AuthEffects,
  ssoMetaReducers,
  beforeSsoInit,
  // getTokenGetter,
  // SsoWrapperComponent,
  HcscLibSsoModule
} from 'hcsc-lib-sso';


export function getMetaReducers(
  saveKeys: string[],
  localStorageKey: string,
  storageService: LocalStorageService
): MetaReducer<any>[] {
  return [storageMetaReducer(saveKeys, localStorageKey, storageService)];
}



export function initializeApp(appConfigService: AppConfigService) {
  return (): Promise<any> => {
    return appConfigService.load();
  };
}

export function logger(reducer: ActionReducer<any>): any {
  return storeLogger()(reducer);
}

const metaReducers: Array<MetaReducer<any, any>> = [
  ...ssoMetaReducers(),
  logger
];

@NgModule({
  declarations: [AppComponent],
  imports: [
    BrowserModule,
    HttpClientModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    CalculationsModule,
    ConfigurationsModule,
    ReportsModule,
    PipesModule,
    StoreModule.forRoot(reducers as ActionReducerMap<{}>, { metaReducers }),
    EffectsModule.forRoot([]), //This has to commented out, Also need to revert the modification in hcsc-lib-sso
    !environment.production ? StoreDevtoolsModule.instrument() : [],
    NgrxRouterStoreModule,
    RouterModule,

    HcscLibSsoModule,
    // StoreModule.forRoot(ssoReducers), in the document
    // We need to comment below 2 lines to make Reporting workable
    StoreModule.forRoot(ssoReducers, { metaReducers }), //This has to commented out, Also need to revert the modification in hcsc-lib-sso
    EffectsModule.forRoot([AuthEffects])
  ],
  providers: [
    AppConfigService,
    {
      provide: APP_INITIALIZER,
      useFactory: initializeApp,
      multi: true,
      deps: [AppConfigService]
    },
    { provide: ROOT_STORAGE_KEYS, useValue: [] },
    { provide: ROOT_LOCAL_STORAGE_KEY, useValue: '__app_storage__' },
    {
      provide: META_REDUCERS,
      deps: [ROOT_STORAGE_KEYS, ROOT_LOCAL_STORAGE_KEY, LocalStorageService],
      useFactory: getMetaReducers
    },

    {
      provide: HTTP_INTERCEPTORS,
      useClass: ApiAuthRequestInterceptor,
      multi: true
    },
    { provide: 'env', useValue: environment }
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
