import { MediaMatcher } from '@angular/cdk/layout';
import { ChangeDetectorRef, Component, HostListener, OnDestroy, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { State, Store } from '@ngrx/store';
// SSO
import { AuthorizationUserActive } from 'hcsc-lib-sso';
import { Observable } from 'rxjs';
import { APPVERSION } from '../app-version';
import { SetActiveReport } from './actions/reports.actions';
import { Report } from './models/configuration.model';
import * as fromReducer from './reducers';
import { SharedService } from './shared/services/shared.service';
import { UserCacheService } from './shared/services/user-cache.service';
import { AppState } from './store/app.state';
import { ReportChangedAction } from './store/reports/reports.actions';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnDestroy, OnInit {
  isOpened = false;
  isMin = false;
  title = 'VBR';
  isCollapsed = false;
  addMinWidth: boolean;
  selectedReportId: Observable<string>;
  public activeReport$: Observable<Report>;
  routeSub: any;
  menu = [
    {
      title: 'Calculations & Approvals',
      items: [
        {
          title: 'Calculation Runs',
          route: '/calculations/calculationrun',
          disabled: false
        },
        {
          title: 'Review Calc Results & Approve',
          route: '/calculations/reviewingresults',
          disabled: false
        },
        { title: 'Financial Recoupment', route: '', disabled: true },
        { title: 'Manual Adjustments', route: '', disabled: true }
      ]
    },
    {
      title: 'Arrangement Configuration',
      items: [
        {
          title: 'Payment Arrangements',
          route: '/configurations/arrangements',
          disabled: false
        },
        { title: 'Payees', route: '/configurations/payees', disabled: false },
        {
          title: 'Rate Tables',
          route: '/configurations/rates',
          disabled: false
        },
        {
          title: 'Payment Types',
          route: '/configurations/paymenttypes',
          disabled: false
        }
      ]
    },
    {
      title: 'Rules Configuration',
      items: [
        {
          title: 'Retroactivity Settings',
          route: '/configurations/retroactivities',
          disabled: true
        },
        { title: 'Member Eligibility Settings', route: '', disabled: true }
      ]
    },
    {
      title: 'Reporting',
      items: [
        {
          title: 'Tableau Reports',
          route: '/reports/tableau-report',
          disabled: false
        }
      ]
    }
  ];

  mobileQuery: MediaQueryList;
  private _mobileQueryListener: () => void;
  versionNum: string;
  buildDate: string;
  corporateEntityDescription: Observable<any>;
  corporateEntityList: any;
  corporateEntityCode: any;

  constructor(
    private changeDetectorRef: ChangeDetectorRef,
    private media: MediaMatcher,
    private route: ActivatedRoute,
    private userCacheService: UserCacheService,
    private state: State<AppState>,
    private store: Store<fromReducer.State>,
    public router: Router,
    private sharedService: SharedService
  ) {
    this.setUserInfo();
    this.setRateConfigTypeName();
    this.sharedService.getCorpEntityCode().subscribe(data => this.corporateEntityCode = data);
    this.sharedService.getCorpEntityDescription().subscribe(data => this.corporateEntityDescription = data);
  }


  /* Method : setUserInfo
   * This method is used to set logged In users Info
   */
  setUserInfo() {
    this.userCacheService.setUserCacheData('USER_ID', 'U402537');
  }



  /* Method : setRateConfigTypeName
   * This method is used to set Rate Config Type Name
   */
  setRateConfigTypeName() {
    this.userCacheService.setUserCacheData('RATE_CONFIG_TYPE_NAME', 'FLATRT');
  }

  ngOnInit() {
    this.mobileQuery = this.media.matchMedia('(min-width: 600px)');
    this._mobileQueryListener = () => {
      this.isMin = false;
      this.changeDetectorRef.detectChanges();
    };
    // tslint:disable-next-line: deprecation
    this.mobileQuery.addListener(this._mobileQueryListener);
    this.activeReport$ = this.store.select(fromReducer.getActiveReport);

    this.versionNum = APPVERSION.version;
    this.buildDate = APPVERSION.buildDate;
  }

  ngOnDestroy() {
    this.routeSub.unsubscribe();
  }

  menuClick() {
    this.isMin = false;
    this.isOpened = !this.isOpened;
  }

  onMinClick() {
    this.isMin = !this.isMin;
  }

  reportToggle() {
    this.isCollapsed = !this.isCollapsed;
    if (!this.isCollapsed) {
      this.onChangeReport({ id: '', name: '', header: '' });
    }
  }

  collapseReport() {
    this.isCollapsed = false;
  }
  public reportSelected(report: Report) {
    this.store.dispatch(new SetActiveReport(report));
  }
  onChangeReport(id) {
    this.store.dispatch(new ReportChangedAction(id));
  }
  onActivate(event) {
    window.scroll(0, 0);
  }

  // SSO Integration
  @HostListener('document:click', ['$event'])
  @HostListener('document:keyup', ['$event'])
  handleUserActivity() {
    this.store.dispatch(new AuthorizationUserActive());
  }
}
