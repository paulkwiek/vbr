import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { AppConfig } from './appConfig';


@Injectable({
  providedIn: 'root'
})
export class AppConfigService {

  constructor( private httpClient: HttpClient) {

    if (window.location.href.indexOf('localhost:4200') > 0) {
      this.currentEnvironment = 'LOCAL';
      this.jsonConfig = 'assets/config/config.local.json';
    }

    if (window.location.href.indexOf('vbr-ui-dev.cfaa.hcsctest.net') > 0 || window.location.href.indexOf('vbr-uit1.test.fyiblue.com') > 0) {
      this.currentEnvironment = 'DEV';
      this.jsonConfig = 'assets/config/config.dev.json';
    }

    if (window.location.href.indexOf('vbr-ui-dev2.cfaa.hcsctest.net') > 0 || window.location.href.indexOf('vbr-uit2.test.fyiblue.com') > 0) {
      this.currentEnvironment = 'DEV2';
      this.jsonConfig = 'assets/config/config.dev2.json';
    }

    if (window.location.href.indexOf('vbr-ui-dev3.cfaa.hcsctest.net') > 0 || window.location.href.indexOf('vbr-uit3.test.fyiblue.com') > 0) {
      this.currentEnvironment = 'DEV3';
      this.jsonConfig = 'assets/config/config.dev3.json';
    }

    if (window.location.href.indexOf('vbr-ui-test.cfaa.hcsctest.net') > 0 || window.location.href.indexOf('vbr-sit.test.fyiblue.com') > 0) {
      this.currentEnvironment = 'TEST';
      this.jsonConfig = 'assets/config/config.test.json';
    }

    if (window.location.href.indexOf('vbr-ui-lnp.cfaa.hcsctest.net') > 0 || window.location.href.indexOf('vbr-lnp.test.fyiblue.com') > 0) {
      this.currentEnvironment = 'LNP';
      this.jsonConfig = 'assets/config/config.lnp.json';
    }

    if (window.location.href.indexOf('vbr-ui-uat.cfaa.hcsctest.net') > 0 || window.location.href.indexOf('vbr-uat.test.fyiblue.com') > 0) {
      this.currentEnvironment = 'UAT';
      this.jsonConfig = 'assets/config/config.uat.json';
    }

    if (window.location.href.indexOf('vbr-ui-poc.cfaa.hcsctest.net') > 0) {
      this.currentEnvironment = 'POC';
      this.jsonConfig = 'assets/config/config.poc.json';
    }

    // SSO testing

    if (window.location.href.indexOf('vbr.fyiblue.com') > 0) {
      this.currentEnvironment = 'PROD';
      this.jsonConfig = 'assets/config/config.prod.json';
    }

   }
  static settings: AppConfig;
  currentEnvironment: string;
  jsonConfig: string;

   load() {
     return new Promise<void>((resolve, reject) => {
      this.httpClient.get((this.jsonConfig)).toPromise().then((response: AppConfig) => {
        AppConfigService.settings = <AppConfig>response;
        resolve();
      }).catch((response: any) => {
        reject('Could not load the config file');
      });
     });
   }
}
