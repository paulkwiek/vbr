import * as fromActions from '../actions/reports.actions';
import { Report } from '../models/configuration.model';

export interface State {
  report: Report;
}

const initialState: State = {
  report: {
    id: 0,
    name: 'NM10931 - Cap Distribution Report (HMO)',
    header: 'NM10931 - Cap Distribution Report'
  }
};

export function reducer(
  state = initialState,
  action: fromActions.AppActions
): State {
  switch (action.type) {
    case fromActions.AppActionTypes.SetReport:
      return { ...state, report: action.payload };
    default:
      return state;
  }
}
