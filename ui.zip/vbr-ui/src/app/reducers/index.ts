import { ActionReducerMap, createSelector, MetaReducer } from '@ngrx/store';
import { Tab } from '../models/calculation.model';
import { Report } from '../models/configuration.model';
import { environment } from '../../environments/environment';
import * as fromTabs from './tabs.reducer';
import * as fromReports from './reports.reducer';

export interface State {
  tabState: fromTabs.State;
  reportState: fromReports.State;
}

export const reducers: ActionReducerMap<State> = {
  tabState: fromTabs.reducer,
  reportState: fromReports.reducer
};

export const getTabState = (state: State) => state.tabState;
export const getReportState = (state: State) => state.reportState;

export const metaReducers: MetaReducer<State>[] = !environment.production
  ? []
  : [];
export const getActiveTab = createSelector(
  getTabState,
  (state): Tab => state.tab
);
export const getActiveReport = createSelector(
  getReportState,
  (state): Report => state.report
);
