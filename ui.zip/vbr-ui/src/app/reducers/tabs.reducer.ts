import * as fromActions from '../actions/tabs.actions';
import { Tab } from '../models/calculation.model';

export interface State {
  tab: Tab;
}

const initialState: State = {
  tab: {
    id: 'nm-preliminary-1',
    aria: 'nm-preliminary-1',
    name: 'NW-Preliminary-1',
    type: 'Preliminary',
    list: [
      {
        type: 'Line Of Business',
        name: 'Medicare Advantage - Daily'
      },
      { type: 'Payment Types', name: 'HME 2' }
    ],
    date_modified: ''
  }
};

export function reducer(
  state = initialState,
  action: fromActions.AppActions
): State {
  switch (action.type) {
    case fromActions.AppActionTypes.SetTab:
      return { ...state, tab: action.payload };
    default:
      return state;
  }
}
