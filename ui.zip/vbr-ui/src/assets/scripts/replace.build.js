var replace = require('replace-in-file');
var package = require("./../../../package.json");
var versionNum = package.version;
var buildDate = new Date();
const versionInfo = {
  files: 'src/app-version.ts',
  from: /version: '(.*)'/g,
  to: "version: '"+ versionNum + "'",
  allowEmptyPaths: false,
};

const buildInfo = {
    files: 'src/app-version.ts',
    from: /buildDate: '(.*)'/g,
    to: "buildDate: '"+ buildDate + "'",
    allowEmptyPaths: false,
  };

try {
  replace.sync(versionInfo);
  replace.sync(buildInfo);
  console.log('Build version set: ' + versionNum);
  console.log('Build Date set: ' + buildDate);
}
catch (error) {
  console.error('Error occurred:', error);
}