import { ReviewStatus, CalculationRunNames } from 'src/app/models/calculation.model';



export const calculationStatusCard: ReviewStatus = {
    calculationRunName: "RUN1",
    calculationRequestId:1,
    approvedBy: null,
    requestedTime: "2019-09-20T14:48:01",
    calculationRequestStatusCode: "CASU",
    calculationRequestStatusDescription: "Calculation Approval Submitted",
    processingTimeInMinutes: 1440,
    errorsOccuredDuringRun: [ "INVALID ARRANGEMENT PAYEE", "INVALID ARRANGEMENT RATE"],
   
}
export const mockCalculationRunNamesList: CalculationRunNames = {
    calculationRunName: [
        {
            createUserId: 'U402537',
            updateUserId: 'U402537',
            createRecordTimestamp: '2019-10-07T07:22:03.221',
            updateRecordTimestamp: '2019-10-07T07:22:03.221',
            rowAction: 'NO_ACTION',
            calculationRunName: '2378428647823642364',
            corporateEntityCode: 'NM1',
            runTypeCode: 'Approval',
            runNameStatusCode: '',
            calculationRequests: [],
            calculationGroupings: []
        }
    ]
}



