For BA build:
Files updated:
pom.xml    (Locally update by removing /ui in line no 54 - DONOT CHECKIN THIS CHANGE)
manifest-ba.yml

Maven build:
mvn clean package -Plocal

PCF push:
cf push -f manifest-ba.yml -p target/vbr-ui-0.0.1-SNAPSHOT.jar



For DEV and Test build:
Files updated: 
pom.xml
manifest-poc.xml

Maven build:
mvn clean package -Ppoc

PCF push:
cf push -f manifest-poc.yml -p target/vbr-ui-0.0.1-SNAPSHOT.jar